import React from 'react'
import { Table } from "react-bootstrap";
function HomeBeyondPlus() {
  return (
    <div>
      <Table striped bordered hover size="sm">
        <thead>
          <tr>
            <th style={{ width: "200px" }}>L12m Active</th>
            <th>Customers</th>
            <th>Transactions</th>
            <th>Net Sales</th>
            <th>AUR</th>
            <th>UPT</th>
            <th>AOV</th>
            <th>Product Margin</th>
          </tr>
        </thead>
        <tbody>
          <tr>
            <td className="tableCol" id={"AtRisk_69"}>
              {"At risk (6m-9m)"}
            </td>
            <td>
              {"136K"}
              <br />
              <span style={{ color: "green" }}>{"LY +23%"}</span>
              <br />
              <span style={{ color: "red" }}>{"LLY -3%"}</span>
            </td>
            <td>
              {"136K"}
              <br />
              <span style={{ color: "green" }}>{"LY +23%"}</span>
              <br />
              <span style={{ color: "red" }}>{"LLY -3%"}</span>
            </td>
            <td>
              {"136K"}
              <br />
              <span style={{ color: "green" }}>{"LY +23%"}</span>
              <br />
              <span style={{ color: "red" }}>{"LLY -3%"}</span>
            </td>
            <td>
              {"136K"}
              <br />
              <span style={{ color: "green" }}>{"LY +23%"}</span>
              <br />
              <span style={{ color: "red" }}>{"LLY -3%"}</span>
            </td>
            <td>
              {"136K"}
              <br />
              <span style={{ color: "green" }}>{"LY +23%"}</span>
              <br />
              <span style={{ color: "red" }}>{"LLY -3%"}</span>
            </td>
            <td>
              {"136K"}
              <br />
              <span style={{ color: "green" }}>{"LY +23%"}</span>
              <br />
              <span style={{ color: "red" }}>{"LLY -3%"}</span>
            </td>
            <td>
              {"136K"}
              <br />
              <span style={{ color: "green" }}>{"LY +23%"}</span>
              <br />
              <span style={{ color: "red" }}>{"LLY -3%"}</span>
            </td>
          </tr>
          <tr>
            <td className="tableCol" id={"AtRisk_9_12"}>
              {"At risk (9m-12m)"}
            </td>
            <td>
              {"136K"}
              <br />
              <span style={{ color: "green" }}>{"LY +23%"}</span>
              <br />
              <span style={{ color: "red" }}>{"LLY -3%"}</span>
            </td>
            <td>
              {"136K"}
              <br />
              <span style={{ color: "green" }}>{"LY +23%"}</span>
              <br />
              <span style={{ color: "red" }}>{"LLY -3%"}</span>
            </td>
            <td>
              {"136K"}
              <br />
              <span style={{ color: "green" }}>{"LY +23%"}</span>
              <br />
              <span style={{ color: "red" }}>{"LLY -3%"}</span>
            </td>
            <td>
              {"136K"}
              <br />
              <span style={{ color: "green" }}>{"LY +23%"}</span>
              <br />
              <span style={{ color: "green" }}>{"LLY +3%"}</span>
            </td>
            <td>
              {"136K"}
              <br />
              <span style={{ color: "green" }}>{"LY +23%"}</span>
              <br />
              <span style={{ color: "green" }}>{"LLY +3%"}</span>
            </td>
            <td>
              {"136K"}
              <br />
              <span style={{ color: "green" }}>{"LY +23%"}</span>
              <br />
              <span style={{ color: "green" }}>{"LLY +3%"}</span>
            </td>
            <td>
              {"136K"}
              <br />
              <span style={{ color: "green" }}>{"LY +23%"}</span>
              <br />
              <span style={{ color: "green" }}>{"LLY +3%"}</span>
            </td>
          </tr>
          <tr>
            <td className="tableCol">{"Active (Existing)"}</td>
            <td>
              {"136K"}
              <br />
              <span style={{ color: "green" }}>{"LY +23%"}</span>
              <br />
              <span style={{ color: "red" }}>{"LLY -3%"}</span>
            </td>
            <td>
              {"136K"}
              <br />
              <span style={{ color: "green" }}>{"LY +23%"}</span>
              <br />
              <span style={{ color: "red" }}>{"LLY -3%"}</span>
            </td>
            <td>
              {"136K"}
              <br />
              <span style={{ color: "green" }}>{"LY +23%"}</span>
              <br />
              <span style={{ color: "red" }}>{"LLY -3%"}</span>
            </td>
            <td>
              {"136K"}
              <br />
              <span style={{ color: "red" }}>{"LY -23%"}</span>
              <br />
              <span style={{ color: "green" }}>{"LLY +3%"}</span>
            </td>
            <td>
              {"136K"}
              <br />
              <span style={{ color: "red" }}>{"LY -23%"}</span>
              <br />
              <span style={{ color: "green" }}>{"LLY +3%"}</span>
            </td>
            <td>
              {"136K"}
              <br />
              <span style={{ color: "red" }}>{"LY -23%"}</span>
              <br />
              <span style={{ color: "green" }}>{"LLY +3%"}</span>
            </td>
            <td>
              {"136K"}
              <br />
              <span style={{ color: "red" }}>{"LY -23%"}</span>
              <br />
              <span style={{ color: "green" }}>{"LLY +3%"}</span>
            </td>
          </tr>
          <tr>
            <td className="tableCol">{"Active (New L12m)"}</td>
            <td>
              {"136K"}
              <br />
              <span style={{ color: "green" }}>{"LY +23%"}</span>
              <br />
              <span style={{ color: "red" }}>{"LLY -3%"}</span>
            </td>
            <td>
              {"136K"}
              <br />
              <span style={{ color: "green" }}>{"LY +23%"}</span>
              <br />
              <span style={{ color: "red" }}>{"LLY -3%"}</span>
            </td>
            <td>
              {"136K"}
              <br />
              <span style={{ color: "green" }}>{"LY +23%"}</span>
              <br />
              <span style={{ color: "green" }}>{"LLY +3%"}</span>
            </td>
            <td>
              {"136K"}
              <br />
              <span style={{ color: "green" }}>{"LY +23%"}</span>
              <br />
              <span style={{ color: "green" }}>{"LLY +3%"}</span>
            </td>
            <td>
              {"136K"}
              <br />
              <span style={{ color: "green" }}>{"LY +23%"}</span>
              <br />
              <span style={{ color: "green" }}>{"LLY +3%"}</span>
            </td>
            <td>
              {"136K"}
              <br />
              <span style={{ color: "green" }}>{"LY +23%"}</span>
              <br />
              <span style={{ color: "red" }}>{"LLY -3%"}</span>
            </td>
            <td>
              {"136K"}
              <br />
              <span style={{ color: "green" }}>{"LY +23%"}</span>
              <br />
              <span style={{ color: "red" }}>{"LLY -3%"}</span>
            </td>
          </tr>
          <tr>
            <td className="tableCol">{"Inactive (13m-18m)"}</td>
            <td>
              {"136K"}
              <br />
              <span style={{ color: "green" }}>{"LY +23%"}</span>
              <br />
              <span style={{ color: "green" }}>{"LLY +3%"}</span>
            </td>
            <td>
              {"136K"}
              <br />
              <span style={{ color: "green" }}>{"LY +23%"}</span>
              <br />
              <span style={{ color: "green" }}>{"LLY +3%"}</span>
            </td>
            <td>
              {"136K"}
              <br />
              <span style={{ color: "green" }}>{"LY +23%"}</span>
              <br />
              <span style={{ color: "red" }}>{"LLY -3%"}</span>
            </td>
            <td>
              {"136K"}
              <br />
              <span style={{ color: "green" }}>{"LY +23%"}</span>
              <br />
              <span style={{ color: "red" }}>{"LLY -3%"}</span>
            </td>
            <td>
              {"136K"}
              <br />
              <span style={{ color: "green" }}>{"LY +23%"}</span>
              <br />
              <span style={{ color: "red" }}>{"LLY -3%"}</span>
            </td>
            <td>
              {"136K"}
              <br />
              <span style={{ color: "green" }}>{"LY +23%"}</span>
              <br />
              <span style={{ color: "red" }}>{"LLY -3%"}</span>
            </td>
            <td>
              {"136K"}
              <br />
              <span style={{ color: "green" }}>{"LY +23%"}</span>
              <br />
              <span style={{ color: "red" }}>{"LLY -3%"}</span>
            </td>
          </tr>
          <tr>
            <td className="tableCol">{"Inactive (18m-24m)"}</td>
            <td>
              {"136K"}
              <br />
              <span style={{ color: "green" }}>{"LY +23%"}</span>
              <br />
              <span style={{ color: "red" }}>{"LLY -3%"}</span>
            </td>
            <td>
              {"136K"}
              <br />
              <span style={{ color: "green" }}>{"LY +23%"}</span>
              <br />
              <span style={{ color: "red" }}>{"LLY -3%"}</span>
            </td>
            <td>
              {"136K"}
              <br />
              <span style={{ color: "green" }}>{"LY +23%"}</span>
              <br />
              <span style={{ color: "red" }}>{"LLY -3%"}</span>
            </td>
            <td>
              {"136K"}
              <br />
              <span style={{ color: "green" }}>{"LY +23%"}</span>
              <br />
              <span style={{ color: "red" }}>{"LLY -3%"}</span>
            </td>
            <td>
              {"136K"}
              <br />
              <span style={{ color: "green" }}>{"LY +23%"}</span>
              <br />
              <span style={{ color: "red" }}>{"LLY -3%"}</span>
            </td>
            <td>
              {"136K"}
              <br />
              <span style={{ color: "green" }}>{"LY +23%"}</span>
              <br />
              <span style={{ color: "red" }}>{"LLY -3%"}</span>
            </td>
            <td>
              {"136K"}
              <br />
              <span style={{ color: "green" }}>{"LY +23%"}</span>
              <br />
              <span style={{ color: "red" }}>{"LLY -3%"}</span>
            </td>
          </tr>
        </tbody>
      </Table>
    </div>
  );
}

export default HomeBeyondPlus
