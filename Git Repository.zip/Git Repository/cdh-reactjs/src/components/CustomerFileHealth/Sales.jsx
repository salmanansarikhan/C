import { React, useState } from "react";
import { useSelector } from "react-redux";
import "../CustomerFileHealth/CustomerFile.css";
import { Table } from "react-bootstrap";
import LoaderForRow from "../LoaderForTable/LoaderForRow";
import { gettooltip, getDateFormatFromDB } from "../Utils";
export const currencyFormat = (value) => {
  return parseFloat(value)
    .toFixed(0)
    .replace(/(\d)(?=(\d{3})+(?!\d))/g, "$1,");
};
export const decimalCurrencyFormat = (value) => {
  return parseFloat(value)
    .toFixed(2)
    .replace(/(\d)(?=(\d{3})+(?!\d))/g, "$1,");
};

function Sales({
  loading,
  makeTransactions,
  makeOnlineOnly,
  makeStoresOnly,
  makeStoresAndOnlineOnly,
}) {
  return (
    <div>
      <div className="p-3" style={{ marginBottom: "50px" }}>
        <Table style={{ textAlign: "center" }} striped bordered hover size="sm">
          <thead className="text">
            <tr>
              <th></th>
            </tr>
          </thead>
          <tbody>
            <tr style={{ fontWeight: "500" }}>
              <td style={{ backgroundColor: "lightgrey", width: "40rem" }}>
                How many total customers Make Transactions
              </td>
              {loading.make_transactions ? (
                <>
                  <LoaderForRow tdCount={1} />
                </>
              ) : (
                <td>
                  {makeTransactions &&
                  makeTransactions !== undefined &&
                  makeTransactions.length !== 0 &&
                  makeTransactions[0].CUST_CNT !== "-999999"
                    ? currencyFormat(Number(makeTransactions[0].CUST_CNT))
                    : "-"}
                </td>
              )}
            </tr>
            <tr>
              <td>Customers transacted online only</td>
              {loading.online_only ? (
                <>
                  <LoaderForRow tdCount={1} />
                </>
              ) : (
                <td>
                  {makeOnlineOnly &&
                  makeOnlineOnly !== undefined &&
                  makeOnlineOnly.length !== 0 &&
                  makeOnlineOnly[0].CUST_CNT !== "-999999"
                    ? currencyFormat(Number(makeOnlineOnly[0].CUST_CNT))
                    : "-"}
                </td>
              )}
            </tr>
            <tr>
              <td>Customers transacted in stores only</td>
              {loading.stores_only ? (
                <>
                  <LoaderForRow tdCount={1} />
                </>
              ) : (
                <td>
                  {makeStoresOnly &&
                  makeStoresOnly !== undefined &&
                  makeStoresOnly.length !== 0 &&
                  makeStoresOnly[0].CUST_CNT !== "-999999"
                    ? currencyFormat(Number(makeStoresOnly[0].CUST_CNT))
                    : "-"}
                </td>
              )}
            </tr>
            <tr>
              <td>Customers transacted stores and online both</td>
              {loading.stores_and_online ? (
                <>
                  <LoaderForRow tdCount={1} />
                </>
              ) : (
                <td>
                  {makeStoresAndOnlineOnly &&
                  makeStoresAndOnlineOnly !== undefined &&
                  makeStoresAndOnlineOnly.length !== 0 &&
                  makeStoresAndOnlineOnly[0].CUST_CNT !== "-999999"
                    ? currencyFormat(
                        Number(makeStoresAndOnlineOnly[0].CUST_CNT)
                      )
                    : "-"}
                </td>
              )}
            </tr>
          </tbody>
        </Table>
      </div>
    </div>
  );
}

export default Sales;
