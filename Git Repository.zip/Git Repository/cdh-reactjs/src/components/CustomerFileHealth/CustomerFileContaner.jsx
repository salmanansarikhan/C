import React, { useState, useEffect, useCallback } from "react";
import { useSelector, useDispatch } from "react-redux";
import { useHistory } from "react-router-dom";
import {
  Dropdown,
  Form,
  Placeholder,
  PlaceholderButton,
  Button,
} from "react-bootstrap";
import axios from "axios";
import NoAccess from "../NoAccess/NoAccess";
import NotificationMessage from "../NotificationMessage/NotificationMessage";
import "../CustomerFileHealth/CustomerFile.css";
import Growth from "./Growth";
import Sales from "./Sales";
import Engagement from "./Engagement";
import { handleCustomerFileBannerChange } from "../../Redux/Actions/BannerChangeActions";
import { handleCustomerFilePeriodChange } from "../../Redux/Actions/CustomerFilePeriodChangeActions";
import { getDateFormatFromDB, UTCtoEST, DateCompare } from "../Utils";
import DatePicker from "react-datetime";
import moment from "moment";
import calender from "../../assests/images/calender.svg";

function CustomerFileContainer() {
  const CustomerFilePeriods = [
    { value: "Yesterday", id: "0" },
    { value: "WTD", id: "1" },
    { value: "MTD", id: "2" },
    { value: "QTD", id: "3" },
    { value: "YTD", id: "4" },
    { value: "Date Range", id: "5" },
  ];

  const dispatch = useDispatch();

  const disableCustomDt = (current) => {
    return current.isBefore(moment().subtract(1, "days"));
  };

  const CustomerFileBanners = [
    { value: "All Banner", id: "0,1,2,3,5" },
    { value: "BBBY US", id: "1" },
    { value: "BBBY CA", id: "2" },
    { value: "buy buy Baby", id: "3" },
    { value: "Harmon", id: "5" },
  ];

  const [loading, setLoader] = useState({
    customerFilePeriod: false,
    tot_customers: false,
    new_to_file: false,
    able_to_contact: false,
    contact_info: false,
    make_transactions: false,
    online_only: false,
    stores_only: false,
    stores_and_online: false,
    customers_engaged: false,
    customers_transacted: false,
    mobile_app: false,
    loyalty: false,
    registry: false,
    csp: false,
    refreshTime: false,
  });

  const [tabView, setTabview] = useState({
    growthView: true,
    salesView: false,
    enagagementView: false,
  });

  const [refreshTime, setRefreshTime] = useState("");
  const [submitActive, setSubmitActive] = useState(false);
  const [allStorePeriods, setAllStorePeriods] = useState([]);
  const [correctDateRange, setCorrectDateRange] = useState(false);
  const [periodStartDateTY, setPeriodStartDateTY] = useState("");
  const [periodEndDateTY, setPeriodEndDateTY] = useState("");
  const [selectedCustomerFileBanner, setSelectedCustomerFileBanner] = useState(
    CustomerFileBanners[0]
  );
  const [selectedDateCorrect, isSelectedDateCorrect] = useState(false);
  /// tab 1
  const [totalCustomers, setTotalCustomers] = useState();
  const [newToFileCustomers, setNewToFileCustomers] = useState();
  const [ableToContactCustomers, setAbleToContactCustomers] = useState();
  const [contactInfoCustomers, setContactInfo] = useState();
  /// tab 2
  const [makeTransactions, setMakeTransactions] = useState();
  const [makeOnlineOnly, setOnlineOnly] = useState();
  const [makeStoresOnly, setStoresOnly] = useState();
  const [makeStoresAndOnlineOnly, setStoresAndOnlineOnly] = useState();
  /// tab 3
  const [makeCustomersEngaged, setCustomersEngaged] = useState();
  const [makeCustomersTransacted, setCustomersTransacted] = useState();
  const [mobileApp, setMobileApp] = useState();
  const [loyaltys, setLoyaltys] = useState();
  const [registrys, setRegistrys] = useState();
  const [csps, setCsps] = useState();

  const refreshDate =
    refreshTime.length > 0 && UTCtoEST(refreshTime[0].end_time * 1000);

  const selectedCustomerFileBannerId = useSelector(
    (store) => store.CustomerFileBanner.id
  );

  const selectedCustomerFilePeriodValue = useSelector(
    (store) => store.CustomerFilePeriod.value
  );
  const selectedCustomerFilePeriodId = useSelector(
    (store) => store.CustomerFilePeriod.id
  );

  const buttonClick = (tab) => {
    if (tab === "1") {
      setTabview(() => ({
        growthView: true,
        salesView: false,
        enagagementView: false,
      }));
    } else if (tab === "2") {
      setTabview(() => ({
        growthView: false,
        salesView: true,
        enagagementView: false,
      }));
    } else if (tab === "3") {
      setTabview(() => ({
        growthView: false,
        salesView: false,
        enagagementView: true,
      }));
    }
  };

  const handleCustomerFileBanner = useCallback(
    (event) => {
      setSelectedCustomerFileBanner((prevsValue) => ({
        ...prevsValue,
        value: event.target.innerText,
        id: event.target.id,
      }));
      dispatch(
        handleCustomerFileBannerChange({
          value: event.target.innerText,
          id: event.target.id,
        })
      );
      setCorrectDateRange(true);
    },
    [selectedCustomerFileBannerId]
  );

  const handleCustomerFilePeriod = useCallback(
    (event) => {
      dispatch(
        handleCustomerFilePeriodChange({
          value: event.target.innerText,
          id: event.target.id,
        })
      );
      if (event.target.innerText === "Date Range") {
        setPeriodStartDateTY("");
        setPeriodEndDateTY("");
        setTotalCustomers();
        setNewToFileCustomers();
        setAbleToContactCustomers();
        setContactInfo();
        setMakeTransactions();
        setOnlineOnly();
        setStoresOnly();
        setStoresAndOnlineOnly();
        setCustomersEngaged();
        setCustomersTransacted();
        setMobileApp();
        setLoyaltys();
        setRegistrys();
        setCsps();
      } else {
        setCorrectDateRange(false);
        setSubmitActive(false);
      }
    },
    [selectedCustomerFilePeriodId]
  );

  const handleStartDate = (dateSelected) => {
    if (moment(dateSelected, "MM/DD/YYYY", true).isValid()) {
      setPeriodStartDateTY(dateSelected.format("YYYY-MM-DD"));
      periodEndDateTY !== "" && setSubmitActive(true);
    }
    setCorrectDateRange(false);
    // setLoader((currValue) => ({
    //   ...currValue,
    //   feedbackData: false,
    // }));
  };

  const handleEndDate = (dateSelected) => {
    if (moment(dateSelected, "MM/DD/YYYY", true).isValid()) {
      setPeriodEndDateTY(dateSelected.format("YYYY-MM-DD"));
      periodStartDateTY !== "" && setSubmitActive(true);
    }
    setCorrectDateRange(false);
    // setLoader((currValue) => ({
    //   ...currValue,
    //   feedbackData: false,
    // }));
  };

  const handleSubmit = () => {
    if (DateCompare(periodStartDateTY, periodEndDateTY) > 0) {
      alert("Start date cannot be greater than end date");
      isSelectedDateCorrect(false);
      setCorrectDateRange(false);
    } else {
      setSubmitActive(false);
      isSelectedDateCorrect(true);
      setCorrectDateRange(true);
    }
  };

  useEffect(() => {
    const getLastRefreshTime = async () => {
      try {
        setLoader((currValue) => ({
          ...currValue,
          refreshTime: true,
        }));
        let url =
          process.env.REACT_APP_API_ENDPOINT +
          process.env.REACT_APP_REFRESH_TIME +
          "dagId=CUSTOMER_FILE_HEALTH";
        await axios({ url }).then((res) => {
          setLoader((currValue) => ({
            ...currValue,
            refreshTime: false,
          }));
          setRefreshTime(res.data);
        });
      } catch (err) {
        setLoader((currValue) => ({
          ...currValue,
          refreshTime: true,
        }));
        console.log("err-getLastRefreshTime", err);
      }
    };
    const getCustomerFilePeriods = async () => {
      try {
        setLoader((currValue) => ({
          ...currValue,
          customerFilePeriod: true,
        }));
        let url =
          process.env.REACT_APP_API_ENDPOINT +
          process.env.REACT_APP_FEEDBACK_DATE_FILTER;
        await axios({ url }).then((res) => {
          setLoader((currValue) => ({
            ...currValue,
            customerFilePeriod: false,
          }));
          setAllStorePeriods(res.data);
          if (
            selectedCustomerFilePeriodId === "0" &&
            allStorePeriods[0] !== undefined &&
            allStorePeriods[0] !== null
          ) {
            setPeriodStartDateTY(allStorePeriods[0].TY_YESTERDAY);
            setPeriodEndDateTY(allStorePeriods[0].TY_YESTERDAY);
            // setPeriodStartDateTY_FB(allStorePeriods[0].TY_YESTERDAY_FB);
            // setPeriodEndDateTY_FB(allStorePeriods[0].TY_YESTERDAY_FB);
            // setPeriodStartDateLY(allStorePeriods[0].LY_YESTERDAY);
            // setPeriodEndDateLY(allStorePeriods[0].LY_YESTERDAY);
            setCorrectDateRange(true);
          }
        });
      } catch (err) {
        setLoader((currValue) => ({
          ...currValue,
          customerFilePeriod: true,
        }));
        console.log("err-getCustomerFilePeriods", err);
      }
    };
    getLastRefreshTime();
    getCustomerFilePeriods();
  }, []);

  useEffect(() => {
    const fetchTotalCustomers = async () => {
      try {
        setLoader((currValue) => ({
          ...currValue,
          tot_customers: true,
        }));
        let url =
          process.env.REACT_APP_API_ENDPOINT +
          process.env.REACT_APP_CUSTOMER_FILE_HEALTH +
          "concept=" +
          selectedCustomerFileBannerId +
          "&startDate=" +
          periodStartDateTY +
          "&endDate=" +
          periodEndDateTY +
          "&metric=" +
          "G_TC";
        if (
          correctDateRange &&
          periodStartDateTY !== "" &&
          periodEndDateTY !== ""
        ) {
          setSubmitActive(false);
          await axios({ url }).then((res) => {
            setLoader((currValue) => ({
              ...currValue,
              tot_customers: false,
            }));
            setTotalCustomers(res.data);
            setCorrectDateRange(false);
            isSelectedDateCorrect(false);
          });
        } else {
          setLoader((currValue) => ({
            ...currValue,
            tot_customers: false,
          }));
        }
      } catch (err) {
        setLoader((currValue) => ({
          ...currValue,
          tot_customers: true,
        }));
        console.log("err-fetchTotalCustomers", err);
      }
    };
    const fetchNewToFileCustomers = async () => {
      try {
        setLoader((currValue) => ({
          ...currValue,
          new_to_file: true,
        }));
        let url =
          process.env.REACT_APP_API_ENDPOINT +
          process.env.REACT_APP_CUSTOMER_FILE_HEALTH +
          "concept=" +
          selectedCustomerFileBannerId +
          "&startDate=" +
          periodStartDateTY +
          "&endDate=" +
          periodEndDateTY +
          "&metric=" +
          "G_NEW_FILE";
        if (
          correctDateRange &&
          periodStartDateTY !== "" &&
          periodEndDateTY !== ""
        ) {
          setSubmitActive(false);
          await axios({ url }).then((res) => {
            setLoader((currValue) => ({
              ...currValue,
              new_to_file: false,
            }));
            setNewToFileCustomers(res.data);
            setCorrectDateRange(false);
            isSelectedDateCorrect(false);
          });
        } else {
          setLoader((currValue) => ({
            ...currValue,
            tot_customers: false,
          }));
        }
      } catch (err) {
        setLoader((currValue) => ({
          ...currValue,
          new_to_file: true,
        }));
        console.log("err-fetchNewToFileCustomers", err);
      }
    };
    const fetchAbleToContact = async () => {
      try {
        setLoader((currValue) => ({
          ...currValue,
          able_to_contact: true,
        }));
        let url =
          process.env.REACT_APP_API_ENDPOINT +
          process.env.REACT_APP_CUSTOMER_FILE_HEALTH +
          "concept=" +
          selectedCustomerFileBannerId +
          "&startDate=" +
          periodStartDateTY +
          "&endDate=" +
          periodEndDateTY +
          "&metric=" +
          "G_CUST_CONTACT";
        if (
          correctDateRange &&
          periodStartDateTY !== "" &&
          periodEndDateTY !== ""
        ) {
          setSubmitActive(false);
          await axios({ url }).then((res) => {
            setLoader((currValue) => ({
              ...currValue,
              able_to_contact: false,
            }));
            setAbleToContactCustomers(res.data);
            setCorrectDateRange(false);
            isSelectedDateCorrect(false);
          });
        } else {
          setLoader((currValue) => ({
            ...currValue,
            tot_customers: false,
          }));
        }
      } catch (err) {
        setLoader((currValue) => ({
          ...currValue,
          able_to_contact: true,
        }));
        console.log("err-fetchAbleToContact", err);
      }
    };
    const fetchContactInfo = async () => {
      try {
        setLoader((currValue) => ({
          ...currValue,
          contact_info: true,
        }));
        let url =
          process.env.REACT_APP_API_ENDPOINT +
          process.env.REACT_APP_CUSTOMER_FILE_HEALTH +
          "concept=" +
          selectedCustomerFileBannerId +
          "&startDate=" +
          periodStartDateTY +
          "&endDate=" +
          periodEndDateTY +
          "&metric=" +
          "G_E_PH";
        if (
          correctDateRange &&
          periodStartDateTY !== "" &&
          periodEndDateTY !== ""
        ) {
          setSubmitActive(false);
          await axios({ url }).then((res) => {
            setLoader((currValue) => ({
              ...currValue,
              contact_info: false,
            }));
            setContactInfo(res.data);
            setCorrectDateRange(false);
            isSelectedDateCorrect(false);
          });
        } else {
          setLoader((currValue) => ({
            ...currValue,
            tot_customers: false,
          }));
        }
      } catch (err) {
        setLoader((currValue) => ({
          ...currValue,
          contact_info: true,
        }));
        console.log("err-fetchContactInfo", err);
      }
    };
    const fetchMakeTransaction = async () => {
      try {
        setLoader((currValue) => ({
          ...currValue,
          make_transactions: true,
        }));
        let url =
          process.env.REACT_APP_API_ENDPOINT +
          process.env.REACT_APP_CUSTOMER_FILE_HEALTH +
          "concept=" +
          selectedCustomerFileBannerId +
          "&startDate=" +
          periodStartDateTY +
          "&endDate=" +
          periodEndDateTY +
          "&metric=" +
          "S_TCT";
        if (
          correctDateRange &&
          periodStartDateTY !== "" &&
          periodEndDateTY !== ""
        ) {
          setSubmitActive(false);
          await axios({ url }).then((res) => {
            setLoader((currValue) => ({
              ...currValue,
              make_transactions: false,
            }));
            setMakeTransactions(res.data);
            setCorrectDateRange(false);
            isSelectedDateCorrect(false);
          });
        } else {
          setLoader((currValue) => ({
            ...currValue,
            tot_customers: false,
          }));
        }
      } catch (err) {
        setLoader((currValue) => ({
          ...currValue,
          make_transactions: true,
        }));
        console.log("err-fetchMakeTransaction", err);
      }
    };
    const fetchOnlineOnly = async () => {
      try {
        setLoader((currValue) => ({
          ...currValue,
          online_only: true,
        }));
        let url =
          process.env.REACT_APP_API_ENDPOINT +
          process.env.REACT_APP_CUSTOMER_FILE_HEALTH +
          "concept=" +
          selectedCustomerFileBannerId +
          "&startDate=" +
          periodStartDateTY +
          "&endDate=" +
          periodEndDateTY +
          "&metric=" +
          "S_ONLINE";
        if (
          correctDateRange &&
          periodStartDateTY !== "" &&
          periodEndDateTY !== ""
        ) {
          setSubmitActive(false);
          await axios({ url }).then((res) => {
            setLoader((currValue) => ({
              ...currValue,
              online_only: false,
            }));
            setOnlineOnly(res.data);
            setCorrectDateRange(false);
            isSelectedDateCorrect(false);
          });
        } else {
          setLoader((currValue) => ({
            ...currValue,
            tot_customers: false,
          }));
        }
      } catch (err) {
        setLoader((currValue) => ({
          ...currValue,
          online_only: true,
        }));
        console.log("err-fetchOnlineOnly", err);
      }
    };
    const fetchStoreOnly = async () => {
      try {
        setLoader((currValue) => ({
          ...currValue,
          stores_only: true,
        }));
        let url =
          process.env.REACT_APP_API_ENDPOINT +
          process.env.REACT_APP_CUSTOMER_FILE_HEALTH +
          "concept=" +
          selectedCustomerFileBannerId +
          "&startDate=" +
          periodStartDateTY +
          "&endDate=" +
          periodEndDateTY +
          "&metric=" +
          "S_STORE";
        if (
          correctDateRange &&
          periodStartDateTY !== "" &&
          periodEndDateTY !== ""
        ) {
          setSubmitActive(false);
          await axios({ url }).then((res) => {
            setLoader((currValue) => ({
              ...currValue,
              stores_only: false,
            }));
            setStoresOnly(res.data);
            setCorrectDateRange(false);
            isSelectedDateCorrect(false);
          });
        } else {
          setLoader((currValue) => ({
            ...currValue,
            tot_customers: false,
          }));
        }
      } catch (err) {
        setLoader((currValue) => ({
          ...currValue,
          stores_only: true,
        }));
        console.log("err-fetchStoreOnly", err);
      }
    };
    const fetchStoresAndOnline = async () => {
      try {
        setLoader((currValue) => ({
          ...currValue,
          stores_and_online: true,
        }));
        let url =
          process.env.REACT_APP_API_ENDPOINT +
          process.env.REACT_APP_CUSTOMER_FILE_HEALTH +
          "concept=" +
          selectedCustomerFileBannerId +
          "&startDate=" +
          periodStartDateTY +
          "&endDate=" +
          periodEndDateTY +
          "&metric=" +
          "S_ONLINE_STORE";
        if (
          correctDateRange &&
          periodStartDateTY !== "" &&
          periodEndDateTY !== ""
        ) {
          setSubmitActive(false);
          await axios({ url }).then((res) => {
            setLoader((currValue) => ({
              ...currValue,
              stores_and_online: false,
            }));
            setStoresAndOnlineOnly(res.data);
            setCorrectDateRange(false);
            isSelectedDateCorrect(false);
          });
        } else {
          setLoader((currValue) => ({
            ...currValue,
            tot_customers: false,
          }));
        }
      } catch (err) {
        setLoader((currValue) => ({
          ...currValue,
          stores_and_online: true,
        }));
        console.log("err-fetchStoresAndOnline", err);
      }
    };
    const fetchCustomersEngaged = async () => {
      try {
        setLoader((currValue) => ({
          ...currValue,
          customers_engaged: true,
        }));
        let url =
          process.env.REACT_APP_API_ENDPOINT +
          process.env.REACT_APP_CUSTOMER_FILE_HEALTH +
          "concept=" +
          selectedCustomerFileBannerId +
          "&startDate=" +
          periodStartDateTY +
          "&endDate=" +
          periodEndDateTY +
          "&metric=" +
          "E_TCE";
        if (
          correctDateRange &&
          periodStartDateTY !== "" &&
          periodEndDateTY !== ""
        ) {
          setSubmitActive(false);
          await axios({ url }).then((res) => {
            setLoader((currValue) => ({
              ...currValue,
              customers_engaged: false,
            }));
            setCustomersEngaged(res.data);
            setCorrectDateRange(false);
            isSelectedDateCorrect(false);
          });
        } else {
          setLoader((currValue) => ({
            ...currValue,
            tot_customers: false,
          }));
        }
      } catch (err) {
        setLoader((currValue) => ({
          ...currValue,
          customers_engaged: true,
        }));
        console.log("err-fetchCustomersEngaged", err);
      }
    };
    const fetchCustomersTransacted = async () => {
      try {
        setLoader((currValue) => ({
          ...currValue,
          customers_transacted: true,
        }));
        let url =
          process.env.REACT_APP_API_ENDPOINT +
          process.env.REACT_APP_CUSTOMER_FILE_HEALTH +
          "concept=" +
          selectedCustomerFileBannerId +
          "&startDate=" +
          periodStartDateTY +
          "&endDate=" +
          periodEndDateTY +
          "&metric=" +
          "E_TCT";
        if (
          correctDateRange &&
          periodStartDateTY !== "" &&
          periodEndDateTY !== ""
        ) {
          setSubmitActive(false);
          await axios({ url }).then((res) => {
            setLoader((currValue) => ({
              ...currValue,
              customers_transacted: false,
            }));
            setCustomersTransacted(res.data);
            setCorrectDateRange(false);
            isSelectedDateCorrect(false);
          });
        } else {
          setLoader((currValue) => ({
            ...currValue,
            tot_customers: false,
          }));
        }
      } catch (err) {
        setLoader((currValue) => ({
          ...currValue,
          customers_transacted: true,
        }));
        console.log("err-fetchCustomersTransacted", err);
      }
    };
    const fetchMobileApp = async () => {
      try {
        setLoader((currValue) => ({
          ...currValue,
          mobile_app: true,
        }));
        let url =
          process.env.REACT_APP_API_ENDPOINT +
          process.env.REACT_APP_CUSTOMER_FILE_HEALTH +
          "concept=" +
          selectedCustomerFileBannerId +
          "&startDate=" +
          periodStartDateTY +
          "&endDate=" +
          periodEndDateTY +
          "&metric=" +
          "E_APP";
        if (
          correctDateRange &&
          periodStartDateTY !== "" &&
          periodEndDateTY !== ""
        ) {
          setSubmitActive(false);
          await axios({ url }).then((res) => {
            setLoader((currValue) => ({
              ...currValue,
              mobile_app: false,
            }));
            setMobileApp(res.data);
            setCorrectDateRange(false);
            isSelectedDateCorrect(false);
          });
        } else {
          setLoader((currValue) => ({
            ...currValue,
            tot_customers: false,
          }));
        }
      } catch (err) {
        setLoader((currValue) => ({
          ...currValue,
          mobile_app: true,
        }));
        console.log("err-fetchMobileApp", err);
      }
    };
    const fetchLoyaltys = async () => {
      try {
        setLoader((currValue) => ({
          ...currValue,
          loyalty: true,
        }));
        let url =
          process.env.REACT_APP_API_ENDPOINT +
          process.env.REACT_APP_CUSTOMER_FILE_HEALTH +
          "concept=" +
          selectedCustomerFileBannerId +
          "&startDate=" +
          periodStartDateTY +
          "&endDate=" +
          periodEndDateTY +
          "&metric=" +
          "E_LOYALTY";
        if (
          correctDateRange &&
          periodStartDateTY !== "" &&
          periodEndDateTY !== ""
        ) {
          setSubmitActive(false);
          await axios({ url }).then((res) => {
            setLoader((currValue) => ({
              ...currValue,
              loyalty: false,
            }));
            setLoyaltys(res.data);
            setCorrectDateRange(false);
            isSelectedDateCorrect(false);
          });
        } else {
          setLoader((currValue) => ({
            ...currValue,
            tot_customers: false,
          }));
        }
      } catch (err) {
        setLoader((currValue) => ({
          ...currValue,
          loyalty: true,
        }));
        console.log("err-fetchLoyaltys", err);
      }
    };
    const fetchRegistrys = async () => {
      try {
        setLoader((currValue) => ({
          ...currValue,
          registry: true,
        }));
        let url =
          process.env.REACT_APP_API_ENDPOINT +
          process.env.REACT_APP_CUSTOMER_FILE_HEALTH +
          "concept=" +
          selectedCustomerFileBannerId +
          "&startDate=" +
          periodStartDateTY +
          "&endDate=" +
          periodEndDateTY +
          "&metric=" +
          "E_REGISTRY";
        if (
          correctDateRange &&
          periodStartDateTY !== "" &&
          periodEndDateTY !== ""
        ) {
          setSubmitActive(false);
          await axios({ url }).then((res) => {
            setLoader((currValue) => ({
              ...currValue,
              registry: false,
            }));
            setRegistrys(res.data);
            setCorrectDateRange(false);
            isSelectedDateCorrect(false);
          });
        } else {
          setLoader((currValue) => ({
            ...currValue,
            tot_customers: false,
          }));
        }
      } catch (err) {
        setLoader((currValue) => ({
          ...currValue,
          registry: true,
        }));
        console.log("err-fetchRegistrys", err);
      }
    };
    const fetchCsps = async () => {
      try {
        setLoader((currValue) => ({
          ...currValue,
          csp: true,
        }));
        let url =
          process.env.REACT_APP_API_ENDPOINT +
          process.env.REACT_APP_CUSTOMER_FILE_HEALTH +
          "concept=" +
          selectedCustomerFileBannerId +
          "&startDate=" +
          periodStartDateTY +
          "&endDate=" +
          periodEndDateTY +
          "&metric=" +
          "E_CSP";
        if (
          correctDateRange &&
          periodStartDateTY !== "" &&
          periodEndDateTY !== ""
        ) {
          setSubmitActive(false);
          await axios({ url }).then((res) => {
            setLoader((currValue) => ({
              ...currValue,
              csp: false,
            }));
            setCsps(res.data);
            setCorrectDateRange(false);
            isSelectedDateCorrect(false);
          });
        } else {
          setLoader((currValue) => ({
            ...currValue,
            tot_customers: false,
          }));
        }
      } catch (err) {
        setLoader((currValue) => ({
          ...currValue,
          csp: true,
        }));
        console.log("err-fetchCsps", err);
      }
    };
    console.log("selectedCustomerFilePeriodId", selectedCustomerFilePeriodId);
    console.log("periodStartDateTY", periodStartDateTY);
    console.log("periodEndDateTY", periodEndDateTY);
    console.log("correctDateRange", correctDateRange);
    if (
      selectedCustomerFilePeriodId &&
      localStorage.getItem("isCUSTOMERFILEHEALTH") === "Y" &&
      periodStartDateTY !== "" &&
      periodEndDateTY !== "" &&
      correctDateRange &&
      DateCompare(periodStartDateTY, periodEndDateTY) <= 0
    ) {
      // tab 1
      fetchTotalCustomers();
      fetchNewToFileCustomers();
      fetchAbleToContact();
      fetchContactInfo();
      // tab 2
      fetchMakeTransaction();
      fetchOnlineOnly();
      fetchStoreOnly();
      fetchStoresAndOnline();
      // tab 3
      fetchCustomersEngaged();
      fetchCustomersTransacted();
      fetchMobileApp();
      fetchLoyaltys();
      fetchRegistrys();
      fetchCsps();
    }
  }, [
    allStorePeriods,
    selectedCustomerFileBannerId,
    selectedCustomerFilePeriodId,
    periodEndDateTY,
    periodStartDateTY,
    selectedDateCorrect,
  ]);

  useEffect(() => {
    const assignDates = () => {
      if (selectedCustomerFilePeriodId === "0") {
        setPeriodStartDateTY(allStorePeriods[0].TY_YESTERDAY);
        setPeriodEndDateTY(allStorePeriods[0].TY_YESTERDAY);
        setCorrectDateRange(true);
      } else if (selectedCustomerFilePeriodId === "1") {
        setPeriodStartDateTY(allStorePeriods[0].TY_WTD_START_DATE);
        setPeriodEndDateTY(allStorePeriods[0].TY_WTD_END_DATE);
        setCorrectDateRange(true);
      } else if (selectedCustomerFilePeriodId === "2") {
        setPeriodStartDateTY(allStorePeriods[0].TY_MTD_START_DATE);
        setPeriodEndDateTY(allStorePeriods[0].TY_MTD_END_DATE);
        setCorrectDateRange(true);
      } else if (selectedCustomerFilePeriodId === "3") {
        setPeriodStartDateTY(allStorePeriods[0].TY_QTD_START_DATE);
        setPeriodEndDateTY(allStorePeriods[0].TY_QTD_END_DATE);
        setCorrectDateRange(true);
      } else if (selectedCustomerFilePeriodId === "4") {
        setPeriodStartDateTY(allStorePeriods[0].TY_YTD_START_DATE);
        setPeriodEndDateTY(allStorePeriods[0].TY_YTD_END_DATE);
        setCorrectDateRange(true);
      }
    };
    allStorePeriods[0] !== undefined &&
      allStorePeriods[0] !== null &&
      correctDateRange === false &&
      assignDates();
  }, [
    allStorePeriods,
    selectedCustomerFilePeriodId,
    //periodEndDateLY,
    periodEndDateTY,
    //periodStartDateLY,
    periodStartDateTY,
    //correctDateRange,
  ]);

  return localStorage.getItem("isCUSTOMERFILEHEALTH") === "Y" ? (
    <div>
      {refreshTime.length > 0 && <NotificationMessage message={refreshDate} />}
      <div className="mt-1 d-flex align-items-center headings">
        <div className="d-flex justify-content-start p-3">
          <span className="progselectupText">Concept</span>
        </div>
        <div className="d-flex justify-content-start p-3">
          <span className="progselectupText" style={{ paddingLeft: "2.5rem" }}>
            Period
          </span>
        </div>
        {selectedCustomerFilePeriodValue === "Date Range" && (
          <div className="d-flex justify-content-start p-3">
            <span
              className="progselectupText"
              style={{ paddingLeft: "3.8rem" }}
            >
              Start Date
            </span>
          </div>
        )}
        {selectedCustomerFilePeriodValue === "Date Range" && (
          <div className="d-flex justify-content-start p-3">
            <span
              className="progselectupText"
              style={{ paddingLeft: "3.8rem" }}
            >
              End Date
            </span>
          </div>
        )}
      </div>
      <div className="mt-3 d-flex align-items-center">
        <div className="d-flex justify-content-start p-3">
          <Dropdown className="d-inline">
            <Dropdown.Toggle>
              {selectedCustomerFileBanner.value}
            </Dropdown.Toggle>
            <Dropdown.Menu
              className="dropdown-menu-ext"
              onClick={(e) => handleCustomerFileBanner(e)}
            >
              {CustomerFileBanners.map((data) => {
                return (
                  <Dropdown.Item
                    key={data.id}
                    className="dropdown-item-ext"
                    id={data.id}
                  >
                    {data.value}
                  </Dropdown.Item>
                );
              })}
            </Dropdown.Menu>
          </Dropdown>
        </div>
        <div className="d-flex justify-content-start p-3">
          <Dropdown className="d-inline">
            <Dropdown.Toggle>{selectedCustomerFilePeriodValue}</Dropdown.Toggle>
            <Dropdown.Menu
              className="dropdown-menu-ext"
              onClick={(e) => handleCustomerFilePeriod(e)}
            >
              {CustomerFilePeriods.map((data) => {
                return (
                  <Dropdown.Item
                    key={data.id}
                    className="dropdown-item-ext"
                    id={data.id}
                  >
                    {data.value}
                  </Dropdown.Item>
                );
              })}
            </Dropdown.Menu>
          </Dropdown>
        </div>
        <div>
          {selectedCustomerFilePeriodValue !== "Date Range" &&
          periodEndDateTY !== "" ? (
            <div>
              <span>{`(${getDateFormatFromDB(
                periodStartDateTY
              )} - ${getDateFormatFromDB(periodEndDateTY)})`}</span>
            </div>
          ) : (
            <div>
              {selectedCustomerFilePeriodValue !== "Date Range" && (
                <span>{`( - )`}</span>
              )}
            </div>
          )}
        </div>
        {selectedCustomerFilePeriodValue === "Date Range" && (
          <div
            className="d-flex justify-content-start p-3"
            style={{ marginRight: "-5rem" }}
          >
            <label
              className="d-flex datepicker"
              onClick={(e) => e.preventDefault()}
            >
              <DatePicker
                timeFormat={false}
                value={periodStartDateTY}
                isValidDate={disableCustomDt}
                onChange={(date) => handleStartDate(date)}
                closeOnSelect
                inputProps={{ readOnly: true }}
              />
              <img src={calender} className="date-picker-icon" />
            </label>
          </div>
        )}
        {selectedCustomerFilePeriodValue === "Date Range" && (
          <div
            className="d-flex justify-content-start p-3"
            style={{ marginRight: "-5rem" }}
          >
            <label
              className="d-flex datepicker"
              onClick={(e) => e.preventDefault()}
            >
              <DatePicker
                timeFormat={false}
                value={periodEndDateTY}
                isValidDate={disableCustomDt}
                onChange={(date) => handleEndDate(date)}
                closeOnSelect
                inputProps={{ readOnly: true }}
              />
              <img src={calender} className="date-picker-icon" />
            </label>
          </div>
        )}
        {selectedCustomerFilePeriodValue === "Date Range" && (
          <Button
            type="button"
            className="btn btn-primary"
            id={submitActive ? "submit" : "noSubmit"}
            onClick={() => handleSubmit()}
          >
            Submit
          </Button>
        )}
      </div>
      <div className="row HeaderContainer">
        <div className="col-2 col-sm-1 SubHeader justify-content-center">
          <p
            className={
              tabView.growthView ? "Header-Active HeaderTab " : "HeaderTab"
            }
            onClick={() => buttonClick("1")}
          >
            Growth
          </p>
        </div>
        <div className="col-2 col-sm-2 SubHeader justify-content-center">
          <p
            className={
              tabView.salesView ? "Header-Active HeaderTab " : "HeaderTab"
            }
            onClick={() => buttonClick("2")}
          >
            Sales
          </p>
        </div>
        <div className="col-2 col-sm-2 SubHeader justify-content-left">
          <p
            className={
              tabView.enagagementView ? "Header-Active HeaderTab " : "HeaderTab"
            }
            onClick={() => buttonClick("3")}
          >
            Engagement
          </p>
        </div>
      </div>
      <div>
        {tabView.growthView ? (
          <Growth
            loading={loading}
            totalCustomers={totalCustomers}
            newToFileCustomers={newToFileCustomers}
            ableToContactCustomers={ableToContactCustomers}
            contactInfoCustomers={contactInfoCustomers}
          />
        ) : tabView.salesView ? (
          <Sales
            loading={loading}
            makeTransactions={makeTransactions}
            makeOnlineOnly={makeOnlineOnly}
            makeStoresOnly={makeStoresOnly}
            makeStoresAndOnlineOnly={makeStoresAndOnlineOnly}
          />
        ) : (
          <Engagement
            loading={loading}
            makeCustomersEngaged={makeCustomersEngaged}
            makeCustomersTransacted={makeCustomersTransacted}
            mobileApp={mobileApp}
            loyaltys={loyaltys}
            registrys={registrys}
            csps={csps}
          />
        )}
      </div>
    </div>
  ) : (
    <NoAccess tabName="Customer File Health" />
  );
}

export default CustomerFileContainer;
