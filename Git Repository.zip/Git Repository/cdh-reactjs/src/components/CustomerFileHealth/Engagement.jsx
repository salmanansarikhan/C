import { React, useState } from "react";
import { useSelector } from "react-redux";
import "../CustomerFileHealth/CustomerFile.css";
import { Table } from "react-bootstrap";
import LoaderForRow from "../LoaderForTable/LoaderForRow";
import { gettooltip, getDateFormatFromDB } from "../Utils";
export const currencyFormat = (value) => {
  return parseFloat(value)
    .toFixed(0)
    .replace(/(\d)(?=(\d{3})+(?!\d))/g, "$1,");
};
export const decimalCurrencyFormat = (value) => {
  return parseFloat(value)
    .toFixed(2)
    .replace(/(\d)(?=(\d{3})+(?!\d))/g, "$1,");
};

function Engagement({
  loading,
  makeCustomersEngaged,
  makeCustomersTransacted,
  mobileApp,
  loyaltys,
  registrys,
  csps,
}) {
  return (
    <div>
      <div className="p-3" style={{ marginBottom: "50px" }}>
        <Table style={{ textAlign: "center" }} striped bordered hover size="sm">
          <thead className="text">
            <tr>
              <th></th>
            </tr>
          </thead>
          <tbody>
            <tr style={{ fontWeight: "500" }}>
              <td style={{ backgroundColor: "lightgrey", width: "40rem" }}>
                Total number of customers engaged
              </td>
              {loading.customers_engaged ? (
                <>
                  <LoaderForRow tdCount={1} />
                </>
              ) : (
                <td>
                  {makeCustomersEngaged &&
                  makeCustomersEngaged !== undefined &&
                  makeCustomersEngaged.length !== 0 &&
                  makeCustomersEngaged[0].CUST_CNT !== "-999999"
                    ? currencyFormat(Number(makeCustomersEngaged[0].CUST_CNT))
                    : "-"}
                </td>
              )}
            </tr>
            <tr>
              <td>Total number of customers transacted</td>
              {loading.customers_transacted ? (
                <>
                  <LoaderForRow tdCount={1} />
                </>
              ) : (
                <td>
                  {makeCustomersTransacted &&
                  makeCustomersTransacted !== undefined &&
                  makeCustomersTransacted.length !== 0 &&
                  makeCustomersTransacted[0].CUST_CNT !== "-999999"
                    ? currencyFormat(
                        Number(makeCustomersTransacted[0].CUST_CNT)
                      )
                    : "-"}
                </td>
              )}
            </tr>
            <tr>
              <td>Total number of customers used Mobile app</td>
              {loading.mobile_app ? (
                <>
                  <LoaderForRow tdCount={1} />
                </>
              ) : (
                <td>
                  {mobileApp &&
                  mobileApp !== undefined &&
                  mobileApp.length !== 0 &&
                  mobileApp[0].CUST_CNT !== "-999999"
                    ? currencyFormat(Number(mobileApp[0].CUST_CNT))
                    : "-"}
                </td>
              )}
            </tr>
            <tr>
              <td>Total number of customers enrolled to Loyalty</td>
              {loading.loyalty ? (
                <>
                  <LoaderForRow tdCount={1} />
                </>
              ) : (
                <td>
                  {loyaltys &&
                  loyaltys !== undefined &&
                  loyaltys.length !== 0 &&
                  loyaltys[0].CUST_CNT !== "-999999"
                    ? currencyFormat(Number(loyaltys[0].CUST_CNT))
                    : "-"}
                </td>
              )}
            </tr>
            <tr>
              <td>Total number of customers created registry</td>
              {loading.registry ? (
                <>
                  <LoaderForRow tdCount={1} />
                </>
              ) : (
                <td>
                  {registrys &&
                  registrys !== undefined &&
                  registrys.length !== 0 &&
                  registrys[0].CUST_CNT !== "-999999"
                    ? currencyFormat(Number(registrys[0].CUST_CNT))
                    : "-"}
                </td>
              )}
            </tr>
            <tr>
              <td>Total number of customers created CSP</td>
              {loading.csp ? (
                <>
                  <LoaderForRow tdCount={1} />
                </>
              ) : (
                <td>
                  {csps &&
                  csps !== undefined &&
                  csps.length !== 0 &&
                  csps[0].CUST_CNT !== "-999999"
                    ? currencyFormat(Number(csps[0].CUST_CNT))
                    : "-"}
                </td>
              )}
            </tr>
          </tbody>
        </Table>
      </div>
    </div>
  );
}

export default Engagement;
