import { React, useState } from "react";
import { useSelector } from "react-redux";
import "../CustomerFileHealth/CustomerFile.css";
import { Table } from "react-bootstrap";
import LoaderForRow from "../LoaderForTable/LoaderForRow";
import { currencyFormat } from "../Utils";

function Growth({
  loading,
  totalCustomers,
  newToFileCustomers,
  ableToContactCustomers,
  contactInfoCustomers,
}) {
  return (
    <div>
      <div className="p-3" style={{ marginBottom: "50px" }}>
        <Table style={{ textAlign: "center" }} striped bordered hover size="sm">
          <thead className="text">
            <tr>
              <th></th>
            </tr>
          </thead>
          <tbody>
            <tr style={{ fontWeight: "500" }}>
              <td style={{ backgroundColor: "lightgrey", width: "40rem" }}>
                Total customers
              </td>
              {loading.tot_customers ? (
                <>
                  <LoaderForRow tdCount={1} />
                </>
              ) : (
                <td>
                  {totalCustomers &&
                  totalCustomers !== undefined &&
                  totalCustomers.length !== 0 &&
                  totalCustomers[0].CUST_CNT !== "-999999"
                    ? currencyFormat(Number(totalCustomers[0].CUST_CNT))
                    : "-"}
                </td>
              )}
            </tr>
            <tr>
              <td>How many new to file</td>
              {loading.new_to_file ? (
                <>
                  <LoaderForRow tdCount={1} />
                </>
              ) : (
                <td>
                  {newToFileCustomers &&
                  newToFileCustomers !== undefined &&
                  newToFileCustomers.length !== 0 &&
                  newToFileCustomers[0].CUST_CNT !== "-999999"
                    ? currencyFormat(Number(newToFileCustomers[0].CUST_CNT))
                    : "-"}
                </td>
              )}
            </tr>
            <tr>
              <td>How many customers we are able to contact</td>
              {loading.able_to_contact ? (
                <>
                  <LoaderForRow tdCount={1} />
                </>
              ) : (
                <td>
                  {ableToContactCustomers &&
                  ableToContactCustomers !== undefined &&
                  ableToContactCustomers.length !== 0 &&
                  ableToContactCustomers[0].CUST_CNT !== "-999999"
                    ? currencyFormat(Number(ableToContactCustomers[0].CUST_CNT))
                    : "-"}
                </td>
              )}
            </tr>
            <tr>
              <td>
                For How many customers received contact info (email and Phone)
              </td>
              {loading.contact_info ? (
                <>
                  <LoaderForRow tdCount={1} />
                </>
              ) : (
                <td>
                  {contactInfoCustomers &&
                  contactInfoCustomers !== undefined &&
                  contactInfoCustomers.length !== 0 &&
                  contactInfoCustomers[0].CUST_CNT !== "-999999"
                    ? currencyFormat(Number(contactInfoCustomers[0].CUST_CNT))
                    : "-"}
                </td>
              )}
            </tr>
          </tbody>
        </Table>
      </div>
    </div>
  );
}

export default Growth;
