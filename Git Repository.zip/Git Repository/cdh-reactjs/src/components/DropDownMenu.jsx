import React, { useState } from "react";
import { Dropdown } from "react-bootstrap";
import PropTypes from "prop-types";
import { useDispatch} from "react-redux";
import { handleBannerChange } from "../Redux/Actions/BannerChangeActions";
import { handleCategoryChange } from "../Redux/Actions/CategoryChangeActions";
const DropDownMenu = (props) => {
  const dispatch = useDispatch();
  const [selectedItem, setSelectedItem] = useState(props.initalProps);
  const handleChange = (event) => {
    setSelectedItem((prevsValue) => ({
      ...prevsValue,
      value: event.target.innerText,
      id: event.target.id,
    }));
    if (props.ActionType==="Banner")
    {
      dispatch(
        handleBannerChange({
          value: event.target.innerText,
          id: event.target.id,
        })
      );
    }
    else if (props.ActionType === "Category") {
       dispatch(
         handleCategoryChange({
           value: event.target.innerText,
           id: event.target.id,
         })
       );
    }
  };
  return (
    <>
      <Dropdown className="d-inline">
        <Dropdown.Toggle>{selectedItem.value}</Dropdown.Toggle>

        <Dropdown.Menu
          className="dropdown-menu-ext"
          onClick={(e) => handleChange(e)}
        >
          {props.DropDownItems &&
            props.DropDownItems.map((data) => {
              return (
                <Dropdown.Item
                  key={data.id}
                  id={data.id}
                  className="dropdown-item-ext"
                >
                  {data.value}
                </Dropdown.Item>
              );
            })}
        </Dropdown.Menu>
      </Dropdown>
    </>
  );
};

DropDownMenu.propTypes = {
  initalProps: PropTypes.object,
  DropDownItems: PropTypes.array,
};

export default DropDownMenu;
