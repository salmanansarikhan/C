import React from "react";
import { Table } from "react-bootstrap";
import "../Loyality/BeyondPlusContainer.css";
import LoaderForRow from "../LoaderForTable/LoaderForRow";
import { FontAwesomeIcon } from "@fortawesome/react-fontawesome";
import { faCaretUp, faCaretDown } from "@fortawesome/free-solid-svg-icons";
import "./LoyalityContainer.css";
import { decimalCurrencyFormat } from "../ScoreCard/Marketing";

function BeyondPlus({
  loading,
  beyondPlusReport,
  sortSelection,
  sortBPlusReport,
}) {
  return (
    <div>
      <div className="p-3" style={{ marginBottom: "50px" }}>
        <Table style={{ textAlign: "center" }} striped bordered hover size="sm">
          <thead className="text">
            <tr>
              <th rowSpan="2">
                Store
                {sortSelection.arrowIcon === "default" && (
                  <FontAwesomeIcon
                    style={{ paddingLeft: "5px" }}
                    icon={faCaretUp}
                  />
                )}
              </th>
              <th
                rowSpan="2"
                style={{ cursor: "pointer" }}
                onClick={() => {
                  sortBPlusReport("district");
                }}
              >
                District
                {(sortSelection.arrowIcon === "districtUp" && (
                  <FontAwesomeIcon
                    style={{ paddingLeft: "5px" }}
                    icon={faCaretUp}
                  />
                )) ||
                  (sortSelection.arrowIcon === "districtDown" && (
                    <FontAwesomeIcon
                      style={{ paddingLeft: "5px" }}
                      icon={faCaretDown}
                    />
                  ))}
              </th>
              <th
                rowSpan="2"
                style={{ cursor: "pointer" }}
                onClick={() => {
                  sortBPlusReport("region");
                }}
              >
                Region
                {(sortSelection.arrowIcon === "regionUp" && (
                  <FontAwesomeIcon
                    style={{ paddingLeft: "5px" }}
                    icon={faCaretUp}
                  />
                )) ||
                  (sortSelection.arrowIcon === "regionDown" && (
                    <FontAwesomeIcon
                      style={{ paddingLeft: "5px" }}
                      icon={faCaretDown}
                    />
                  ))}
              </th>
            </tr>
            <tr>
              <th>POS</th>
              <th>TBS</th>
              <th>SMS</th>
            </tr>
          </thead>
          <tbody className="textTable">
            {loading.beyondPlusData ? (
              <tr>
                <LoaderForRow height={"500px"} tdCount={6} />
              </tr>
            ) : beyondPlusReport != undefined &&
              beyondPlusReport.length !== 0 ? (
              beyondPlusReport != undefined &&
              beyondPlusReport.length !== 0 &&
              beyondPlusReport.map((data) => {
                return (
                  <tr class="align-middle">
                    <td>
                      {data.STORE_NBR !== undefined &&
                      data.STORE_NBR.length !== 0 &&
                      data.STORE_NBR !== "-999999"
                        ? data.STORE_NBR
                        : "-"}
                    </td>
                    <td>
                      {data.DISTRICT !== undefined &&
                      data.DISTRICT.length !== 0 &&
                      data.DISTRICT !== "-999999"
                        ? data.DISTRICT
                        : "-"}
                    </td>
                    <td>
                      {data.REGION !== undefined &&
                      data.REGION.length !== 0 &&
                      data.REGION !== "-999999"
                        ? data.REGION
                        : "-"}
                    </td>
                    <td>
                      <span>
                        {data.POS_TY !== undefined &&
                        data.POS_TY.length !== 0 &&
                        data.POS_TY !== "-999999"
                          ? data.POS_TY
                          : "-"}
                      </span>
                      <br />
                      <span style={{ fontSize: "11px" }}>
                        {data.POS_YOY !== undefined &&
                        data.POS_YOY.length !== 0 &&
                        data.POS_YOY !== "-999999" ? (
                          Number(data.POS_YOY).toFixed(2).includes("-") ? (
                            <span style={{ color: "red" }}>
                              {`${decimalCurrencyFormat(data.POS_YOY)}%`}
                            </span>
                          ) : (
                            <span style={{ color: "green" }}>
                              {`${decimalCurrencyFormat(data.POS_YOY)}%`}
                            </span>
                          )
                        ) : (
                          "-"
                        )}
                      </span>
                    </td>
                    <td>
                      <span>
                        {data.TBS_TY !== undefined &&
                        data.TBS_TY.length !== 0 &&
                        data.TBS_TY !== "-999999"
                          ? data.TBS_TY
                          : "-"}
                      </span>
                      <br />
                      <span style={{ fontSize: "11px" }}>
                        {data.TBS_YOY !== undefined &&
                        data.TBS_YOY.length !== 0 &&
                        data.TBS_YOY !== "-999999" ? (
                          Number(data.TBS_YOY).toFixed(2).includes("-") ? (
                            <span style={{ color: "red" }}>
                              {`${decimalCurrencyFormat(data.TBS_YOY)}%`}
                            </span>
                          ) : (
                            <span style={{ color: "green" }}>
                              {`${decimalCurrencyFormat(data.TBS_YOY)}%`}
                            </span>
                          )
                        ) : (
                          "-"
                        )}
                      </span>
                    </td>
                    <td>
                      <span>
                        {data.SMS_TY !== undefined &&
                        data.SMS_TY.length !== 0 &&
                        data.SMS_TY !== "-999999"
                          ? data.SMS_TY
                          : "-"}
                      </span>
                      <br />
                      <span style={{ fontSize: "11px" }}>
                        {data.SMS_YOY !== undefined &&
                        data.SMS_YOY.length !== 0 &&
                        data.SMS_YOY !== "-999999" ? (
                          Number(data.SMS_YOY).toFixed(2).includes("-") ? (
                            <span style={{ color: "red" }}>
                              {`${decimalCurrencyFormat(data.SMS_YOY)}%`}
                            </span>
                          ) : (
                            <span style={{ color: "green" }}>
                              {`${decimalCurrencyFormat(data.SMS_YOY)}%`}
                            </span>
                          )
                        ) : (
                          "-"
                        )}
                      </span>
                    </td>
                  </tr>
                );
              })
            ) : (
              <tr>
                <td align="center" colSpan="8" style={{ fontWeight: "500" }}>
                  DATA NOT AVAILABLE
                </td>
              </tr>
            )}
          </tbody>
        </Table>
      </div>
    </div>
  );
}

export default BeyondPlus;
