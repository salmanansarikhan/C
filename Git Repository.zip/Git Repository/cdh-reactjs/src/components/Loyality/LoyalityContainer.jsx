import React, { useState, useEffect, useCallback } from "react";
import { useSelector, useDispatch } from "react-redux";
import { Dropdown, Placeholder } from "react-bootstrap";
import axios from "axios";
import "../Loyality/LoyalityContainer.css";
import { handleLoyalityBannerChange } from "../../Redux/Actions/BannerChangeActions";
import {
  handleLoyalityCustChange,
  handleLoyalityChannelChange,
} from "../../Redux/Actions/CategoryChangeActions";
import { handleLoyalityPeriodChange } from "../../Redux/Actions/LoyalityPeriodChangeActions";
import BeyondPlus from "./BeyondPlus";
import StoreCC from "./StoreCC";
import LoyaltyWelcome from "./LoyaltyWelcome";
import { getDateFormatFromDB } from "../Utils";
import { UTCtoEST } from "../Utils";
import NotificationMessage from "../NotificationMessage/NotificationMessage";
import NoAccess from "../NoAccess/NoAccess";

const LoyalityBanners = [
  { value: "All Banner", id: "1,2,3,5" },
  { value: "BBBY US", id: "1" },
  { value: "BBBY CA", id: "2" },
  { value: "buy buy Baby", id: "3" },
  { value: "Harmon", id: "5" },
];

const LoyalityCategory = [
  { value: "Beyond+", id: "BPLUS" },
  { value: "Credit Card", id: "CC" },
  { value: "Loyalty", id: "LOYALTY" },
];

const LoyalityChannels = [
  { value: "All", id: "0" },
  { value: "Store", id: "1" },
  { value: "Online", id: "2" },
];

const LoyalityPeriods = [
  { value: "Yesterday", id: "0" },
  { value: "WTD", id: "1" },
  { value: "MTD", id: "2" },
  { value: "QTD", id: "3" },
  { value: "YTD ", id: "4" },
];

function LoyalityContainer() {
  const dispatch = useDispatch();

  const [selectedLoyalityBanner, setSelectedLoyalityBanner] = useState(
    LoyalityBanners[1]
  );
  const [selectedLoyalityCategory, setSelectedLoyalityCategory] = useState(
    LoyalityCategory[0]
  );
  const [selectedLoyalityChannel, setSelectedLoyalityChannel] = useState(
    LoyalityChannels[1]
  );
  const [selectedLoyalityPeriod, setSelectedLoyalityPeriod] = useState(
    LoyalityPeriods[0]
  );
  const [allLoyalityPeriods, setAllLoyalityPeriods] = useState([]);
  const [beyondPlusReport, setbeyondPlusReport] = useState();
  const [ccData, setCcData] = useState();
  const [periodStartDateLY, setPeriodStartDateLY] = useState("");
  const [periodEndDateLY, setPeriodEndDateLY] = useState("");
  const [periodStartDateTY, setPeriodStartDateTY] = useState("");
  const [periodEndDateTY, setPeriodEndDateTY] = useState("");
  const [correctDateRange, setCorrectDateRange] = useState(false);
  const [loyalityWelcome, setLoyalityWelcome] = useState();
  const [loyalityWelcomePlus, setLoyalityWelcomePlus] = useState();
  const [loyalityCreditCard, setLoyalityCreditCard] = useState();
  const [loyaltyWelcomeTotal, setLoyaltyWelcomeTotal] = useState();
  const [loyaltyWelcomePlusTotal, setLoyaltyWelcomePlusTotal] = useState();
  const [loyaltyCreditCardTotal, setLoyaltyCreditCardTotal] = useState();
  const [refreshTime, setRefreshTime] = useState("");

  const refreshDate =
    refreshTime.length > 0 && UTCtoEST(refreshTime[0].end_time * 1000);

  const [sortSelection, setSortSelector] = useState({
    districtAscending: true,
    regionAscending: true,
    arrowIcon: "default",
  });
  const [sortSelectionCC, setCCSortSelector] = useState({
    districtAscending: true,
    regionAscending: true,
    arrowIcon: "default",
  });

  const selectedLoyalityPeriodId = useSelector(
    (store) => store.LoyalityPeriod.id
  );

  const selectedLoyalityPeriodValue = useSelector(
    (store) => store.LoyalityPeriod.value
  );
  const selectedLoyalityBannerId = useSelector(
    (store) => store.LoyalityBanner.id
  );

  const selectedLoyalityCustId = useSelector((store) => store.LoyalityCust.id);

  const selectedLoyalityChannelId = useSelector(
    (store) => store.LoyalityChannel.id
  );
  const [loading, setloader] = useState({
    beyondPlusData: false,
    ccData: false,
    periodData: false,
    welcomeData: false,
    welcomeDataPlus: false,
    loyaltyCreditCard: false,
    loyaltyWelcomeTotal: false,
    loyaltyWelcomePlusTotal: false,
    loyaltyCreditCardTotal: false,
    refreshTime: false,
  });

  const handleLoyalityBanner = useCallback(
    (event) => {
      setSelectedLoyalityBanner((prevsValue) => ({
        ...prevsValue,
        value: event.target.innerText,
        id: event.target.id,
      }));
      dispatch(
        handleLoyalityBannerChange({
          value: event.target.innerText,
          id: event.target.id,
        })
      );
    },
    [selectedLoyalityBannerId]
  );

  const handleLoyalityChannel = useCallback((event) => {
    setSelectedLoyalityChannel((prevsValue) => ({
      ...prevsValue,
      value: event.target.innerText,
      id: event.target.id,
    }));
    dispatch(
      handleLoyalityChannelChange({
        value: event.target.innerText,
        id: event.target.id,
      })
    );
  }, []);

  const handleLoyalityPeriod = useCallback((event) => {
    setSelectedLoyalityPeriod((prevsValue) => ({
      ...prevsValue,
      value: event.target.innerText,
      id: event.target.id,
    }));
    dispatch(
      handleLoyalityPeriodChange({
        value: event.target.innerText,
        id: event.target.id,
      })
    );
  }, []);

  const handleLoyalityCategory = useCallback((event) => {
    if (event.target.id === "BPLUS" || event.target.id === "BC") {
      setSelectedLoyalityBanner({ value: "BBBY US", id: "1" });
      setSelectedLoyalityCategory((prevsValue) => ({
        ...prevsValue,
        value: event.target.innerText,
        id: event.target.id,
      }));
      dispatch(
        handleLoyalityCustChange({
          value: event.target.innerText,
          id: event.target.id,
        })
      );
      dispatch(handleLoyalityBannerChange({ value: "BBBY US", id: "1" }));
      setCorrectDateRange(true);
    } else if (event.target.id === "LOYALTY") {
      setSelectedLoyalityBanner({ value: "All Banner", id: "1,2,3,5" });
      setSelectedLoyalityChannel({ value: "All", id: "0" });
      setSelectedLoyalityCategory((prevsValue) => ({
        ...prevsValue,
        value: event.target.innerText,
        id: event.target.id,
      }));
      dispatch(
        handleLoyalityCustChange({
          value: event.target.innerText,
          id: event.target.id,
        })
      );
      dispatch(
        handleLoyalityBannerChange({ value: "All Banner", id: "1,2,3,5" })
      );
      dispatch(handleLoyalityChannelChange({ value: "All", id: "0" }));
      setCorrectDateRange(true);
    } else {
      setSelectedLoyalityCategory((prevsValue) => ({
        ...prevsValue,
        value: event.target.innerText,
        id: event.target.id,
      }));
      dispatch(
        handleLoyalityCustChange({
          value: event.target.innerText,
          id: event.target.id,
        })
      );
      setCorrectDateRange(true);
    }
  }, []);

  const sortBPlusReport = (value) => {
    if (value === "district") {
      let newArr = [...beyondPlusReport];
      sortSelection.districtAscending
        ? newArr.sort((a, b) => {
            return a.DISTRICT.localeCompare(b.DISTRICT);
          })
        : newArr.sort((a, b) => {
            return b.DISTRICT.localeCompare(a.DISTRICT);
          });
      setbeyondPlusReport(newArr);
      sortSelection.districtAscending
        ? setSortSelector(() => ({
            districtAscending: false,
            regionAscending: true,
            arrowIcon: "districtUp",
          }))
        : setSortSelector(() => ({
            districtAscending: true,
            regionAscending: true,
            arrowIcon: "districtDown",
          }));
    } else if (value === "region") {
      let newArr = [...beyondPlusReport];
      sortSelection.regionAscending
        ? newArr.sort((a, b) => {
            return a.REGION.localeCompare(b.REGION);
          })
        : newArr.sort((a, b) => {
            return b.REGION.localeCompare(a.REGION);
          });
      setbeyondPlusReport(newArr);
      sortSelection.regionAscending
        ? setSortSelector(() => ({
            districtAscending: true,
            regionAscending: false,
            arrowIcon: "regionUp",
          }))
        : setSortSelector(() => ({
            districtAscending: true,
            regionAscending: true,
            arrowIcon: "regionDown",
          }));
    }
  };

  const sortCC = (value) => {
    if (value === "district") {
      let newArr = [...ccData];
      sortSelectionCC.districtAscending
        ? newArr.sort((a, b) => {
            return a.DISTRICT.localeCompare(b.DISTRICT);
          })
        : newArr.sort((a, b) => {
            return b.DISTRICT.localeCompare(a.DISTRICT);
          });
      setCcData(newArr);
      sortSelectionCC.districtAscending
        ? setCCSortSelector(() => ({
            districtAscending: false,
            regionAscending: true,
            arrowIcon: "districtUp",
          }))
        : setCCSortSelector(() => ({
            districtAscending: true,
            regionAscending: true,
            arrowIcon: "districtDown",
          }));
    } else if (value === "region") {
      let newArr = [...ccData];
      sortSelectionCC.regionAscending
        ? newArr.sort((a, b) => {
            return a.REGION.localeCompare(b.REGION);
          })
        : newArr.sort((a, b) => {
            return b.REGION.localeCompare(a.REGION);
          });
      setCcData(newArr);
      sortSelectionCC.regionAscending
        ? setCCSortSelector(() => ({
            districtAscending: true,
            regionAscending: false,
            arrowIcon: "regionUp",
          }))
        : setCCSortSelector(() => ({
            districtAscending: true,
            regionAscending: true,
            arrowIcon: "regionDown",
          }));
    }
  };

  useEffect(() => {
    const getLoyalityPeriods = async () => {
      try {
        setloader((currValue) => ({
          ...currValue,
          periodData: true,
        }));
        let url =
          process.env.REACT_APP_API_ENDPOINT +
          process.env.REACT_APP_LOYALTY_PERIODS;
        await axios({ url }).then((res) => {
          setloader((currValue) => ({
            ...currValue,
            periodData: false,
          }));
          setAllLoyalityPeriods(res.data);
        });
      } catch (err) {
        setloader((currValue) => ({
          ...currValue,
          periodData: true,
        }));
        console.log("err-getLoyalityPeriods", err);
      }
    };
    getLoyalityPeriods();
  }, [
    selectedLoyalityPeriodId,
    selectedLoyalityBannerId,
    selectedLoyalityCustId,
    selectedLoyalityChannelId,
  ]);

  useEffect(() => {
    const assignDates = () => {
      if (selectedLoyalityPeriodId === "0") {
        setPeriodStartDateTY(allLoyalityPeriods[0].TY_YESTERDAY);
        setPeriodEndDateTY(allLoyalityPeriods[0].TY_YESTERDAY);
        setPeriodStartDateLY(allLoyalityPeriods[0].LY_YESTERDAY);
        setPeriodEndDateLY(allLoyalityPeriods[0].LY_YESTERDAY);
        setCorrectDateRange(true);
      } else if (selectedLoyalityPeriodId === "1") {
        setPeriodStartDateTY(allLoyalityPeriods[0].TY_WTD_START_DATE);
        setPeriodEndDateTY(allLoyalityPeriods[0].TY_WTD_END_DATE);
        setPeriodStartDateLY(allLoyalityPeriods[0].LY_WTD_START_DATE);
        setPeriodEndDateLY(allLoyalityPeriods[0].LY_WTD_END_DATE);
        setCorrectDateRange(true);
      } else if (selectedLoyalityPeriodId === "2") {
        setPeriodStartDateTY(allLoyalityPeriods[0].TY_MTD_START_DATE);
        setPeriodEndDateTY(allLoyalityPeriods[0].TY_MTD_END_DATE);
        setPeriodStartDateLY(allLoyalityPeriods[0].LY_MTD_START_DATE);
        setPeriodEndDateLY(allLoyalityPeriods[0].LY_MTD_END_DATE);
        setCorrectDateRange(true);
      } else if (selectedLoyalityPeriodId === "3") {
        setPeriodStartDateTY(allLoyalityPeriods[0].TY_QTD_START_DATE);
        setPeriodEndDateTY(allLoyalityPeriods[0].TY_QTD_END_DATE);
        setPeriodStartDateLY(allLoyalityPeriods[0].LY_QTD_START_DATE);
        setPeriodEndDateLY(allLoyalityPeriods[0].LY_QTD_END_DATE);
        setCorrectDateRange(true);
      } else if (selectedLoyalityPeriodId === "4") {
        setPeriodStartDateTY(allLoyalityPeriods[0].TY_YTD_START_DATE);
        setPeriodEndDateTY(allLoyalityPeriods[0].TY_YTD_END_DATE);
        setPeriodStartDateLY(allLoyalityPeriods[0].LY_YTD_START_DATE);
        setPeriodEndDateLY(allLoyalityPeriods[0].LY_YTD_END_DATE);
        setCorrectDateRange(true);
      }
    };
    allLoyalityPeriods[0] !== undefined &&
      allLoyalityPeriods[0] !== null &&
      correctDateRange === false &&
      assignDates();
  }, [
    allLoyalityPeriods,
    selectedLoyalityPeriodId,
    selectedLoyalityBannerId,
    selectedLoyalityCustId,
    selectedLoyalityChannelId,
    periodEndDateLY,
    periodEndDateTY,
    periodStartDateLY,
    periodStartDateTY,
    correctDateRange,
  ]);

  useEffect(() => {
    const fetchBPlusReport = async () => {
      try {
        setloader((currValue) => ({
          ...currValue,
          beyondPlusData: true,
        }));
        let url =
          process.env.REACT_APP_API_ENDPOINT +
          process.env.REACT_APP_BEYOND_PLUS_REPORT +
          "startDate=" +
          periodStartDateTY +
          "&endDate=" +
          periodEndDateTY;
        if (correctDateRange) {
          await axios({ url }).then((res) => {
            setloader((currValue) => ({
              ...currValue,
              beyondPlusData: false,
            }));
            //Sorting data by Store Number as default
            setbeyondPlusReport(
              res.data.sort((a, b) => {
                return Number(a.STORE_NBR) - Number(b.STORE_NBR);
              })
            );
            setCorrectDateRange(false);
          });
        }
      } catch (err) {
        console.log("err-fetchBPlusReport", err);
        setloader((currValue) => ({
          ...currValue,
          beyondPlusData: false,
        }));
      }
    };
    const fetchLoyaltyWelcome = async () => {
      try {
        setloader((currValue) => ({
          ...currValue,
          welcomeData: true,
        }));
        let url =
          process.env.REACT_APP_API_ENDPOINT +
          process.env.REACT_APP_LOYALTY_WELCOME +
          "loyaltyBanner=WELCOME" +
          "&startDate=" +
          periodStartDateTY +
          "&endDate=" +
          periodEndDateTY;
        await axios({ url }).then((res) => {
          setloader((currValue) => ({
            ...currValue,
            welcomeData: false,
          }));
          setLoyalityWelcome(res.data);
        });
      } catch (err) {
        console.log("err-fetchLoyalityWelcomeData", err);
        setloader((currValue) => ({
          ...currValue,
          welcomeData: false,
        }));
      }
    };
    const fetchLoyaltyWelcomePlus = async () => {
      try {
        setloader((currValue) => ({
          ...currValue,
          welcomeDataPlus: true,
        }));
        let url =
          process.env.REACT_APP_API_ENDPOINT +
          process.env.REACT_APP_LOYALTY_WELCOME +
          "loyaltyBanner=WELCOME PLUS" +
          "&startDate=" +
          periodStartDateTY +
          "&endDate=" +
          periodEndDateTY;
        await axios({ url }).then((res) => {
          setloader((currValue) => ({
            ...currValue,
            welcomeDataPlus: false,
          }));
          setLoyalityWelcomePlus(res.data);
        });
      } catch (err) {
        console.log("err-fetchWelcomePlusData", err);
        setloader((currValue) => ({
          ...currValue,
          welcomeDataPlus: false,
        }));
      }
    };
    const fetchLoyaltyCreditCard = async () => {
      try {
        setloader((currValue) => ({
          ...currValue,
          loyaltyCreditCard: true,
        }));
        let url =
          process.env.REACT_APP_API_ENDPOINT +
          process.env.REACT_APP_LOYALTY_WELCOME +
          "loyaltyBanner=CC" +
          "&startDate=" +
          periodStartDateTY +
          "&endDate=" +
          periodEndDateTY;
        await axios({ url }).then((res) => {
          setloader((currValue) => ({
            ...currValue,
            loyaltyCreditCard: false,
          }));
          setLoyalityCreditCard(res.data);
        });
      } catch (err) {
        console.log("err-fetchLoyaltyCreditCard", err);
        setloader((currValue) => ({
          ...currValue,
          loyaltyCreditCard: false,
        }));
      }
    };
    const fetchLoyaltyWelcomeTotal = async () => {
      try {
        setloader((currValue) => ({
          ...currValue,
          loyaltyWelcomeTotal: true,
        }));
        let url =
          process.env.REACT_APP_API_ENDPOINT +
          process.env.REACT_APP_CUSTOMER_LOYALTY_WELCOME_Total +
          "&startDate=" +
          periodStartDateTY +
          "&endDate=" +
          periodEndDateTY +
          "&loyaltyBanner=WELCOME";
        if (correctDateRange) {
          await axios({ url }).then((res) => {
            setloader((currValue) => ({
              ...currValue,
              loyaltyWelcomeTotal: false,
            }));
            setLoyaltyWelcomeTotal(res.data);
          });
          setCorrectDateRange(false);
        }
      } catch (err) {
        console.log("err-fetchLoyaltyWelcomeTotal", err);
        setloader((currValue) => ({
          ...currValue,
          loyaltyWelcomeTotal: false,
        }));
      }
    };
    const fetchLoyaltyWelcomePlusTotal = async () => {
      try {
        setloader((currValue) => ({
          ...currValue,
          loyaltyWelcomePlusTotal: true,
        }));
        let url =
          process.env.REACT_APP_API_ENDPOINT +
          process.env.REACT_APP_CUSTOMER_LOYALTY_WELCOME_Total +
          "&startDate=" +
          periodStartDateTY +
          "&endDate=" +
          periodEndDateTY +
          "&loyaltyBanner=WELCOME PLUS";
        if (correctDateRange) {
          await axios({ url }).then((res) => {
            setloader((currValue) => ({
              ...currValue,
              loyaltyWelcomePlusTotal: false,
            }));
            setLoyaltyWelcomePlusTotal(res.data);
          });
          setCorrectDateRange(false);
        }
      } catch (err) {
        console.log("err-fetchLoyaltyWelcomePlusTotal", err);
        setloader((currValue) => ({
          ...currValue,
          loyaltyWelcomePlusTotal: false,
        }));
      }
    };
    const fetchLoyaltyCreditCardTotal = async () => {
      try {
        setloader((currValue) => ({
          ...currValue,
          loyaltyCreditCardTotal: true,
        }));
        let url =
          process.env.REACT_APP_API_ENDPOINT +
          process.env.REACT_APP_CUSTOMER_LOYALTY_WELCOME_Total +
          "&startDate=" +
          periodStartDateTY +
          "&endDate=" +
          periodEndDateTY +
          "&loyaltyBanner=CC";
        if (correctDateRange) {
          await axios({ url }).then((res) => {
            setloader((currValue) => ({
              ...currValue,
              loyaltyCreditCardTotal: false,
            }));
            setLoyaltyCreditCardTotal(res.data);
          });
          setCorrectDateRange(false);
        }
      } catch (err) {
        console.log("err-fetchLoyaltyCreditCardTotal", err);
        setloader((currValue) => ({
          ...currValue,
          fetchLoyaltyCreditCardTotal: false,
        }));
      }
    };
    if (
      localStorage.getItem("isLOYALTY") === "Y" &&
      selectedLoyalityPeriodId &&
      selectedLoyalityChannelId === "1" &&
      periodEndDateLY !== ""
    ) {
      fetchBPlusReport();
      setSortSelector({
        cityAscending: true,
        districtAscending: true,
        stateAscending: true,
        regionAscending: true,
        arrowIcon: "default",
      });
    } else {
      setbeyondPlusReport();
    }

    if (selectedLoyalityCustId === "LOYALTY") {
      fetchLoyaltyWelcome();
      fetchLoyaltyWelcomePlus();
      fetchLoyaltyWelcomeTotal();
      fetchLoyaltyWelcomePlusTotal();
      fetchLoyaltyCreditCard();
      fetchLoyaltyCreditCardTotal();
    }
  }, [
    selectedLoyalityPeriodId,
    selectedLoyalityBannerId,
    selectedLoyalityCustId,
    selectedLoyalityChannelId,
    periodStartDateTY,
    periodEndDateTY,
    periodEndDateLY,
    periodStartDateLY,
  ]);

  useEffect(() => {
    const fetchCcData = async () => {
      try {
        setloader((currValue) => ({
          ...currValue,
          ccData: true,
        }));
        let url =
          process.env.REACT_APP_API_ENDPOINT +
          process.env.REACT_APP_STORE_CC +
          "concept=" +
          selectedLoyalityBannerId +
          "&startDate=" +
          periodStartDateTY +
          "&endDate=" +
          periodEndDateTY;
        if (correctDateRange) {
          await axios({ url }).then((res) => {
            setloader((currValue) => ({
              ...currValue,
              ccData: false,
            }));
            //Sorting data by Store Number as default
            setCcData(
              res.data.sort((a, b) => {
                return Number(a.STORE_NBR) - Number(b.STORE_NBR);
              })
            );
          });
          setCorrectDateRange(false);
        }
      } catch (err) {
        console.log("err-fetchCcData", err);
        setloader((currValue) => ({
          ...currValue,
          ccData: false,
        }));
      }
    };
    if (
      localStorage.getItem("isLOYALTY") === "Y" &&
      selectedLoyalityPeriodId &&
      selectedLoyalityChannelId === "1" &&
      periodEndDateLY !== ""
    ) {
      fetchCcData();
      setCCSortSelector({
        cityAscending: true,
        districtAscending: true,
        stateAscending: true,
        regionAscending: true,
        arrowIcon: "default",
      });
    } else {
      setCcData();
    }
  }, [
    selectedLoyalityPeriodId,
    selectedLoyalityBannerId,
    selectedLoyalityCustId,
    selectedLoyalityChannelId,
    periodStartDateTY,
    periodEndDateTY,
    periodEndDateLY,
    periodStartDateLY,
  ]);

  useEffect(() => {
    const getLastRefreshTime = async () => {
      try {
        setloader((currValue) => ({
          ...currValue,
          refreshTime: true,
        }));
        let url =
          process.env.REACT_APP_API_ENDPOINT +
          process.env.REACT_APP_REFRESH_TIME +
          "dagId=LOYALTY";
        await axios({ url }).then((res) => {
          setloader((currValue) => ({
            ...currValue,
            refreshTime: false,
          }));
          setRefreshTime(res.data);
        });
      } catch (err) {
        setloader((currValue) => ({
          ...currValue,
          refreshTime: true,
        }));
        console.log("err-getLastRefreshTime", err);
      }
    };
    getLastRefreshTime();
  }, []);

  return localStorage.getItem("isLOYALTY") === "Y" ? (
    <div>
      {refreshTime.length > 0 && <NotificationMessage message={refreshDate} />}
      <div className="mt-1 d-flex align-items-center headings">
        <div className="d-flex justify-content-start p-3">
          <span className="progselectupText">Concept</span>
        </div>
        <div className="d-flex justify-content-start p-3">
          <span className="progselectupText" style={{ paddingLeft: "0px" }}>
            Channel Type
          </span>
        </div>
        <div className="d-flex justify-content-start p-3">
          <span className="progselectupText" style={{ paddingLeft: "0px" }}>
            Type
          </span>
        </div>
        <div className="d-flex justify-content-start p-3">
          <span className="progselectupText" style={{ paddingLeft: "43px" }}>
            Period
          </span>
        </div>
      </div>
      <div className="mt-3 d-flex align-items-center">
        <div className="d-flex justify-content-start p-3">
          <Dropdown className="d-inline">
            <Dropdown.Toggle>{selectedLoyalityBanner.value}</Dropdown.Toggle>
            <Dropdown.Menu
              className="dropdown-menu-ext"
              onClick={(e) => handleLoyalityBanner(e)}
            >
              {selectedLoyalityCustId === "BPLUS"
                ? LoyalityBanners.filter((data) => {
                    return data.id === "1";
                  }).map((data) => {
                    return (
                      <Dropdown.Item
                        key={data.id}
                        className="dropdown-item-ext"
                        id={data.id}
                      >
                        {data.value}
                      </Dropdown.Item>
                    );
                  })
                : selectedLoyalityCustId === "LOYALTY"
                ? LoyalityBanners.filter((data) => {
                    return data.id === "1,2,3,5";
                  }).map((data) => {
                    return (
                      <Dropdown.Item
                        key={data.id}
                        className="dropdown-item-ext"
                        id={data.id}
                      >
                        {data.value}
                      </Dropdown.Item>
                    );
                  })
                : LoyalityBanners.map((data) => {
                    return (
                      <Dropdown.Item
                        key={data.id}
                        className="dropdown-item-ext"
                        id={data.id}
                      >
                        {data.value}
                      </Dropdown.Item>
                    );
                  })}
            </Dropdown.Menu>
          </Dropdown>
        </div>
        <div className="d-flex justify-content-start p-3">
          <Dropdown className="d-inline">
            <Dropdown.Toggle>{selectedLoyalityChannel.value}</Dropdown.Toggle>
            <Dropdown.Menu
              className="dropdown-menu-ext"
              onClick={(e) => handleLoyalityChannel(e)}
            >
              {selectedLoyalityCustId === "LOYALTY"
                ? LoyalityChannels.filter((data) => {
                    return data.id === "0";
                  }).map((data) => {
                    return (
                      <Dropdown.Item
                        key={data.id}
                        className="dropdown-item-ext"
                        id={data.id}
                      >
                        {data.value}
                      </Dropdown.Item>
                    );
                  })
                : LoyalityChannels.map((data) => {
                    return (
                      <Dropdown.Item
                        key={data.id}
                        className="dropdown-item-ext"
                        id={data.id}
                      >
                        {data.value}
                      </Dropdown.Item>
                    );
                  })}
            </Dropdown.Menu>
          </Dropdown>
        </div>
        <div className="d-flex justify-content-start p-3">
          <Dropdown className="d-inline">
            <Dropdown.Toggle>{selectedLoyalityCategory.value}</Dropdown.Toggle>
            <Dropdown.Menu
              className="dropdown-menu-ext"
              onClick={(e) => handleLoyalityCategory(e)}
            >
              {LoyalityCategory.map((data) => {
                return (
                  <Dropdown.Item
                    key={data.id}
                    className="dropdown-item-ext"
                    id={data.id}
                  >
                    {data.value}
                  </Dropdown.Item>
                );
              })}
            </Dropdown.Menu>
          </Dropdown>
        </div>
        <div className="d-flex justify-content-start p-3">
          <Dropdown className="d-inline">
            <Dropdown.Toggle>{selectedLoyalityPeriod.value}</Dropdown.Toggle>
            <Dropdown.Menu
              className="dropdown-menu-ext"
              onClick={(e) => handleLoyalityPeriod(e)}
            >
              {LoyalityPeriods.map((data) => {
                return (
                  <Dropdown.Item
                    key={data.id}
                    className="dropdown-item-ext"
                    id={data.id}
                  >
                    {data.value}
                  </Dropdown.Item>
                );
              })}
            </Dropdown.Menu>
          </Dropdown>
        </div>
        <div>
          {periodEndDateLY !== "" ? (
            <div>
              <span>{`(${getDateFormatFromDB(
                periodStartDateTY
              )} - ${getDateFormatFromDB(periodEndDateTY)}`}</span>
              <span className="vsStyling"> vs </span>
              <span>{`${getDateFormatFromDB(
                periodStartDateLY
              )} - ${getDateFormatFromDB(periodEndDateLY)})`}</span>
            </div>
          ) : (
            <div>
              <span>{`( - `}</span>
              <span className="vsStyling"> vs </span>
              <span>{` - )`}</span>
            </div>
          )}
        </div>
      </div>
      <div>
        {selectedLoyalityCustId === "BPLUS" ? (
          <BeyondPlus
            loading={loading}
            beyondPlusReport={beyondPlusReport}
            sortSelection={sortSelection}
            sortBPlusReport={sortBPlusReport}
          />
        ) : selectedLoyalityCustId === "LOYALTY" ? (
          <LoyaltyWelcome
            loading={loading}
            loyalityWelcome={loyalityWelcome}
            loyalityWelcomePlus={loyalityWelcomePlus}
            loyaltyWelcomeTotal={loyaltyWelcomeTotal}
            loyaltyWelcomePlusTotal={loyaltyWelcomePlusTotal}
            loyalityCreditCard={loyalityCreditCard}
            loyaltyCreditCardTotal={loyaltyCreditCardTotal}
          />
        ) : selectedLoyalityCustId === "CC" ? (
          <StoreCC
            loading={loading}
            ccData={ccData}
            sortSelectionCC={sortSelectionCC}
            sortCC={sortCC}
          />
        ) : (
          ""
        )}
      </div>
    </div>
  ) : (
    <NoAccess tabName="Loyality" />
  );
}

export default LoyalityContainer;
