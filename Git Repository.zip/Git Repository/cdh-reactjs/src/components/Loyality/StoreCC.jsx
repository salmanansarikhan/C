import React from "react";
import { Table } from "react-bootstrap";
import "../Loyality/BeyondPlusContainer.css";
import LoaderForRow from "../LoaderForTable/LoaderForRow";
import { FontAwesomeIcon } from "@fortawesome/react-fontawesome";
import { faCaretUp, faCaretDown } from "@fortawesome/free-solid-svg-icons";
import "./LoyalityContainer.css";
import { decimalCurrencyFormat } from "../ScoreCard/Marketing";

function StoreCC({ loading, ccData, sortSelectionCC, sortCC }) {
  return (
    <div>
      <div className="p-3" style={{ marginBottom: "50px" }}>
        <Table style={{ textAlign: "center" }} striped bordered hover size="sm">
          <thead className="text">
            <tr>
              <th rowSpan="2">
                Store
                {sortSelectionCC.arrowIcon === "default" && (
                  <FontAwesomeIcon
                    style={{ paddingLeft: "5px" }}
                    icon={faCaretUp}
                  />
                )}
              </th>
              <th
                rowSpan="2"
                style={{ cursor: "pointer" }}
                onClick={() => {
                  sortCC("district");
                }}
              >
                District
                {(sortSelectionCC.arrowIcon === "districtUp" && (
                  <FontAwesomeIcon
                    style={{ paddingLeft: "5px" }}
                    icon={faCaretUp}
                  />
                )) ||
                  (sortSelectionCC.arrowIcon === "districtDown" && (
                    <FontAwesomeIcon
                      style={{ paddingLeft: "5px" }}
                      icon={faCaretDown}
                    />
                  ))}
              </th>
              <th
                rowSpan="2"
                style={{ cursor: "pointer" }}
                onClick={() => {
                  sortCC("region");
                }}
              >
                Region
                {(sortSelectionCC.arrowIcon === "regionUp" && (
                  <FontAwesomeIcon
                    style={{ paddingLeft: "5px" }}
                    icon={faCaretUp}
                  />
                )) ||
                  (sortSelectionCC.arrowIcon === "regionDown" && (
                    <FontAwesomeIcon
                      style={{ paddingLeft: "5px" }}
                      icon={faCaretDown}
                    />
                  ))}
              </th>
            </tr>
            <tr>
              <th>Credit Card</th>
            </tr>
          </thead>
          <tbody className="textTable">
            {loading.ccData ? (
              <tr>
                <LoaderForRow height={"500px"} tdCount={4} />
              </tr>
            ) : ccData != undefined && ccData.length !== 0 ? (
              ccData != undefined &&
              ccData.length !== 0 &&
              ccData.map((data) => {
                return (
                  <tr class="align-middle">
                    <td>
                      {data.STORE_NBR !== undefined &&
                      data.STORE_NBR.length !== 0 &&
                      data.STORE_NBR !== "-999999"
                        ? data.STORE_NBR
                        : "-"}
                    </td>
                    <td>
                      {data.DISTRICT !== undefined &&
                      data.DISTRICT.length !== 0 &&
                      data.DISTRICT !== "-999999"
                        ? data.DISTRICT
                        : "-"}
                    </td>
                    <td>
                      {data.REGION !== undefined &&
                      data.REGION.length !== 0 &&
                      data.REGION !== "-999999"
                        ? data.REGION
                        : "-"}
                    </td>
                    <td>
                      <span>
                        {data.CC_TY !== undefined &&
                        data.CC_TY.length !== 0 &&
                        data.CC_TY !== "-999999"
                          ? data.CC_TY
                          : "-"}
                      </span>
                      <br />
                      <span style={{ fontSize: "11px" }}>
                        {data.CC_YOY !== undefined &&
                        data.CC_YOY.length !== 0 &&
                        data.CC_YOY !== "-999999" ? (
                          Number(data.CC_YOY).toFixed(2).includes("-") ? (
                            <span style={{ color: "red" }}>
                              {`${decimalCurrencyFormat(data.CC_YOY)}%`}
                            </span>
                          ) : (
                            <span style={{ color: "green" }}>
                              {`${decimalCurrencyFormat(data.CC_YOY)}%`}
                            </span>
                          )
                        ) : (
                          "-"
                        )}
                      </span>
                    </td>
                  </tr>
                );
              })
            ) : (
              <tr>
                <td align="center" colSpan="6" style={{ fontWeight: "500" }}>
                  DATA NOT AVAILABLE
                </td>
              </tr>
            )}
          </tbody>
        </Table>
      </div>
    </div>
  );
}

export default StoreCC;
