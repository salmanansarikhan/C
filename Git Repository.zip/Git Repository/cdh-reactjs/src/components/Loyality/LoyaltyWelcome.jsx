import React from "react";
import { Table } from "react-bootstrap";
import LoaderForRow from "../LoaderForTable/LoaderForRow";
import "../Loyality/BeyondPlusContainer.css";
import { currencyFormat } from "../CdhHome/CdhHome";
import { decimalCurrencyFormat } from "../ScoreCard/Marketing";
import { gettooltip } from "../Utils";

function LoyaltyWelcome({
  loyalityWelcome,
  loyalityWelcomePlus,
  loading,
  loyaltyWelcomeTotal,
  loyaltyWelcomePlusTotal,
  loyalityCreditCard,
  loyaltyCreditCardTotal,
}) {
  return (
    <div>
      <div className="p-3" style={{ marginBottom: "50px" }}>
        <Table style={{ textAlign: "center" }} striped bordered hover size="sm">
          <thead className="text">
            <tr>
              <th></th>
              <th>Sign-ups</th>
              <th>
                % of Total Transactions{" "}
                {gettooltip(
                  "TotalTransactionsInfoIcon",
                  "TotalTransactions",
                  "TotalTransactions",
                  "Number of loyalty Transaction divided by",
                  "number of total transaction"
                )}
              </th>
              <th>Online</th>
              <th>
                % of Online Transactions{" "}
                {gettooltip(
                  "OnlineTransactionsInfoIcon",
                  "OnlineTransactions",
                  "OnlineTransactions",
                  "Number of online loyalty Transaction divided by",
                  "number of total online transaction"
                )}
              </th>
              <th>In-Store</th>
              <th>
                % of Store Transactions{" "}
                {gettooltip(
                  "StoreTransactionsInfoIcon",
                  "StoreTransactions",
                  "StoreTransactions",
                  "Number of Store loyalty Transaction divided by",
                  "number of total store transaction"
                )}
              </th>
              <th>Customer Care</th>
              <th>
                % New Accounts{" "}
                {gettooltip(
                  "NewAccountsInfoIcon",
                  "NewAccounts",
                  "NewAccounts",
                  "Percentage of net new customers whose email address",
                  "we didn’t have in our database before they signed up"
                )}
              </th>
            </tr>
          </thead>
          <tbody>
            <tr style={{ fontWeight: "500" }}>
              <td style={{ backgroundColor: "lightgrey" }}>Welcome</td>
              {loading.loyaltyWelcomeTotal ? (
                <>
                  <LoaderForRow tdCount={8} />
                </>
              ) : (
                <>
                  <th>
                    {loyaltyWelcomeTotal !== undefined &&
                    loyaltyWelcomeTotal.length !== 0 &&
                    loyaltyWelcomeTotal[0].signup_count !== "-999999"
                      ? currencyFormat(loyaltyWelcomeTotal[0].signup_count)
                      : "-"}
                  </th>
                  <th>
                    {loyaltyWelcomeTotal !== undefined &&
                    loyaltyWelcomeTotal.length !== 0 &&
                    loyaltyWelcomeTotal[0].PER_loyalty_transaction_count !==
                      "-999999"
                      ? `${decimalCurrencyFormat(
                          loyaltyWelcomeTotal[0].PER_loyalty_transaction_count
                        )}%`
                      : "-"}
                  </th>
                  <th>
                    {loyaltyWelcomeTotal !== undefined &&
                    loyaltyWelcomeTotal.length !== 0 &&
                    loyaltyWelcomeTotal[0].signup_online_count !== "-999999"
                      ? currencyFormat(
                          loyaltyWelcomeTotal[0].signup_online_count
                        )
                      : "-"}
                  </th>
                  <th>
                    {loyaltyWelcomeTotal !== undefined &&
                    loyaltyWelcomeTotal.length !== 0 &&
                    loyaltyWelcomeTotal[0]
                      .PER_loyalty_online_transaction_count !== "-999999"
                      ? `${decimalCurrencyFormat(
                          loyaltyWelcomeTotal[0]
                            .PER_loyalty_online_transaction_count
                        )}%`
                      : "-"}
                  </th>
                  <th>
                    {loyaltyWelcomeTotal !== undefined &&
                    loyaltyWelcomeTotal.length !== 0 &&
                    loyaltyWelcomeTotal[0].signup_store_count !== "-999999"
                      ? currencyFormat(
                          loyaltyWelcomeTotal[0].signup_store_count
                        )
                      : "-"}
                  </th>
                  <th>
                    {loyaltyWelcomeTotal !== undefined &&
                    loyaltyWelcomeTotal.length !== 0 &&
                    loyaltyWelcomeTotal[0]
                      .PER_loyalty_store_transaction_count !== "-999999"
                      ? `${decimalCurrencyFormat(
                          loyaltyWelcomeTotal[0]
                            .PER_loyalty_store_transaction_count
                        )}%`
                      : "-"}
                  </th>
                  <th>
                    {loyaltyWelcomeTotal !== undefined &&
                    loyaltyWelcomeTotal.length !== 0 &&
                    loyaltyWelcomeTotal[0].signup_cs_count !== "-999999"
                      ? currencyFormat(loyaltyWelcomeTotal[0].signup_cs_count)
                      : "-"}
                  </th>
                  <th>
                    {loyaltyWelcomeTotal !== undefined &&
                    loyaltyWelcomeTotal.length !== 0 &&
                    loyaltyWelcomeTotal[0].per_new_signup !==
                      "-999999"
                      ? `${decimalCurrencyFormat(
                          loyaltyWelcomeTotal[0].per_new_signup
                        )}%`
                      : "-"}
                  </th>
                </>
              )}
            </tr>
            {loading.welcomeData ? (
              <></>
            ) : (
              <>
                <tr>
                  <td>
                    {loyalityWelcome !== undefined &&
                      loyalityWelcome.length !== 0 &&
                      loyalityWelcome[0].concept_short_name}
                  </td>
                  <td>
                    {loyalityWelcome !== undefined &&
                    loyalityWelcome.length !== 0 &&
                    loyalityWelcome[0].signup_count !== "-999999"
                      ? currencyFormat(loyalityWelcome[0].signup_count)
                      : "-"}
                  </td>
                  <td>
                    {loyalityWelcome !== undefined &&
                    loyalityWelcome.length !== 0 &&
                    loyalityWelcome[0].PER_loyalty_transaction_count !==
                      "-999999"
                      ? `${decimalCurrencyFormat(
                          loyalityWelcome[0].PER_loyalty_transaction_count
                        )}%`
                      : "-"}
                  </td>
                  <td>
                    {loyalityWelcome !== undefined &&
                    loyalityWelcome.length !== 0 &&
                    loyalityWelcome[0].signup_online_count !== "-999999"
                      ? currencyFormat(loyalityWelcome[0].signup_online_count)
                      : "-"}
                  </td>
                  <td>
                    {loyalityWelcome !== undefined &&
                    loyalityWelcome.length !== 0 &&
                    loyalityWelcome[0].PER_loyalty_online_transaction_count !==
                      "-999999"
                      ? `${decimalCurrencyFormat(
                          loyalityWelcome[0]
                            .PER_loyalty_online_transaction_count
                        )}%`
                      : "-"}
                  </td>
                  <td>
                    {loyalityWelcome !== undefined &&
                    loyalityWelcome.length !== 0 &&
                    loyalityWelcome[0].signup_store_count !== "-999999"
                      ? currencyFormat(loyalityWelcome[0].signup_store_count)
                      : "-"}
                  </td>
                  <td>
                    {loyalityWelcome !== undefined &&
                    loyalityWelcome.length !== 0 &&
                    loyalityWelcome[0].PER_loyalty_store_transaction_count !==
                      "-999999"
                      ? `${decimalCurrencyFormat(
                          loyalityWelcome[0].PER_loyalty_store_transaction_count
                        )}%`
                      : "-"}
                  </td>
                  <td>
                    {loyalityWelcome !== undefined &&
                    loyalityWelcome.length !== 0 &&
                    loyalityWelcome[0].signup_cs_count !== "-999999"
                      ? currencyFormat(loyalityWelcome[0].signup_cs_count)
                      : "-"}
                  </td>
                  <td>
                    {loyalityWelcome !== undefined &&
                    loyalityWelcome.length !== 0 &&
                    loyalityWelcome[0].per_new_signup !==
                      "-999999"
                      ? `${decimalCurrencyFormat(
                          loyalityWelcome[0].per_new_signup
                        )}%`
                      : "-"}
                  </td>
                </tr>
                <tr>
                  <td>
                    {loyalityWelcome !== undefined &&
                      loyalityWelcome.length !== 0 &&
                      loyalityWelcome[1].concept_short_name}
                  </td>
                  <td>
                    {loyalityWelcome !== undefined &&
                    loyalityWelcome.length !== 0 &&
                    loyalityWelcome[1].signup_count !== "-999999"
                      ? currencyFormat(loyalityWelcome[1].signup_count)
                      : "-"}
                  </td>
                  <td>
                    {loyalityWelcome !== undefined &&
                    loyalityWelcome.length !== 0 &&
                    loyalityWelcome[1].PER_loyalty_transaction_count !==
                      "-999999"
                      ? `${decimalCurrencyFormat(
                          loyalityWelcome[1].PER_loyalty_transaction_count
                        )}%`
                      : "-"}
                  </td>
                  <td>
                    {loyalityWelcome !== undefined &&
                    loyalityWelcome.length !== 0 &&
                    loyalityWelcome[1].signup_online_count !== "-999999"
                      ? currencyFormat(loyalityWelcome[1].signup_online_count)
                      : "-"}
                  </td>
                  <td>
                    {loyalityWelcome !== undefined &&
                    loyalityWelcome.length !== 0 &&
                    loyalityWelcome[1].PER_loyalty_online_transaction_count !==
                      "-999999"
                      ? `${decimalCurrencyFormat(
                          loyalityWelcome[1]
                            .PER_loyalty_online_transaction_count
                        )}%`
                      : "-"}
                  </td>
                  <td>
                    {loyalityWelcome !== undefined &&
                    loyalityWelcome.length !== 0 &&
                    loyalityWelcome[1].signup_store_count !== "-999999"
                      ? currencyFormat(loyalityWelcome[1].signup_store_count)
                      : "-"}
                  </td>
                  <td>
                    {loyalityWelcome !== undefined &&
                    loyalityWelcome.length !== 0 &&
                    loyalityWelcome[1].PER_loyalty_store_transaction_count !==
                      "-999999"
                      ? `${decimalCurrencyFormat(
                          loyalityWelcome[1].PER_loyalty_store_transaction_count
                        )}%`
                      : "-"}
                  </td>
                  <td>
                    {loyalityWelcome !== undefined &&
                    loyalityWelcome.length !== 0 &&
                    loyalityWelcome[1].signup_cs_count !== "-999999"
                      ? currencyFormat(loyalityWelcome[1].signup_cs_count)
                      : "-"}
                  </td>
                  <td>
                    {loyalityWelcome !== undefined &&
                    loyalityWelcome.length !== 0 &&
                    loyalityWelcome[1].per_new_signup !==
                      "-999999"
                      ? `${decimalCurrencyFormat(
                          loyalityWelcome[1].per_new_signup
                        )}%`
                      : "-"}
                  </td>
                </tr>
                <tr>
                  <td>
                    {loyalityWelcome !== undefined &&
                      loyalityWelcome.length !== 0 &&
                      loyalityWelcome[2].concept_short_name}
                  </td>
                  <td>
                    {loyalityWelcome !== undefined &&
                    loyalityWelcome.length !== 0 &&
                    loyalityWelcome[2].signup_count !== "-999999"
                      ? currencyFormat(loyalityWelcome[2].signup_count)
                      : "-"}
                  </td>
                  <td>
                    {loyalityWelcome !== undefined &&
                    loyalityWelcome.length !== 0 &&
                    loyalityWelcome[2].PER_loyalty_transaction_count !==
                      "-999999"
                      ? `${decimalCurrencyFormat(
                          loyalityWelcome[2].PER_loyalty_transaction_count
                        )}%`
                      : "-"}
                  </td>
                  <td>
                    {loyalityWelcome !== undefined &&
                    loyalityWelcome.length !== 0 &&
                    loyalityWelcome[2].signup_online_count !== "-999999"
                      ? currencyFormat(loyalityWelcome[2].signup_online_count)
                      : "-"}
                  </td>
                  <td>
                    {loyalityWelcome !== undefined &&
                    loyalityWelcome.length !== 0 &&
                    loyalityWelcome[2].PER_loyalty_online_transaction_count !==
                      "-999999"
                      ? `${decimalCurrencyFormat(
                          loyalityWelcome[2]
                            .PER_loyalty_online_transaction_count
                        )}%`
                      : "-"}
                  </td>
                  <td>
                    {loyalityWelcome !== undefined &&
                    loyalityWelcome.length !== 0 &&
                    loyalityWelcome[2].signup_store_count !== "-999999"
                      ? currencyFormat(loyalityWelcome[2].signup_store_count)
                      : "-"}
                  </td>
                  <td>
                    {loyalityWelcome !== undefined &&
                    loyalityWelcome.length !== 0 &&
                    loyalityWelcome[2].PER_loyalty_store_transaction_count !==
                      "-999999"
                      ? `${decimalCurrencyFormat(
                          loyalityWelcome[2].PER_loyalty_store_transaction_count
                        )}%`
                      : "-"}
                  </td>
                  <td>
                    {loyalityWelcome !== undefined &&
                    loyalityWelcome.length !== 0 &&
                    loyalityWelcome[2].signup_cs_count !== "-999999"
                      ? currencyFormat(loyalityWelcome[2].signup_cs_count)
                      : "-"}
                  </td>
                  <td>
                    {loyalityWelcome !== undefined &&
                    loyalityWelcome.length !== 0 &&
                    loyalityWelcome[2].per_new_signup !==
                      "-999999"
                      ? `${decimalCurrencyFormat(
                          loyalityWelcome[2].per_new_signup
                        )}%`
                      : "-"}
                  </td>
                </tr>
                <tr>
                  <td>
                    {loyalityWelcome !== undefined &&
                      loyalityWelcome.length !== 0 &&
                      loyalityWelcome[3].concept_short_name}
                  </td>
                  <td>
                    {loyalityWelcome !== undefined &&
                    loyalityWelcome.length !== 0 &&
                    loyalityWelcome[3].signup_count !== "-999999"
                      ? currencyFormat(loyalityWelcome[3].signup_count)
                      : "-"}
                  </td>
                  <td>
                    {loyalityWelcome !== undefined &&
                    loyalityWelcome.length !== 0 &&
                    loyalityWelcome[3].PER_loyalty_transaction_count !==
                      "-999999"
                      ? `${decimalCurrencyFormat(
                          loyalityWelcome[3].PER_loyalty_transaction_count
                        )}%`
                      : "-"}
                  </td>
                  <td>
                    {loyalityWelcome !== undefined &&
                    loyalityWelcome.length !== 0 &&
                    loyalityWelcome[3].signup_online_count !== "-999999"
                      ? currencyFormat(loyalityWelcome[3].signup_online_count)
                      : "-"}
                  </td>
                  <td>
                    {loyalityWelcome !== undefined &&
                    loyalityWelcome.length !== 0 &&
                    loyalityWelcome[3].PER_loyalty_online_transaction_count !==
                      "-999999"
                      ? `${decimalCurrencyFormat(
                          loyalityWelcome[3]
                            .PER_loyalty_online_transaction_count
                        )}%`
                      : "-"}
                  </td>
                  <td>
                    {loyalityWelcome !== undefined &&
                    loyalityWelcome.length !== 0 &&
                    loyalityWelcome[3].signup_store_count !== "-999999"
                      ? currencyFormat(loyalityWelcome[3].signup_store_count)
                      : "-"}
                  </td>
                  <td>
                    {loyalityWelcome !== undefined &&
                    loyalityWelcome.length !== 0 &&
                    loyalityWelcome[3].PER_loyalty_store_transaction_count !==
                      "-999999"
                      ? `${decimalCurrencyFormat(
                          loyalityWelcome[3].PER_loyalty_store_transaction_count
                        )}%`
                      : "-"}
                  </td>
                  <td>
                    {loyalityWelcome !== undefined &&
                    loyalityWelcome.length !== 0 &&
                    loyalityWelcome[3].signup_cs_count !== "-999999"
                      ? currencyFormat(loyalityWelcome[3].signup_cs_count)
                      : "-"}
                  </td>
                  <td>
                    {loyalityWelcome !== undefined &&
                    loyalityWelcome.length !== 0 &&
                    loyalityWelcome[3].per_new_signup !==
                      "-999999"
                      ? `${decimalCurrencyFormat(
                          loyalityWelcome[3]
                            .per_new_signup
                        )}%`
                      : "-"}
                  </td>
                </tr>
              </>
            )}
            <tr style={{ fontWeight: "500" }}>
              <td style={{ backgroundColor: "lightgrey", fontWeight: "500" }}>
                Welcome+
              </td>
              {loading.loyaltyWelcomePlusTotal ? (
                <>
                  <LoaderForRow tdCount={8} />
                </>
              ) : (
                <>
                  <th>
                    {loyaltyWelcomePlusTotal !== undefined &&
                    loyaltyWelcomePlusTotal.length !== 0 &&
                    loyaltyWelcomePlusTotal[0].signup_count !== "-999999"
                      ? currencyFormat(loyaltyWelcomePlusTotal[0].signup_count)
                      : "-"}
                  </th>
                  <th>
                    {loyaltyWelcomePlusTotal !== undefined &&
                    loyaltyWelcomePlusTotal.length !== 0 &&
                    loyaltyWelcomePlusTotal[0].PER_loyalty_transaction_count !==
                      "-999999"
                      ? `${decimalCurrencyFormat(
                          loyaltyWelcomePlusTotal[0]
                            .PER_loyalty_transaction_count
                        )}%`
                      : "-"}
                  </th>
                  <th>
                    {loyaltyWelcomePlusTotal !== undefined &&
                    loyaltyWelcomePlusTotal.length !== 0 &&
                    loyaltyWelcomePlusTotal[0].signup_online_count !== "-999999"
                      ? currencyFormat(
                          loyaltyWelcomePlusTotal[0].signup_online_count
                        )
                      : "-"}
                  </th>
                  <th>
                    {loyaltyWelcomePlusTotal !== undefined &&
                    loyaltyWelcomePlusTotal.length !== 0 &&
                    loyaltyWelcomePlusTotal[0]
                      .PER_loyalty_online_transaction_count !== "-999999"
                      ? `${decimalCurrencyFormat(
                          loyaltyWelcomePlusTotal[0]
                            .PER_loyalty_online_transaction_count
                        )}%`
                      : "-"}
                  </th>
                  <th>
                    {loyaltyWelcomePlusTotal !== undefined &&
                    loyaltyWelcomePlusTotal.length !== 0 &&
                    loyaltyWelcomePlusTotal[0].signup_store_count !== "-999999"
                      ? currencyFormat(
                          loyaltyWelcomePlusTotal[0].signup_store_count
                        )
                      : "-"}
                  </th>
                  <th>
                    {loyaltyWelcomePlusTotal !== undefined &&
                    loyaltyWelcomePlusTotal.length !== 0 &&
                    loyaltyWelcomePlusTotal[0]
                      .PER_loyalty_store_transaction_count !== "-999999"
                      ? `${decimalCurrencyFormat(
                          loyaltyWelcomePlusTotal[0]
                            .PER_loyalty_store_transaction_count
                        )}%`
                      : "-"}
                  </th>
                  <th>
                    {loyaltyWelcomePlusTotal !== undefined &&
                    loyaltyWelcomePlusTotal.length !== 0 &&
                    loyaltyWelcomePlusTotal[0].signup_cs_count !== "-999999"
                      ? currencyFormat(
                          loyaltyWelcomePlusTotal[0].signup_cs_count
                        )
                      : "-"}
                  </th>
                  <th>
                    {loyaltyWelcomePlusTotal !== undefined &&
                    loyaltyWelcomePlusTotal.length !== 0 &&
                    loyaltyWelcomePlusTotal[0]
                      .per_new_signup !== "-999999"
                      ? `${decimalCurrencyFormat(
                          loyaltyWelcomePlusTotal[0]
                            .per_new_signup
                        )}%`
                      : "-"}
                  </th>
                </>
              )}
            </tr>
            {loading.welcomeDataPlus ? (
              <></>
            ) : (
              <>
                <tr>
                  <td>
                    {loyalityWelcomePlus !== undefined &&
                      loyalityWelcomePlus.length !== 0 &&
                      loyalityWelcomePlus[0].concept_short_name}
                  </td>
                  <td>
                    {loyalityWelcomePlus !== undefined &&
                    loyalityWelcomePlus.length !== 0 &&
                    loyalityWelcomePlus[0].signup_count !== "-999999"
                      ? currencyFormat(loyalityWelcomePlus[0].signup_count)
                      : "-"}
                  </td>
                  <td>
                    {loyalityWelcomePlus !== undefined &&
                    loyalityWelcomePlus.length !== 0 &&
                    loyalityWelcomePlus[0].PER_loyalty_transaction_count !==
                      "-999999"
                      ? `${decimalCurrencyFormat(
                          loyalityWelcomePlus[0].PER_loyalty_transaction_count
                        )}%`
                      : "-"}
                  </td>
                  <td>
                    {loyalityWelcomePlus !== undefined &&
                    loyalityWelcomePlus.length !== 0 &&
                    loyalityWelcomePlus[0].signup_online_count !== "-999999"
                      ? currencyFormat(
                          loyalityWelcomePlus[0].signup_online_count
                        )
                      : "-"}
                  </td>
                  <td>
                    {loyalityWelcomePlus !== undefined &&
                    loyalityWelcomePlus.length !== 0 &&
                    loyalityWelcomePlus[0]
                      .PER_loyalty_online_transaction_count !== "-999999"
                      ? `${decimalCurrencyFormat(
                          loyalityWelcomePlus[0]
                            .PER_loyalty_online_transaction_count
                        )}%`
                      : "-"}
                  </td>
                  <td>
                    {loyalityWelcomePlus !== undefined &&
                    loyalityWelcomePlus.length !== 0 &&
                    loyalityWelcomePlus[0].signup_store_count !== "-999999"
                      ? currencyFormat(
                          loyalityWelcomePlus[0].signup_store_count
                        )
                      : "-"}
                  </td>
                  <td>
                    {loyalityWelcomePlus !== undefined &&
                    loyalityWelcomePlus.length !== 0 &&
                    loyalityWelcomePlus[0]
                      .PER_loyalty_store_transaction_count !== "-999999"
                      ? `${decimalCurrencyFormat(
                          loyalityWelcomePlus[0]
                            .PER_loyalty_store_transaction_count
                        )}%`
                      : "-"}
                  </td>
                  <td>
                    {loyalityWelcomePlus !== undefined &&
                    loyalityWelcomePlus.length !== 0 &&
                    loyalityWelcomePlus[0].signup_cs_count !== "-999999"
                      ? currencyFormat(loyalityWelcomePlus[0].signup_cs_count)
                      : "-"}
                  </td>
                  <td>
                    {loyalityWelcomePlus !== undefined &&
                    loyalityWelcomePlus.length !== 0 &&
                    loyalityWelcomePlus[0].per_new_signup !==
                      "-999999"
                      ? `${decimalCurrencyFormat(
                          loyalityWelcomePlus[0].per_new_signup
                        )}%`
                      : "-"}
                  </td>
                </tr>
                <tr>
                  <td>
                    {loyalityWelcomePlus !== undefined &&
                      loyalityWelcomePlus.length !== 0 &&
                      loyalityWelcomePlus[1].concept_short_name}
                  </td>
                  <td>
                    {loyalityWelcomePlus !== undefined &&
                    loyalityWelcomePlus.length !== 0 &&
                    loyalityWelcomePlus[1].signup_count !== "-999999"
                      ? currencyFormat(loyalityWelcomePlus[1].signup_count)
                      : "-"}
                  </td>
                  <td>
                    {loyalityWelcomePlus !== undefined &&
                    loyalityWelcomePlus.length !== 0 &&
                    loyalityWelcomePlus[1].PER_loyalty_transaction_count !==
                      "-999999"
                      ? `${decimalCurrencyFormat(
                          loyalityWelcomePlus[1].PER_loyalty_transaction_count
                        )}%`
                      : "-"}
                  </td>
                  <td>
                    {loyalityWelcomePlus !== undefined &&
                    loyalityWelcomePlus.length !== 0 &&
                    loyalityWelcomePlus[1].signup_online_count !== "-999999"
                      ? currencyFormat(
                          loyalityWelcomePlus[1].signup_online_count
                        )
                      : "-"}
                  </td>
                  <td>
                    {loyalityWelcomePlus !== undefined &&
                    loyalityWelcomePlus.length !== 0 &&
                    loyalityWelcomePlus[1]
                      .PER_loyalty_online_transaction_count !== "-999999"
                      ? `${decimalCurrencyFormat(
                          loyalityWelcomePlus[1]
                            .PER_loyalty_online_transaction_count
                        )}%`
                      : "-"}
                  </td>
                  <td>
                    {loyalityWelcomePlus !== undefined &&
                    loyalityWelcomePlus.length !== 0 &&
                    loyalityWelcomePlus[1].signup_store_count !== "-999999"
                      ? currencyFormat(
                          loyalityWelcomePlus[1].signup_store_count
                        )
                      : "-"}
                  </td>
                  <td>
                    {loyalityWelcomePlus !== undefined &&
                    loyalityWelcomePlus.length !== 0 &&
                    loyalityWelcomePlus[1]
                      .PER_loyalty_store_transaction_count !== "-999999"
                      ? `${decimalCurrencyFormat(
                          loyalityWelcomePlus[1]
                            .PER_loyalty_store_transaction_count
                        )}%`
                      : "-"}
                  </td>
                  <td>
                    {loyalityWelcomePlus !== undefined &&
                    loyalityWelcomePlus.length !== 0 &&
                    loyalityWelcomePlus[1].signup_cs_count !== "-999999"
                      ? currencyFormat(loyalityWelcomePlus[1].signup_cs_count)
                      : "-"}
                  </td>
                  <td>
                    {loyalityWelcomePlus !== undefined &&
                    loyalityWelcomePlus.length !== 0 &&
                    loyalityWelcomePlus[1].per_new_signup !==
                      "-999999"
                      ? `${decimalCurrencyFormat(
                          loyalityWelcomePlus[1].per_new_signup
                        )}%`
                      : "-"}
                  </td>
                </tr>
                <tr>
                  <td>
                    {loyalityWelcomePlus !== undefined &&
                      loyalityWelcomePlus.length !== 0 &&
                      loyalityWelcomePlus[2].concept_short_name}
                  </td>
                  <td>
                    {loyalityWelcomePlus !== undefined &&
                    loyalityWelcomePlus.length !== 0 &&
                    loyalityWelcomePlus[2].signup_count !== "-999999"
                      ? currencyFormat(loyalityWelcomePlus[2].signup_count)
                      : "-"}
                  </td>
                  <td>
                    {loyalityWelcomePlus !== undefined &&
                    loyalityWelcomePlus.length !== 0 &&
                    loyalityWelcomePlus[2].PER_loyalty_transaction_count !==
                      "-999999"
                      ? `${decimalCurrencyFormat(
                          loyalityWelcomePlus[2].PER_loyalty_transaction_count
                        )}%`
                      : "-"}
                  </td>
                  <td>
                    {loyalityWelcomePlus !== undefined &&
                    loyalityWelcomePlus.length !== 0 &&
                    loyalityWelcomePlus[2].signup_online_count !== "-999999"
                      ? currencyFormat(
                          loyalityWelcomePlus[2].signup_online_count
                        )
                      : "-"}
                  </td>
                  <td>
                    {loyalityWelcomePlus !== undefined &&
                    loyalityWelcomePlus.length !== 0 &&
                    loyalityWelcomePlus[2]
                      .PER_loyalty_online_transaction_count !== "-999999"
                      ? `${decimalCurrencyFormat(
                          loyalityWelcomePlus[2]
                            .PER_loyalty_online_transaction_count
                        )}%`
                      : "-"}
                  </td>
                  <td>
                    {loyalityWelcomePlus !== undefined &&
                    loyalityWelcomePlus.length !== 0 &&
                    loyalityWelcomePlus[2].signup_store_count !== "-999999"
                      ? currencyFormat(
                          loyalityWelcomePlus[2].signup_store_count
                        )
                      : "-"}
                  </td>
                  <td>
                    {loyalityWelcomePlus !== undefined &&
                    loyalityWelcomePlus.length !== 0 &&
                    loyalityWelcomePlus[2]
                      .PER_loyalty_store_transaction_count !== "-999999"
                      ? `${decimalCurrencyFormat(
                          loyalityWelcomePlus[2]
                            .PER_loyalty_store_transaction_count
                        )}%`
                      : "-"}
                  </td>
                  <td>
                    {loyalityWelcomePlus !== undefined &&
                    loyalityWelcomePlus.length !== 0 &&
                    loyalityWelcomePlus[2].signup_cs_count !== "-999999"
                      ? currencyFormat(loyalityWelcomePlus[2].signup_cs_count)
                      : "-"}
                  </td>
                  <td>
                    {loyalityWelcomePlus !== undefined &&
                    loyalityWelcomePlus.length !== 0 &&
                    loyalityWelcomePlus[2].per_new_signup !==
                      "-999999"
                      ? `${decimalCurrencyFormat(
                          loyalityWelcomePlus[2].per_new_signup
                        )}%`
                      : "-"}
                  </td>
                </tr>
                <tr>
                  <td>
                    {loyalityWelcomePlus !== undefined &&
                      loyalityWelcomePlus.length !== 0 &&
                      loyalityWelcomePlus[3].concept_short_name}
                  </td>
                  <td>
                    {loyalityWelcomePlus !== undefined &&
                    loyalityWelcomePlus.length !== 0 &&
                    loyalityWelcomePlus[3].signup_count !== "-999999"
                      ? currencyFormat(loyalityWelcomePlus[3].signup_count)
                      : "-"}
                  </td>
                  <td>
                    {loyalityWelcomePlus !== undefined &&
                    loyalityWelcomePlus.length !== 0 &&
                    loyalityWelcomePlus[3].PER_loyalty_transaction_count !==
                      "-999999"
                      ? `${decimalCurrencyFormat(
                          loyalityWelcomePlus[3].PER_loyalty_transaction_count
                        )}%`
                      : "-"}
                  </td>
                  <td>
                    {loyalityWelcomePlus !== undefined &&
                    loyalityWelcomePlus.length !== 0 &&
                    loyalityWelcomePlus[3].signup_online_count !== "-999999"
                      ? currencyFormat(
                          loyalityWelcomePlus[3].signup_online_count
                        )
                      : "-"}
                  </td>
                  <td>
                    {loyalityWelcomePlus !== undefined &&
                    loyalityWelcomePlus.length !== 0 &&
                    loyalityWelcomePlus[3]
                      .PER_loyalty_online_transaction_count !== "-999999"
                      ? `${decimalCurrencyFormat(
                          loyalityWelcomePlus[3]
                            .PER_loyalty_online_transaction_count
                        )}%`
                      : "-"}
                  </td>
                  <td>
                    {loyalityWelcomePlus !== undefined &&
                    loyalityWelcomePlus.length !== 0 &&
                    loyalityWelcomePlus[3].signup_store_count !== "-999999"
                      ? currencyFormat(
                          loyalityWelcomePlus[3].signup_store_count
                        )
                      : "-"}
                  </td>
                  <td>
                    {loyalityWelcomePlus !== undefined &&
                    loyalityWelcomePlus.length !== 0 &&
                    loyalityWelcomePlus[3]
                      .PER_loyalty_store_transaction_count !== "-999999"
                      ? `${decimalCurrencyFormat(
                          loyalityWelcomePlus[3]
                            .PER_loyalty_store_transaction_count
                        )}%`
                      : "-"}
                  </td>
                  <td>
                    {loyalityWelcomePlus !== undefined &&
                    loyalityWelcomePlus.length !== 0 &&
                    loyalityWelcomePlus[3].signup_cs_count !== "-999999"
                      ? currencyFormat(loyalityWelcomePlus[3].signup_cs_count)
                      : "-"}
                  </td>
                  <td>
                    {loyalityWelcomePlus !== undefined &&
                    loyalityWelcomePlus.length !== 0 &&
                    loyalityWelcomePlus[3].per_new_signup !==
                      "-999999"
                      ? `${decimalCurrencyFormat(
                          loyalityWelcomePlus[3].per_new_signup
                        )}%`
                      : "-"}
                  </td>
                </tr>
              </>
            )}
            <tr style={{ fontWeight: "500" }}>
              <td style={{ backgroundColor: "lightgrey" }}>
                Credit Card{" "}
                {gettooltip(
                  "CCInfoIcon",
                  "CC",
                  "CC",
                  "Credit card enrollments including only POS enrollments currently"
                )}
              </td>
              {loading.loyaltyCreditCardTotal ? (
                <>
                  <LoaderForRow tdCount={8} />
                </>
              ) : (
                <>
                  <th>
                    {loyaltyCreditCardTotal !== undefined &&
                    loyaltyCreditCardTotal.length !== 0 &&
                    loyaltyCreditCardTotal[0].signup_count !== "-999999"
                      ? currencyFormat(loyaltyCreditCardTotal[0].signup_count)
                      : "-"}
                  </th>
                  <th>
                    {loyaltyCreditCardTotal !== undefined &&
                    loyaltyCreditCardTotal.length !== 0 &&
                    loyaltyCreditCardTotal[0].PER_loyalty_transaction_count !==
                      "-999999"
                      ? `${decimalCurrencyFormat(
                          loyaltyCreditCardTotal[0]
                            .PER_loyalty_transaction_count
                        )}%`
                      : "-"}
                  </th>
                  <th>
                    {loyaltyCreditCardTotal !== undefined &&
                    loyaltyCreditCardTotal.length !== 0 &&
                    loyaltyCreditCardTotal[0].signup_online_count !== "-999999"
                      ? currencyFormat(
                          loyaltyCreditCardTotal[0].signup_online_count
                        )
                      : "-"}
                  </th>
                  <th>
                    {loyaltyCreditCardTotal !== undefined &&
                    loyaltyCreditCardTotal.length !== 0 &&
                    loyaltyCreditCardTotal[0]
                      .PER_loyalty_online_transaction_count !== "-999999"
                      ? `${decimalCurrencyFormat(
                          loyaltyCreditCardTotal[0]
                            .PER_loyalty_online_transaction_count
                        )}%`
                      : "-"}
                  </th>
                  <th>
                    {loyaltyCreditCardTotal !== undefined &&
                    loyaltyCreditCardTotal.length !== 0 &&
                    loyaltyCreditCardTotal[0].signup_store_count !== "-999999"
                      ? currencyFormat(
                          loyaltyCreditCardTotal[0].signup_store_count
                        )
                      : "-"}
                  </th>
                  <th>
                    {loyaltyCreditCardTotal !== undefined &&
                    loyaltyCreditCardTotal.length !== 0 &&
                    loyaltyCreditCardTotal[0]
                      .PER_loyalty_store_transaction_count !== "-999999"
                      ? `${decimalCurrencyFormat(
                          loyaltyCreditCardTotal[0]
                            .PER_loyalty_store_transaction_count
                        )}%`
                      : "-"}
                  </th>
                  <th>
                    {loyaltyCreditCardTotal !== undefined &&
                    loyaltyCreditCardTotal.length !== 0 &&
                    loyaltyCreditCardTotal[0].signup_cs_count !== "-999999"
                      ? currencyFormat(
                          loyaltyCreditCardTotal[0].signup_cs_count
                        )
                      : "-"}
                  </th>
                  <th>
                    {loyaltyCreditCardTotal !== undefined &&
                    loyaltyCreditCardTotal.length !== 0 &&
                    loyaltyCreditCardTotal[0]
                      .per_new_signup !== "-999999"
                      ? `${decimalCurrencyFormat(
                          loyaltyCreditCardTotal[0]
                            .per_new_signup
                        )}%`
                      : "-"}
                  </th>
                </>
              )}
            </tr>
            {loading.loyaltyCreditCard ? (
              <></>
            ) : (
              <>
                <tr>
                  <td>
                    {loyalityCreditCard !== undefined &&
                      loyalityCreditCard.length !== 0 &&
                      loyalityCreditCard[0].concept_short_name}
                  </td>
                  <td>
                    {loyalityCreditCard !== undefined &&
                    loyalityCreditCard.length !== 0 &&
                    loyalityCreditCard[0].signup_count !== "-999999"
                      ? currencyFormat(loyalityCreditCard[0].signup_count)
                      : "-"}
                  </td>
                  <td>
                    {loyalityCreditCard !== undefined &&
                    loyalityCreditCard.length !== 0 &&
                    loyalityCreditCard[0].PER_loyalty_transaction_count !==
                      "-999999"
                      ? `${decimalCurrencyFormat(
                          loyalityCreditCard[0].PER_loyalty_transaction_count
                        )}%`
                      : "-"}
                  </td>
                  <td>
                    {loyalityCreditCard !== undefined &&
                    loyalityCreditCard.length !== 0 &&
                    loyalityCreditCard[0].signup_online_count !== "-999999"
                      ? currencyFormat(
                          loyalityCreditCard[0].signup_online_count
                        )
                      : "-"}
                  </td>
                  <td>
                    {loyalityCreditCard !== undefined &&
                    loyalityCreditCard.length !== 0 &&
                    loyalityCreditCard[0]
                      .PER_loyalty_online_transaction_count !== "-999999"
                      ? `${decimalCurrencyFormat(
                          loyalityCreditCard[0]
                            .PER_loyalty_online_transaction_count
                        )}%`
                      : "-"}
                  </td>
                  <td>
                    {loyalityCreditCard !== undefined &&
                    loyalityCreditCard.length !== 0 &&
                    loyalityCreditCard[0].signup_store_count !== "-999999"
                      ? currencyFormat(loyalityCreditCard[0].signup_store_count)
                      : "-"}
                  </td>
                  <td>
                    {loyalityCreditCard !== undefined &&
                    loyalityCreditCard.length !== 0 &&
                    loyalityCreditCard[0]
                      .PER_loyalty_store_transaction_count !== "-999999"
                      ? `${decimalCurrencyFormat(
                          loyalityCreditCard[0]
                            .PER_loyalty_store_transaction_count
                        )}%`
                      : "-"}
                  </td>
                  <td>
                    {loyalityCreditCard !== undefined &&
                    loyalityCreditCard.length !== 0 &&
                    loyalityCreditCard[0].signup_cs_count !== "-999999"
                      ? currencyFormat(loyalityCreditCard[1].signup_cs_count)
                      : "-"}
                  </td>
                  <td>
                    {loyalityCreditCard !== undefined &&
                    loyalityCreditCard.length !== 0 &&
                    loyalityCreditCard[0].per_new_signup !==
                      "-999999"
                      ? `${decimalCurrencyFormat(
                          loyalityCreditCard[0].per_new_signup
                        )}%`
                      : "-"}
                  </td>
                </tr>
                <tr>
                  <td>
                    {loyalityCreditCard !== undefined &&
                      loyalityCreditCard.length !== 0 &&
                      loyalityCreditCard[1].concept_short_name}
                  </td>
                  <td>
                    {loyalityCreditCard !== undefined &&
                    loyalityCreditCard.length !== 0 &&
                    loyalityCreditCard[1].signup_count !== "-999999"
                      ? currencyFormat(loyalityCreditCard[1].signup_count)
                      : "-"}
                  </td>
                  <td>
                    {loyalityCreditCard !== undefined &&
                    loyalityCreditCard.length !== 0 &&
                    loyalityCreditCard[1].PER_loyalty_transaction_count !==
                      "-999999"
                      ? `${decimalCurrencyFormat(
                          loyalityCreditCard[1].PER_loyalty_transaction_count
                        )}%`
                      : "-"}
                  </td>
                  <td>
                    {loyalityCreditCard !== undefined &&
                    loyalityCreditCard.length !== 0 &&
                    loyalityCreditCard[1].signup_online_count !== "-999999"
                      ? currencyFormat(
                          loyalityCreditCard[1].signup_online_count
                        )
                      : "-"}
                  </td>
                  <td>
                    {loyalityCreditCard !== undefined &&
                    loyalityCreditCard.length !== 0 &&
                    loyalityCreditCard[1]
                      .PER_loyalty_online_transaction_count !== "-999999"
                      ? `${decimalCurrencyFormat(
                          loyalityCreditCard[1]
                            .PER_loyalty_online_transaction_count
                        )}%`
                      : "-"}
                  </td>
                  <td>
                    {loyalityCreditCard !== undefined &&
                    loyalityCreditCard.length !== 0 &&
                    loyalityCreditCard[1].signup_store_count !== "-999999"
                      ? currencyFormat(loyalityCreditCard[1].signup_store_count)
                      : "-"}
                  </td>
                  <td>
                    {loyalityCreditCard !== undefined &&
                    loyalityCreditCard.length !== 0 &&
                    loyalityCreditCard[1]
                      .PER_loyalty_store_transaction_count !== "-999999"
                      ? `${decimalCurrencyFormat(
                          loyalityCreditCard[1]
                            .PER_loyalty_store_transaction_count
                        )}%`
                      : "-"}
                  </td>
                  <td>
                    {loyalityCreditCard !== undefined &&
                    loyalityCreditCard.length !== 0 &&
                    loyalityCreditCard[1].signup_cs_count !== "-999999"
                      ? currencyFormat(loyalityCreditCard[1].signup_cs_count)
                      : "-"}
                  </td>
                  <td>
                    {loyalityCreditCard !== undefined &&
                    loyalityCreditCard.length !== 0 &&
                    loyalityCreditCard[1].per_new_signup !==
                      "-999999"
                      ? `${decimalCurrencyFormat(
                          loyalityCreditCard[1].per_new_signup
                        )}%`
                      : "-"}
                  </td>
                </tr>
                <tr>
                  <td>
                    {loyalityCreditCard !== undefined &&
                      loyalityCreditCard.length !== 0 &&
                      loyalityCreditCard[2].concept_short_name}
                  </td>
                  <td>
                    {loyalityCreditCard !== undefined &&
                    loyalityCreditCard.length !== 0 &&
                    loyalityCreditCard[2].signup_count !== "-999999"
                      ? currencyFormat(loyalityCreditCard[2].signup_count)
                      : "-"}
                  </td>
                  <td>
                    {loyalityCreditCard !== undefined &&
                    loyalityCreditCard.length !== 0 &&
                    loyalityCreditCard[2].PER_loyalty_transaction_count !==
                      "-999999"
                      ? `${decimalCurrencyFormat(
                          loyalityCreditCard[2].PER_loyalty_transaction_count
                        )}%`
                      : "-"}
                  </td>
                  <td>
                    {loyalityCreditCard !== undefined &&
                    loyalityCreditCard.length !== 0 &&
                    loyalityCreditCard[2].signup_online_count !== "-999999"
                      ? currencyFormat(
                          loyalityCreditCard[2].signup_online_count
                        )
                      : "-"}
                  </td>
                  <td>
                    {loyalityCreditCard !== undefined &&
                    loyalityCreditCard.length !== 0 &&
                    loyalityCreditCard[2]
                      .PER_loyalty_online_transaction_count !== "-999999"
                      ? `${decimalCurrencyFormat(
                          loyalityCreditCard[2]
                            .PER_loyalty_online_transaction_count
                        )}%`
                      : "-"}
                  </td>
                  <td>
                    {loyalityCreditCard !== undefined &&
                    loyalityCreditCard.length !== 0 &&
                    loyalityCreditCard[2].signup_store_count !== "-999999"
                      ? currencyFormat(loyalityCreditCard[2].signup_store_count)
                      : "-"}
                  </td>
                  <td>
                    {loyalityCreditCard !== undefined &&
                    loyalityCreditCard.length !== 0 &&
                    loyalityCreditCard[2]
                      .PER_loyalty_store_transaction_count !== "-999999"
                      ? `${decimalCurrencyFormat(
                          loyalityCreditCard[2]
                            .PER_loyalty_store_transaction_count
                        )}%`
                      : "-"}
                  </td>
                  <td>
                    {loyalityCreditCard !== undefined &&
                    loyalityCreditCard.length !== 0 &&
                    loyalityCreditCard[2].signup_cs_count !== "-999999"
                      ? currencyFormat(loyalityCreditCard[2].signup_cs_count)
                      : "-"}
                  </td>
                  <td>
                    {loyalityCreditCard !== undefined &&
                    loyalityCreditCard.length !== 0 &&
                    loyalityCreditCard[2].per_new_signup !==
                      "-999999"
                      ? `${decimalCurrencyFormat(
                          loyalityCreditCard[2].per_new_signup
                        )}%`
                      : "-"}
                  </td>
                </tr>
                <tr>
                  <td>
                    {loyalityCreditCard !== undefined &&
                      loyalityCreditCard.length !== 0 &&
                      loyalityCreditCard[3].concept_short_name}
                  </td>
                  <td>
                    {loyalityCreditCard !== undefined &&
                    loyalityCreditCard.length !== 0 &&
                    loyalityCreditCard[3].signup_count !== "-999999"
                      ? currencyFormat(loyalityCreditCard[3].signup_count)
                      : "-"}
                  </td>
                  <td>
                    {loyalityCreditCard !== undefined &&
                    loyalityCreditCard.length !== 0 &&
                    loyalityCreditCard[3].PER_loyalty_transaction_count !==
                      "-999999"
                      ? `${decimalCurrencyFormat(
                          loyalityCreditCard[3].PER_loyalty_transaction_count
                        )}%`
                      : "-"}
                  </td>
                  <td>
                    {loyalityCreditCard !== undefined &&
                    loyalityCreditCard.length !== 0 &&
                    loyalityCreditCard[3].signup_online_count !== "-999999"
                      ? currencyFormat(
                          loyalityCreditCard[3].signup_online_count
                        )
                      : "-"}
                  </td>
                  <td>
                    {loyalityCreditCard !== undefined &&
                    loyalityCreditCard.length !== 0 &&
                    loyalityCreditCard[3]
                      .PER_loyalty_online_transaction_count !== "-999999"
                      ? `${decimalCurrencyFormat(
                          loyalityCreditCard[3]
                            .PER_loyalty_online_transaction_count
                        )}%`
                      : "-"}
                  </td>
                  <td>
                    {loyalityCreditCard !== undefined &&
                    loyalityCreditCard.length !== 0 &&
                    loyalityCreditCard[3].signup_store_count !== "-999999"
                      ? currencyFormat(loyalityCreditCard[3].signup_store_count)
                      : "-"}
                  </td>
                  <td>
                    {loyalityCreditCard !== undefined &&
                    loyalityCreditCard.length !== 0 &&
                    loyalityCreditCard[3]
                      .PER_loyalty_store_transaction_count !== "-999999"
                      ? `${decimalCurrencyFormat(
                          loyalityCreditCard[3]
                            .PER_loyalty_store_transaction_count
                        )}%`
                      : "-"}
                  </td>
                  <td>
                    {loyalityCreditCard !== undefined &&
                    loyalityCreditCard.length !== 0 &&
                    loyalityCreditCard[3].signup_cs_count !== "-999999"
                      ? currencyFormat(loyalityCreditCard[3].signup_cs_count)
                      : "-"}
                  </td>
                  <td>
                    {loyalityCreditCard !== undefined &&
                    loyalityCreditCard.length !== 0 &&
                    loyalityCreditCard[3]
                      .per_new_signup !== "-999999"
                      ? `${decimalCurrencyFormat(
                          loyalityCreditCard[3]
                            .per_new_signup
                        )}%`
                      : "-"}
                  </td>
                </tr>
              </>
            )}
          </tbody>
        </Table>
      </div>
    </div>
  );
}

export default LoyaltyWelcome;
