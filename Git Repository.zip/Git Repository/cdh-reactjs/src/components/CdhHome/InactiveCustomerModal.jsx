import React, { useEffect, useState } from "react";
import { Modal, Table } from "react-bootstrap";
import axios from "axios";
import LoaderForRow from "../LoaderForTable/LoaderForRow";
import { FontAwesomeIcon } from "@fortawesome/react-fontawesome";
import { faCaretUp, faCaretDown } from "@fortawesome/free-solid-svg-icons";
import { currencyFormat } from "../CdhHome/CdhHome";
import { getDateFormat } from "../Utils";
import "./CdhHome.css";

function InactiveCustomerModal({
  modalFlag,
  handleModalClose,
  modalHeaderText,
  selectedBannerId,
  selectedCategoryId,
  selectedDate,
  loadingHome,
  periodStartDate,
  periodEndDate,
}) {
  const [loading, setloader] = useState({
    modalData: false,
    modalTotal: false,
  });

  const [sortSelection, setSortSelector] = useState({
    storeAscending: true,
    districtAscending: false,
    regionAscending: false,
    customerAscending: false,
    arrowIcon: "storeUp",
  });

  const [customerInactiveData, setCustomerInactiveData] = useState();
  const [customerInactiveTotal, setCustomerInactiveTotal] = useState();
  const [allCustomerDataForSearch, setAllCustomerData] = useState();
  const [searchBarActive, setSearchBarActive] = useState(false);

  const dimensionType =
    modalHeaderText === "Returning Customers"
      ? "RC"
      : modalHeaderText === "New Customers"
      ? "NC"
      : modalHeaderText === "At risk (6m-9m)"
      ? "AR_6M_9M"
      : modalHeaderText === "At risk (9m-12m)"
      ? "AR_9M_12M"
      : modalHeaderText === "Inactive (12m-18m)"
      ? "INA_12M_18M"
      : modalHeaderText === "Inactive (18m-24m)"
      ? "INA_18M_24M"
      : "";

  useEffect(() => {
    const fetchCustomerInactiveData = async () => {
      try {
        setCustomerInactiveData();
        setloader(() => ({
          modalData: true,
        }));
        let url =
          process.env.REACT_APP_API_ENDPOINT +
          process.env.REACT_APP_CUSTOMER_MODAL_InActive +
          "concept=" +
          selectedBannerId +
          "&date=" +
          selectedDate +
          "&dimensiontype=" +
          dimensionType +
          "&customerType=" +
          selectedCategoryId;
        if (modalFlag) {
          await axios({ url }).then((res) => {
            res.data !== undefined &&
              res.data.length !== 0 &&
              setCustomerInactiveData(
                res.data.sort((a, b) => {
                  return Number(a.STORE_NBR) - Number(b.STORE_NBR);
                })
              );
            setAllCustomerData(
              res.data.sort((a, b) => {
                return Number(a.STORE_NBR) - Number(b.STORE_NBR);
              })
            );
            setloader(() => ({
              modalData: false,
            }));
          });
        } else {
          setloader(() => ({
            modalData: false,
          }));
        }
      } catch (err) {
        console.log("err-fetchCustomerOverallInactiveModal", err);
        setloader(() => ({
          modalData: false,
        }));
      }
    };

    const fetchCustomerInactiveTotal = async () => {
      try {
        setCustomerInactiveTotal();
        setloader(() => ({
          modalTotal: true,
        }));
        let url =
          process.env.REACT_APP_API_ENDPOINT +
          process.env.REACT_APP_CUSTOMER_MODAL_InActive_Total +
          "concept=" +
          selectedBannerId +
          "&date=" +
          selectedDate +
          "&dimensiontype=" +
          dimensionType +
          "&customerType=" +
          selectedCategoryId;
        if (modalFlag) {
          await axios({ url }).then((res) => {
            res.data !== undefined &&
              res.data.length !== 0 &&
              setCustomerInactiveTotal(res.data);
            setloader(() => ({
              modalTotal: false,
            }));
          });
        } else {
          setloader(() => ({
            modalTotal: false,
          }));
        }
      } catch (err) {
        console.log("err-fetchCustomerOverallInactiveModalTotal", err);
        setloader(() => ({
          modalTotal: false,
        }));
      }
    };

    fetchCustomerInactiveData();
    fetchCustomerInactiveTotal();
    setSortSelector(() => ({
      storeAscending: true,
      districtAscending: false,
      regionAscending: false,
      customerAscending: false,
      arrowIcon: "storeUp",
    }));
  }, [
    modalFlag,
    dimensionType,
    selectedBannerId,
    selectedCategoryId,
    selectedDate,
  ]);

  const sortInactiveData = (value) => {
    if (value === "store") {
      let newArr = [...customerInactiveData];
      sortSelection.storeAscending
        ? newArr.sort((a, b) => {
            return Number(b.STORE_NBR) - Number(a.STORE_NBR);
          })
        : newArr.sort((a, b) => {
            return Number(a.STORE_NBR) - Number(b.STORE_NBR);
          });
      setCustomerInactiveData(newArr);
      sortSelection.storeAscending
        ? setSortSelector(() => ({
            storeAscending: false,
            districtAscending: false,
            regionAscending: false,
            customerAscending: false,
            arrowIcon: "storeDown",
          }))
        : setSortSelector(() => ({
            storeAscending: true,
            districtAscending: false,
            regionAscending: false,
            customerAscending: false,
            arrowIcon: "storeUp",
          }));
    } else if (value === "district") {
      let newArr = [...customerInactiveData];
      sortSelection.districtAscending
        ? newArr.sort((a, b) => {
            return b.DISTRICT.localeCompare(a.DISTRICT);
          })
        : newArr.sort((a, b) => {
            return a.DISTRICT.localeCompare(b.DISTRICT);
          });
      setCustomerInactiveData(newArr);
      sortSelection.districtAscending
        ? setSortSelector(() => ({
            storeAscending: false,
            districtAscending: false,
            regionAscending: false,
            customerAscending: false,
            arrowIcon: "districtDown",
          }))
        : setSortSelector(() => ({
            storeAscending: false,
            districtAscending: true,
            regionAscending: false,
            customerAscending: false,
            arrowIcon: "districtUp",
          }));
    } else if (value === "region") {
      let newArr = [...customerInactiveData];
      sortSelection.regionAscending
        ? newArr.sort((a, b) => {
            return b.REGION.localeCompare(a.REGION);
          })
        : newArr.sort((a, b) => {
            return a.REGION.localeCompare(b.REGION);
          });
      setCustomerInactiveData(newArr);
      sortSelection.regionAscending
        ? setSortSelector(() => ({
            storeAscending: false,
            districtAscending: false,
            regionAscending: false,
            customerAscending: false,
            arrowIcon: "regionDown",
          }))
        : setSortSelector(() => ({
            storeAscending: false,
            districtAscending: false,
            regionAscending: true,
            customerAscending: false,
            arrowIcon: "regionUp",
          }));
    } else if (value === "customer") {
      let newArr = [...customerInactiveData];
      sortSelection.customerAscending
        ? newArr.sort((a, b) => {
            return Number(b.CUST_TY) - Number(a.CUST_TY);
          })
        : newArr.sort((a, b) => {
            return Number(a.CUST_TY) - Number(b.CUST_TY);
          });
      setCustomerInactiveData(newArr);
      sortSelection.customerAscending
        ? setSortSelector(() => ({
            storeAscending: false,
            districtAscending: false,
            regionAscending: false,
            customerAscending: false,
            arrowIcon: "customerDown",
          }))
        : setSortSelector(() => ({
            storeAscending: false,
            districtAscending: false,
            regionAscending: true,
            customerAscending: true,
            arrowIcon: "customerUp",
          }));
    }
  };

  const searchFilter = (value) => {
    let searchQuery = value.target.value;
    if (searchQuery === "") {
      setSearchBarActive(false);
    } else {
      setSearchBarActive(true);
    }
    const allDataForSearch = allCustomerDataForSearch;
    let newArr = allDataForSearch
      .filter((data) => {
        if (searchQuery === "") {
          return data;
        } else if (
          data.STORE_NBR.toLowerCase().includes(searchQuery.toLowerCase())
        ) {
          return data;
        } else if (
          data.DISTRICT.toLowerCase().includes(searchQuery.toLowerCase())
        ) {
          return data;
        } else if (
          data.REGION.toLowerCase().includes(searchQuery.toLowerCase())
        ) {
          return data;
        }
      })
      .sort((a, b) => {
        return Number(a.STORE_NBR) - Number(b.STORE_NBR);
      });
    setCustomerInactiveData(newArr);
    setSortSelector(() => ({
      storeAscending: true,
      districtAscending: false,
      regionAscending: false,
      customerAscending: false,
      arrowIcon: "storeUp",
    }));
  };

  return (
    <>
      <Modal show={modalFlag} fullscreen={true} onHide={handleModalClose}>
        <Modal.Header closeButton>
          <Modal.Title>{modalHeaderText}</Modal.Title>
        </Modal.Header>
        <div
          className="DatePeriod"
          style={{ textAlign: "center", fontWeight: "500" }}
        >
          {!loadingHome.record_dates && periodStartDate !== "" ? (
            <div>
              <span>
                Period:{" "}
                {`(${getDateFormat(periodStartDate)} - ${getDateFormat(
                  periodEndDate
                )})`}
              </span>
            </div>
          ) : (
            ""
          )}
          <div className="searchBar">
            Search:{" "}
            <input
              placeholder="Enter Store/District/Region"
              onChange={(event) => searchFilter(event)}
              style={{
                borderRadius: "5px",
                width: "250px",
                borderColor: "lightgrey",
              }}
            />
          </div>
        </div>
        <Modal.Body>
          <div className="p-3" style={{ marginBottom: "50px" }}>
            <Table striped bordered hover size="sm">
              <thead>
                <tr>
                  <th
                    style={{ cursor: "pointer" }}
                    onClick={() => {
                      sortInactiveData("store");
                    }}
                  >
                    Store{" "}
                    {(sortSelection.arrowIcon === "storeUp" &&
                      customerInactiveData !== undefined &&
                      customerInactiveData.length !== 0 && (
                        <FontAwesomeIcon
                          style={{ paddingLeft: "5px" }}
                          icon={faCaretUp}
                        />
                      )) ||
                      (sortSelection.arrowIcon === "storeDown" &&
                        customerInactiveData !== undefined &&
                        customerInactiveData.length !== 0 && (
                          <FontAwesomeIcon
                            style={{ paddingLeft: "5px" }}
                            icon={faCaretDown}
                          />
                        ))}
                  </th>
                  <th
                    style={{ cursor: "pointer" }}
                    onClick={() => {
                      sortInactiveData("district");
                    }}
                  >
                    District{" "}
                    {(sortSelection.arrowIcon === "districtUp" && (
                      <FontAwesomeIcon
                        style={{ paddingLeft: "5px" }}
                        icon={faCaretUp}
                      />
                    )) ||
                      (sortSelection.arrowIcon === "districtDown" && (
                        <FontAwesomeIcon
                          style={{ paddingLeft: "5px" }}
                          icon={faCaretDown}
                        />
                      ))}
                  </th>
                  <th
                    style={{ cursor: "pointer" }}
                    onClick={() => {
                      sortInactiveData("region");
                    }}
                  >
                    Region{" "}
                    {(sortSelection.arrowIcon === "regionUp" && (
                      <FontAwesomeIcon
                        style={{ paddingLeft: "5px" }}
                        icon={faCaretUp}
                      />
                    )) ||
                      (sortSelection.arrowIcon === "regionDown" && (
                        <FontAwesomeIcon
                          style={{ paddingLeft: "5px" }}
                          icon={faCaretDown}
                        />
                      ))}
                  </th>
                  <th
                    style={{ cursor: "pointer" }}
                    onClick={() => {
                      sortInactiveData("customer");
                    }}
                  >
                    Customers{" "}
                    {(sortSelection.arrowIcon === "customerUp" &&
                      customerInactiveData !== undefined &&
                      customerInactiveData.length !== 0 && (
                        <FontAwesomeIcon
                          style={{ paddingLeft: "5px" }}
                          icon={faCaretUp}
                        />
                      )) ||
                      (sortSelection.arrowIcon === "customerDown" &&
                        customerInactiveData !== undefined &&
                        customerInactiveData.length !== 0 && (
                          <FontAwesomeIcon
                            style={{ paddingLeft: "5px" }}
                            icon={faCaretDown}
                          />
                        ))}
                  </th>
                </tr>
              </thead>
              <tbody>
                {loading.modalData || loading.modalTotal ? (
                  <tr>
                    <LoaderForRow height={"700px"} tdCount={4} />
                  </tr>
                ) : customerInactiveData !== undefined &&
                  customerInactiveData.length !== 0 ? (
                  customerInactiveData.map((data) => {
                    return (
                      <tr className="align-middle">
                        <td>
                          {data.STORE_NBR !== undefined &&
                          data.STORE_NBR.length !== 0 &&
                          data.STORE_NBR !== "-999999"
                            ? data.STORE_NBR
                            : "-"}
                        </td>
                        <td>
                          {data.DISTRICT !== undefined &&
                          data.DISTRICT.length !== 0 &&
                          data.DISTRICT !== "-999999"
                            ? data.DISTRICT
                            : "-"}
                        </td>
                        <td>
                          {data.REGION !== undefined &&
                          data.REGION.length !== 0 &&
                          data.REGION !== "-999999"
                            ? data.REGION
                            : "-"}
                        </td>
                        <td>
                          {data.CUST_TY !== undefined &&
                          data.CUST_TY.length !== 0 &&
                          data.CUST_TY !== "-999999"
                            ? currencyFormat(data.CUST_TY)
                            : "-"}
                        </td>
                      </tr>
                    );
                  })
                ) : (
                  <tr>
                    <td
                      align="center"
                      colSpan="4"
                      style={{ fontWeight: "500" }}
                    >
                      DATA NOT AVAILABLE
                    </td>
                  </tr>
                )}
                {customerInactiveTotal !== undefined &&
                customerInactiveTotal.length !== 0 &&
                customerInactiveData !== undefined &&
                customerInactiveData.length !== 0 &&
                !searchBarActive
                  ? customerInactiveTotal.map((data) => {
                      return (
                        <tr style={{ fontWeight: "500" }}>
                          <td></td>
                          <td></td>
                          <td>Total</td>
                          <td>
                            {data.CUST_TY !== undefined &&
                            data.CUST_TY.length !== 0 &&
                            data.CUST_TY !== "-999999"
                              ? currencyFormat(data.CUST_TY)
                              : "-"}
                          </td>
                        </tr>
                      );
                    })
                  : ""}
              </tbody>
            </Table>
          </div>
        </Modal.Body>
      </Modal>
    </>
  );
}

export default InactiveCustomerModal;
