import { React, useState } from "react";
import { useHistory } from "react-router-dom";
import "./CdhHome.css";
import { Table } from "react-bootstrap";
import LoaderForRow from "../LoaderForTable/LoaderForRow";
import InactiveCustomerModal from "./InactiveCustomerModal";
// import { Spinner, SpinnerSize } from 'office-ui-fabric-react';
import { gettooltip } from "../Utils";
export const currencyFormat = (value) => {
  return parseFloat(value)
    .toFixed(0)
    .replace(/(\d)(?=(\d{3})+(?!\d))/g, "$1,");
};
function CdhHome({
  customerDataSixMonths,
  customerDataNineMonths,
  customerActiveData,
  customerActiveExisting,
  customerInActive_12_18_Data,
  customerInActive_18_24_Data,
  firsthalftotalData,
  secondhalftotalData,
  loading,
  selectedCategoryId,
  customerUnidentifiedData,
  customerTotal,
  firstFourTotalData,
  customerInActive_24plus_Data,
  selectedBannerId,
  selectedDate,
  periodStartDate,
  periodEndDate,
}) {
  let history = useHistory();
  const flag =
    firsthalftotalData !== undefined && firsthalftotalData.length !== 0;
  const firstFourTotalflag =
    firstFourTotalData !== undefined && firstFourTotalData.length !== 0;

  const [modalFlag, setModalFlag] = useState(false);
  const [modalHeaderText, setModalHeader] = useState();
  const handleModalOpen = (type) => {
    setModalFlag(true);
    setModalHeader(type);
  };
  const handleModalClose = () => {
    setModalFlag(false);
  };

  const openOverviewTable = (event) => {
    if (event.target.id === "Stable_Exist") {
      history.push("/cdh/Marketing/Returning_Customers");
    }
    if (event.target.id === "Stable_New_L12m") {
      history.push("/cdh/Marketing/New_Customers");
    }
  };
  return (
    <div className="">
      <InactiveCustomerModal
        modalFlag={modalFlag}
        handleModalClose={handleModalClose}
        modalHeaderText={modalHeaderText}
        selectedBannerId={selectedBannerId}
        selectedCategoryId={selectedCategoryId}
        selectedDate={selectedDate}
        loadingHome={loading}
        periodStartDate={periodStartDate}
        periodEndDate={periodEndDate}
      />
      <div className="p-3" style={{ marginBottom: "50px" }}>
        <Table striped bordered hover size="sm">
          <thead className="tableHeader">
            <tr className="align-middle">
              <th style={{ width: "200px" }}>
                L12m Active{" "}
                {gettooltip(
                  "L12mActiveInfoIcon",
                  "L12mActive",
                  "L12mActive",
                  "Inactive (24 months) - The customers",
                  "who were not active in last 24 months"
                )}
              </th>
              <th>
                Customers{" "}
                {gettooltip(
                  "customersInfoIcon",
                  "Customers",
                  "Customers",
                  "Data based on two years"
                )}
              </th>
              <th>
                Net Sales{" "}
                {gettooltip(
                  "NetSalesInfoIcon",
                  "NetSales",
                  "NetSales",
                  "Net Sales for customers in one year"
                )}
              </th>
              <th>
                Transactions{" "}
                {gettooltip(
                  "TransactionsInfoIcon",
                  "Transactions",
                  "Transactions",
                  "Number of distinct transaction for customer in one year"
                )}
              </th>
              <th>
                Product Margin{" "}
                {gettooltip(
                  "ProductMarginInfoIcon",
                  "ProductMargin",
                  "ProductMargin",
                  "Product Margin for customers in one year",
                  "(Net Sales - Cost of Sales)"
                )}
              </th>
              <th>
                AOV{" "}
                {gettooltip(
                  "AOVInfoIcon",
                  "AOV",
                  "AOV",
                  "Net Sales divided by number of transaction"
                )}
              </th>
              <th>
                UPT{" "}
                {gettooltip(
                  "UPTInfoIcon",
                  "UPT",
                  "UPT",
                  "Unit Sold per transaction"
                )}
              </th>
              <th>
                AUR{" "}
                {gettooltip(
                  "AURInfoIcon",
                  "AUR",
                  "AUR",
                  "Net Sales divided by unit sold"
                )}
              </th>
              <th>
                Margin Rate
                <br /> %{" "}
                {gettooltip(
                  "MarginRateInfoIcon",
                  "MarginRate",
                  "MarginRate",
                  "(Net Sales - Cost of Sales) / Net Sales"
                )}
              </th>
              <th>
                Net Sales per <br /> Customer{" "}
                {gettooltip(
                  "NPCInfoIcon",
                  "NPC",
                  "NPC",
                  "Net Sales per Customer"
                )}
              </th>
              <th>
                Transactions per <br /> Customer{" "}
                {gettooltip(
                  "TPCInfoIcon",
                  "TPC",
                  "TPC",
                  "Number of Transactions per customer"
                )}
              </th>
            </tr>
          </thead>
          {/* onClick={(e) => openOverviewTable(e)} */}
          <tbody className="tableBody">
            <tr className="align-middle">
              <td className="tableCol " id={"Stable_Exist"}>
                {"Returning Customers"}{" "}
                {gettooltip(
                  "ReturningCustomersInfoIcon",
                  "ReturningCustomers",
                  "ReturningCustomers",
                  "Active in L6M and active in L12M to L24M"
                )}
              </td>
              {loading.Active_Existing ? (
                <>
                  <LoaderForRow tdCount={10} />
                </>
              ) : (
                <>
                  <td>
                    {customerActiveExisting !== undefined &&
                      customerActiveExisting.length !== 0 &&
                      (customerActiveExisting[0].ACT_CUST_COUNT_TY === "-999999"
                        ? "-"
                        : currencyFormat(
                            Number(customerActiveExisting[0].ACT_CUST_COUNT_TY)
                          ))}
                    <br />
                    {customerActiveExisting !== undefined &&
                    customerActiveExisting.length !== 0 &&
                    Number(customerActiveExisting[0].TY_VS_LY)
                      .toFixed(2)
                      .includes("-") ? (
                      <span style={{ color: "red", fontSize: "12px" }}>
                        {customerActiveExisting !== undefined &&
                          customerActiveExisting.length !== 0 &&
                          (customerActiveExisting[0].TY_VS_LY === "-999999"
                            ? "-"
                            : `LY ${Number(
                                customerActiveExisting[0].TY_VS_LY
                              ).toFixed(2)}%`)}
                      </span>
                    ) : (
                      <span style={{ color: "green", fontSize: "12px" }}>
                        {customerActiveExisting !== undefined &&
                          customerActiveExisting.length !== 0 &&
                          (customerActiveExisting[0].TY_VS_LY === "-999999"
                            ? "-"
                            : `LY +${Number(
                                customerActiveExisting[0].TY_VS_LY
                              ).toFixed(2)}%`)}
                      </span>
                    )}
                    <br />
                    {customerActiveExisting !== undefined &&
                    customerActiveExisting.length !== 0 &&
                    Number(customerActiveExisting[0].TY_VS_LLY)
                      .toFixed(2)
                      .includes("-") ? (
                      <span style={{ color: "red", fontSize: "11px" }}>
                        {customerActiveExisting !== undefined &&
                          customerActiveExisting.length !== 0 &&
                          (customerActiveExisting[0].TY_VS_LLY === "-999999"
                            ? "-"
                            : `LLY ${Number(
                                customerActiveExisting[0].TY_VS_LLY
                              ).toFixed(2)}%`)}
                      </span>
                    ) : (
                      <span style={{ color: "green", fontSize: "11px" }}>
                        {customerActiveExisting !== undefined &&
                          customerActiveExisting.length !== 0 &&
                          (customerActiveExisting[0].TY_VS_LLY === "-999999"
                            ? "-"
                            : `LLY +${Number(
                                customerActiveExisting[0].TY_VS_LLY
                              ).toFixed(2)}%`)}
                      </span>
                    )}
                  </td>
                  <td>
                    {customerActiveExisting !== undefined &&
                      customerActiveExisting.length !== 0 &&
                      (customerActiveExisting[0].NET_SALES_TY === "-999999"
                        ? "-"
                        : "$" +
                          currencyFormat(
                            Number(customerActiveExisting[0].NET_SALES_TY)
                          ))}
                    <br />
                    {customerActiveExisting !== undefined &&
                    customerActiveExisting.length !== 0 &&
                    Number(customerActiveExisting[0].NET_SALES_TY_VS_LY)
                      .toFixed(2)
                      .includes("-") ? (
                      <span style={{ color: "red", fontSize: "12px" }}>
                        {customerActiveExisting !== undefined &&
                          customerActiveExisting.length !== 0 &&
                          (customerActiveExisting[0].NET_SALES_TY_VS_LY ===
                          "-999999"
                            ? "-"
                            : `LY ${Number(
                                customerActiveExisting[0].NET_SALES_TY_VS_LY
                              ).toFixed(2)}%`)}
                      </span>
                    ) : (
                      <span style={{ color: "green", fontSize: "12px" }}>
                        {customerActiveExisting !== undefined &&
                          customerActiveExisting.length !== 0 &&
                          (customerActiveExisting[0].NET_SALES_TY_VS_LY ===
                          "-999999"
                            ? "-"
                            : `LY +${Number(
                                customerActiveExisting[0].NET_SALES_TY_VS_LY
                              ).toFixed(2)}%`)}
                      </span>
                    )}
                    <br />
                    {customerActiveExisting !== undefined &&
                    customerActiveExisting.length !== 0 &&
                    Number(customerActiveExisting[0].NET_SALES_TY_VS_LLY)
                      .toFixed(2)
                      .includes("-") ? (
                      <span style={{ color: "red", fontSize: "11px" }}>
                        {customerActiveExisting !== undefined &&
                          customerActiveExisting.length !== 0 &&
                          (customerActiveExisting[0].NET_SALES_TY_VS_LLY ===
                          "-999999"
                            ? "-"
                            : `LLY ${Number(
                                customerActiveExisting[0].NET_SALES_TY_VS_LLY
                              ).toFixed(2)}%`)}
                      </span>
                    ) : (
                      <span style={{ color: "green", fontSize: "11px" }}>
                        {customerActiveExisting !== undefined &&
                          customerActiveExisting.length !== 0 &&
                          (customerActiveExisting[0].NET_SALES_TY_VS_LLY ===
                          "-999999"
                            ? "-"
                            : `LLY +${Number(
                                customerActiveExisting[0].NET_SALES_TY_VS_LLY
                              ).toFixed(2)}%`)}
                      </span>
                    )}
                  </td>
                  <td>
                    {customerActiveExisting !== undefined &&
                      customerActiveExisting.length !== 0 &&
                      (customerActiveExisting[0].TRANS_COUNT_TY === "-999999"
                        ? "-"
                        : currencyFormat(
                            Number(customerActiveExisting[0].TRANS_COUNT_TY)
                          ))}
                    <br />
                    {customerActiveExisting !== undefined &&
                    customerActiveExisting.length !== 0 &&
                    Number(customerActiveExisting[0].TRANS_TY_VS_LY)
                      .toFixed(2)
                      .includes("-") ? (
                      <span style={{ color: "red", fontSize: "12px" }}>
                        {customerActiveExisting !== undefined &&
                          customerActiveExisting.length !== 0 &&
                          (customerActiveExisting[0].TRANS_TY_VS_LY ===
                          "-999999"
                            ? "-"
                            : `LY ${Number(
                                customerActiveExisting[0].TRANS_TY_VS_LY
                              ).toFixed(2)}%`)}
                      </span>
                    ) : (
                      <span style={{ color: "green", fontSize: "12px" }}>
                        {customerActiveExisting !== undefined &&
                          customerActiveExisting.length !== 0 &&
                          (customerActiveExisting[0].TRANS_TY_VS_LY ===
                          "-999999"
                            ? "-"
                            : `LY +${Number(
                                customerActiveExisting[0].TRANS_TY_VS_LY
                              ).toFixed(2)}%`)}
                      </span>
                    )}
                    <br />
                    {customerActiveExisting !== undefined &&
                    customerActiveExisting.length !== 0 &&
                    Number(customerActiveExisting[0].TRANS_TY_VS_LLY)
                      .toFixed(2)
                      .includes("-") ? (
                      <span style={{ color: "red", fontSize: "11px" }}>
                        {customerActiveExisting !== undefined &&
                          customerActiveExisting.length !== 0 &&
                          (customerActiveExisting[0].TRANS_TY_VS_LLY ===
                          "-999999"
                            ? "-"
                            : `LLY ${Number(
                                customerActiveExisting[0].TRANS_TY_VS_LLY
                              ).toFixed(2)}`)}
                      </span>
                    ) : (
                      <span style={{ color: "green", fontSize: "11px" }}>
                        {customerActiveExisting !== undefined &&
                          customerActiveExisting.length !== 0 &&
                          (customerActiveExisting[0].TRANS_TY_VS_LLY ===
                          "-999999"
                            ? "-"
                            : `LLY +${Number(
                                customerActiveExisting[0].TRANS_TY_VS_LLY
                              ).toFixed(2)}`)}
                      </span>
                    )}
                  </td>
                  <td>
                    {customerActiveExisting !== undefined &&
                      customerActiveExisting.length !== 0 &&
                      (customerActiveExisting[0].PM_TY === "-999999"
                        ? "-"
                        : "$" +
                          currencyFormat(
                            Number(customerActiveExisting[0].PM_TY)
                          ))}
                    <br />
                    {customerActiveExisting !== undefined &&
                    customerActiveExisting.length !== 0 &&
                    Number(customerActiveExisting[0].PM_TY_VS_LY)
                      .toFixed(2)
                      .includes("-") ? (
                      <span style={{ color: "red", fontSize: "12px" }}>
                        {customerActiveExisting !== undefined &&
                          customerActiveExisting.length !== 0 &&
                          (customerActiveExisting[0].PM_TY_VS_LY === "-999999"
                            ? "-"
                            : `LY ${Number(
                                customerActiveExisting[0].PM_TY_VS_LY
                              ).toFixed(2)}%`)}
                      </span>
                    ) : (
                      <span style={{ color: "green", fontSize: "12px" }}>
                        {customerActiveExisting !== undefined &&
                          customerActiveExisting.length !== 0 &&
                          (customerActiveExisting[0].PM_TY_VS_LY === "-999999"
                            ? "-"
                            : `LY +${Number(
                                customerActiveExisting[0].PM_TY_VS_LY
                              ).toFixed(2)}%`)}
                      </span>
                    )}
                    <br />
                    {customerActiveExisting !== undefined &&
                    customerActiveExisting.length !== 0 &&
                    Number(customerActiveExisting[0].PM_TY_VS_LLY)
                      .toFixed(2)
                      .includes("-") ? (
                      <span style={{ color: "red", fontSize: "11px" }}>
                        {customerActiveExisting !== undefined &&
                          customerActiveExisting.length !== 0 &&
                          (customerActiveExisting[0].PM_TY_VS_LLY === "-999999"
                            ? "-"
                            : `LLY ${Number(
                                customerActiveExisting[0].PM_TY_VS_LLY
                              ).toFixed(2)}%`)}
                      </span>
                    ) : (
                      <span style={{ color: "green", fontSize: "11px" }}>
                        {customerActiveExisting !== undefined &&
                          customerActiveExisting.length !== 0 &&
                          (customerActiveExisting[0].PM_TY_VS_LLY === "-999999"
                            ? "-"
                            : `LLY +${Number(
                                customerActiveExisting[0].PM_TY_VS_LLY
                              ).toFixed(2)}%`)}
                      </span>
                    )}
                  </td>
                  <td>
                    {customerActiveExisting !== undefined &&
                      customerActiveExisting.length !== 0 &&
                      (customerActiveExisting[0].AOV_TY === "-999999"
                        ? "-"
                        : "$" +
                          Number(customerActiveExisting[0].AOV_TY).toFixed(2))}
                    <br />
                    {customerActiveExisting !== undefined &&
                    customerActiveExisting.length !== 0 &&
                    Number(customerActiveExisting[0].AOV_TY_VS_LY)
                      .toFixed(2)
                      .includes("-") ? (
                      <span style={{ color: "red", fontSize: "12px" }}>
                        {customerActiveExisting !== undefined &&
                          customerActiveExisting.length !== 0 &&
                          (customerActiveExisting[0].AOV_TY_VS_LY === "-999999"
                            ? "-"
                            : `LY ${Number(
                                customerActiveExisting[0].AOV_TY_VS_LY
                              ).toFixed(2)}%`)}
                      </span>
                    ) : (
                      <span style={{ color: "green", fontSize: "12px" }}>
                        {customerActiveExisting !== undefined &&
                          customerActiveExisting.length !== 0 &&
                          (customerActiveExisting[0].AOV_TY_VS_LY === "-999999"
                            ? "-"
                            : `LY +${Number(
                                customerActiveExisting[0].AOV_TY_VS_LY
                              ).toFixed(2)}%`)}
                      </span>
                    )}
                    <br />
                    {customerActiveExisting !== undefined &&
                    customerActiveExisting.length !== 0 &&
                    Number(customerActiveExisting[0].AOV_TY_VS_LLY)
                      .toFixed(2)
                      .includes("-") ? (
                      <span style={{ color: "red", fontSize: "11px" }}>
                        {customerActiveExisting !== undefined &&
                          customerActiveExisting.length !== 0 &&
                          (customerActiveExisting[0].AOV_TY_VS_LLY === "-999999"
                            ? "-"
                            : `LLY ${Number(
                                customerActiveExisting[0].AOV_TY_VS_LLY
                              ).toFixed(2)}%`)}
                      </span>
                    ) : (
                      <span style={{ color: "green", fontSize: "11px" }}>
                        {customerActiveExisting !== undefined &&
                          customerActiveExisting.length !== 0 &&
                          (customerActiveExisting[0].AOV_TY_VS_LLY === "-999999"
                            ? "-"
                            : `LLY +${Number(
                                customerActiveExisting[0].AOV_TY_VS_LLY
                              ).toFixed(2)}%`)}
                      </span>
                    )}
                  </td>
                  <td>
                    {customerActiveExisting !== undefined &&
                      customerActiveExisting.length !== 0 &&
                      (customerActiveExisting[0].UPT_TY === "-999999"
                        ? "-"
                        : Number(customerActiveExisting[0].UPT_TY).toFixed(1))}
                    <br />
                    {customerActiveExisting !== undefined &&
                    customerActiveExisting.length !== 0 &&
                    Number(customerActiveExisting[0].UPT_TY_VS_LY)
                      .toFixed(2)
                      .includes("-") ? (
                      <span style={{ color: "red", fontSize: "12px" }}>
                        {customerActiveExisting !== undefined &&
                          customerActiveExisting.length !== 0 &&
                          (customerActiveExisting[0].UPT_TY_VS_LY === "-999999"
                            ? "-"
                            : `LY ${Number(
                                customerActiveExisting[0].UPT_TY_VS_LY
                              ).toFixed(2)}%`)}
                      </span>
                    ) : (
                      <span style={{ color: "green", fontSize: "12px" }}>
                        {customerActiveExisting !== undefined &&
                          customerActiveExisting.length !== 0 &&
                          (customerActiveExisting[0].UPT_TY_VS_LY === "-999999"
                            ? "-"
                            : `LY +${Number(
                                customerActiveExisting[0].UPT_TY_VS_LY
                              ).toFixed(2)}%`)}
                      </span>
                    )}
                    <br />
                    {customerActiveExisting !== undefined &&
                    customerActiveExisting.length !== 0 &&
                    Number(customerActiveExisting[0].UPT_TY_VS_LLY)
                      .toFixed(2)
                      .includes("-") ? (
                      <span style={{ color: "red", fontSize: "11px" }}>
                        {customerActiveExisting !== undefined &&
                          customerActiveExisting.length !== 0 &&
                          (customerActiveExisting[0].UPT_TY_VS_LLY === "-999999"
                            ? "-"
                            : `LLY ${Number(
                                customerActiveExisting[0].UPT_TY_VS_LLY
                              ).toFixed(2)}%`)}
                      </span>
                    ) : (
                      <span style={{ color: "green", fontSize: "11px" }}>
                        {customerActiveExisting !== undefined &&
                          customerActiveExisting.length !== 0 &&
                          (customerActiveExisting[0].UPT_TY_VS_LLY === "-999999"
                            ? "-"
                            : `LLY +${Number(
                                customerActiveExisting[0].UPT_TY_VS_LLY
                              ).toFixed(2)}%`)}
                      </span>
                    )}
                  </td>
                  <td>
                    {customerActiveExisting !== undefined &&
                      customerActiveExisting.length !== 0 &&
                      (customerActiveExisting[0].AUR_TY === "-999999"
                        ? "-"
                        : "$" +
                          Number(customerActiveExisting[0].AUR_TY).toFixed(2))}
                    <br />
                    {customerActiveExisting !== undefined &&
                    customerActiveExisting.length !== 0 &&
                    Number(customerActiveExisting[0].AUR_TY_VS_LY)
                      .toFixed(2)
                      .includes("-") ? (
                      <span style={{ color: "red", fontSize: "12px" }}>
                        {customerActiveExisting !== undefined &&
                          customerActiveExisting.length !== 0 &&
                          (customerActiveExisting[0].AUR_TY_VS_LY === "-999999"
                            ? "-"
                            : `LY ${Number(
                                customerActiveExisting[0].AUR_TY_VS_LY
                              ).toFixed(2)}%`)}
                      </span>
                    ) : (
                      <span style={{ color: "green", fontSize: "12px" }}>
                        {customerActiveExisting !== undefined &&
                          customerActiveExisting.length !== 0 &&
                          (customerActiveExisting[0].AUR_TY_VS_LY === "-999999"
                            ? "-"
                            : `LY +${Number(
                                customerActiveExisting[0].AUR_TY_VS_LY
                              ).toFixed(2)}%`)}
                      </span>
                    )}
                    <br />
                    {customerActiveExisting !== undefined &&
                    customerActiveExisting.length !== 0 &&
                    Number(customerActiveExisting[0].AUR_TY_VS_LLY)
                      .toFixed(2)
                      .includes("-") ? (
                      <span style={{ color: "red", fontSize: "11px" }}>
                        {customerActiveExisting !== undefined &&
                          customerActiveExisting.length !== 0 &&
                          (customerActiveExisting[0].AUR_TY_VS_LLY === "-999999"
                            ? "-"
                            : `LLY ${Number(
                                customerActiveExisting[0].AUR_TY_VS_LLY
                              ).toFixed(2)}%`)}
                      </span>
                    ) : (
                      <span style={{ color: "green", fontSize: "11px" }}>
                        {customerActiveExisting !== undefined &&
                          customerActiveExisting.length !== 0 &&
                          (customerActiveExisting[0].AUR_TY_VS_LLY === "-999999"
                            ? "-"
                            : `LLY +${Number(
                                customerActiveExisting[0].AUR_TY_VS_LLY
                              ).toFixed(2)}%`)}
                      </span>
                    )}
                  </td>
                  <td>
                    {customerActiveExisting !== undefined &&
                      customerActiveExisting.length !== 0 &&
                      (customerActiveExisting[0].MARGIN_RATE_PER_TY ===
                      "-999999"
                        ? "-"
                        : Number(
                            customerActiveExisting[0].MARGIN_RATE_PER_TY
                          ).toFixed(2))}
                    <br />
                    {customerActiveExisting !== undefined &&
                    customerActiveExisting.length !== 0 &&
                    Number(customerActiveExisting[0].MARGIN_RATE_PER_TY_VS_LY)
                      .toFixed(2)
                      .includes("-") ? (
                      <span style={{ color: "red", fontSize: "12px" }}>
                        {customerActiveExisting !== undefined &&
                          customerActiveExisting.length !== 0 &&
                          (customerActiveExisting[0]
                            .MARGIN_RATE_PER_TY_VS_LY === "-999999"
                            ? "-"
                            : `LY ${Number(
                                customerActiveExisting[0]
                                  .MARGIN_RATE_PER_TY_VS_LY
                              ).toFixed(2)}%`)}
                      </span>
                    ) : (
                      <span style={{ color: "green", fontSize: "12px" }}>
                        {customerActiveExisting !== undefined &&
                          customerActiveExisting.length !== 0 &&
                          (customerActiveExisting[0]
                            .MARGIN_RATE_PER_TY_VS_LY === "-999999"
                            ? "-"
                            : `LY +${Number(
                                customerActiveExisting[0]
                                  .MARGIN_RATE_PER_TY_VS_LY
                              ).toFixed(2)}%`)}
                      </span>
                    )}
                    <br />
                    {customerActiveExisting !== undefined &&
                    customerActiveExisting.length !== 0 &&
                    Number(customerActiveExisting[0].MARGIN_RATE_PER_TY_VS_LLY)
                      .toFixed(2)
                      .includes("-") ? (
                      <span style={{ color: "red", fontSize: "11px" }}>
                        {customerActiveExisting !== undefined &&
                          customerActiveExisting.length !== 0 &&
                          (customerActiveExisting[0]
                            .MARGIN_RATE_PER_TY_VS_LLY === "-999999"
                            ? "-"
                            : `LLY ${Number(
                                customerActiveExisting[0]
                                  .MARGIN_RATE_PER_TY_VS_LLY
                              ).toFixed(2)}%`)}
                      </span>
                    ) : (
                      <span style={{ color: "green", fontSize: "11px" }}>
                        {customerActiveExisting !== undefined &&
                          customerActiveExisting.length !== 0 &&
                          (customerActiveExisting[0]
                            .MARGIN_RATE_PER_TY_VS_LLY === "-999999"
                            ? "-"
                            : `LLY +${Number(
                                customerActiveExisting[0]
                                  .MARGIN_RATE_PER_TY_VS_LLY
                              ).toFixed(2)}%`)}
                      </span>
                    )}
                  </td>
                  <td>
                    {customerActiveExisting !== undefined &&
                      customerActiveExisting.length !== 0 &&
                      (customerActiveExisting[0].NET_SALES_PER_CUST_TY ===
                      "-999999"
                        ? "-"
                        : "$" +
                          Number(
                            customerActiveExisting[0].NET_SALES_PER_CUST_TY
                          ).toFixed(2))}
                    <br />
                    {customerActiveExisting !== undefined &&
                    customerActiveExisting.length !== 0 &&
                    Number(
                      customerActiveExisting[0].NET_SALES_PER_CUST_TY_VS_LY
                    )
                      .toFixed(2)
                      .includes("-") ? (
                      <span style={{ color: "red", fontSize: "12px" }}>
                        {customerActiveExisting !== undefined &&
                          customerActiveExisting.length !== 0 &&
                          (customerActiveExisting[0]
                            .NET_SALES_PER_CUST_TY_VS_LY === "-999999"
                            ? "-"
                            : `LY ${Number(
                                customerActiveExisting[0]
                                  .NET_SALES_PER_CUST_TY_VS_LY
                              ).toFixed(2)}%`)}
                      </span>
                    ) : (
                      <span style={{ color: "green", fontSize: "12px" }}>
                        {customerActiveExisting !== undefined &&
                          customerActiveExisting.length !== 0 &&
                          (customerActiveExisting[0]
                            .NET_SALES_PER_CUST_TY_VS_LY === "-999999"
                            ? "-"
                            : `LY +${Number(
                                customerActiveExisting[0]
                                  .NET_SALES_PER_CUST_TY_VS_LY
                              ).toFixed(2)}%`)}
                      </span>
                    )}
                    <br />
                    {customerActiveExisting !== undefined &&
                    customerActiveExisting.length !== 0 &&
                    Number(
                      customerActiveExisting[0].NET_SALES_PER_CUST_TY_VS_LLY
                    )
                      .toFixed(2)
                      .includes("-") ? (
                      <span style={{ color: "red", fontSize: "11px" }}>
                        {customerActiveExisting !== undefined &&
                          customerActiveExisting.length !== 0 &&
                          (customerActiveExisting[0]
                            .NET_SALES_PER_CUST_TY_VS_LLY === "-999999"
                            ? "-"
                            : `LLY ${Number(
                                customerActiveExisting[0]
                                  .NET_SALES_PER_CUST_TY_VS_LLY
                              ).toFixed(2)}%`)}
                      </span>
                    ) : (
                      <span style={{ color: "green", fontSize: "11px" }}>
                        {customerActiveExisting !== undefined &&
                          customerActiveExisting.length !== 0 &&
                          (customerActiveExisting[0]
                            .NET_SALES_PER_CUST_TY_VS_LLY === "-999999"
                            ? "-"
                            : `LLY +${Number(
                                customerActiveExisting[0]
                                  .NET_SALES_PER_CUST_TY_VS_LLY
                              ).toFixed(2)}%`)}
                      </span>
                    )}
                  </td>
                  <td>
                    {customerActiveExisting !== undefined &&
                      customerActiveExisting.length !== 0 &&
                      (customerActiveExisting[0].AVG_TRAN_TY === "-999999"
                        ? "-"
                        : Number(customerActiveExisting[0].AVG_TRAN_TY).toFixed(
                            2
                          ))}
                    <br />
                    {customerActiveExisting !== undefined &&
                    customerActiveExisting.length !== 0 &&
                    Number(customerActiveExisting[0].AVG_TRAN_TY_VS_LY)
                      .toFixed(2)
                      .includes("-") ? (
                      <span style={{ color: "red", fontSize: "12px" }}>
                        {customerActiveExisting !== undefined &&
                          customerActiveExisting.length !== 0 &&
                          (customerActiveExisting[0].AVG_TRAN_TY_VS_LY ===
                          "-999999"
                            ? "-"
                            : `LY ${Number(
                                customerActiveExisting[0].AVG_TRAN_TY_VS_LY
                              ).toFixed(2)}%`)}
                      </span>
                    ) : (
                      <span style={{ color: "green", fontSize: "12px" }}>
                        {customerActiveExisting !== undefined &&
                          customerActiveExisting.length !== 0 &&
                          (customerActiveExisting[0].AVG_TRAN_TY_VS_LY ===
                          "-999999"
                            ? "-"
                            : `LY +${Number(
                                customerActiveExisting[0].AVG_TRAN_TY_VS_LY
                              ).toFixed(2)}%`)}
                      </span>
                    )}
                    <br />
                    {customerActiveExisting !== undefined &&
                    customerActiveExisting.length !== 0 &&
                    Number(customerActiveExisting[0].AVG_TRAN_TY_VS_LLY)
                      .toFixed(2)
                      .includes("-") ? (
                      <span style={{ color: "red", fontSize: "11px" }}>
                        {customerActiveExisting !== undefined &&
                          customerActiveExisting.length !== 0 &&
                          (customerActiveExisting[0].AVG_TRAN_TY_VS_LLY ===
                          "-999999"
                            ? "-"
                            : `LLY ${Number(
                                customerActiveExisting[0].AVG_TRAN_TY_VS_LLY
                              ).toFixed(2)}%`)}
                      </span>
                    ) : (
                      <span style={{ color: "green", fontSize: "11px" }}>
                        {customerActiveExisting !== undefined &&
                          customerActiveExisting.length !== 0 &&
                          (customerActiveExisting[0].AVG_TRAN_TY_VS_LLY ===
                          "-999999"
                            ? "-"
                            : `LLY +${Number(
                                customerActiveExisting[0].AVG_TRAN_TY_VS_LLY
                              ).toFixed(2)}%`)}
                      </span>
                    )}
                  </td>
                </>
              )}
            </tr>
            <tr className="align-middle">
              <td className="tableCol">
                {"New Customers"}{" "}
                {gettooltip(
                  "NewCustomersInfoIcon",
                  "NewCustomers",
                  "NewCustomers",
                  "Active in L12M but not active in L12M to L24M"
                )}
              </td>
              {loading.Active_L12m ? (
                <>
                  <LoaderForRow tdCount={10} />
                </>
              ) : (
                <>
                  <td>
                    {customerActiveData !== undefined &&
                      customerActiveData.length !== 0 &&
                      (customerActiveData[0].ACT_CUST_COUNT_TY === "-999999"
                        ? "-"
                        : currencyFormat(
                            Number(customerActiveData[0].ACT_CUST_COUNT_TY)
                          ))}
                    <br />
                    {customerActiveData !== undefined &&
                    customerActiveData.length !== 0 &&
                    Number(customerActiveData[0].TY_VS_LY)
                      .toFixed(2)
                      .includes("-") ? (
                      <span style={{ color: "red", fontSize: "12px" }}>
                        {customerActiveData[0].TY_VS_LY === "-999999"
                          ? "-"
                          : `LY ${Number(
                              customerActiveData[0].TY_VS_LY
                            ).toFixed(2)}%`}
                      </span>
                    ) : (
                      <span style={{ color: "green", fontSize: "12px" }}>
                        {customerActiveData !== undefined &&
                          customerActiveData.length !== 0 &&
                          (customerActiveData[0].TY_VS_LY === "-999999"
                            ? "-"
                            : `LY +${Number(
                                customerActiveData[0].TY_VS_LY
                              ).toFixed(2)}%`)}
                      </span>
                    )}
                    <br />
                    {customerActiveData !== undefined &&
                    customerActiveData.length !== 0 &&
                    Number(customerActiveData[0].TY_VS_LLY)
                      .toFixed(2)
                      .includes("-") ? (
                      <span style={{ color: "red", fontSize: "11px" }}>
                        {customerActiveData !== undefined &&
                          customerActiveData.length !== 0 &&
                          (customerActiveData[0].TY_VS_LLY === "-999999"
                            ? "-"
                            : `LLY ${Number(
                                customerActiveData[0].TY_VS_LLY
                              ).toFixed(2)}%`)}
                      </span>
                    ) : (
                      <span style={{ color: "green", fontSize: "11px" }}>
                        {customerActiveData !== undefined &&
                          customerActiveData.length !== 0 &&
                          (customerActiveData[0].TY_VS_LLY === "-999999"
                            ? "-"
                            : `LLY +${Number(
                                customerActiveData[0].TY_VS_LLY
                              ).toFixed(2)}%`)}
                      </span>
                    )}
                  </td>
                  <td>
                    {customerActiveData !== undefined &&
                      customerActiveData.length !== 0 &&
                      (customerActiveData[0].NET_SALES_TY === "-999999"
                        ? "-"
                        : "$" +
                          currencyFormat(
                            Number(customerActiveData[0].NET_SALES_TY)
                          ))}
                    <br />
                    {customerActiveData !== undefined &&
                    customerActiveData.length !== 0 &&
                    Number(customerActiveData[0].NET_SALES_TY_VS_LY)
                      .toFixed(2)
                      .includes("-") ? (
                      <span style={{ color: "red", fontSize: "12px" }}>
                        {customerActiveData !== undefined &&
                          customerActiveData.length !== 0 &&
                          (customerActiveData[0].NET_SALES_TY_VS_LY ===
                          "-999999"
                            ? "-"
                            : `LY ${Number(
                                customerActiveData[0].NET_SALES_TY_VS_LY
                              ).toFixed(2)}%`)}
                      </span>
                    ) : (
                      <span style={{ color: "green", fontSize: "12px" }}>
                        {customerActiveData !== undefined &&
                          customerActiveData.length !== 0 &&
                          (customerActiveData[0].NET_SALES_TY_VS_LY ===
                          "-999999"
                            ? "-"
                            : `LY +${Number(
                                customerActiveData[0].NET_SALES_TY_VS_LY
                              ).toFixed(2)}%`)}
                      </span>
                    )}
                    <br />
                    {customerActiveData !== undefined &&
                    customerActiveData.length !== 0 &&
                    Number(customerActiveData[0].NET_SALES_TY_VS_LLY)
                      .toFixed(2)
                      .includes("-") ? (
                      <span style={{ color: "red", fontSize: "11px" }}>
                        {customerActiveData !== undefined &&
                          customerActiveData.length !== 0 &&
                          (customerActiveData[0].NET_SALES_TY_VS_LLY ===
                          "-999999"
                            ? "-"
                            : `LLY ${Number(
                                customerActiveData[0].NET_SALES_TY_VS_LLY
                              ).toFixed(2)}%`)}
                      </span>
                    ) : (
                      <span style={{ color: "green", fontSize: "11px" }}>
                        {customerActiveData !== undefined &&
                          customerActiveData.length !== 0 &&
                          (customerActiveData[0].NET_SALES_TY_VS_LLY ===
                          "-999999"
                            ? "-"
                            : `LLY +${Number(
                                customerActiveData[0].NET_SALES_TY_VS_LLY
                              ).toFixed(2)}%`)}
                      </span>
                    )}
                  </td>
                  <td>
                    {customerActiveData !== undefined &&
                      customerActiveData.length !== 0 &&
                      (customerActiveData[0].TRANS_COUNT_TY === "-999999"
                        ? "-"
                        : currencyFormat(
                            Number(customerActiveData[0].TRANS_COUNT_TY)
                          ))}
                    <br />
                    {customerActiveData !== undefined &&
                    customerActiveData.length !== 0 &&
                    Number(customerActiveData[0].TRANS_TY_VS_LY)
                      .toFixed(2)
                      .includes("-") ? (
                      <span style={{ color: "red", fontSize: "12px" }}>
                        {customerActiveData !== undefined &&
                          customerActiveData.length !== 0 &&
                          (customerActiveData[0].TRANS_TY_VS_LY === "-999999"
                            ? "-"
                            : `LY ${Number(
                                customerActiveData[0].TRANS_TY_VS_LY
                              ).toFixed(2)}%`)}
                      </span>
                    ) : (
                      <span style={{ color: "green", fontSize: "12px" }}>
                        {customerActiveData !== undefined &&
                          customerActiveData.length !== 0 &&
                          (customerActiveData[0].TRANS_TY_VS_LY === "-999999"
                            ? "-"
                            : `LY +${Number(
                                customerActiveData[0].TRANS_TY_VS_LY
                              ).toFixed(2)}%`)}
                      </span>
                    )}
                    <br />
                    {customerActiveData !== undefined &&
                    customerActiveData.length !== 0 &&
                    Number(customerActiveData[0].TRANS_TY_VS_LLY)
                      .toFixed(2)
                      .includes("-") ? (
                      <span style={{ color: "red", fontSize: "11px" }}>
                        {customerActiveData !== undefined &&
                          customerActiveData.length !== 0 &&
                          (customerActiveData[0].TRANS_TY_VS_LLY === "-999999"
                            ? "-"
                            : `LLY ${Number(
                                customerActiveData[0].TRANS_TY_VS_LLY
                              ).toFixed(2)}%`)}
                      </span>
                    ) : (
                      <span style={{ color: "green", fontSize: "11px" }}>
                        {customerActiveData !== undefined &&
                          customerActiveData.length !== 0 &&
                          (customerActiveData[0].TRANS_TY_VS_LLY === "-999999"
                            ? "-"
                            : `LLY +${Number(
                                customerActiveData[0].TRANS_TY_VS_LLY
                              ).toFixed(2)}%`)}
                      </span>
                    )}
                  </td>
                  <td>
                    {customerActiveData !== undefined &&
                      customerActiveData.length !== 0 &&
                      (customerActiveData[0].PM_TY === "-999999"
                        ? "-"
                        : "$" +
                          currencyFormat(Number(customerActiveData[0].PM_TY)))}
                    <br />
                    {customerActiveData !== undefined &&
                    customerActiveData.length !== 0 &&
                    Number(customerActiveData[0].PM_TY_VS_LY)
                      .toFixed(2)
                      .includes("-") ? (
                      <span style={{ color: "red", fontSize: "12px" }}>
                        {customerActiveData !== undefined &&
                          customerActiveData.length !== 0 &&
                          (customerActiveData[0].PM_TY_VS_LY === "-999999"
                            ? "-"
                            : `LY ${Number(
                                customerActiveData[0].PM_TY_VS_LY
                              ).toFixed(2)}%`)}
                      </span>
                    ) : (
                      <span style={{ color: "green", fontSize: "12px" }}>
                        {customerActiveData !== undefined &&
                          customerActiveData.length !== 0 &&
                          (customerActiveData[0].PM_TY_VS_LY === "-999999"
                            ? "-"
                            : `LY +${Number(
                                customerActiveData[0].PM_TY_VS_LY
                              ).toFixed(2)}%`)}
                      </span>
                    )}
                    <br />
                    {customerActiveData !== undefined &&
                    customerActiveData.length !== 0 &&
                    Number(customerActiveData[0].PM_TY_VS_LLY)
                      .toFixed(2)
                      .includes("-") ? (
                      <span style={{ color: "red", fontSize: "11px" }}>
                        {customerActiveData !== undefined &&
                          customerActiveData.length !== 0 &&
                          (customerActiveData[0].PM_TY_VS_LLY === "-999999"
                            ? "-"
                            : `LLY ${Number(
                                customerActiveData[0].PM_TY_VS_LLY
                              ).toFixed(2)}%`)}
                      </span>
                    ) : (
                      <span style={{ color: "green", fontSize: "11px" }}>
                        {customerActiveData !== undefined &&
                          customerActiveData.length !== 0 &&
                          (customerActiveData[0].PM_TY_VS_LLY === "-999999"
                            ? "-"
                            : `LLY +${Number(
                                customerActiveData[0].PM_TY_VS_LLY
                              ).toFixed(2)}%`)}
                      </span>
                    )}
                  </td>
                  <td>
                    {customerActiveData !== undefined &&
                      customerActiveData.length !== 0 &&
                      (customerActiveData[0].AOV_TY === "-999999"
                        ? "-"
                        : "$" +
                          Number(customerActiveData[0].AOV_TY).toFixed(2))}
                    <br />
                    {customerActiveData !== undefined &&
                    customerActiveData.length !== 0 &&
                    Number(customerActiveData[0].AOV_TY_VS_LY)
                      .toFixed(2)
                      .includes("-") ? (
                      <span style={{ color: "red", fontSize: "12px" }}>
                        {customerActiveData !== undefined &&
                          customerActiveData.length !== 0 &&
                          (customerActiveData[0].AOV_TY_VS_LY === "-999999"
                            ? "-"
                            : `LY ${Number(
                                customerActiveData[0].AOV_TY_VS_LY
                              ).toFixed(2)}%`)}
                      </span>
                    ) : (
                      <span style={{ color: "green", fontSize: "12px" }}>
                        {customerActiveData !== undefined &&
                          customerActiveData.length !== 0 &&
                          (customerActiveData[0].AOV_TY_VS_LY === "-999999"
                            ? "-"
                            : `LY +${Number(
                                customerActiveData[0].AOV_TY_VS_LY
                              ).toFixed(2)}%`)}
                      </span>
                    )}
                    <br />
                    {customerActiveData !== undefined &&
                    customerActiveData.length !== 0 &&
                    Number(customerActiveData[0].AOV_TY_VS_LLY)
                      .toFixed(2)
                      .includes("-") ? (
                      <span style={{ color: "red", fontSize: "11px" }}>
                        {customerActiveData !== undefined &&
                          customerActiveData.length !== 0 &&
                          (customerActiveData[0].AOV_TY_VS_LLY === "-999999"
                            ? "-"
                            : `LLY ${Number(
                                customerActiveData[0].AOV_TY_VS_LLY
                              ).toFixed(2)}%`)}
                      </span>
                    ) : (
                      <span style={{ color: "green", fontSize: "11px" }}>
                        {customerActiveData !== undefined &&
                          customerActiveData.length !== 0 &&
                          (customerActiveData[0].AOV_TY_VS_LLY === "-999999"
                            ? "-"
                            : `LLY +${Number(
                                customerActiveData[0].AOV_TY_VS_LLY
                              ).toFixed(2)}%`)}
                      </span>
                    )}
                  </td>
                  <td>
                    {customerActiveData !== undefined &&
                      customerActiveData.length !== 0 &&
                      (customerActiveData[0].UPT_TY === "-999999"
                        ? "-"
                        : Number(customerActiveData[0].UPT_TY).toFixed(1))}
                    <br />
                    {customerActiveData !== undefined &&
                    customerActiveData.length !== 0 &&
                    Number(customerActiveData[0].UPT_TY_VS_LY)
                      .toFixed(2)
                      .includes("-") ? (
                      <span style={{ color: "red", fontSize: "12px" }}>
                        {customerActiveData !== undefined &&
                          customerActiveData.length !== 0 &&
                          (customerActiveData[0].UPT_TY_VS_LY === "-999999"
                            ? "-"
                            : `LY ${Number(
                                customerActiveData[0].UPT_TY_VS_LY
                              ).toFixed(2)}%`)}
                      </span>
                    ) : (
                      <span style={{ color: "green", fontSize: "12px" }}>
                        {customerActiveData !== undefined &&
                          customerActiveData.length !== 0 &&
                          (customerActiveData[0].UPT_TY_VS_LY === "-999999"
                            ? "-"
                            : `LY +${Number(
                                customerActiveData[0].UPT_TY_VS_LY
                              ).toFixed(2)}%`)}
                      </span>
                    )}
                    <br />
                    {customerActiveData !== undefined &&
                    customerActiveData.length !== 0 &&
                    Number(customerActiveData[0].UPT_TY_VS_LLY)
                      .toFixed(2)
                      .includes("-") ? (
                      <span style={{ color: "red", fontSize: "11px" }}>
                        {customerActiveData !== undefined &&
                          customerActiveData.length !== 0 &&
                          (customerActiveData[0].UPT_TY_VS_LLY === "-999999"
                            ? "-"
                            : `LLY ${Number(
                                customerActiveData[0].UPT_TY_VS_LLY
                              ).toFixed(2)}%`)}
                      </span>
                    ) : (
                      <span style={{ color: "green", fontSize: "11px" }}>
                        {customerActiveData !== undefined &&
                          customerActiveData.length !== 0 &&
                          (customerActiveData[0].UPT_TY_VS_LLY === "-999999"
                            ? "-"
                            : `LLY +${Number(
                                customerActiveData[0].UPT_TY_VS_LLY
                              ).toFixed(2)}%`)}
                      </span>
                    )}
                  </td>
                  <td>
                    {customerActiveData !== undefined &&
                      customerActiveData.length !== 0 &&
                      (customerActiveData[0].AUR_TY === "-999999"
                        ? "-"
                        : "$" +
                          Number(customerActiveData[0].AUR_TY).toFixed(2))}
                    <br />
                    {customerActiveData !== undefined &&
                    customerActiveData.length !== 0 &&
                    Number(customerActiveData[0].AUR_TY_VS_LY)
                      .toFixed(2)
                      .includes("-") ? (
                      <span style={{ color: "red", fontSize: "12px" }}>
                        {customerActiveData !== undefined &&
                          customerActiveData.length !== 0 &&
                          (customerActiveData[0].AUR_TY_VS_LY === "-999999"
                            ? "-"
                            : `LY ${Number(
                                customerActiveData[0].AUR_TY_VS_LY
                              ).toFixed(2)}%`)}
                      </span>
                    ) : (
                      <span style={{ color: "green", fontSize: "12px" }}>
                        {customerActiveData !== undefined &&
                          customerActiveData.length !== 0 &&
                          (customerActiveData[0].AUR_TY_VS_LY === "-999999"
                            ? "-"
                            : `LY +${Number(
                                customerActiveData[0].AUR_TY_VS_LY
                              ).toFixed(2)}%`)}
                      </span>
                    )}
                    <br />
                    {customerActiveData !== undefined &&
                    customerActiveData.length !== 0 &&
                    Number(customerActiveData[0].AUR_TY_VS_LLY)
                      .toFixed(2)
                      .includes("-") ? (
                      <span style={{ color: "red", fontSize: "11px" }}>
                        {customerActiveData !== undefined &&
                          customerActiveData.length !== 0 &&
                          (customerActiveData[0].AUR_TY_VS_LLY === "-999999"
                            ? "-"
                            : `LLY ${Number(
                                customerActiveData[0].AUR_TY_VS_LLY
                              ).toFixed(2)}%`)}
                      </span>
                    ) : (
                      <span style={{ color: "green", fontSize: "11px" }}>
                        {customerActiveData !== undefined &&
                          customerActiveData.length !== 0 &&
                          (customerActiveData[0].AUR_TY_VS_LLY === "-999999"
                            ? "-"
                            : `LLY +${Number(
                                customerActiveData[0].AUR_TY_VS_LLY
                              ).toFixed(2)}%`)}
                      </span>
                    )}
                  </td>
                  <td>
                    {customerActiveData !== undefined &&
                      customerActiveData.length !== 0 &&
                      (customerActiveData[0].MARGIN_RATE_PER_TY === "-999999"
                        ? "-"
                        : Number(
                            customerActiveData[0].MARGIN_RATE_PER_TY
                          ).toFixed(2))}
                    <br />
                    {customerActiveData !== undefined &&
                    customerActiveData.length !== 0 &&
                    Number(customerActiveData[0].MARGIN_RATE_PER_TY_VS_LY)
                      .toFixed(2)
                      .includes("-") ? (
                      <span style={{ color: "red", fontSize: "12px" }}>
                        {customerActiveData !== undefined &&
                          customerActiveData.length !== 0 &&
                          (customerActiveData[0].MARGIN_RATE_PER_TY_VS_LY ===
                          "-999999"
                            ? "-"
                            : `LY ${Number(
                                customerActiveData[0].MARGIN_RATE_PER_TY_VS_LY
                              ).toFixed(2)}%`)}
                      </span>
                    ) : (
                      <span style={{ color: "green", fontSize: "12px" }}>
                        {customerActiveData !== undefined &&
                          customerActiveData.length !== 0 &&
                          (customerActiveData[0].MARGIN_RATE_PER_TY_VS_LY ===
                          "-999999"
                            ? "-"
                            : `LY +${Number(
                                customerActiveData[0].MARGIN_RATE_PER_TY_VS_LY
                              ).toFixed(2)}%`)}
                      </span>
                    )}
                    <br />
                    {customerActiveData !== undefined &&
                    customerActiveData.length !== 0 &&
                    Number(customerActiveData[0].MARGIN_RATE_PER_TY_VS_LLY)
                      .toFixed(2)
                      .includes("-") ? (
                      <span style={{ color: "red", fontSize: "11px" }}>
                        {customerActiveData !== undefined &&
                          customerActiveData.length !== 0 &&
                          (customerActiveData[0].MARGIN_RATE_PER_TY_VS_LLY ===
                          "-999999"
                            ? "-"
                            : `LLY ${Number(
                                customerActiveData[0].MARGIN_RATE_PER_TY_VS_LLY
                              ).toFixed(2)}%`)}
                      </span>
                    ) : (
                      <span style={{ color: "green", fontSize: "11px" }}>
                        {customerActiveData !== undefined &&
                          customerActiveData.length !== 0 &&
                          (customerActiveData[0].MARGIN_RATE_PER_TY_VS_LLY ===
                          "-999999"
                            ? "-"
                            : `LLY +${Number(
                                customerActiveData[0].MARGIN_RATE_PER_TY_VS_LLY
                              ).toFixed(2)}%`)}
                      </span>
                    )}
                  </td>
                  <td>
                    {customerActiveData !== undefined &&
                      customerActiveData.length !== 0 &&
                      (customerActiveData[0].NET_SALES_PER_CUST_TY === "-999999"
                        ? "-"
                        : "$" +
                          Number(
                            customerActiveData[0].NET_SALES_PER_CUST_TY
                          ).toFixed(2))}
                    <br />
                    {customerActiveData !== undefined &&
                    customerActiveData.length !== 0 &&
                    Number(customerActiveData[0].NET_SALES_PER_CUST_TY_VS_LY)
                      .toFixed(2)
                      .includes("-") ? (
                      <span style={{ color: "red", fontSize: "12px" }}>
                        {customerActiveData !== undefined &&
                          customerActiveData.length !== 0 &&
                          (customerActiveData[0].NET_SALES_PER_CUST_TY_VS_LY ===
                          "-999999"
                            ? "-"
                            : `LY ${Number(
                                customerActiveData[0]
                                  .NET_SALES_PER_CUST_TY_VS_LY
                              ).toFixed(2)}%`)}
                      </span>
                    ) : (
                      <span style={{ color: "green", fontSize: "12px" }}>
                        {customerActiveData !== undefined &&
                          customerActiveData.length !== 0 &&
                          (customerActiveData[0].NET_SALES_PER_CUST_TY_VS_LY ===
                          "-999999"
                            ? "-"
                            : `LY +${Number(
                                customerActiveData[0]
                                  .NET_SALES_PER_CUST_TY_VS_LY
                              ).toFixed(2)}%`)}
                      </span>
                    )}
                    <br />
                    {customerActiveData !== undefined &&
                    customerActiveData.length !== 0 &&
                    Number(customerActiveData[0].NET_SALES_PER_CUST_TY_VS_LLY)
                      .toFixed(2)
                      .includes("-") ? (
                      <span style={{ color: "red", fontSize: "11px" }}>
                        {customerActiveData !== undefined &&
                          customerActiveData.length !== 0 &&
                          (customerActiveData[0]
                            .NET_SALES_PER_CUST_TY_VS_LLY === "-999999"
                            ? "-"
                            : `LLY ${Number(
                                customerActiveData[0]
                                  .NET_SALES_PER_CUST_TY_VS_LLY
                              ).toFixed(2)}%`)}
                      </span>
                    ) : (
                      <span style={{ color: "green", fontSize: "11px" }}>
                        {customerActiveData !== undefined &&
                          customerActiveData.length !== 0 &&
                          (customerActiveData[0]
                            .NET_SALES_PER_CUST_TY_VS_LLY === "-999999"
                            ? "-"
                            : `LLY +${Number(
                                customerActiveData[0]
                                  .NET_SALES_PER_CUST_TY_VS_LLY
                              ).toFixed(2)}%`)}
                      </span>
                    )}
                  </td>
                  <td>
                    {customerActiveData !== undefined &&
                      customerActiveData.length !== 0 &&
                      (customerActiveData[0].AVG_TRAN_TY === "-999999"
                        ? "-"
                        : Number(customerActiveData[0].AVG_TRAN_TY).toFixed(2))}
                    <br />
                    {customerActiveData !== undefined &&
                    customerActiveData.length !== 0 &&
                    Number(customerActiveData[0].AVG_TRAN_TY_VS_LY)
                      .toFixed(2)
                      .includes("-") ? (
                      <span style={{ color: "red", fontSize: "12px" }}>
                        {customerActiveData !== undefined &&
                          customerActiveData.length !== 0 &&
                          (customerActiveData[0].AVG_TRAN_TY_VS_LY === "-999999"
                            ? "-"
                            : `LY ${Number(
                                customerActiveData[0].AVG_TRAN_TY_VS_LY
                              ).toFixed(2)}%`)}
                      </span>
                    ) : (
                      <span style={{ color: "green", fontSize: "12px" }}>
                        {customerActiveData !== undefined &&
                          customerActiveData.length !== 0 &&
                          (customerActiveData[0].AVG_TRAN_TY_VS_LY === "-999999"
                            ? "-"
                            : `LY +${Number(
                                customerActiveData[0].AVG_TRAN_TY_VS_LY
                              ).toFixed(2)}%`)}
                      </span>
                    )}
                    <br />
                    {customerActiveData !== undefined &&
                    customerActiveData.length !== 0 &&
                    Number(customerActiveData[0].AVG_TRAN_TY_VS_LLY)
                      .toFixed(2)
                      .includes("-") ? (
                      <span style={{ color: "red", fontSize: "11px" }}>
                        {customerActiveData !== undefined &&
                          customerActiveData.length !== 0 &&
                          (customerActiveData[0].AVG_TRAN_TY_VS_LLY ===
                          "-999999"
                            ? "-"
                            : `LLY ${Number(
                                customerActiveData[0].AVG_TRAN_TY_VS_LLY
                              ).toFixed(2)}%`)}
                      </span>
                    ) : (
                      <span style={{ color: "green", fontSize: "11px" }}>
                        {customerActiveData !== undefined &&
                          customerActiveData.length !== 0 &&
                          (customerActiveData[0].AVG_TRAN_TY_VS_LLY ===
                          "-999999"
                            ? "-"
                            : `LLY +${Number(
                                customerActiveData[0].AVG_TRAN_TY_VS_LLY
                              ).toFixed(2)}%`)}
                      </span>
                    )}
                  </td>
                </>
              )}
            </tr>
            <tr className="align-middle">
              <td className="tableCol" id={"AtRisk_69"}>
                {"At risk (6m-9m)"}{" "}
                {gettooltip(
                  "AtRisk_6_9InfoIcon",
                  "AtRisk_6_9",
                  "AtRisk_6_9",
                  "Active in L9M but not active in L6M"
                )}
              </td>
              {loading.AtRisk_6m_9m ? (
                <>
                  <LoaderForRow tdCount={10} />
                </>
              ) : (
                <>
                  <td>
                    {customerDataSixMonths !== undefined &&
                      customerDataSixMonths.length !== 0 &&
                      (customerDataSixMonths[0].CUST_COUNT_TY === "-999999"
                        ? "-"
                        : currencyFormat(
                            Number(customerDataSixMonths[0].CUST_COUNT_TY)
                          ))}
                    <br />
                    {customerDataSixMonths !== undefined &&
                    customerDataSixMonths.length !== 0 &&
                    Number(customerDataSixMonths[0].TY_VS_LY)
                      .toFixed(2)
                      .includes("-") ? (
                      <span style={{ color: "green", fontSize: "12px" }}>
                        {customerDataSixMonths !== undefined &&
                          customerDataSixMonths.length !== 0 &&
                          (customerDataSixMonths[0].TY_VS_LY === "-999999"
                            ? "-"
                            : `LY ${Number(
                                customerDataSixMonths[0].TY_VS_LY
                              ).toFixed(2)}%`)}
                      </span>
                    ) : (
                      <span style={{ color: "red", fontSize: "12px" }}>
                        {customerDataSixMonths !== undefined &&
                          customerDataSixMonths.length !== 0 &&
                          (customerDataSixMonths[0].TY_VS_LY === "-999999"
                            ? "-"
                            : `LY +${Number(
                                customerDataSixMonths[0].TY_VS_LY
                              ).toFixed(2)}%`)}
                      </span>
                    )}
                    <br />
                    {customerDataSixMonths !== undefined &&
                    customerDataSixMonths.length !== 0 &&
                    Number(customerDataSixMonths[0].TY_VS_LLY)
                      .toFixed(2)
                      .includes("-") ? (
                      <span style={{ color: "green", fontSize: "11px" }}>
                        {customerDataSixMonths !== undefined &&
                          customerDataSixMonths.length !== 0 &&
                          (customerDataSixMonths[0].TY_VS_LLY === "-999999"
                            ? "-"
                            : `LLY ${Number(
                                customerDataSixMonths[0].TY_VS_LLY
                              ).toFixed(2)}%`)}
                      </span>
                    ) : (
                      <span style={{ color: "red", fontSize: "11px" }}>
                        {customerDataSixMonths !== undefined &&
                          customerDataSixMonths.length !== 0 &&
                          (customerDataSixMonths[0].TY_VS_LLY === "-999999"
                            ? "-"
                            : `LLY +${Number(
                                customerDataSixMonths[0].TY_VS_LLY
                              ).toFixed(2)}%`)}
                      </span>
                    )}
                  </td>
                  <td>
                    {customerDataSixMonths !== undefined &&
                      customerDataSixMonths.length !== 0 &&
                      (customerDataSixMonths[0].NET_SALES_TY === "-999999"
                        ? "-"
                        : "$" +
                          currencyFormat(
                            Number(customerDataSixMonths[0].NET_SALES_TY)
                          ))}
                    <br />
                    {customerDataSixMonths !== undefined &&
                    customerDataSixMonths.length !== 0 &&
                    Number(customerDataSixMonths[0].NET_SALES_TY_VS_LY)
                      .toFixed(2)
                      .includes("-") ? (
                      <span style={{ color: "green", fontSize: "12px" }}>
                        {customerDataSixMonths !== undefined &&
                          customerDataSixMonths.length !== 0 &&
                          (customerDataSixMonths[0].NET_SALES_TY_VS_LY ===
                          "-999999"
                            ? "-"
                            : `LY ${Number(
                                customerDataSixMonths[0].NET_SALES_TY_VS_LY
                              ).toFixed(2)}%`)}
                      </span>
                    ) : (
                      <span style={{ color: "red", fontSize: "12px" }}>
                        {customerDataSixMonths !== undefined &&
                          customerDataSixMonths.length !== 0 &&
                          (customerDataSixMonths[0].NET_SALES_TY_VS_LY ===
                          "-999999"
                            ? "-"
                            : `LY +${Number(
                                customerDataSixMonths[0].NET_SALES_TY_VS_LY
                              ).toFixed(2)}%`)}
                      </span>
                    )}
                    <br />
                    {customerDataSixMonths !== undefined &&
                    customerDataSixMonths.length !== 0 &&
                    Number(customerDataSixMonths[0].NET_SALES_TY_VS_LLY)
                      .toFixed(2)
                      .includes("-") ? (
                      <span style={{ color: "green", fontSize: "11px" }}>
                        {customerDataSixMonths !== undefined &&
                          customerDataSixMonths.length !== 0 &&
                          (customerDataSixMonths[0].NET_SALES_TY_VS_LLY ===
                          "-999999"
                            ? "-"
                            : `LLY ${Number(
                                customerDataSixMonths[0].NET_SALES_TY_VS_LLY
                              ).toFixed(2)}%`)}
                      </span>
                    ) : (
                      <span style={{ color: "red", fontSize: "11px" }}>
                        {customerDataSixMonths !== undefined &&
                          customerDataSixMonths.length !== 0 &&
                          (customerDataSixMonths[0].NET_SALES_TY_VS_LLY ===
                          "-999999"
                            ? "-"
                            : `LLY +${Number(
                                customerDataSixMonths[0].NET_SALES_TY_VS_LLY
                              ).toFixed(2)}%`)}
                      </span>
                    )}
                  </td>
                  <td>
                    {customerDataSixMonths !== undefined &&
                      customerDataSixMonths.length !== 0 &&
                      (customerDataSixMonths[0].TRANS_COUNT_TY === "-999999"
                        ? "-"
                        : currencyFormat(
                            Number(customerDataSixMonths[0].TRANS_COUNT_TY)
                          ))}
                    <br />
                    {customerDataSixMonths !== undefined &&
                    customerDataSixMonths.length !== 0 &&
                    Number(customerDataSixMonths[0].TRANS_TY_VS_LY)
                      .toFixed(2)
                      .includes("-") ? (
                      <span style={{ color: "green", fontSize: "12px" }}>
                        {customerDataSixMonths !== undefined &&
                          customerDataSixMonths.length !== 0 &&
                          (customerDataSixMonths[0].TRANS_TY_VS_LY === "-999999"
                            ? "-"
                            : `LY ${Number(
                                customerDataSixMonths[0].TRANS_TY_VS_LY
                              ).toFixed(2)}%`)}
                      </span>
                    ) : (
                      <span style={{ color: "red", fontSize: "12px" }}>
                        {customerDataSixMonths !== undefined &&
                          customerDataSixMonths.length !== 0 &&
                          (customerDataSixMonths[0].TRANS_TY_VS_LY === "-999999"
                            ? "-"
                            : `LY ${Number(
                                customerDataSixMonths[0].TRANS_TY_VS_LY
                              ).toFixed(2)}%`)}
                      </span>
                    )}
                    <br />
                    {customerDataSixMonths !== undefined &&
                    customerDataSixMonths.length !== 0 &&
                    Number(customerDataSixMonths[0].TRANS_TY_VS_LLY)
                      .toFixed(2)
                      .includes("-") ? (
                      <span style={{ color: "green", fontSize: "11px" }}>
                        {customerDataSixMonths !== undefined &&
                          customerDataSixMonths.length !== 0 &&
                          (customerDataSixMonths[0].TRANS_TY_VS_LLY ===
                          "-999999"
                            ? "-"
                            : `LLY ${Number(
                                customerDataSixMonths[0].TRANS_TY_VS_LLY
                              ).toFixed(2)}%`)}
                      </span>
                    ) : (
                      <span style={{ color: "red", fontSize: "11px" }}>
                        {customerDataSixMonths !== undefined &&
                          customerDataSixMonths.length !== 0 &&
                          (customerDataSixMonths[0].TRANS_TY_VS_LLY ===
                          "-999999"
                            ? "-"
                            : `LLY +${Number(
                                customerDataSixMonths[0].TRANS_TY_VS_LLY
                              ).toFixed(2)}%`)}
                      </span>
                    )}
                  </td>
                  <td>
                    {customerDataSixMonths !== undefined &&
                      customerDataSixMonths.length !== 0 &&
                      (customerDataSixMonths[0].PM_TY === "-999999"
                        ? "-"
                        : "$" +
                          currencyFormat(
                            Number(customerDataSixMonths[0].PM_TY)
                          ))}
                    <br />
                    {customerDataSixMonths !== undefined &&
                    customerDataSixMonths.length !== 0 &&
                    Number(customerDataSixMonths[0].PM_TY_VS_LY)
                      .toFixed(2)
                      .includes("-") ? (
                      <span style={{ color: "green", fontSize: "12px" }}>
                        {customerDataSixMonths !== undefined &&
                          customerDataSixMonths.length !== 0 &&
                          (customerDataSixMonths[0].PM_TY_VS_LY === "-999999"
                            ? "-"
                            : `LY ${Number(
                                customerDataSixMonths[0].PM_TY_VS_LY
                              ).toFixed(2)}%`)}
                      </span>
                    ) : (
                      <span style={{ color: "red", fontSize: "12px" }}>
                        {customerDataSixMonths !== undefined &&
                          customerDataSixMonths.length !== 0 &&
                          (customerDataSixMonths[0].PM_TY_VS_LY === "-999999"
                            ? "-"
                            : `LY +${Number(
                                customerDataSixMonths[0].PM_TY_VS_LY
                              ).toFixed(2)}%`)}
                      </span>
                    )}
                    <br />
                    {customerDataSixMonths !== undefined &&
                    customerDataSixMonths.length !== 0 &&
                    Number(customerDataSixMonths[0].PM_TY_VS_LLY)
                      .toFixed(2)
                      .includes("-") ? (
                      <span style={{ color: "green", fontSize: "11px" }}>
                        {customerDataSixMonths !== undefined &&
                          customerDataSixMonths.length !== 0 &&
                          (customerDataSixMonths[0].PM_TY_VS_LLY === "-999999"
                            ? "-"
                            : `LLY ${Number(
                                customerDataSixMonths[0].PM_TY_VS_LLY
                              ).toFixed(2)}%`)}
                      </span>
                    ) : (
                      <span style={{ color: "red", fontSize: "11px" }}>
                        {customerDataSixMonths !== undefined &&
                          customerDataSixMonths.length !== 0 &&
                          (customerDataSixMonths[0].PM_TY_VS_LLY === "-999999"
                            ? "-"
                            : `LLY +${Number(
                                customerDataSixMonths[0].PM_TY_VS_LLY
                              ).toFixed(2)}%`)}
                      </span>
                    )}
                  </td>
                  <td>
                    {customerDataSixMonths !== undefined &&
                      customerDataSixMonths.length !== 0 &&
                      (customerDataSixMonths[0].AOV_TY === "-999999"
                        ? "-"
                        : "$" +
                          Number(customerDataSixMonths[0].AOV_TY).toFixed(2))}
                    <br />
                    {customerDataSixMonths !== undefined &&
                    customerDataSixMonths.length !== 0 &&
                    Number(customerDataSixMonths[0].AOV_TY_VS_LY)
                      .toFixed(2)
                      .includes("-") ? (
                      <span style={{ color: "green", fontSize: "12px" }}>
                        {customerDataSixMonths !== undefined &&
                          customerDataSixMonths.length !== 0 &&
                          (customerDataSixMonths[0].AOV_TY_VS_LY === "-999999"
                            ? "-"
                            : `LY ${Number(
                                customerDataSixMonths[0].AOV_TY_VS_LY
                              ).toFixed(2)}%`)}
                      </span>
                    ) : (
                      <span style={{ color: "red", fontSize: "12px" }}>
                        {customerDataSixMonths !== undefined &&
                          customerDataSixMonths.length !== 0 &&
                          (customerDataSixMonths[0].AOV_TY_VS_LY === "-999999"
                            ? "-"
                            : `LY +${Number(
                                customerDataSixMonths[0].AOV_TY_VS_LY
                              ).toFixed(2)}%`)}
                      </span>
                    )}
                    <br />
                    {customerDataSixMonths !== undefined &&
                    customerDataSixMonths.length !== 0 &&
                    Number(customerDataSixMonths[0].AOV_TY_VS_LLY)
                      .toFixed(2)
                      .includes("-") ? (
                      <span style={{ color: "green", fontSize: "11px" }}>
                        {customerDataSixMonths !== undefined &&
                          customerDataSixMonths.length !== 0 &&
                          (customerDataSixMonths[0].AOV_TY_VS_LLY === "-999999"
                            ? "-"
                            : `LLY ${Number(
                                customerDataSixMonths[0].AOV_TY_VS_LLY
                              ).toFixed(2)}%`)}
                      </span>
                    ) : (
                      <span style={{ color: "red", fontSize: "11px" }}>
                        {customerDataSixMonths !== undefined &&
                          customerDataSixMonths.length !== 0 &&
                          (customerDataSixMonths[0].AOV_TY_VS_LLY === "-999999"
                            ? "-"
                            : `LLY +${Number(
                                customerDataSixMonths[0].AOV_TY_VS_LLY
                              ).toFixed(2)}%`)}
                      </span>
                    )}
                  </td>
                  <td>
                    {customerDataSixMonths !== undefined &&
                      customerDataSixMonths.length !== 0 &&
                      (customerDataSixMonths[0].UPT_TY === "-999999"
                        ? "-"
                        : Number(customerDataSixMonths[0].UPT_TY).toFixed(1))}
                    <br />
                    {customerDataSixMonths !== undefined &&
                    customerDataSixMonths.length !== 0 &&
                    Number(customerDataSixMonths[0].UPT_TY_VS_LY)
                      .toFixed(2)
                      .includes("-") ? (
                      <span style={{ color: "green", fontSize: "12px" }}>
                        {customerDataSixMonths !== undefined &&
                          customerDataSixMonths.length !== 0 &&
                          (customerDataSixMonths[0].UPT_TY_VS_LY === "-999999"
                            ? "-"
                            : `LY ${Number(
                                customerDataSixMonths[0].UPT_TY_VS_LY
                              ).toFixed(2)}%`)}
                      </span>
                    ) : (
                      <span style={{ color: "red", fontSize: "12px" }}>
                        {customerDataSixMonths !== undefined &&
                          customerDataSixMonths.length !== 0 &&
                          (customerDataSixMonths[0].UPT_TY_VS_LY === "-999999"
                            ? "-"
                            : `LY +${Number(
                                customerDataSixMonths[0].UPT_TY_VS_LY
                              ).toFixed(2)}%`)}
                      </span>
                    )}
                    <br />
                    {customerDataSixMonths !== undefined &&
                    customerDataSixMonths.length !== 0 &&
                    Number(customerDataSixMonths[0].UPT_TY_VS_LLY)
                      .toFixed(2)
                      .includes("-") ? (
                      <span style={{ color: "green", fontSize: "11px" }}>
                        {customerDataSixMonths !== undefined &&
                          customerDataSixMonths.length !== 0 &&
                          (customerDataSixMonths[0].UPT_TY_VS_LLY === "-999999"
                            ? "-"
                            : `LLY ${Number(
                                customerDataSixMonths[0].UPT_TY_VS_LLY
                              ).toFixed(2)}%`)}
                      </span>
                    ) : (
                      <span style={{ color: "red", fontSize: "11px" }}>
                        {customerDataSixMonths !== undefined &&
                          customerDataSixMonths.length !== 0 &&
                          (customerDataSixMonths[0].UPT_TY_VS_LLY === "-999999"
                            ? "-"
                            : `LLY +${Number(
                                customerDataSixMonths[0].UPT_TY_VS_LLY
                              ).toFixed(2)}%`)}
                      </span>
                    )}
                  </td>
                  <td>
                    {customerDataSixMonths !== undefined &&
                      customerDataSixMonths.length !== 0 &&
                      (customerDataSixMonths[0].AUR_TY === "-999999"
                        ? "-"
                        : "$" +
                          Number(customerDataSixMonths[0].AUR_TY).toFixed(2))}
                    <br />
                    {customerDataSixMonths !== undefined &&
                    customerDataSixMonths.length !== 0 &&
                    Number(customerDataSixMonths[0].AUR_TY_VS_LY)
                      .toFixed(2)
                      .includes("-") ? (
                      <span style={{ color: "green", fontSize: "12px" }}>
                        {customerDataSixMonths !== undefined &&
                          customerDataSixMonths.length !== 0 &&
                          (customerDataSixMonths[0].AUR_TY_VS_LY === "-999999"
                            ? "-"
                            : `LY ${Number(
                                customerDataSixMonths[0].AUR_TY_VS_LY
                              ).toFixed(2)}%`)}
                      </span>
                    ) : (
                      <span style={{ color: "red", fontSize: "12px" }}>
                        {customerDataSixMonths !== undefined &&
                          customerDataSixMonths.length !== 0 &&
                          (customerDataSixMonths[0].AUR_TY_VS_LY === "-999999"
                            ? "-"
                            : `LY +${Number(
                                customerDataSixMonths[0].AUR_TY_VS_LY
                              ).toFixed(2)}%`)}
                      </span>
                    )}
                    <br />
                    {customerDataSixMonths !== undefined &&
                    customerDataSixMonths.length !== 0 &&
                    Number(customerDataSixMonths[0].AUR_TY_VS_LLY)
                      .toFixed(2)
                      .includes("-") ? (
                      <span style={{ color: "green", fontSize: "11px" }}>
                        {customerDataSixMonths !== undefined &&
                          customerDataSixMonths.length !== 0 &&
                          (customerDataSixMonths[0].AUR_TY_VS_LLY === "-999999"
                            ? "-"
                            : `LLY ${Number(
                                customerDataSixMonths[0].AUR_TY_VS_LLY
                              ).toFixed(2)}%`)}
                      </span>
                    ) : (
                      <span style={{ color: "red", fontSize: "11px" }}>
                        {customerDataSixMonths !== undefined &&
                          customerDataSixMonths.length !== 0 &&
                          (customerDataSixMonths[0].AUR_TY_VS_LLY === "-999999"
                            ? "-"
                            : `LLY +${Number(
                                customerDataSixMonths[0].AUR_TY_VS_LLY
                              ).toFixed(2)}%`)}
                      </span>
                    )}
                  </td>
                  <td>
                    {customerDataSixMonths !== undefined &&
                      customerDataSixMonths.length !== 0 &&
                      (customerDataSixMonths[0].MARGIN_RATE_PER_TY === "-999999"
                        ? "-"
                        : Number(
                            customerDataSixMonths[0].MARGIN_RATE_PER_TY
                          ).toFixed(2))}
                    <br />
                    {customerDataSixMonths !== undefined &&
                    customerDataSixMonths.length !== 0 &&
                    Number(customerDataSixMonths[0].MARGIN_RATE_PER_TY_VS_LY)
                      .toFixed(2)
                      .includes("-") ? (
                      <span style={{ color: "green", fontSize: "12px" }}>
                        {customerDataSixMonths !== undefined &&
                          customerDataSixMonths.length !== 0 &&
                          (customerDataSixMonths[0].MARGIN_RATE_PER_TY_VS_LY ===
                          "-999999"
                            ? "-"
                            : `LY ${Number(
                                customerDataSixMonths[0]
                                  .MARGIN_RATE_PER_TY_VS_LY
                              ).toFixed(2)}%`)}
                      </span>
                    ) : (
                      <span style={{ color: "red", fontSize: "12px" }}>
                        {customerDataSixMonths !== undefined &&
                          customerDataSixMonths.length !== 0 &&
                          (customerDataSixMonths[0].MARGIN_RATE_PER_TY_VS_LY ===
                          "-999999"
                            ? "-"
                            : `LY +${Number(
                                customerDataSixMonths[0]
                                  .MARGIN_RATE_PER_TY_VS_LY
                              ).toFixed(2)}%`)}
                      </span>
                    )}
                    <br />
                    {customerDataSixMonths !== undefined &&
                    customerDataSixMonths.length !== 0 &&
                    Number(customerDataSixMonths[0].MARGIN_RATE_PER_TY_VS_LLY)
                      .toFixed(2)
                      .includes("-") ? (
                      <span style={{ color: "green", fontSize: "11px" }}>
                        {customerDataSixMonths !== undefined &&
                          customerDataSixMonths.length !== 0 &&
                          (customerDataSixMonths[0]
                            .MARGIN_RATE_PER_TY_VS_LLY === "-999999"
                            ? "-"
                            : `LLY ${Number(
                                customerDataSixMonths[0]
                                  .MARGIN_RATE_PER_TY_VS_LLY
                              ).toFixed(2)}%`)}
                      </span>
                    ) : (
                      <span style={{ color: "red", fontSize: "11px" }}>
                        {customerDataSixMonths !== undefined &&
                          customerDataSixMonths.length !== 0 &&
                          (customerDataSixMonths[0]
                            .MARGIN_RATE_PER_TY_VS_LLY === "-999999"
                            ? "-"
                            : `LLY +${Number(
                                customerDataSixMonths[0]
                                  .MARGIN_RATE_PER_TY_VS_LLY
                              ).toFixed(2)}%`)}
                      </span>
                    )}
                  </td>
                  <td>
                    {customerDataSixMonths !== undefined &&
                      customerDataSixMonths.length !== 0 &&
                      (customerDataSixMonths[0].NET_SALES_PER_CUST_TY ===
                      "-999999"
                        ? "-"
                        : "$" +
                          Number(
                            customerDataSixMonths[0].NET_SALES_PER_CUST_TY
                          ).toFixed(2))}
                    <br />
                    {customerDataSixMonths !== undefined &&
                    customerDataSixMonths.length !== 0 &&
                    Number(customerDataSixMonths[0].NET_SALES_PER_CUST_TY_VS_LY)
                      .toFixed(2)
                      .includes("-") ? (
                      <span style={{ color: "green", fontSize: "12px" }}>
                        {customerDataSixMonths !== undefined &&
                          customerDataSixMonths.length !== 0 &&
                          (customerDataSixMonths[0]
                            .NET_SALES_PER_CUST_TY_VS_LY === "-999999"
                            ? "-"
                            : `LY ${Number(
                                customerDataSixMonths[0]
                                  .NET_SALES_PER_CUST_TY_VS_LY
                              ).toFixed(2)}%`)}
                      </span>
                    ) : (
                      <span style={{ color: "red", fontSize: "12px" }}>
                        {customerDataSixMonths !== undefined &&
                          customerDataSixMonths.length !== 0 &&
                          (customerDataSixMonths[0]
                            .NET_SALES_PER_CUST_TY_VS_LY === "-999999"
                            ? "-"
                            : `LY +${Number(
                                customerDataSixMonths[0]
                                  .NET_SALES_PER_CUST_TY_VS_LY
                              ).toFixed(2)}%`)}
                      </span>
                    )}
                    <br />
                    {customerDataSixMonths !== undefined &&
                    customerDataSixMonths.length !== 0 &&
                    Number(
                      customerDataSixMonths[0].NET_SALES_PER_CUST_TY_VS_LLY
                    )
                      .toFixed(2)
                      .includes("-") ? (
                      <span style={{ color: "green", fontSize: "11px" }}>
                        {customerDataSixMonths !== undefined &&
                          customerDataSixMonths.length !== 0 &&
                          (customerDataSixMonths[0]
                            .NET_SALES_PER_CUST_TY_VS_LLY === "-999999"
                            ? "-"
                            : `LLY ${Number(
                                customerDataSixMonths[0]
                                  .NET_SALES_PER_CUST_TY_VS_LLY
                              ).toFixed(2)}%`)}
                      </span>
                    ) : (
                      <span style={{ color: "red", fontSize: "11px" }}>
                        {customerDataSixMonths !== undefined &&
                          customerDataSixMonths.length !== 0 &&
                          (customerDataSixMonths[0]
                            .NET_SALES_PER_CUST_TY_VS_LLY === "-999999"
                            ? "-"
                            : `LLY +${Number(
                                customerDataSixMonths[0]
                                  .NET_SALES_PER_CUST_TY_VS_LLY
                              ).toFixed(2)}%`)}
                      </span>
                    )}
                  </td>
                  <td>
                    {customerDataSixMonths !== undefined &&
                      customerDataSixMonths.length !== 0 &&
                      (customerDataSixMonths[0].AVG_TRAN_TY === "-999999"
                        ? "-"
                        : Number(customerDataSixMonths[0].AVG_TRAN_TY).toFixed(
                            2
                          ))}
                    <br />
                    {customerDataSixMonths !== undefined &&
                    customerDataSixMonths.length !== 0 &&
                    Number(customerDataSixMonths[0].AVG_TRAN_TY_VS_LY)
                      .toFixed(2)
                      .includes("-") ? (
                      <span style={{ color: "green", fontSize: "12px" }}>
                        {customerDataSixMonths !== undefined &&
                          customerDataSixMonths.length !== 0 &&
                          (customerDataSixMonths[0].AVG_TRAN_TY_VS_LY ===
                          "-999999"
                            ? "-"
                            : `LY ${Number(
                                customerDataSixMonths[0].AVG_TRAN_TY_VS_LY
                              ).toFixed(2)}%`)}
                      </span>
                    ) : (
                      <span style={{ color: "red", fontSize: "12px" }}>
                        {customerDataSixMonths !== undefined &&
                          customerDataSixMonths.length !== 0 &&
                          (customerDataSixMonths[0].AVG_TRAN_TY_VS_LY ===
                          "-999999"
                            ? "-"
                            : `LY +${Number(
                                customerDataSixMonths[0].AVG_TRAN_TY_VS_LY
                              ).toFixed(2)}%`)}
                      </span>
                    )}
                    <br />
                    {customerDataSixMonths !== undefined &&
                    customerDataSixMonths.length !== 0 &&
                    Number(customerDataSixMonths[0].AVG_TRAN_TY_VS_LLY)
                      .toFixed(2)
                      .includes("-") ? (
                      <span style={{ color: "green", fontSize: "11px" }}>
                        {customerDataSixMonths !== undefined &&
                          customerDataSixMonths.length !== 0 &&
                          (customerDataSixMonths[0].AVG_TRAN_TY_VS_LLY ===
                          "-999999"
                            ? "-"
                            : `LLY ${Number(
                                customerDataSixMonths[0].AVG_TRAN_TY_VS_LLY
                              ).toFixed(2)}%`)}
                      </span>
                    ) : (
                      <span style={{ color: "red", fontSize: "11px" }}>
                        {customerDataSixMonths !== undefined &&
                          customerDataSixMonths.length !== 0 &&
                          (customerDataSixMonths[0].AVG_TRAN_TY_VS_LLY ===
                          "-999999"
                            ? "-"
                            : `LLY +${Number(
                                customerDataSixMonths[0].AVG_TRAN_TY_VS_LLY
                              ).toFixed(2)}%`)}
                      </span>
                    )}
                  </td>
                </>
              )}
            </tr>
            <tr className="align-middle">
              <td className="tableCol" id={"AtRisk_9_12"}>
                {"At risk (9m-12m)"}{" "}
                {gettooltip(
                  "AtRisk_9_12InfoIcon",
                  "AtRisk_9_12",
                  "AtRisk_9_12",
                  "Active in L12M but not active in L9M"
                )}
              </td>
              {loading.AtRisk_9m_12m ? (
                <>
                  <LoaderForRow tdCount={10} />
                </>
              ) : (
                <>
                  <td>
                    {customerDataNineMonths !== undefined &&
                      customerDataNineMonths.length !== 0 &&
                      (customerDataNineMonths[0].CUST_COUNT_TY === "-999999"
                        ? "-"
                        : currencyFormat(
                            Number(customerDataNineMonths[0].CUST_COUNT_TY)
                          ))}
                    <br />
                    {customerDataNineMonths !== undefined &&
                    customerDataNineMonths.length !== 0 &&
                    Number(customerDataNineMonths[0].TY_VS_LY)
                      .toFixed(2)
                      .includes("-") ? (
                      <span style={{ color: "green", fontSize: "12px" }}>
                        {customerDataNineMonths !== undefined &&
                          customerDataNineMonths.length !== 0 &&
                          (customerDataNineMonths[0].TY_VS_LY === "-999999"
                            ? "-"
                            : `LY ${Number(
                                customerDataNineMonths[0].TY_VS_LY
                              ).toFixed(2)}%`)}
                      </span>
                    ) : (
                      <span style={{ color: "red", fontSize: "12px" }}>
                        {customerDataNineMonths !== undefined &&
                          customerDataNineMonths.length !== 0 &&
                          (customerDataNineMonths[0].TY_VS_LY === "-999999"
                            ? "-"
                            : `LY +${Number(
                                customerDataNineMonths[0].TY_VS_LY
                              ).toFixed(2)}%`)}
                      </span>
                    )}
                    <br />
                    {customerDataNineMonths !== undefined &&
                    customerDataNineMonths.length !== 0 &&
                    Number(customerDataNineMonths[0].TY_VS_LLY)
                      .toFixed(2)
                      .includes("-") ? (
                      <span style={{ color: "green", fontSize: "11px" }}>
                        {customerDataNineMonths !== undefined &&
                          customerDataNineMonths.length !== 0 &&
                          (customerDataNineMonths[0].TY_VS_LLY === "-999999"
                            ? "-"
                            : `LLY ${Number(
                                customerDataNineMonths[0].TY_VS_LLY
                              ).toFixed(2)}%`)}
                      </span>
                    ) : (
                      <span style={{ color: "red", fontSize: "11px" }}>
                        {customerDataNineMonths !== undefined &&
                          customerDataNineMonths.length !== 0 &&
                          (customerDataNineMonths[0].TY_VS_LLY === "-999999"
                            ? "-"
                            : `LLY +${Number(
                                customerDataNineMonths[0].TY_VS_LLY
                              ).toFixed(2)}%`)}
                      </span>
                    )}
                  </td>
                  <td>
                    {customerDataNineMonths !== undefined &&
                      customerDataNineMonths.length !== 0 &&
                      (customerDataNineMonths[0].NET_SALES_TY === "-999999"
                        ? "-"
                        : "$" +
                          currencyFormat(
                            Number(customerDataNineMonths[0].NET_SALES_TY)
                          ))}
                    <br />
                    {customerDataNineMonths !== undefined &&
                    customerDataNineMonths.length !== 0 &&
                    Number(customerDataNineMonths[0].NET_SALES_TY_VS_LY)
                      .toFixed(2)
                      .includes("-") ? (
                      <span style={{ color: "green", fontSize: "12px" }}>
                        {customerDataNineMonths !== undefined &&
                          customerDataNineMonths.length !== 0 &&
                          (customerDataNineMonths[0].NET_SALES_TY_VS_LY ===
                          "-999999"
                            ? "-"
                            : `LY ${Number(
                                customerDataNineMonths[0].NET_SALES_TY_VS_LY
                              ).toFixed(2)}%`)}
                      </span>
                    ) : (
                      <span style={{ color: "red", fontSize: "12px" }}>
                        {customerDataNineMonths !== undefined &&
                          customerDataNineMonths.length !== 0 &&
                          (customerDataNineMonths[0].NET_SALES_TY_VS_LY ===
                          "-999999"
                            ? "-"
                            : `LY +${Number(
                                customerDataNineMonths[0].NET_SALES_TY_VS_LY
                              ).toFixed(2)}%`)}
                      </span>
                    )}
                    <br />
                    {customerDataNineMonths !== undefined &&
                    customerDataNineMonths.length !== 0 &&
                    Number(customerDataNineMonths[0].NET_SALES_TY_VS_LLY)
                      .toFixed(2)
                      .includes("-") ? (
                      <span style={{ color: "green", fontSize: "11px" }}>
                        {customerDataNineMonths !== undefined &&
                          customerDataNineMonths.length !== 0 &&
                          (customerDataNineMonths[0].NET_SALES_TY_VS_LLY ===
                          "-999999"
                            ? "-"
                            : `LLY ${Number(
                                customerDataNineMonths[0].NET_SALES_TY_VS_LLY
                              ).toFixed(2)}%`)}
                      </span>
                    ) : (
                      <span style={{ color: "red", fontSize: "11px" }}>
                        {customerDataNineMonths !== undefined &&
                          customerDataNineMonths.length !== 0 &&
                          (customerDataNineMonths[0].NET_SALES_TY_VS_LLY ===
                          "-999999"
                            ? "-"
                            : `LLY +${Number(
                                customerDataNineMonths[0].NET_SALES_TY_VS_LLY
                              ).toFixed(2)}%`)}
                      </span>
                    )}
                  </td>
                  <td>
                    {customerDataNineMonths !== undefined &&
                      customerDataNineMonths.length !== 0 &&
                      (customerDataNineMonths[0].TRANS_COUNT_TY === "-999999"
                        ? "-"
                        : currencyFormat(
                            Number(customerDataNineMonths[0].TRANS_COUNT_TY)
                          ))}
                    <br />
                    {customerDataNineMonths !== undefined &&
                    customerDataNineMonths.length !== 0 &&
                    Number(customerDataNineMonths[0].TRANS_TY_VS_LY)
                      .toFixed(2)
                      .includes("-") ? (
                      <span style={{ color: "green", fontSize: "12px" }}>
                        {customerDataNineMonths !== undefined &&
                          customerDataNineMonths.length !== 0 &&
                          (customerDataNineMonths[0].TRANS_TY_VS_LY ===
                          "-999999"
                            ? "-"
                            : `LY ${Number(
                                customerDataNineMonths[0].TRANS_TY_VS_LY
                              ).toFixed(2)}%`)}
                      </span>
                    ) : (
                      <span style={{ color: "red", fontSize: "12px" }}>
                        {customerDataNineMonths !== undefined &&
                          customerDataNineMonths.length !== 0 &&
                          (customerDataNineMonths[0].TRANS_TY_VS_LY ===
                          "-999999"
                            ? "-"
                            : `LY +${Number(
                                customerDataNineMonths[0].TRANS_TY_VS_LY
                              ).toFixed(2)}%`)}
                      </span>
                    )}
                    <br />
                    {customerDataNineMonths !== undefined &&
                    customerDataNineMonths.length !== 0 &&
                    Number(customerDataNineMonths[0].TRANS_TY_VS_LLY)
                      .toFixed(2)
                      .includes("-") ? (
                      <span style={{ color: "green", fontSize: "11px" }}>
                        {customerDataNineMonths !== undefined &&
                          customerDataNineMonths.length !== 0 &&
                          (customerDataNineMonths[0].TRANS_TY_VS_LLY ===
                          "-999999"
                            ? "-"
                            : `LLY ${Number(
                                customerDataNineMonths[0].TRANS_TY_VS_LLY
                              ).toFixed(2)}%`)}
                      </span>
                    ) : (
                      <span style={{ color: "red", fontSize: "11px" }}>
                        {customerDataNineMonths !== undefined &&
                          customerDataNineMonths.length !== 0 &&
                          (customerDataNineMonths[0].TRANS_TY_VS_LLY ===
                          "-999999"
                            ? "-"
                            : `LLY +${Number(
                                customerDataNineMonths[0].TRANS_TY_VS_LLY
                              ).toFixed(2)}%`)}
                      </span>
                    )}
                  </td>
                  <td>
                    {customerDataNineMonths !== undefined &&
                      customerDataNineMonths.length !== 0 &&
                      (customerDataNineMonths[0].PM_TY === "-999999"
                        ? "-"
                        : "$" +
                          currencyFormat(
                            Number(customerDataNineMonths[0].PM_TY)
                          ))}
                    <br />
                    {customerDataNineMonths !== undefined &&
                    customerDataNineMonths.length !== 0 &&
                    Number(customerDataNineMonths[0].PM_TY_VS_LY)
                      .toFixed(2)
                      .includes("-") ? (
                      <span style={{ color: "green", fontSize: "12px" }}>
                        {customerDataNineMonths !== undefined &&
                          customerDataNineMonths.length !== 0 &&
                          (customerDataNineMonths[0].PM_TY_VS_LY === "-999999"
                            ? "-"
                            : `LY ${Number(
                                customerDataNineMonths[0].PM_TY_VS_LY
                              ).toFixed(2)}%`)}
                      </span>
                    ) : (
                      <span style={{ color: "red", fontSize: "12px" }}>
                        {customerDataNineMonths !== undefined &&
                          customerDataNineMonths.length !== 0 &&
                          (customerDataNineMonths[0].PM_TY_VS_LY === "-999999"
                            ? "-"
                            : `LY +${Number(
                                customerDataNineMonths[0].PM_TY_VS_LY
                              ).toFixed(2)}%`)}
                      </span>
                    )}
                    <br />
                    {customerDataNineMonths !== undefined &&
                    customerDataNineMonths.length !== 0 &&
                    Number(customerDataNineMonths[0].PM_TY_VS_LLY)
                      .toFixed(2)
                      .includes("-") ? (
                      <span style={{ color: "green", fontSize: "11px" }}>
                        {customerDataNineMonths !== undefined &&
                          customerDataNineMonths.length !== 0 &&
                          (customerDataNineMonths[0].PM_TY_VS_LLY === "-999999"
                            ? "-"
                            : `LLY ${Number(
                                customerDataNineMonths[0].PM_TY_VS_LLY
                              ).toFixed(2)}%`)}
                      </span>
                    ) : (
                      <span style={{ color: "red", fontSize: "11px" }}>
                        {customerDataNineMonths !== undefined &&
                          customerDataNineMonths.length !== 0 &&
                          (customerDataNineMonths[0].PM_TY_VS_LLY === "-999999"
                            ? "-"
                            : `LLY +${Number(
                                customerDataNineMonths[0].PM_TY_VS_LLY
                              ).toFixed(2)}%`)}
                      </span>
                    )}
                  </td>
                  <td>
                    {customerDataNineMonths !== undefined &&
                      customerDataNineMonths.length !== 0 &&
                      (customerDataNineMonths[0].AOV_TY === "-999999"
                        ? "-"
                        : "$" +
                          Number(customerDataNineMonths[0].AOV_TY).toFixed(2))}
                    <br />
                    {customerDataNineMonths !== undefined &&
                    customerDataNineMonths.length !== 0 &&
                    Number(customerDataNineMonths[0].AOV_TY_VS_LY)
                      .toFixed(2)
                      .includes("-") ? (
                      <span style={{ color: "green", fontSize: "12px" }}>
                        {customerDataNineMonths !== undefined &&
                          customerDataNineMonths.length !== 0 &&
                          (customerDataNineMonths[0].AOV_TY_VS_LY === "-999999"
                            ? "-"
                            : `LY ${Number(
                                customerDataNineMonths[0].AOV_TY_VS_LY
                              ).toFixed(2)}%`)}
                      </span>
                    ) : (
                      <span style={{ color: "red", fontSize: "12px" }}>
                        {customerDataNineMonths !== undefined &&
                          customerDataNineMonths.length !== 0 &&
                          (customerDataNineMonths[0].AOV_TY_VS_LY === "-999999"
                            ? "-"
                            : `LY +${Number(
                                customerDataNineMonths[0].AOV_TY_VS_LY
                              ).toFixed(2)}%`)}
                      </span>
                    )}
                    <br />
                    {customerDataNineMonths !== undefined &&
                    customerDataNineMonths.length !== 0 &&
                    Number(customerDataNineMonths[0].AOV_TY_VS_LLY)
                      .toFixed(2)
                      .includes("-") ? (
                      <span style={{ color: "green", fontSize: "11px" }}>
                        {customerDataNineMonths !== undefined &&
                          customerDataNineMonths.length !== 0 &&
                          (customerDataNineMonths[0].AOV_TY_VS_LLY === "-999999"
                            ? "-"
                            : `LLY ${Number(
                                customerDataNineMonths[0].AOV_TY_VS_LLY
                              ).toFixed(2)}%`)}
                      </span>
                    ) : (
                      <span style={{ color: "red", fontSize: "11px" }}>
                        {customerDataNineMonths !== undefined &&
                          customerDataNineMonths.length !== 0 &&
                          (customerDataNineMonths[0].AOV_TY_VS_LLY === "-999999"
                            ? "-"
                            : `LLY +${Number(
                                customerDataNineMonths[0].AOV_TY_VS_LLY
                              ).toFixed(2)}%`)}
                      </span>
                    )}
                  </td>
                  <td>
                    {customerDataNineMonths !== undefined &&
                      customerDataNineMonths.length !== 0 &&
                      (customerDataNineMonths[0].UPT_TY === "-999999"
                        ? "-"
                        : Number(customerDataNineMonths[0].UPT_TY).toFixed(1))}
                    <br />
                    {customerDataNineMonths !== undefined &&
                    customerDataNineMonths.length !== 0 &&
                    Number(customerDataNineMonths[0].UPT_TY_VS_LY)
                      .toFixed(2)
                      .includes("-") ? (
                      <span style={{ color: "green", fontSize: "12px" }}>
                        {customerDataNineMonths !== undefined &&
                          customerDataNineMonths.length !== 0 &&
                          (customerDataNineMonths[0].UPT_TY_VS_LY === "-999999"
                            ? "-"
                            : `LY ${Number(
                                customerDataNineMonths[0].UPT_TY_VS_LY
                              ).toFixed(2)}%`)}
                      </span>
                    ) : (
                      <span style={{ color: "red", fontSize: "12px" }}>
                        {customerDataNineMonths !== undefined &&
                          customerDataNineMonths.length !== 0 &&
                          (customerDataNineMonths[0].UPT_TY_VS_LY === "-999999"
                            ? "-"
                            : `LY +${Number(
                                customerDataNineMonths[0].UPT_TY_VS_LY
                              ).toFixed(2)}%`)}
                      </span>
                    )}
                    <br />
                    {customerDataNineMonths !== undefined &&
                    customerDataNineMonths.length !== 0 &&
                    Number(customerDataNineMonths[0].UPT_TY_VS_LLY)
                      .toFixed(2)
                      .includes("-") ? (
                      <span style={{ color: "green", fontSize: "11px" }}>
                        {customerDataNineMonths !== undefined &&
                          customerDataNineMonths.length !== 0 &&
                          (customerDataNineMonths[0].UPT_TY_VS_LLY === "-999999"
                            ? "-"
                            : `LLY ${Number(
                                customerDataNineMonths[0].UPT_TY_VS_LLY
                              ).toFixed(2)}%`)}
                      </span>
                    ) : (
                      <span style={{ color: "red", fontSize: "11px" }}>
                        {customerDataNineMonths !== undefined &&
                          customerDataNineMonths.length !== 0 &&
                          (customerDataNineMonths[0].UPT_TY_VS_LLY === "-999999"
                            ? "-"
                            : `LLY +${Number(
                                customerDataNineMonths[0].UPT_TY_VS_LLY
                              ).toFixed(2)}%`)}
                      </span>
                    )}
                  </td>
                  <td>
                    {customerDataNineMonths !== undefined &&
                      customerDataNineMonths.length !== 0 &&
                      (customerDataNineMonths[0].AUR_TY === "-999999"
                        ? "-"
                        : "$" +
                          Number(customerDataNineMonths[0].AUR_TY).toFixed(2))}
                    <br />
                    {customerDataNineMonths !== undefined &&
                    customerDataNineMonths.length !== 0 &&
                    Number(customerDataNineMonths[0].AUR_TY_VS_LY)
                      .toFixed(2)
                      .includes("-") ? (
                      <span style={{ color: "green", fontSize: "12px" }}>
                        {customerDataNineMonths !== undefined &&
                          customerDataNineMonths.length !== 0 &&
                          (customerDataNineMonths[0].AUR_TY_VS_LY === "-999999"
                            ? "-"
                            : `LY ${Number(
                                customerDataNineMonths[0].AUR_TY_VS_LY
                              ).toFixed(2)}%`)}
                      </span>
                    ) : (
                      <span style={{ color: "red", fontSize: "12px" }}>
                        {customerDataNineMonths !== undefined &&
                          customerDataNineMonths.length !== 0 &&
                          (customerDataNineMonths[0].AUR_TY_VS_LY === "-999999"
                            ? "-"
                            : `LY +${Number(
                                customerDataNineMonths[0].AUR_TY_VS_LY
                              ).toFixed(2)}%`)}
                      </span>
                    )}
                    <br />
                    {customerDataNineMonths !== undefined &&
                    customerDataNineMonths.length !== 0 &&
                    Number(customerDataNineMonths[0].AUR_TY_VS_LLY)
                      .toFixed(2)
                      .includes("-") ? (
                      <span style={{ color: "green", fontSize: "11px" }}>
                        {customerDataNineMonths !== undefined &&
                          customerDataNineMonths.length !== 0 &&
                          (customerDataNineMonths[0].AUR_TY_VS_LLY === "-999999"
                            ? "-"
                            : `LLY ${Number(
                                customerDataNineMonths[0].AUR_TY_VS_LLY
                              ).toFixed(2)}%`)}
                      </span>
                    ) : (
                      <span style={{ color: "red", fontSize: "11px" }}>
                        {customerDataNineMonths !== undefined &&
                          customerDataNineMonths.length !== 0 &&
                          (customerDataNineMonths[0].AUR_TY_VS_LLY === "-999999"
                            ? "-"
                            : `LLY +${Number(
                                customerDataNineMonths[0].AUR_TY_VS_LLY
                              ).toFixed(2)}%`)}
                      </span>
                    )}
                  </td>
                  <td>
                    {customerDataNineMonths !== undefined &&
                      customerDataNineMonths.length !== 0 &&
                      (customerDataNineMonths[0].MARGIN_RATE_PER_TY ===
                      "-999999"
                        ? "-"
                        : Number(
                            customerDataNineMonths[0].MARGIN_RATE_PER_TY
                          ).toFixed(2))}
                    <br />
                    {customerDataNineMonths !== undefined &&
                    customerDataNineMonths.length !== 0 &&
                    Number(customerDataNineMonths[0].MARGIN_RATE_PER_TY_VS_LY)
                      .toFixed(2)
                      .includes("-") ? (
                      <span style={{ color: "green", fontSize: "12px" }}>
                        {customerDataNineMonths !== undefined &&
                          customerDataNineMonths.length !== 0 &&
                          (customerDataNineMonths[0]
                            .MARGIN_RATE_PER_TY_VS_LY === "-999999"
                            ? "-"
                            : `LY ${Number(
                                customerDataNineMonths[0]
                                  .MARGIN_RATE_PER_TY_VS_LY
                              ).toFixed(2)}%`)}
                      </span>
                    ) : (
                      <span style={{ color: "red", fontSize: "12px" }}>
                        {customerDataNineMonths !== undefined &&
                          customerDataNineMonths.length !== 0 &&
                          (customerDataNineMonths[0]
                            .MARGIN_RATE_PER_TY_VS_LY === "-999999"
                            ? "-"
                            : `LY +${Number(
                                customerDataNineMonths[0]
                                  .MARGIN_RATE_PER_TY_VS_LY
                              ).toFixed(2)}%`)}
                      </span>
                    )}
                    <br />
                    {customerDataNineMonths !== undefined &&
                    customerDataNineMonths.length !== 0 &&
                    Number(customerDataNineMonths[0].MARGIN_RATE_PER_TY_VS_LLY)
                      .toFixed(2)
                      .includes("-") ? (
                      <span style={{ color: "green", fontSize: "11px" }}>
                        {customerDataNineMonths !== undefined &&
                          customerDataNineMonths.length !== 0 &&
                          (customerDataNineMonths[0]
                            .MARGIN_RATE_PER_TY_VS_LLY === "-999999"
                            ? "-"
                            : `LLY ${Number(
                                customerDataNineMonths[0]
                                  .MARGIN_RATE_PER_TY_VS_LLY
                              ).toFixed(2)}%`)}
                      </span>
                    ) : (
                      <span style={{ color: "red", fontSize: "11px" }}>
                        {customerDataNineMonths !== undefined &&
                          customerDataNineMonths.length !== 0 &&
                          (customerDataNineMonths[0]
                            .MARGIN_RATE_PER_TY_VS_LLY === "-999999"
                            ? "-"
                            : `LLY +${Number(
                                customerDataNineMonths[0]
                                  .MARGIN_RATE_PER_TY_VS_LLY
                              ).toFixed(2)}%`)}
                      </span>
                    )}
                  </td>
                  <td>
                    {customerDataNineMonths !== undefined &&
                      customerDataNineMonths.length !== 0 &&
                      (customerDataNineMonths[0].NET_SALES_PER_CUST_TY ===
                      "-999999"
                        ? "-"
                        : "$" +
                          Number(
                            customerDataNineMonths[0].NET_SALES_PER_CUST_TY
                          ).toFixed(2))}
                    <br />
                    {customerDataNineMonths !== undefined &&
                    customerDataNineMonths.length !== 0 &&
                    Number(
                      customerDataNineMonths[0].NET_SALES_PER_CUST_TY_VS_LY
                    )
                      .toFixed(2)
                      .includes("-") ? (
                      <span style={{ color: "green", fontSize: "12px" }}>
                        {customerDataNineMonths !== undefined &&
                          customerDataNineMonths.length !== 0 &&
                          (customerDataNineMonths[0]
                            .NET_SALES_PER_CUST_TY_VS_LY === "-999999"
                            ? "-"
                            : `LY ${Number(
                                customerDataNineMonths[0]
                                  .NET_SALES_PER_CUST_TY_VS_LY
                              ).toFixed(2)}%`)}
                      </span>
                    ) : (
                      <span style={{ color: "red", fontSize: "12px" }}>
                        {customerDataNineMonths !== undefined &&
                          customerDataNineMonths.length !== 0 &&
                          (customerDataNineMonths[0]
                            .NET_SALES_PER_CUST_TY_VS_LY === "-999999"
                            ? "-"
                            : `LY +${Number(
                                customerDataNineMonths[0]
                                  .NET_SALES_PER_CUST_TY_VS_LY
                              ).toFixed(2)}%`)}
                      </span>
                    )}
                    <br />
                    {customerDataNineMonths !== undefined &&
                    customerDataNineMonths.length !== 0 &&
                    Number(
                      customerDataNineMonths[0].NET_SALES_PER_CUST_TY_VS_LLY
                    )
                      .toFixed(2)
                      .includes("-") ? (
                      <span style={{ color: "green", fontSize: "11px" }}>
                        {customerDataNineMonths !== undefined &&
                          customerDataNineMonths.length !== 0 &&
                          (customerDataNineMonths[0]
                            .NET_SALES_PER_CUST_TY_VS_LLY === "-999999"
                            ? "-"
                            : `LLY ${Number(
                                customerDataNineMonths[0]
                                  .NET_SALES_PER_CUST_TY_VS_LLY
                              ).toFixed(2)}%`)}
                      </span>
                    ) : (
                      <span style={{ color: "red", fontSize: "11px" }}>
                        {customerDataNineMonths !== undefined &&
                          customerDataNineMonths.length !== 0 &&
                          (customerDataNineMonths[0]
                            .NET_SALES_PER_CUST_TY_VS_LLY === "-999999"
                            ? "-"
                            : `LLY +${Number(
                                customerDataNineMonths[0]
                                  .NET_SALES_PER_CUST_TY_VS_LLY
                              ).toFixed(2)}%`)}
                      </span>
                    )}
                  </td>
                  <td>
                    {customerDataNineMonths !== undefined &&
                      customerDataNineMonths.length !== 0 &&
                      (customerDataNineMonths[0].AVG_TRAN_TY === "-999999"
                        ? "-"
                        : Number(customerDataNineMonths[0].AVG_TRAN_TY).toFixed(
                            2
                          ))}
                    <br />
                    {customerDataNineMonths !== undefined &&
                    customerDataNineMonths.length !== 0 &&
                    Number(customerDataNineMonths[0].AVG_TRAN_TY_VS_LY)
                      .toFixed(2)
                      .includes("-") ? (
                      <span style={{ color: "green", fontSize: "12px" }}>
                        {customerDataNineMonths !== undefined &&
                          customerDataNineMonths.length !== 0 &&
                          (customerDataNineMonths[0].AVG_TRAN_TY_VS_LY ===
                          "-999999"
                            ? "-"
                            : `LY ${Number(
                                customerDataNineMonths[0].AVG_TRAN_TY_VS_LY
                              ).toFixed(2)}%`)}
                      </span>
                    ) : (
                      <span style={{ color: "red", fontSize: "12px" }}>
                        {customerDataNineMonths !== undefined &&
                          customerDataNineMonths.length !== 0 &&
                          (customerDataNineMonths[0].AVG_TRAN_TY_VS_LY ===
                          "-999999"
                            ? "-"
                            : `LY +${Number(
                                customerDataNineMonths[0].AVG_TRAN_TY_VS_LY
                              ).toFixed(2)}%`)}
                      </span>
                    )}
                    <br />
                    {customerDataNineMonths !== undefined &&
                    customerDataNineMonths.length !== 0 &&
                    Number(customerDataNineMonths[0].AVG_TRAN_TY_VS_LLY)
                      .toFixed(2)
                      .includes("-") ? (
                      <span style={{ color: "green", fontSize: "11px" }}>
                        {customerDataNineMonths !== undefined &&
                          customerDataNineMonths.length !== 0 &&
                          (customerDataNineMonths[0].AVG_TRAN_TY_VS_LLY ===
                          "-999999"
                            ? "-"
                            : `LLY ${Number(
                                customerDataNineMonths[0].AVG_TRAN_TY_VS_LLY
                              ).toFixed(2)}%`)}
                      </span>
                    ) : (
                      <span style={{ color: "red", fontSize: "11px" }}>
                        {customerDataNineMonths !== undefined &&
                          customerDataNineMonths.length !== 0 &&
                          (customerDataNineMonths[0].AVG_TRAN_TY_VS_LLY ===
                          "-999999"
                            ? "-"
                            : `LLY +${Number(
                                customerDataNineMonths[0].AVG_TRAN_TY_VS_LLY
                              ).toFixed(2)}%`)}
                      </span>
                    )}
                  </td>
                </>
              )}
            </tr>

            {selectedCategoryId === "ALL" && (
              <tr className="align-middle">
                <td className="tableTotalCol">
                  <b>{"Sub Total"}</b>
                </td>
                {loading.first_four_total ? (
                  <>
                    <LoaderForRow tdCount={10} />
                  </>
                ) : (
                  <>
                    <th>
                      {firstFourTotalflag &&
                        firstFourTotalData !== undefined &&
                        firstFourTotalData.length !== 0 &&
                        (firstFourTotalData[0].CUST_COUNT_TY === "-999999"
                          ? "-"
                          : currencyFormat(
                              Number(firstFourTotalData[0].CUST_COUNT_TY)
                            ))}
                      <br />
                      {firstFourTotalData !== undefined &&
                      firstFourTotalData.length !== 0 &&
                      Number(firstFourTotalData[0].CUST_TY_VS_LY)
                        .toFixed(2)
                        .includes("-") ? (
                        <span style={{ color: "red", fontSize: "12px" }}>
                          {firstFourTotalData !== undefined &&
                            firstFourTotalData.length !== 0 &&
                            (firstFourTotalData[0].CUST_TY_VS_LY === "-999999"
                              ? "-"
                              : `LY ${Number(
                                  firstFourTotalData[0].CUST_TY_VS_LY
                                ).toFixed(2)}%`)}
                        </span>
                      ) : (
                        <span style={{ color: "green", fontSize: "12px" }}>
                          {firstFourTotalData !== undefined &&
                            firstFourTotalData.length !== 0 &&
                            (firstFourTotalData[0].CUST_TY_VS_LY === "-999999"
                              ? "-"
                              : `LY +${Number(
                                  firstFourTotalData[0].CUST_TY_VS_LY
                                ).toFixed(2)}%`)}
                        </span>
                      )}
                      <br />
                      {firstFourTotalData !== undefined &&
                      firstFourTotalData.length !== 0 &&
                      Number(firstFourTotalData[0].CUST_TY_VS_LLY)
                        .toFixed(2)
                        .includes("-") ? (
                        <span style={{ color: "red", fontSize: "11px" }}>
                          {firstFourTotalData !== undefined &&
                            firstFourTotalData.length !== 0 &&
                            (firstFourTotalData[0].CUST_TY_VS_LLY === "-999999"
                              ? "-"
                              : `LLY ${Number(
                                  firstFourTotalData[0].CUST_TY_VS_LLY
                                ).toFixed(2)}%`)}
                        </span>
                      ) : (
                        <span style={{ color: "green", fontSize: "11px" }}>
                          {firstFourTotalData !== undefined &&
                            firstFourTotalData.length !== 0 &&
                            (firstFourTotalData[0].CUST_TY_VS_LLY === "-999999"
                              ? "-"
                              : `LLY +${Number(
                                  firstFourTotalData[0].CUST_TY_VS_LLY
                                ).toFixed(2)}%`)}
                        </span>
                      )}
                    </th>
                    <th>
                      {firstFourTotalflag &&
                        firstFourTotalData !== undefined &&
                        firstFourTotalData.length !== 0 &&
                        (firstFourTotalData[0].NET_SALES_TY === "-999999"
                          ? "-"
                          : "$" +
                            currencyFormat(
                              Number(firstFourTotalData[0].NET_SALES_TY)
                            ))}
                      <br />
                      {firstFourTotalData !== undefined &&
                      firstFourTotalData.length !== 0 &&
                      Number(firstFourTotalData[0].NET_SALES_TY_VS_LY)
                        .toFixed(2)
                        .includes("-") ? (
                        <span style={{ color: "red", fontSize: "12px" }}>
                          {firstFourTotalData !== undefined &&
                            firstFourTotalData.length !== 0 &&
                            (firstFourTotalData[0].NET_SALES_TY_VS_LY ===
                            "-999999"
                              ? "-"
                              : `LY ${Number(
                                  firstFourTotalData[0].NET_SALES_TY_VS_LY
                                ).toFixed(2)}%`)}
                        </span>
                      ) : (
                        <span style={{ color: "green", fontSize: "12px" }}>
                          {firstFourTotalData !== undefined &&
                            firstFourTotalData.length !== 0 &&
                            (firstFourTotalData[0].NET_SALES_TY_VS_LY ===
                            "-999999"
                              ? "-"
                              : `LY +${Number(
                                  firstFourTotalData[0].NET_SALES_TY_VS_LY
                                ).toFixed(2)}%`)}
                        </span>
                      )}
                      <br />
                      {firstFourTotalData !== undefined &&
                      firstFourTotalData.length !== 0 &&
                      Number(firstFourTotalData[0].NET_SALES_TY_VS_LLY)
                        .toFixed(2)
                        .includes("-") ? (
                        <span style={{ color: "red", fontSize: "11px" }}>
                          {firstFourTotalData !== undefined &&
                            firstFourTotalData.length !== 0 &&
                            (firstFourTotalData[0].NET_SALES_TY_VS_LLY ===
                            "-999999"
                              ? "-"
                              : `LLY ${Number(
                                  firstFourTotalData[0].NET_SALES_TY_VS_LLY
                                ).toFixed(2)}%`)}
                        </span>
                      ) : (
                        <span style={{ color: "green", fontSize: "11px" }}>
                          {firstFourTotalData !== undefined &&
                            firstFourTotalData.length !== 0 &&
                            (firstFourTotalData[0].NET_SALES_TY_VS_LLY ===
                            "-999999"
                              ? "-"
                              : `LLY +${Number(
                                  firstFourTotalData[0].NET_SALES_TY_VS_LLY
                                ).toFixed(2)}%`)}
                        </span>
                      )}
                    </th>
                    <th>
                      {firstFourTotalflag &&
                        firstFourTotalData !== undefined &&
                        firstFourTotalData.length !== 0 &&
                        (firstFourTotalData[0].TRANS_COUNT_TY === "-999999"
                          ? "-"
                          : currencyFormat(
                              Number(firstFourTotalData[0].TRANS_COUNT_TY)
                            ))}
                      <br />
                      {firstFourTotalData !== undefined &&
                      firstFourTotalData.length !== 0 &&
                      Number(firstFourTotalData[0].TRANS_TY_VS_LY)
                        .toFixed(2)
                        .includes("-") ? (
                        <span style={{ color: "red", fontSize: "12px" }}>
                          {firstFourTotalData !== undefined &&
                            firstFourTotalData.length !== 0 &&
                            (firstFourTotalData[0].TRANS_TY_VS_LY === "-999999"
                              ? "-"
                              : `LY ${Number(
                                  firstFourTotalData[0].TRANS_TY_VS_LY
                                ).toFixed(2)}%`)}
                        </span>
                      ) : (
                        <span style={{ color: "green", fontSize: "12px" }}>
                          {firstFourTotalData !== undefined &&
                            firstFourTotalData.length !== 0 &&
                            (firstFourTotalData[0].TRANS_TY_VS_LY === "-999999"
                              ? "-"
                              : `LY +${Number(
                                  firstFourTotalData[0].TRANS_TY_VS_LY
                                ).toFixed(2)}%`)}
                        </span>
                      )}
                      <br />
                      {firstFourTotalData !== undefined &&
                      firstFourTotalData.length !== 0 &&
                      Number(firstFourTotalData[0].TRANS_TY_VS_LLY)
                        .toFixed(2)
                        .includes("-") ? (
                        <span style={{ color: "red", fontSize: "11px" }}>
                          {firstFourTotalData !== undefined &&
                            firstFourTotalData.length !== 0 &&
                            (firstFourTotalData[0].TRANS_TY_VS_LLY === "-999999"
                              ? "-"
                              : `LLY ${Number(
                                  firstFourTotalData[0].TRANS_TY_VS_LLY
                                ).toFixed(2)}%`)}
                        </span>
                      ) : (
                        <span style={{ color: "green", fontSize: "11px" }}>
                          {firstFourTotalData !== undefined &&
                            firstFourTotalData.length !== 0 &&
                            (firstFourTotalData[0].TRANS_TY_VS_LLY === "-999999"
                              ? "-"
                              : `LLY +${Number(
                                  firstFourTotalData[0].TRANS_TY_VS_LLY
                                ).toFixed(2)}%`)}
                        </span>
                      )}
                    </th>
                    <th>
                      {firstFourTotalflag &&
                        firstFourTotalData !== undefined &&
                        firstFourTotalData.length !== 0 &&
                        (firstFourTotalData[0].PM_TY === "-999999"
                          ? "-"
                          : "$" +
                            currencyFormat(
                              Number(firstFourTotalData[0].PM_TY)
                            ))}
                      <br />
                      {firstFourTotalData !== undefined &&
                      firstFourTotalData.length !== 0 &&
                      Number(firstFourTotalData[0].PM_TY_VS_LY)
                        .toFixed(2)
                        .includes("-") ? (
                        <span style={{ color: "red", fontSize: "12px" }}>
                          {firstFourTotalData !== undefined &&
                            firstFourTotalData.length !== 0 &&
                            (firstFourTotalData[0].PM_TY_VS_LY === "-999999"
                              ? "-"
                              : `LY ${Number(
                                  firstFourTotalData[0].PM_TY_VS_LY
                                ).toFixed(2)}%`)}
                        </span>
                      ) : (
                        <span style={{ color: "green", fontSize: "12px" }}>
                          {firstFourTotalData !== undefined &&
                            firstFourTotalData.length !== 0 &&
                            (firstFourTotalData[0].PM_TY_VS_LY === "-999999"
                              ? "-"
                              : `LY +${Number(
                                  firstFourTotalData[0].PM_TY_VS_LY
                                ).toFixed(2)}%`)}
                        </span>
                      )}
                      <br />
                      {firstFourTotalData !== undefined &&
                      firstFourTotalData.length !== 0 &&
                      Number(firstFourTotalData[0].PM_TY_VS_LLY)
                        .toFixed(2)
                        .includes("-") ? (
                        <span style={{ color: "red", fontSize: "11px" }}>
                          {firstFourTotalData !== undefined &&
                            firstFourTotalData.length !== 0 &&
                            (firstFourTotalData[0].PM_TY_VS_LLY === "-999999"
                              ? "-"
                              : `LLY ${Number(
                                  firstFourTotalData[0].PM_TY_VS_LLY
                                ).toFixed(2)}%`)}
                        </span>
                      ) : (
                        <span style={{ color: "green", fontSize: "11px" }}>
                          {firstFourTotalData !== undefined &&
                            firstFourTotalData.length !== 0 &&
                            (firstFourTotalData[0].PM_TY_VS_LLY === "-999999"
                              ? "-"
                              : `LLY +${Number(
                                  firstFourTotalData[0].PM_TY_VS_LLY
                                ).toFixed(2)}%`)}
                        </span>
                      )}
                    </th>
                    <th>
                      {firstFourTotalflag &&
                        firstFourTotalData !== undefined &&
                        firstFourTotalData.length !== 0 &&
                        (firstFourTotalData[0].AOV_TY === "-999999"
                          ? "-"
                          : "$" +
                            Number(firstFourTotalData[0].AOV_TY).toFixed(2))}
                      <br />
                      {firstFourTotalData !== undefined &&
                      firstFourTotalData.length !== 0 &&
                      Number(firstFourTotalData[0].AOV_TY_VS_LY)
                        .toFixed(2)
                        .includes("-") ? (
                        <span style={{ color: "red", fontSize: "12px" }}>
                          {firstFourTotalData !== undefined &&
                            firstFourTotalData.length !== 0 &&
                            (firstFourTotalData[0].AOV_TY_VS_LY === "-999999"
                              ? "-"
                              : `LY ${Number(
                                  firstFourTotalData[0].AOV_TY_VS_LY
                                ).toFixed(2)}%`)}
                        </span>
                      ) : (
                        <span style={{ color: "green", fontSize: "12px" }}>
                          {firstFourTotalData !== undefined &&
                            firstFourTotalData.length !== 0 &&
                            (firstFourTotalData[0].AOV_TY_VS_LY === "-999999"
                              ? "-"
                              : `LY +${Number(
                                  firstFourTotalData[0].AOV_TY_VS_LY
                                ).toFixed(2)}%`)}
                        </span>
                      )}
                      <br />
                      {firstFourTotalData !== undefined &&
                      firstFourTotalData.length !== 0 &&
                      Number(firstFourTotalData[0].AOV_TY_VS_LLY)
                        .toFixed(2)
                        .includes("-") ? (
                        <span style={{ color: "red", fontSize: "11px" }}>
                          {firstFourTotalData !== undefined &&
                            firstFourTotalData.length !== 0 &&
                            (firstFourTotalData[0].AOV_TY_VS_LLY === "-999999"
                              ? "-"
                              : `LLY ${Number(
                                  firstFourTotalData[0].AOV_TY_VS_LLY
                                ).toFixed(2)}%`)}
                        </span>
                      ) : (
                        <span style={{ color: "green", fontSize: "11px" }}>
                          {firstFourTotalData !== undefined &&
                            firstFourTotalData.length !== 0 &&
                            (firstFourTotalData[0].AOV_TY_VS_LLY === "-999999"
                              ? "-"
                              : `LLY +${Number(
                                  firstFourTotalData[0].AOV_TY_VS_LLY
                                ).toFixed(2)}%`)}
                        </span>
                      )}
                    </th>
                    <th>
                      {firstFourTotalflag &&
                        firstFourTotalData !== undefined &&
                        firstFourTotalData.length !== 0 &&
                        (firstFourTotalData[0].UPT_TY === "-999999"
                          ? "-"
                          : Number(firstFourTotalData[0].UPT_TY).toFixed(1))}
                      <br />
                      {firstFourTotalData !== undefined &&
                      firstFourTotalData.length !== 0 &&
                      Number(firstFourTotalData[0].UPT_TY_VS_LY)
                        .toFixed(2)
                        .includes("-") ? (
                        <span style={{ color: "red", fontSize: "12px" }}>
                          {firstFourTotalData !== undefined &&
                            firstFourTotalData.length !== 0 &&
                            (firstFourTotalData[0].UPT_TY_VS_LY === "-999999"
                              ? "-"
                              : `LY ${Number(
                                  firstFourTotalData[0].UPT_TY_VS_LY
                                ).toFixed(2)}%`)}
                        </span>
                      ) : (
                        <span style={{ color: "green", fontSize: "12px" }}>
                          {firstFourTotalData !== undefined &&
                            firstFourTotalData.length !== 0 &&
                            (firstFourTotalData[0].UPT_TY_VS_LY === "-999999"
                              ? "-"
                              : `LY +${Number(
                                  firstFourTotalData[0].UPT_TY_VS_LY
                                ).toFixed(2)}%`)}
                        </span>
                      )}
                      <br />
                      {firstFourTotalData !== undefined &&
                      firstFourTotalData.length !== 0 &&
                      Number(firstFourTotalData[0].UPT_TY_VS_LLY)
                        .toFixed(2)
                        .includes("-") ? (
                        <span style={{ color: "red", fontSize: "11px" }}>
                          {firstFourTotalData !== undefined &&
                            firstFourTotalData.length !== 0 &&
                            (firstFourTotalData[0].UPT_TY_VS_LLY === "-999999"
                              ? "-"
                              : `LLY ${Number(
                                  firstFourTotalData[0].UPT_TY_VS_LLY
                                ).toFixed(2)}%`)}
                        </span>
                      ) : (
                        <span style={{ color: "green", fontSize: "11px" }}>
                          {firstFourTotalData !== undefined &&
                            firstFourTotalData.length !== 0 &&
                            (firstFourTotalData[0].UPT_TY_VS_LLY === "-999999"
                              ? "-"
                              : `LLY +${Number(
                                  firstFourTotalData[0].UPT_TY_VS_LLY
                                ).toFixed(2)}%`)}
                        </span>
                      )}
                    </th>
                    <th>
                      {firstFourTotalflag &&
                        firstFourTotalData !== undefined &&
                        firstFourTotalData.length !== 0 &&
                        (firstFourTotalData[0].AUR_TY === "-999999"
                          ? "-"
                          : "$" +
                            Number(firstFourTotalData[0].AUR_TY).toFixed(2))}
                      <br />
                      {firstFourTotalData !== undefined &&
                      firstFourTotalData.length !== 0 &&
                      Number(firstFourTotalData[0].AUR_TY_VS_LY)
                        .toFixed(2)
                        .includes("-") ? (
                        <span style={{ color: "red", fontSize: "12px" }}>
                          {firstFourTotalData !== undefined &&
                            firstFourTotalData.length !== 0 &&
                            (firstFourTotalData[0].AUR_TY_VS_LY === "-999999"
                              ? "-"
                              : `LY ${Number(
                                  firstFourTotalData[0].AUR_TY_VS_LY
                                ).toFixed(2)}%`)}
                        </span>
                      ) : (
                        <span style={{ color: "green", fontSize: "12px" }}>
                          {firstFourTotalData !== undefined &&
                            firstFourTotalData.length !== 0 &&
                            (firstFourTotalData[0].AUR_TY_VS_LY === "-999999"
                              ? "-"
                              : `LY +${Number(
                                  firstFourTotalData[0].AUR_TY_VS_LY
                                ).toFixed(2)}%`)}
                        </span>
                      )}
                      <br />
                      {firstFourTotalData !== undefined &&
                      firstFourTotalData.length !== 0 &&
                      Number(firstFourTotalData[0].AUR_TY_VS_LLY)
                        .toFixed(2)
                        .includes("-") ? (
                        <span style={{ color: "red", fontSize: "11px" }}>
                          {firstFourTotalData !== undefined &&
                            firstFourTotalData.length !== 0 &&
                            (firstFourTotalData[0].AUR_TY_VS_LLY === "-999999"
                              ? "-"
                              : `LLY ${Number(
                                  firstFourTotalData[0].AUR_TY_VS_LLY
                                ).toFixed(2)}%`)}
                        </span>
                      ) : (
                        <span style={{ color: "green", fontSize: "11px" }}>
                          {firstFourTotalData !== undefined &&
                            firstFourTotalData.length !== 0 &&
                            (firstFourTotalData[0].AUR_TY_VS_LLY === "-999999"
                              ? "-"
                              : `LLY +${Number(
                                  firstFourTotalData[0].AUR_TY_VS_LLY
                                ).toFixed(2)}%`)}
                        </span>
                      )}
                    </th>
                    <th>
                      {firstFourTotalflag &&
                        firstFourTotalData !== undefined &&
                        firstFourTotalData.length !== 0 &&
                        (firstFourTotalData[0].MARGIN_RATE_PER_TY === "-999999"
                          ? "-"
                          : Number(
                              firstFourTotalData[0].MARGIN_RATE_PER_TY
                            ).toFixed(2))}
                      <br />
                      {firstFourTotalData !== undefined &&
                      firstFourTotalData.length !== 0 &&
                      Number(firstFourTotalData[0].MARGIN_RATE_PER_TY_VS_LY)
                        .toFixed(2)
                        .includes("-") ? (
                        <span style={{ color: "red", fontSize: "12px" }}>
                          {firstFourTotalData !== undefined &&
                            firstFourTotalData.length !== 0 &&
                            (firstFourTotalData[0].MARGIN_RATE_PER_TY_VS_LY ===
                            "-999999"
                              ? "-"
                              : `LY ${Number(
                                  firstFourTotalData[0].MARGIN_RATE_PER_TY_VS_LY
                                ).toFixed(2)}%`)}
                        </span>
                      ) : (
                        <span style={{ color: "green", fontSize: "12px" }}>
                          {firstFourTotalData !== undefined &&
                            firstFourTotalData.length !== 0 &&
                            (firstFourTotalData[0].MARGIN_RATE_PER_TY_VS_LY ===
                            "-999999"
                              ? "-"
                              : `LY +${Number(
                                  firstFourTotalData[0].MARGIN_RATE_PER_TY_VS_LY
                                ).toFixed(2)}%`)}
                        </span>
                      )}
                      <br />
                      {firstFourTotalData !== undefined &&
                      firstFourTotalData.length !== 0 &&
                      Number(firstFourTotalData[0].MARGIN_RATE_PER_TY_VS_LLY)
                        .toFixed(2)
                        .includes("-") ? (
                        <span style={{ color: "red", fontSize: "11px" }}>
                          {firstFourTotalData !== undefined &&
                            firstFourTotalData.length !== 0 &&
                            (firstFourTotalData[0].MARGIN_RATE_PER_TY_VS_LLY ===
                            "-999999"
                              ? "-"
                              : `LLY ${Number(
                                  firstFourTotalData[0]
                                    .MARGIN_RATE_PER_TY_VS_LLY
                                ).toFixed(2)}%`)}
                        </span>
                      ) : (
                        <span style={{ color: "green", fontSize: "11px" }}>
                          {firstFourTotalData !== undefined &&
                            firstFourTotalData.length !== 0 &&
                            (firstFourTotalData[0].MARGIN_RATE_PER_TY_VS_LLY ===
                            "-999999"
                              ? "-"
                              : `LLY +${Number(
                                  firstFourTotalData[0]
                                    .MARGIN_RATE_PER_TY_VS_LLY
                                ).toFixed(2)}%`)}
                        </span>
                      )}
                    </th>
                    <th>
                      {firstFourTotalflag &&
                        firstFourTotalData !== undefined &&
                        firstFourTotalData.length !== 0 &&
                        (firstFourTotalData[0].NET_SALES_PER_CUST_TY ===
                        "-999999"
                          ? "-"
                          : "$" +
                            Number(
                              firstFourTotalData[0].NET_SALES_PER_CUST_TY
                            ).toFixed(2))}
                      <br />
                      {firstFourTotalData !== undefined &&
                      firstFourTotalData.length !== 0 &&
                      Number(firstFourTotalData[0].NET_SALES_PER_CUST_TY_VS_LY)
                        .toFixed(2)
                        .includes("-") ? (
                        <span style={{ color: "red", fontSize: "12px" }}>
                          {firstFourTotalData !== undefined &&
                            firstFourTotalData.length !== 0 &&
                            (firstFourTotalData[0]
                              .NET_SALES_PER_CUST_TY_VS_LY === "-999999"
                              ? "-"
                              : `LY ${Number(
                                  firstFourTotalData[0]
                                    .NET_SALES_PER_CUST_TY_VS_LY
                                ).toFixed(2)}%`)}
                        </span>
                      ) : (
                        <span style={{ color: "green", fontSize: "12px" }}>
                          {firstFourTotalData !== undefined &&
                            firstFourTotalData.length !== 0 &&
                            (firstFourTotalData[0]
                              .NET_SALES_PER_CUST_TY_VS_LY === "-999999"
                              ? "-"
                              : `LY +${Number(
                                  firstFourTotalData[0]
                                    .NET_SALES_PER_CUST_TY_VS_LY
                                ).toFixed(2)}%`)}
                        </span>
                      )}
                      <br />
                      {firstFourTotalData !== undefined &&
                      firstFourTotalData.length !== 0 &&
                      Number(firstFourTotalData[0].NET_SALES_PER_CUST_TY_VS_LLY)
                        .toFixed(2)
                        .includes("-") ? (
                        <span style={{ color: "red", fontSize: "11px" }}>
                          {firstFourTotalData !== undefined &&
                            firstFourTotalData.length !== 0 &&
                            (firstFourTotalData[0]
                              .NET_SALES_PER_CUST_TY_VS_LLY === "-999999"
                              ? "-"
                              : `LLY ${Number(
                                  firstFourTotalData[0]
                                    .NET_SALES_PER_CUST_TY_VS_LLY
                                ).toFixed(2)}%`)}
                        </span>
                      ) : (
                        <span style={{ color: "green", fontSize: "11px" }}>
                          {firstFourTotalData !== undefined &&
                            firstFourTotalData.length !== 0 &&
                            (firstFourTotalData[0]
                              .NET_SALES_PER_CUST_TY_VS_LLY === "-999999"
                              ? "-"
                              : `LLY +${Number(
                                  firstFourTotalData[0]
                                    .NET_SALES_PER_CUST_TY_VS_LLY
                                ).toFixed(2)}%`)}
                        </span>
                      )}
                    </th>
                    <th>
                      {firstFourTotalflag &&
                        firstFourTotalData !== undefined &&
                        firstFourTotalData.length !== 0 &&
                        (firstFourTotalData[0].AVG_TRAN_TY === "-999999"
                          ? "-"
                          : Number(firstFourTotalData[0].AVG_TRAN_TY).toFixed(
                              2
                            ))}
                      <br />
                      {firstFourTotalData !== undefined &&
                      firstFourTotalData.length !== 0 &&
                      Number(firstFourTotalData[0].AVG_TRAN_TY_VS_LY)
                        .toFixed(2)
                        .includes("-") ? (
                        <span style={{ color: "red", fontSize: "12px" }}>
                          {firstFourTotalData !== undefined &&
                            firstFourTotalData.length !== 0 &&
                            (firstFourTotalData[0].AVG_TRAN_TY_VS_LY ===
                            "-999999"
                              ? "-"
                              : `LY ${Number(
                                  firstFourTotalData[0].AVG_TRAN_TY_VS_LY
                                ).toFixed(2)}%`)}
                        </span>
                      ) : (
                        <span style={{ color: "green", fontSize: "12px" }}>
                          {firstFourTotalData !== undefined &&
                            firstFourTotalData.length !== 0 &&
                            (firstFourTotalData[0].AVG_TRAN_TY_VS_LY ===
                            "-999999"
                              ? "-"
                              : `LY +${Number(
                                  firstFourTotalData[0].AVG_TRAN_TY_VS_LY
                                ).toFixed(2)}%`)}
                        </span>
                      )}
                      <br />
                      {firstFourTotalData !== undefined &&
                      firstFourTotalData.length !== 0 &&
                      Number(firstFourTotalData[0].AVG_TRAN_TY_VS_LLY)
                        .toFixed(2)
                        .includes("-") ? (
                        <span style={{ color: "red", fontSize: "11px" }}>
                          {firstFourTotalData !== undefined &&
                            firstFourTotalData.length !== 0 &&
                            (firstFourTotalData[0].AVG_TRAN_TY_VS_LLY ===
                            "-999999"
                              ? "-"
                              : `LLY ${Number(
                                  firstFourTotalData[0].AVG_TRAN_TY_VS_LLY
                                ).toFixed(2)}%`)}
                        </span>
                      ) : (
                        <span style={{ color: "green", fontSize: "11px" }}>
                          {firstFourTotalData !== undefined &&
                            firstFourTotalData.length !== 0 &&
                            (firstFourTotalData[0].AVG_TRAN_TY_VS_LLY ===
                            "-999999"
                              ? "-"
                              : `LLY +${Number(
                                  firstFourTotalData[0].AVG_TRAN_TY_VS_LLY
                                ).toFixed(2)}%`)}
                        </span>
                      )}
                    </th>
                  </>
                )}
              </tr>
            )}
            {selectedCategoryId === "ALL" && (
              <tr className="align-middle">
                <td className="tableCol" id={"UnIdentifed_Customers"}>
                  {"Unidentified Customers"}{" "}
                  {gettooltip(
                    "UnIdentifed_CustomersInfoIcon",
                    "UnIdentifed_Customers",
                    "UnIdentifed_Customers",
                    "UnIdentified Customers"
                  )}
                </td>
                {loading.UnIdentifed_Customers ? (
                  <>
                    <LoaderForRow tdCount={10} />
                  </>
                ) : (
                  <>
                    <td>
                      <br />
                      {customerUnidentifiedData !== undefined &&
                        customerUnidentifiedData.length !== 0 &&
                        "NA"}
                    </td>
                    <td>
                      {customerUnidentifiedData !== undefined &&
                        customerUnidentifiedData.length !== 0 &&
                        (customerUnidentifiedData[0].NET_SALES_TY === "-999999"
                          ? "-"
                          : "$" +
                            currencyFormat(
                              Number(customerUnidentifiedData[0].NET_SALES_TY)
                            ))}
                      <br />
                      {customerUnidentifiedData !== undefined &&
                      customerUnidentifiedData.length !== 0 &&
                      Number(customerUnidentifiedData[0].NET_SALES_TY_VS_LY)
                        .toFixed(2)
                        .includes("-") ? (
                        <span style={{ color: "red", fontSize: "12px" }}>
                          {customerUnidentifiedData !== undefined &&
                            customerUnidentifiedData.length !== 0 &&
                            (customerUnidentifiedData[0].NET_SALES_TY_VS_LY ===
                            "-999999"
                              ? "-"
                              : `LY ${Number(
                                  customerUnidentifiedData[0].NET_SALES_TY_VS_LY
                                ).toFixed(2)}%`)}
                        </span>
                      ) : (
                        <span style={{ color: "green", fontSize: "12px" }}>
                          {customerUnidentifiedData !== undefined &&
                            customerUnidentifiedData.length !== 0 &&
                            (customerUnidentifiedData[0].NET_SALES_TY_VS_LY ===
                            "-999999"
                              ? "-"
                              : `LY +${Number(
                                  customerUnidentifiedData[0].NET_SALES_TY_VS_LY
                                ).toFixed(2)}%`)}
                        </span>
                      )}
                      <br />
                      {customerUnidentifiedData !== undefined &&
                      customerUnidentifiedData.length !== 0 &&
                      Number(customerUnidentifiedData[0].NET_SALES_TY_VS_LLY)
                        .toFixed(2)
                        .includes("-") ? (
                        <span style={{ color: "red", fontSize: "11px" }}>
                          {customerUnidentifiedData !== undefined &&
                            customerUnidentifiedData.length !== 0 &&
                            (customerUnidentifiedData[0].NET_SALES_TY_VS_LLY ===
                            "-999999"
                              ? "-"
                              : `LLY ${Number(
                                  customerUnidentifiedData[0]
                                    .NET_SALES_TY_VS_LLY
                                ).toFixed(2)}%`)}
                        </span>
                      ) : (
                        <span style={{ color: "green", fontSize: "11px" }}>
                          {customerUnidentifiedData !== undefined &&
                            customerUnidentifiedData.length !== 0 &&
                            (customerUnidentifiedData[0].NET_SALES_TY_VS_LLY ===
                            "-999999"
                              ? "-"
                              : `LLY +${Number(
                                  customerUnidentifiedData[0]
                                    .NET_SALES_TY_VS_LLY
                                ).toFixed(2)}%`)}
                        </span>
                      )}
                    </td>
                    <td>
                      {customerUnidentifiedData !== undefined &&
                        customerUnidentifiedData.length !== 0 &&
                        (customerUnidentifiedData[0].TRANS_COUNT_TY ===
                        "-999999"
                          ? "-"
                          : currencyFormat(
                              Number(customerUnidentifiedData[0].TRANS_COUNT_TY)
                            ))}
                      <br />
                      {customerUnidentifiedData !== undefined &&
                      customerUnidentifiedData.length !== 0 &&
                      Number(customerUnidentifiedData[0].TRANS_TY_VS_LY)
                        .toFixed(2)
                        .includes("-") ? (
                        <span style={{ color: "red", fontSize: "12px" }}>
                          {customerUnidentifiedData !== undefined &&
                            customerUnidentifiedData.length !== 0 &&
                            (customerUnidentifiedData[0].TRANS_TY_VS_LY ===
                            "-999999"
                              ? "-"
                              : `LY ${Number(
                                  customerUnidentifiedData[0].TRANS_TY_VS_LY
                                ).toFixed(2)}%`)}
                        </span>
                      ) : (
                        <span style={{ color: "green", fontSize: "12px" }}>
                          {customerUnidentifiedData !== undefined &&
                            customerUnidentifiedData.length !== 0 &&
                            (customerUnidentifiedData[0].TRANS_TY_VS_LY ===
                            "-999999"
                              ? "-"
                              : `LY +${Number(
                                  customerUnidentifiedData[0].TRANS_TY_VS_LY
                                ).toFixed(2)}%`)}
                        </span>
                      )}
                      <br />
                      {customerUnidentifiedData !== undefined &&
                      customerUnidentifiedData.length !== 0 &&
                      Number(customerUnidentifiedData[0].TRANS_TY_VS_LLY)
                        .toFixed(2)
                        .includes("-") ? (
                        <span style={{ color: "red", fontSize: "11px" }}>
                          {customerUnidentifiedData !== undefined &&
                            customerUnidentifiedData.length !== 0 &&
                            (customerUnidentifiedData[0].TRANS_TY_VS_LLY ===
                            "-999999"
                              ? "-"
                              : `LLY ${Number(
                                  customerUnidentifiedData[0].TRANS_TY_VS_LLY
                                ).toFixed(2)}%`)}
                        </span>
                      ) : (
                        <span style={{ color: "green", fontSize: "11px" }}>
                          {customerUnidentifiedData !== undefined &&
                            customerUnidentifiedData.length !== 0 &&
                            (customerUnidentifiedData[0].TRANS_TY_VS_LLY ===
                            "-999999"
                              ? "-"
                              : `LLY +${Number(
                                  customerUnidentifiedData[0].TRANS_TY_VS_LLY
                                ).toFixed(2)}%`)}
                        </span>
                      )}
                    </td>
                    <td>
                      {customerUnidentifiedData !== undefined &&
                        customerUnidentifiedData.length !== 0 &&
                        (customerUnidentifiedData[0].PM_TY === "-999999"
                          ? "-"
                          : "$" +
                            currencyFormat(
                              Number(customerUnidentifiedData[0].PM_TY)
                            ))}
                      <br />
                      {customerUnidentifiedData !== undefined &&
                      customerUnidentifiedData.length !== 0 &&
                      Number(customerUnidentifiedData[0].PM_TY_VS_LY)
                        .toFixed(2)
                        .includes("-") ? (
                        <span style={{ color: "red", fontSize: "12px" }}>
                          {customerUnidentifiedData !== undefined &&
                            customerUnidentifiedData.length !== 0 &&
                            (customerUnidentifiedData[0].PM_TY_VS_LY ===
                            "-999999"
                              ? "-"
                              : `LY ${Number(
                                  customerUnidentifiedData[0].PM_TY_VS_LY
                                ).toFixed(2)}%`)}
                        </span>
                      ) : (
                        <span style={{ color: "green", fontSize: "12px" }}>
                          {customerUnidentifiedData !== undefined &&
                            customerUnidentifiedData.length !== 0 &&
                            (customerUnidentifiedData[0].PM_TY_VS_LY ===
                            "-999999"
                              ? "-"
                              : `LY +${Number(
                                  customerUnidentifiedData[0].PM_TY_VS_LY
                                ).toFixed(2)}%`)}
                        </span>
                      )}
                      <br />
                      {customerUnidentifiedData !== undefined &&
                      customerUnidentifiedData.length !== 0 &&
                      Number(customerUnidentifiedData[0].PM_TY_VS_LLY)
                        .toFixed(2)
                        .includes("-") ? (
                        <span style={{ color: "red", fontSize: "11px" }}>
                          {customerUnidentifiedData !== undefined &&
                            customerUnidentifiedData.length !== 0 &&
                            (customerUnidentifiedData[0].PM_TY_VS_LLY ===
                            "-999999"
                              ? "-"
                              : `LLY ${Number(
                                  customerUnidentifiedData[0].PM_TY_VS_LLY
                                ).toFixed(2)}%`)}
                        </span>
                      ) : (
                        <span style={{ color: "green", fontSize: "11px" }}>
                          {customerUnidentifiedData !== undefined &&
                            customerUnidentifiedData.length !== 0 &&
                            (customerUnidentifiedData[0].PM_TY_VS_LLY ===
                            "-999999"
                              ? "-"
                              : `LLY +${Number(
                                  customerUnidentifiedData[0].PM_TY_VS_LLY
                                ).toFixed(2)}%`)}
                        </span>
                      )}
                    </td>
                    <td>
                      {customerUnidentifiedData !== undefined &&
                        customerUnidentifiedData.length !== 0 &&
                        (customerUnidentifiedData[0].AOV_TY === "-999999"
                          ? "-"
                          : "$" +
                            Number(customerUnidentifiedData[0].AOV_TY).toFixed(
                              2
                            ))}
                      <br />
                      {customerUnidentifiedData !== undefined &&
                      customerUnidentifiedData.length !== 0 &&
                      Number(customerUnidentifiedData[0].AOV_TY_VS_LY)
                        .toFixed(2)
                        .includes("-") ? (
                        <span style={{ color: "red", fontSize: "12px" }}>
                          {customerUnidentifiedData !== undefined &&
                            customerUnidentifiedData.length !== 0 &&
                            (customerUnidentifiedData[0].AOV_TY_VS_LY ===
                            "-999999"
                              ? "-"
                              : `LY ${Number(
                                  customerUnidentifiedData[0].AOV_TY_VS_LY
                                ).toFixed(2)}%`)}
                        </span>
                      ) : (
                        <span style={{ color: "green", fontSize: "12px" }}>
                          {customerUnidentifiedData !== undefined &&
                            customerUnidentifiedData.length !== 0 &&
                            (customerUnidentifiedData[0].AOV_TY_VS_LY ===
                            "-999999"
                              ? "-"
                              : `LY +${Number(
                                  customerUnidentifiedData[0].AOV_TY_VS_LY
                                ).toFixed(2)}%`)}
                        </span>
                      )}
                      <br />
                      {customerUnidentifiedData !== undefined &&
                      customerUnidentifiedData.length !== 0 &&
                      Number(customerUnidentifiedData[0].AOV_TY_VS_LLY)
                        .toFixed(2)
                        .includes("-") ? (
                        <span style={{ color: "red", fontSize: "11px" }}>
                          {customerUnidentifiedData !== undefined &&
                            customerUnidentifiedData.length !== 0 &&
                            (customerUnidentifiedData[0].AOV_TY_VS_LLY ===
                            "-999999"
                              ? "-"
                              : `LLY ${Number(
                                  customerUnidentifiedData[0].AOV_TY_VS_LLY
                                ).toFixed(2)}%`)}
                        </span>
                      ) : (
                        <span style={{ color: "green", fontSize: "11px" }}>
                          {customerUnidentifiedData !== undefined &&
                            customerUnidentifiedData.length !== 0 &&
                            (customerUnidentifiedData[0].AOV_TY_VS_LLY ===
                            "-999999"
                              ? "-"
                              : `LLY +${Number(
                                  customerUnidentifiedData[0].AOV_TY_VS_LLY
                                ).toFixed(2)}%`)}
                        </span>
                      )}
                    </td>
                    <td>
                      {customerUnidentifiedData !== undefined &&
                        customerUnidentifiedData.length !== 0 &&
                        (customerUnidentifiedData[0].UPT_TY === "-999999"
                          ? "-"
                          : Number(customerUnidentifiedData[0].UPT_TY).toFixed(
                              1
                            ))}
                      <br />
                      {customerUnidentifiedData !== undefined &&
                      customerUnidentifiedData.length !== 0 &&
                      Number(customerUnidentifiedData[0].UPT_TY_VS_LY)
                        .toFixed(2)
                        .includes("-") ? (
                        <span style={{ color: "red", fontSize: "12px" }}>
                          {customerUnidentifiedData !== undefined &&
                            customerUnidentifiedData.length !== 0 &&
                            (customerUnidentifiedData[0].UPT_TY_VS_LY ===
                            "-999999"
                              ? "-"
                              : `LY ${Number(
                                  customerUnidentifiedData[0].UPT_TY_VS_LY
                                ).toFixed(2)}%`)}
                        </span>
                      ) : (
                        <span style={{ color: "green", fontSize: "12px" }}>
                          {customerUnidentifiedData !== undefined &&
                            customerUnidentifiedData.length !== 0 &&
                            (customerUnidentifiedData[0].UPT_TY_VS_LY ===
                            "-999999"
                              ? "-"
                              : `LY +${Number(
                                  customerUnidentifiedData[0].UPT_TY_VS_LY
                                ).toFixed(2)}%`)}
                        </span>
                      )}
                      <br />
                      {customerUnidentifiedData !== undefined &&
                      customerUnidentifiedData.length !== 0 &&
                      Number(customerUnidentifiedData[0].UPT_TY_VS_LLY)
                        .toFixed(2)
                        .includes("-") ? (
                        <span style={{ color: "red", fontSize: "11px" }}>
                          {customerUnidentifiedData !== undefined &&
                            customerUnidentifiedData.length !== 0 &&
                            (customerUnidentifiedData[0].UPT_TY_VS_LLY ===
                            "-999999"
                              ? "-"
                              : `LLY ${Number(
                                  customerUnidentifiedData[0].UPT_TY_VS_LLY
                                ).toFixed(2)}%`)}
                        </span>
                      ) : (
                        <span style={{ color: "green", fontSize: "11px" }}>
                          {customerUnidentifiedData !== undefined &&
                            customerUnidentifiedData.length !== 0 &&
                            (customerUnidentifiedData[0].UPT_TY_VS_LLY ===
                            "-999999"
                              ? "-"
                              : `LLY +${Number(
                                  customerUnidentifiedData[0].UPT_TY_VS_LLY
                                ).toFixed(2)}%`)}
                        </span>
                      )}
                    </td>
                    <td>
                      {customerUnidentifiedData !== undefined &&
                        customerUnidentifiedData.length !== 0 &&
                        (customerUnidentifiedData[0].AUR_TY === "-999999"
                          ? "-"
                          : "$" +
                            Number(customerUnidentifiedData[0].AUR_TY).toFixed(
                              2
                            ))}
                      <br />
                      {customerUnidentifiedData !== undefined &&
                      customerUnidentifiedData.length !== 0 &&
                      Number(customerUnidentifiedData[0].AUR_TY_VS_LY)
                        .toFixed(2)
                        .includes("-") ? (
                        <span style={{ color: "red", fontSize: "12px" }}>
                          {customerUnidentifiedData !== undefined &&
                            customerUnidentifiedData.length !== 0 &&
                            (customerUnidentifiedData[0].AUR_TY_VS_LY ===
                            "-999999"
                              ? "-"
                              : `LY ${Number(
                                  customerUnidentifiedData[0].AUR_TY_VS_LY
                                ).toFixed(2)}%`)}
                        </span>
                      ) : (
                        <span style={{ color: "green", fontSize: "12px" }}>
                          {customerUnidentifiedData !== undefined &&
                            customerUnidentifiedData.length !== 0 &&
                            (customerUnidentifiedData[0].AUR_TY_VS_LY ===
                            "-999999"
                              ? "-"
                              : `LY +${Number(
                                  customerUnidentifiedData[0].AUR_TY_VS_LY
                                ).toFixed(2)}%`)}
                        </span>
                      )}
                      <br />
                      {customerUnidentifiedData !== undefined &&
                      customerUnidentifiedData.length !== 0 &&
                      Number(customerUnidentifiedData[0].AUR_TY_VS_LLY)
                        .toFixed(2)
                        .includes("-") ? (
                        <span style={{ color: "red", fontSize: "11px" }}>
                          {customerUnidentifiedData !== undefined &&
                            customerUnidentifiedData.length !== 0 &&
                            (customerUnidentifiedData[0].AUR_TY_VS_LLY ===
                            "-999999"
                              ? "-"
                              : `LLY ${Number(
                                  customerUnidentifiedData[0].AUR_TY_VS_LLY
                                ).toFixed(2)}%`)}
                        </span>
                      ) : (
                        <span style={{ color: "green", fontSize: "11px" }}>
                          {customerUnidentifiedData !== undefined &&
                            customerUnidentifiedData.length !== 0 &&
                            (customerUnidentifiedData[0].AUR_TY_VS_LLY ===
                            "-999999"
                              ? "-"
                              : `LLY +${Number(
                                  customerUnidentifiedData[0].AUR_TY_VS_LLY
                                ).toFixed(2)}%`)}
                        </span>
                      )}
                    </td>
                    <td>
                      {customerUnidentifiedData !== undefined &&
                        customerUnidentifiedData.length !== 0 &&
                        (customerUnidentifiedData[0].MARGIN_RATE_PER_TY ===
                        "-999999"
                          ? "-"
                          : Number(
                              customerUnidentifiedData[0].MARGIN_RATE_PER_TY
                            ).toFixed(2))}
                      <br />
                      {customerUnidentifiedData !== undefined &&
                      customerUnidentifiedData.length !== 0 &&
                      Number(
                        customerUnidentifiedData[0].MARGIN_RATE_PER_TY_VS_LY
                      )
                        .toFixed(2)
                        .includes("-") ? (
                        <span style={{ color: "red", fontSize: "12px" }}>
                          {customerUnidentifiedData !== undefined &&
                            customerUnidentifiedData.length !== 0 &&
                            (customerUnidentifiedData[0]
                              .MARGIN_RATE_PER_TY_VS_LY === "-999999"
                              ? "-"
                              : `LY ${Number(
                                  customerUnidentifiedData[0]
                                    .MARGIN_RATE_PER_TY_VS_LY
                                ).toFixed(2)}%`)}
                        </span>
                      ) : (
                        <span style={{ color: "green", fontSize: "12px" }}>
                          {customerUnidentifiedData !== undefined &&
                            customerUnidentifiedData.length !== 0 &&
                            (customerUnidentifiedData[0]
                              .MARGIN_RATE_PER_TY_VS_LY === "-999999"
                              ? "-"
                              : `LY +${Number(
                                  customerUnidentifiedData[0]
                                    .MARGIN_RATE_PER_TY_VS_LY
                                ).toFixed(2)}%`)}
                        </span>
                      )}
                      <br />
                      {customerUnidentifiedData !== undefined &&
                      customerUnidentifiedData.length !== 0 &&
                      Number(
                        customerUnidentifiedData[0].MARGIN_RATE_PER_TY_VS_LLY
                      )
                        .toFixed(2)
                        .includes("-") ? (
                        <span style={{ color: "red", fontSize: "11px" }}>
                          {customerUnidentifiedData !== undefined &&
                            customerUnidentifiedData.length !== 0 &&
                            (customerUnidentifiedData[0]
                              .MARGIN_RATE_PER_TY_VS_LLY === "-999999"
                              ? "-"
                              : `LLY ${Number(
                                  customerUnidentifiedData[0]
                                    .MARGIN_RATE_PER_TY_VS_LLY
                                ).toFixed(2)}%`)}
                        </span>
                      ) : (
                        <span style={{ color: "green", fontSize: "11px" }}>
                          {customerUnidentifiedData !== undefined &&
                            customerUnidentifiedData.length !== 0 &&
                            (customerUnidentifiedData[0]
                              .MARGIN_RATE_PER_TY_VS_LLY === "-999999"
                              ? "-"
                              : `LLY +${Number(
                                  customerUnidentifiedData[0]
                                    .MARGIN_RATE_PER_TY_VS_LLY
                                ).toFixed(2)}%`)}
                        </span>
                      )}
                    </td>
                    <td>
                      <br />
                      {customerUnidentifiedData !== undefined &&
                        customerUnidentifiedData.length !== 0 &&
                        "NA"}
                    </td>
                    <td>
                      <br />
                      {customerUnidentifiedData !== undefined &&
                        customerUnidentifiedData.length !== 0 &&
                        "NA"}
                    </td>
                  </>
                )}
              </tr>
            )}
            <tr className="align-middle">
              <td className="tableTotalCol">
                <b>{"Sub Total"}</b>
              </td>
              {loading.first_half_total ? (
                <>
                  <LoaderForRow tdCount={10} />
                </>
              ) : (
                <>
                  <th>
                    {flag &&
                      firsthalftotalData !== undefined &&
                      firsthalftotalData.length !== 0 &&
                      (firsthalftotalData[0].CUST_COUNT_TY === "-999999"
                        ? "-"
                        : currencyFormat(
                            Number(firsthalftotalData[0].CUST_COUNT_TY)
                          ))}
                    <br />
                    {firsthalftotalData !== undefined &&
                    firsthalftotalData.length !== 0 &&
                    Number(firsthalftotalData[0].CUST_TY_VS_LY)
                      .toFixed(2)
                      .includes("-") ? (
                      <span style={{ color: "red", fontSize: "12px" }}>
                        {firsthalftotalData !== undefined &&
                          firsthalftotalData.length !== 0 &&
                          (firsthalftotalData[0].CUST_TY_VS_LY === "-999999"
                            ? "-"
                            : `LY ${Number(
                                firsthalftotalData[0].CUST_TY_VS_LY
                              ).toFixed(2)}%`)}
                      </span>
                    ) : (
                      <span style={{ color: "green", fontSize: "12px" }}>
                        {firsthalftotalData !== undefined &&
                          firsthalftotalData.length !== 0 &&
                          (firsthalftotalData[0].CUST_TY_VS_LY === "-999999"
                            ? "-"
                            : `LY +${Number(
                                firsthalftotalData[0].CUST_TY_VS_LY
                              ).toFixed(2)}%`)}
                      </span>
                    )}
                    <br />
                    {firsthalftotalData !== undefined &&
                    firsthalftotalData.length !== 0 &&
                    Number(firsthalftotalData[0].CUST_TY_VS_LLY)
                      .toFixed(2)
                      .includes("-") ? (
                      <span style={{ color: "red", fontSize: "11px" }}>
                        {firsthalftotalData !== undefined &&
                          firsthalftotalData.length !== 0 &&
                          (firsthalftotalData[0].CUST_TY_VS_LLY === "-999999"
                            ? "-"
                            : `LLY ${Number(
                                firsthalftotalData[0].CUST_TY_VS_LLY
                              ).toFixed(2)}%`)}
                      </span>
                    ) : (
                      <span style={{ color: "green", fontSize: "11px" }}>
                        {firsthalftotalData !== undefined &&
                          firsthalftotalData.length !== 0 &&
                          (firsthalftotalData[0].CUST_TY_VS_LLY === "-999999"
                            ? "-"
                            : `LLY +${Number(
                                firsthalftotalData[0].CUST_TY_VS_LLY
                              ).toFixed(2)}%`)}
                      </span>
                    )}
                  </th>
                  <th>
                    {flag &&
                      firsthalftotalData !== undefined &&
                      firsthalftotalData.length !== 0 &&
                      (firsthalftotalData[0].NET_SALES_TY === "-999999"
                        ? "-"
                        : "$" +
                          currencyFormat(
                            Number(firsthalftotalData[0].NET_SALES_TY)
                          ))}
                    <br />
                    {firsthalftotalData !== undefined &&
                    firsthalftotalData.length !== 0 &&
                    Number(firsthalftotalData[0].NET_SALES_TY_VS_LY)
                      .toFixed(2)
                      .includes("-") ? (
                      <span style={{ color: "red", fontSize: "12px" }}>
                        {firsthalftotalData !== undefined &&
                          firsthalftotalData.length !== 0 &&
                          (firsthalftotalData[0].NET_SALES_TY_VS_LY ===
                          "-999999"
                            ? "-"
                            : `LY ${Number(
                                firsthalftotalData[0].NET_SALES_TY_VS_LY
                              ).toFixed(2)}%`)}
                      </span>
                    ) : (
                      <span style={{ color: "green", fontSize: "12px" }}>
                        {firsthalftotalData !== undefined &&
                          firsthalftotalData.length !== 0 &&
                          (firsthalftotalData[0].NET_SALES_TY_VS_LY ===
                          "-999999"
                            ? "-"
                            : `LY +${Number(
                                firsthalftotalData[0].NET_SALES_TY_VS_LY
                              ).toFixed(2)}%`)}
                      </span>
                    )}
                    <br />
                    {firsthalftotalData !== undefined &&
                    firsthalftotalData.length !== 0 &&
                    Number(firsthalftotalData[0].NET_SALES_TY_VS_LLY)
                      .toFixed(2)
                      .includes("-") ? (
                      <span style={{ color: "red", fontSize: "11px" }}>
                        {firsthalftotalData !== undefined &&
                          firsthalftotalData.length !== 0 &&
                          (firsthalftotalData[0].NET_SALES_TY_VS_LLY ===
                          "-999999"
                            ? "-"
                            : `LLY ${Number(
                                firsthalftotalData[0].NET_SALES_TY_VS_LLY
                              ).toFixed(2)}%`)}
                      </span>
                    ) : (
                      <span style={{ color: "green", fontSize: "11px" }}>
                        {firsthalftotalData !== undefined &&
                          firsthalftotalData.length !== 0 &&
                          (firsthalftotalData[0].NET_SALES_TY_VS_LLY ===
                          "-999999"
                            ? "-"
                            : `LLY +${Number(
                                firsthalftotalData[0].NET_SALES_TY_VS_LLY
                              ).toFixed(2)}%`)}
                      </span>
                    )}
                  </th>
                  <th>
                    {flag &&
                      firsthalftotalData !== undefined &&
                      firsthalftotalData.length !== 0 &&
                      (firsthalftotalData[0].TRANS_COUNT_TY === "-999999"
                        ? "-"
                        : currencyFormat(
                            Number(firsthalftotalData[0].TRANS_COUNT_TY)
                          ))}
                    <br />
                    {firsthalftotalData !== undefined &&
                    firsthalftotalData.length !== 0 &&
                    Number(firsthalftotalData[0].TRANS_TY_VS_LY)
                      .toFixed(2)
                      .includes("-") ? (
                      <span style={{ color: "red", fontSize: "12px" }}>
                        {firsthalftotalData !== undefined &&
                          firsthalftotalData.length !== 0 &&
                          (firsthalftotalData[0].TRANS_TY_VS_LY === "-999999"
                            ? "-"
                            : `LY ${Number(
                                firsthalftotalData[0].TRANS_TY_VS_LY
                              ).toFixed(2)}%`)}
                      </span>
                    ) : (
                      <span style={{ color: "green", fontSize: "12px" }}>
                        {firsthalftotalData !== undefined &&
                          firsthalftotalData.length !== 0 &&
                          (firsthalftotalData[0].TRANS_TY_VS_LY === "-999999"
                            ? "-"
                            : `LY +${Number(
                                firsthalftotalData[0].TRANS_TY_VS_LY
                              ).toFixed(2)}%`)}
                      </span>
                    )}
                    <br />
                    {firsthalftotalData !== undefined &&
                    firsthalftotalData.length !== 0 &&
                    Number(firsthalftotalData[0].TRANS_TY_VS_LLY)
                      .toFixed(2)
                      .includes("-") ? (
                      <span style={{ color: "red", fontSize: "11px" }}>
                        {firsthalftotalData !== undefined &&
                          firsthalftotalData.length !== 0 &&
                          (firsthalftotalData[0].TRANS_TY_VS_LLY === "-999999"
                            ? "-"
                            : `LLY ${Number(
                                firsthalftotalData[0].TRANS_TY_VS_LLY
                              ).toFixed(2)}%`)}
                      </span>
                    ) : (
                      <span style={{ color: "green", fontSize: "11px" }}>
                        {firsthalftotalData !== undefined &&
                          firsthalftotalData.length !== 0 &&
                          (firsthalftotalData[0].TRANS_TY_VS_LLY === "-999999"
                            ? "-"
                            : `LLY +${Number(
                                firsthalftotalData[0].TRANS_TY_VS_LLY
                              ).toFixed(2)}%`)}
                      </span>
                    )}
                  </th>
                  <th>
                    {flag &&
                      firsthalftotalData !== undefined &&
                      firsthalftotalData.length !== 0 &&
                      (firsthalftotalData[0].PM_TY === "-999999"
                        ? "-"
                        : "$" +
                          currencyFormat(Number(firsthalftotalData[0].PM_TY)))}
                    <br />
                    {firsthalftotalData !== undefined &&
                    firsthalftotalData.length !== 0 &&
                    Number(firsthalftotalData[0].PM_TY_VS_LY)
                      .toFixed(2)
                      .includes("-") ? (
                      <span style={{ color: "red", fontSize: "12px" }}>
                        {firsthalftotalData !== undefined &&
                          firsthalftotalData.length !== 0 &&
                          (firsthalftotalData[0].PM_TY_VS_LY === "-999999"
                            ? "-"
                            : `LY ${Number(
                                firsthalftotalData[0].PM_TY_VS_LY
                              ).toFixed(2)}%`)}
                      </span>
                    ) : (
                      <span style={{ color: "green", fontSize: "12px" }}>
                        {firsthalftotalData !== undefined &&
                          firsthalftotalData.length !== 0 &&
                          (firsthalftotalData[0].PM_TY_VS_LY === "-999999"
                            ? "-"
                            : `LY +${Number(
                                firsthalftotalData[0].PM_TY_VS_LY
                              ).toFixed(2)}%`)}
                      </span>
                    )}
                    <br />
                    {firsthalftotalData !== undefined &&
                    firsthalftotalData.length !== 0 &&
                    Number(firsthalftotalData[0].PM_TY_VS_LLY)
                      .toFixed(2)
                      .includes("-") ? (
                      <span style={{ color: "red", fontSize: "11px" }}>
                        {firsthalftotalData !== undefined &&
                          firsthalftotalData.length !== 0 &&
                          (firsthalftotalData[0].PM_TY_VS_LLY === "-999999"
                            ? "-"
                            : `LLY ${Number(
                                firsthalftotalData[0].PM_TY_VS_LLY
                              ).toFixed(2)}%`)}
                      </span>
                    ) : (
                      <span style={{ color: "green", fontSize: "11px" }}>
                        {firsthalftotalData !== undefined &&
                          firsthalftotalData.length !== 0 &&
                          (firsthalftotalData[0].PM_TY_VS_LLY === "-999999"
                            ? "-"
                            : `LLY +${Number(
                                firsthalftotalData[0].PM_TY_VS_LLY
                              ).toFixed(2)}%`)}
                      </span>
                    )}
                  </th>
                  <th>
                    {flag &&
                      firsthalftotalData !== undefined &&
                      firsthalftotalData.length !== 0 &&
                      (firsthalftotalData[0].AOV_TY === "-999999"
                        ? "-"
                        : "$" +
                          Number(firsthalftotalData[0].AOV_TY).toFixed(2))}
                    <br />
                    {firsthalftotalData !== undefined &&
                    firsthalftotalData.length !== 0 &&
                    Number(firsthalftotalData[0].AOV_TY_VS_LY)
                      .toFixed(2)
                      .includes("-") ? (
                      <span style={{ color: "red", fontSize: "12px" }}>
                        {firsthalftotalData !== undefined &&
                          firsthalftotalData.length !== 0 &&
                          (firsthalftotalData[0].AOV_TY_VS_LY === "-999999"
                            ? "-"
                            : `LY ${Number(
                                firsthalftotalData[0].AOV_TY_VS_LY
                              ).toFixed(2)}%`)}
                      </span>
                    ) : (
                      <span style={{ color: "green", fontSize: "12px" }}>
                        {firsthalftotalData !== undefined &&
                          firsthalftotalData.length !== 0 &&
                          (firsthalftotalData[0].AOV_TY_VS_LY === "-999999"
                            ? "-"
                            : `LY +${Number(
                                firsthalftotalData[0].AOV_TY_VS_LY
                              ).toFixed(2)}%`)}
                      </span>
                    )}
                    <br />
                    {firsthalftotalData !== undefined &&
                    firsthalftotalData.length !== 0 &&
                    Number(firsthalftotalData[0].AOV_TY_VS_LLY)
                      .toFixed(2)
                      .includes("-") ? (
                      <span style={{ color: "red", fontSize: "11px" }}>
                        {firsthalftotalData !== undefined &&
                          firsthalftotalData.length !== 0 &&
                          (firsthalftotalData[0].AOV_TY_VS_LLY === "-999999"
                            ? "-"
                            : `LLY ${Number(
                                firsthalftotalData[0].AOV_TY_VS_LLY
                              ).toFixed(2)}%`)}
                      </span>
                    ) : (
                      <span style={{ color: "green", fontSize: "11px" }}>
                        {firsthalftotalData !== undefined &&
                          firsthalftotalData.length !== 0 &&
                          (firsthalftotalData[0].AOV_TY_VS_LLY === "-999999"
                            ? "-"
                            : `LLY +${Number(
                                firsthalftotalData[0].AOV_TY_VS_LLY
                              ).toFixed(2)}%`)}
                      </span>
                    )}
                  </th>
                  <th>
                    {flag &&
                      firsthalftotalData !== undefined &&
                      firsthalftotalData.length !== 0 &&
                      (firsthalftotalData[0].UPT_TY === "-999999"
                        ? "-"
                        : Number(firsthalftotalData[0].UPT_TY).toFixed(1))}
                    <br />
                    {firsthalftotalData !== undefined &&
                    firsthalftotalData.length !== 0 &&
                    Number(firsthalftotalData[0].UPT_TY_VS_LY)
                      .toFixed(2)
                      .includes("-") ? (
                      <span style={{ color: "red", fontSize: "12px" }}>
                        {firsthalftotalData !== undefined &&
                          firsthalftotalData.length !== 0 &&
                          (firsthalftotalData[0].UPT_TY_VS_LY === "-999999"
                            ? "-"
                            : `LY ${Number(
                                firsthalftotalData[0].UPT_TY_VS_LY
                              ).toFixed(2)}%`)}
                      </span>
                    ) : (
                      <span style={{ color: "green", fontSize: "12px" }}>
                        {firsthalftotalData !== undefined &&
                          firsthalftotalData.length !== 0 &&
                          (firsthalftotalData[0].UPT_TY_VS_LY === "-999999"
                            ? "-"
                            : `LY +${Number(
                                firsthalftotalData[0].UPT_TY_VS_LY
                              ).toFixed(2)}%`)}
                      </span>
                    )}
                    <br />
                    {firsthalftotalData !== undefined &&
                    firsthalftotalData.length !== 0 &&
                    Number(firsthalftotalData[0].UPT_TY_VS_LLY)
                      .toFixed(2)
                      .includes("-") ? (
                      <span style={{ color: "red", fontSize: "11px" }}>
                        {firsthalftotalData !== undefined &&
                          firsthalftotalData.length !== 0 &&
                          (firsthalftotalData[0].UPT_TY_VS_LLY === "-999999"
                            ? "-"
                            : `LLY ${Number(
                                firsthalftotalData[0].UPT_TY_VS_LLY
                              ).toFixed(2)}%`)}
                      </span>
                    ) : (
                      <span style={{ color: "green", fontSize: "11px" }}>
                        {firsthalftotalData !== undefined &&
                          firsthalftotalData.length !== 0 &&
                          (firsthalftotalData[0].UPT_TY_VS_LLY === "-999999"
                            ? "-"
                            : `LLY +${Number(
                                firsthalftotalData[0].UPT_TY_VS_LLY
                              ).toFixed(2)}%`)}
                      </span>
                    )}
                  </th>
                  <th>
                    {flag &&
                      firsthalftotalData !== undefined &&
                      firsthalftotalData.length !== 0 &&
                      (firsthalftotalData[0].AUR_TY === "-999999"
                        ? "-"
                        : "$" +
                          Number(firsthalftotalData[0].AUR_TY).toFixed(2))}
                    <br />
                    {firsthalftotalData !== undefined &&
                    firsthalftotalData.length !== 0 &&
                    Number(firsthalftotalData[0].AUR_TY_VS_LY)
                      .toFixed(2)
                      .includes("-") ? (
                      <span style={{ color: "red", fontSize: "12px" }}>
                        {firsthalftotalData !== undefined &&
                          firsthalftotalData.length !== 0 &&
                          (firsthalftotalData[0].AUR_TY_VS_LY === "-999999"
                            ? "-"
                            : `LY ${Number(
                                firsthalftotalData[0].AUR_TY_VS_LY
                              ).toFixed(2)}%`)}
                      </span>
                    ) : (
                      <span style={{ color: "green", fontSize: "12px" }}>
                        {firsthalftotalData !== undefined &&
                          firsthalftotalData.length !== 0 &&
                          (firsthalftotalData[0].AUR_TY_VS_LY === "-999999"
                            ? "-"
                            : `LY +${Number(
                                firsthalftotalData[0].AUR_TY_VS_LY
                              ).toFixed(2)}%`)}
                      </span>
                    )}
                    <br />
                    {firsthalftotalData !== undefined &&
                    firsthalftotalData.length !== 0 &&
                    Number(firsthalftotalData[0].AUR_TY_VS_LLY)
                      .toFixed(2)
                      .includes("-") ? (
                      <span style={{ color: "red", fontSize: "11px" }}>
                        {firsthalftotalData !== undefined &&
                          firsthalftotalData.length !== 0 &&
                          (firsthalftotalData[0].AUR_TY_VS_LLY === "-999999"
                            ? "-"
                            : `LLY ${Number(
                                firsthalftotalData[0].AUR_TY_VS_LLY
                              ).toFixed(2)}%`)}
                      </span>
                    ) : (
                      <span style={{ color: "green", fontSize: "11px" }}>
                        {firsthalftotalData !== undefined &&
                          firsthalftotalData.length !== 0 &&
                          (firsthalftotalData[0].AUR_TY_VS_LLY === "-999999"
                            ? "-"
                            : `LLY +${Number(
                                firsthalftotalData[0].AUR_TY_VS_LLY
                              ).toFixed(2)}%`)}
                      </span>
                    )}
                  </th>
                  <th>
                    {flag &&
                      firsthalftotalData !== undefined &&
                      firsthalftotalData.length !== 0 &&
                      (firsthalftotalData[0].MARGIN_RATE_PER_TY === "-999999"
                        ? "-"
                        : Number(
                            firsthalftotalData[0].MARGIN_RATE_PER_TY
                          ).toFixed(2))}
                    <br />
                    {firsthalftotalData !== undefined &&
                    firsthalftotalData.length !== 0 &&
                    Number(firsthalftotalData[0].MARGIN_RATE_PER_TY_VS_LY)
                      .toFixed(2)
                      .includes("-") ? (
                      <span style={{ color: "red", fontSize: "12px" }}>
                        {firsthalftotalData !== undefined &&
                          firsthalftotalData.length !== 0 &&
                          (firsthalftotalData[0].MARGIN_RATE_PER_TY_VS_LY ===
                          "-999999"
                            ? "-"
                            : `LY ${Number(
                                firsthalftotalData[0].MARGIN_RATE_PER_TY_VS_LY
                              ).toFixed(2)}%`)}
                      </span>
                    ) : (
                      <span style={{ color: "green", fontSize: "12px" }}>
                        {firsthalftotalData !== undefined &&
                          firsthalftotalData.length !== 0 &&
                          (firsthalftotalData[0].MARGIN_RATE_PER_TY_VS_LY ===
                          "-999999"
                            ? "-"
                            : `LY +${Number(
                                firsthalftotalData[0].MARGIN_RATE_PER_TY_VS_LY
                              ).toFixed(2)}%`)}
                      </span>
                    )}
                    <br />
                    {firsthalftotalData !== undefined &&
                    firsthalftotalData.length !== 0 &&
                    Number(firsthalftotalData[0].MARGIN_RATE_PER_TY_VS_LLY)
                      .toFixed(2)
                      .includes("-") ? (
                      <span style={{ color: "red", fontSize: "11px" }}>
                        {firsthalftotalData !== undefined &&
                          firsthalftotalData.length !== 0 &&
                          (firsthalftotalData[0].MARGIN_RATE_PER_TY_VS_LLY ===
                          "-999999"
                            ? "-"
                            : `LLY ${Number(
                                firsthalftotalData[0].MARGIN_RATE_PER_TY_VS_LLY
                              ).toFixed(2)}%`)}
                      </span>
                    ) : (
                      <span style={{ color: "green", fontSize: "11px" }}>
                        {firsthalftotalData !== undefined &&
                          firsthalftotalData.length !== 0 &&
                          (firsthalftotalData[0].MARGIN_RATE_PER_TY_VS_LLY ===
                          "-999999"
                            ? "-"
                            : `LLY +${Number(
                                firsthalftotalData[0].MARGIN_RATE_PER_TY_VS_LLY
                              ).toFixed(2)}%`)}
                      </span>
                    )}
                  </th>
                  <th>
                    {flag &&
                      firsthalftotalData !== undefined &&
                      firsthalftotalData.length !== 0 &&
                      (firsthalftotalData[0].NET_SALES_PER_CUST_TY === "-999999"
                        ? "-"
                        : "$" +
                          Number(
                            firsthalftotalData[0].NET_SALES_PER_CUST_TY
                          ).toFixed(2))}
                    <br />
                    {firsthalftotalData !== undefined &&
                    firsthalftotalData.length !== 0 &&
                    Number(firsthalftotalData[0].NET_SALES_PER_CUST_TY_VS_LY)
                      .toFixed(2)
                      .includes("-") ? (
                      <span style={{ color: "red", fontSize: "12px" }}>
                        {firsthalftotalData !== undefined &&
                          firsthalftotalData.length !== 0 &&
                          (firsthalftotalData[0].NET_SALES_PER_CUST_TY_VS_LY ===
                          "-999999"
                            ? "-"
                            : `LY ${Number(
                                firsthalftotalData[0]
                                  .NET_SALES_PER_CUST_TY_VS_LY
                              ).toFixed(2)}%`)}
                      </span>
                    ) : (
                      <span style={{ color: "green", fontSize: "12px" }}>
                        {firsthalftotalData !== undefined &&
                          firsthalftotalData.length !== 0 &&
                          (firsthalftotalData[0].NET_SALES_PER_CUST_TY_VS_LY ===
                          "-999999"
                            ? "-"
                            : `LY +${Number(
                                firsthalftotalData[0]
                                  .NET_SALES_PER_CUST_TY_VS_LY
                              ).toFixed(2)}%`)}
                      </span>
                    )}
                    <br />
                    {firsthalftotalData !== undefined &&
                    firsthalftotalData.length !== 0 &&
                    Number(firsthalftotalData[0].NET_SALES_PER_CUST_TY_VS_LLY)
                      .toFixed(2)
                      .includes("-") ? (
                      <span style={{ color: "red", fontSize: "11px" }}>
                        {firsthalftotalData !== undefined &&
                          firsthalftotalData.length !== 0 &&
                          (firsthalftotalData[0]
                            .NET_SALES_PER_CUST_TY_VS_LLY === "-999999"
                            ? "-"
                            : `LLY ${Number(
                                firsthalftotalData[0]
                                  .NET_SALES_PER_CUST_TY_VS_LLY
                              ).toFixed(2)}%`)}
                      </span>
                    ) : (
                      <span style={{ color: "green", fontSize: "11px" }}>
                        {firsthalftotalData !== undefined &&
                          firsthalftotalData.length !== 0 &&
                          (firsthalftotalData[0]
                            .NET_SALES_PER_CUST_TY_VS_LLY === "-999999"
                            ? "-"
                            : `LLY +${Number(
                                firsthalftotalData[0]
                                  .NET_SALES_PER_CUST_TY_VS_LLY
                              ).toFixed(2)}%`)}
                      </span>
                    )}
                  </th>
                  <th>
                    {flag &&
                      firsthalftotalData !== undefined &&
                      firsthalftotalData.length !== 0 &&
                      (firsthalftotalData[0].AVG_TRAN_TY === "-999999"
                        ? "-"
                        : Number(firsthalftotalData[0].AVG_TRAN_TY).toFixed(2))}
                    <br />
                    {firsthalftotalData !== undefined &&
                    firsthalftotalData.length !== 0 &&
                    Number(firsthalftotalData[0].AVG_TRAN_TY_VS_LY)
                      .toFixed(2)
                      .includes("-") ? (
                      <span style={{ color: "red", fontSize: "12px" }}>
                        {firsthalftotalData !== undefined &&
                          firsthalftotalData.length !== 0 &&
                          (firsthalftotalData[0].AVG_TRAN_TY_VS_LY === "-999999"
                            ? "-"
                            : `LY ${Number(
                                firsthalftotalData[0].AVG_TRAN_TY_VS_LY
                              ).toFixed(2)}%`)}
                      </span>
                    ) : (
                      <span style={{ color: "green", fontSize: "12px" }}>
                        {firsthalftotalData !== undefined &&
                          firsthalftotalData.length !== 0 &&
                          (firsthalftotalData[0].AVG_TRAN_TY_VS_LY === "-999999"
                            ? "-"
                            : `LY +${Number(
                                firsthalftotalData[0].AVG_TRAN_TY_VS_LY
                              ).toFixed(2)}%`)}
                      </span>
                    )}
                    <br />
                    {firsthalftotalData !== undefined &&
                    firsthalftotalData.length !== 0 &&
                    Number(firsthalftotalData[0].AVG_TRAN_TY_VS_LLY)
                      .toFixed(2)
                      .includes("-") ? (
                      <span style={{ color: "red", fontSize: "11px" }}>
                        {firsthalftotalData !== undefined &&
                          firsthalftotalData.length !== 0 &&
                          (firsthalftotalData[0].AVG_TRAN_TY_VS_LLY ===
                          "-999999"
                            ? "-"
                            : `LLY ${Number(
                                firsthalftotalData[0].AVG_TRAN_TY_VS_LLY
                              ).toFixed(2)}%`)}
                      </span>
                    ) : (
                      <span style={{ color: "green", fontSize: "11px" }}>
                        {firsthalftotalData !== undefined &&
                          firsthalftotalData.length !== 0 &&
                          (firsthalftotalData[0].AVG_TRAN_TY_VS_LLY ===
                          "-999999"
                            ? "-"
                            : `LLY +${Number(
                                firsthalftotalData[0].AVG_TRAN_TY_VS_LLY
                              ).toFixed(2)}%`)}
                      </span>
                    )}
                  </th>
                </>
              )}
            </tr>
            <tr className="align-middle">
              <td
                className="tableCol"
                id={"Inactive_12_18"}
                onClick={() => handleModalOpen("Inactive (12m-18m)")}
              >
                {"Inactive (12m-18m)"}{" "}
                {gettooltip(
                  "InActive_12_18InfoIcon",
                  "InActive_12_18",
                  "InActive_12_18",
                  "Active in L12M-L18M but not active in L12M"
                )}
              </td>
              {loading.Inactive_12m_18m ? (
                <>
                  <LoaderForRow tdCount={10} />
                </>
              ) : (
                <>
                  <td>
                    {customerInActive_12_18_Data !== undefined &&
                      customerInActive_12_18_Data.length !== 0 &&
                      (customerInActive_12_18_Data[0].CUST_COUNT_TY ===
                      "-999999"
                        ? "-"
                        : currencyFormat(
                            Number(customerInActive_12_18_Data[0].CUST_COUNT_TY)
                          ))}
                    <br />
                    {customerInActive_12_18_Data !== undefined &&
                    customerInActive_12_18_Data.length !== 0 &&
                    Number(customerInActive_12_18_Data[0].TY_VS_LY)
                      .toFixed(2)
                      .includes("-") ? (
                      <span style={{ color: "green", fontSize: "12px" }}>
                        {customerInActive_12_18_Data !== undefined &&
                          customerInActive_12_18_Data.length !== 0 &&
                          (customerInActive_12_18_Data[0].TY_VS_LY === "-999999"
                            ? "-"
                            : `LY ${Number(
                                customerInActive_12_18_Data[0].TY_VS_LY
                              ).toFixed(2)}%`)}
                      </span>
                    ) : (
                      <span style={{ color: "red", fontSize: "12px" }}>
                        {customerInActive_12_18_Data !== undefined &&
                          customerInActive_12_18_Data.length !== 0 &&
                          (customerInActive_12_18_Data[0].TY_VS_LY === "-999999"
                            ? "-"
                            : `LY +${Number(
                                customerInActive_12_18_Data[0].TY_VS_LY
                              ).toFixed(2)}%`)}
                      </span>
                    )}
                    <br />
                    {customerInActive_12_18_Data !== undefined &&
                    customerInActive_12_18_Data.length !== 0 &&
                    Number(customerInActive_12_18_Data[0].TY_VS_LLY)
                      .toFixed(2)
                      .includes("-") ? (
                      <span style={{ color: "green", fontSize: "11px" }}>
                        {customerInActive_12_18_Data !== undefined &&
                          customerInActive_12_18_Data.length !== 0 &&
                          (customerInActive_12_18_Data[0].TY_VS_LLY ===
                          "-999999"
                            ? "-"
                            : `LLY ${Number(
                                customerInActive_12_18_Data[0].TY_VS_LLY
                              ).toFixed(2)}%`)}
                      </span>
                    ) : (
                      <span style={{ color: "red", fontSize: "11px" }}>
                        {customerInActive_12_18_Data !== undefined &&
                          customerInActive_12_18_Data.length !== 0 &&
                          (customerInActive_12_18_Data[0].TY_VS_LLY ===
                          "-999999"
                            ? "-"
                            : `LLY +${Number(
                                customerInActive_12_18_Data[0].TY_VS_LLY
                              ).toFixed(2)}%`)}
                      </span>
                    )}
                  </td>
                  <td>
                    <br />
                    {customerInActive_12_18_Data !== undefined &&
                      customerInActive_12_18_Data.length !== 0 &&
                      "NA"}
                  </td>
                  <td>
                    <br />
                    {customerInActive_12_18_Data !== undefined &&
                      customerInActive_12_18_Data.length !== 0 &&
                      "NA"}
                  </td>
                  <td>
                    <br />
                    {customerInActive_12_18_Data !== undefined &&
                      customerInActive_12_18_Data.length !== 0 &&
                      "NA"}
                  </td>
                  <td>
                    <br />
                    {customerInActive_12_18_Data !== undefined &&
                      customerInActive_12_18_Data.length !== 0 &&
                      "NA"}
                  </td>
                  <td>
                    <br />
                    {customerInActive_12_18_Data !== undefined &&
                      customerInActive_12_18_Data.length !== 0 &&
                      "NA"}
                  </td>
                  <td>
                    <br />
                    {customerInActive_12_18_Data !== undefined &&
                      customerInActive_12_18_Data.length !== 0 &&
                      "NA"}
                  </td>
                  <td>
                    <br />
                    {customerInActive_12_18_Data !== undefined &&
                      customerInActive_12_18_Data.length !== 0 &&
                      "NA"}
                  </td>
                  <td>
                    <br />
                    {customerInActive_12_18_Data !== undefined &&
                      customerInActive_12_18_Data.length !== 0 &&
                      "NA"}
                  </td>
                  <td>
                    <br />
                    {customerInActive_12_18_Data !== undefined &&
                      customerInActive_12_18_Data.length !== 0 &&
                      "NA"}
                  </td>
                </>
              )}
            </tr>
            <tr className="align-middle">
              <td
                className="tableCol"
                id={"Inactive_18_24"}
                onClick={() => handleModalOpen("Inactive (18m-24m)")}
              >
                {"Inactive (18m-24m)"}{" "}
                {gettooltip(
                  "InActive_18_24InfoIcon",
                  "InActive_18_24",
                  "InActive_18_24",
                  "Active in L18M-L24M but not active in L18M"
                )}
              </td>
              {loading.Inactive_18m_24m ? (
                <>
                  <LoaderForRow tdCount={10} />
                </>
              ) : (
                <>
                  <td>
                    {customerInActive_18_24_Data !== undefined &&
                      customerInActive_18_24_Data.length !== 0 &&
                      (customerInActive_18_24_Data[0].CUST_COUNT_TY ===
                      "-999999"
                        ? "-"
                        : currencyFormat(
                            Number(customerInActive_18_24_Data[0].CUST_COUNT_TY)
                          ))}
                    <br />
                    {customerInActive_18_24_Data !== undefined &&
                    customerInActive_18_24_Data.length !== 0 &&
                    Number(customerInActive_18_24_Data[0].TY_VS_LY)
                      .toFixed(2)
                      .includes("-") ? (
                      <span style={{ color: "green", fontSize: "12px" }}>
                        {customerInActive_18_24_Data !== undefined &&
                          customerInActive_18_24_Data.length !== 0 &&
                          (customerInActive_18_24_Data[0].TY_VS_LY === "-999999"
                            ? "-"
                            : `LY ${Number(
                                customerInActive_18_24_Data[0].TY_VS_LY
                              ).toFixed(2)}%`)}
                      </span>
                    ) : (
                      <span style={{ color: "red", fontSize: "12px" }}>
                        {customerInActive_18_24_Data !== undefined &&
                          customerInActive_18_24_Data.length !== 0 &&
                          (customerInActive_18_24_Data[0].TY_VS_LY === "-999999"
                            ? "-"
                            : `LY +${Number(
                                customerInActive_18_24_Data[0].TY_VS_LY
                              ).toFixed(2)}%`)}
                      </span>
                    )}
                    <br />
                    {customerInActive_18_24_Data !== undefined &&
                    customerInActive_18_24_Data.length !== 0 &&
                    Number(customerInActive_18_24_Data[0].TY_VS_LLY)
                      .toFixed(2)
                      .includes("-") ? (
                      <span style={{ color: "green", fontSize: "11px" }}>
                        {customerInActive_18_24_Data !== undefined &&
                          customerInActive_18_24_Data.length !== 0 &&
                          (customerInActive_18_24_Data[0].TY_VS_LLY ===
                          "-999999"
                            ? "-"
                            : `LLY ${Number(
                                customerInActive_18_24_Data[0].TY_VS_LLY
                              ).toFixed(2)}%`)}
                      </span>
                    ) : (
                      <span style={{ color: "red", fontSize: "11px" }}>
                        {customerInActive_18_24_Data !== undefined &&
                          customerInActive_18_24_Data.length !== 0 &&
                          (customerInActive_18_24_Data[0].TY_VS_LLY ===
                          "-999999"
                            ? "-"
                            : `LLY +${Number(
                                customerInActive_18_24_Data[0].TY_VS_LLY
                              ).toFixed(2)}%`)}
                      </span>
                    )}
                  </td>
                  <td>
                    <br />
                    {customerInActive_18_24_Data !== undefined &&
                      customerInActive_18_24_Data.length !== 0 &&
                      "NA"}
                  </td>
                  <td>
                    <br />
                    {customerInActive_18_24_Data !== undefined &&
                      customerInActive_18_24_Data.length !== 0 &&
                      "NA"}
                  </td>
                  <td>
                    <br />
                    {customerInActive_18_24_Data !== undefined &&
                      customerInActive_18_24_Data.length !== 0 &&
                      "NA"}
                  </td>
                  <td>
                    <br />
                    {customerInActive_18_24_Data !== undefined &&
                      customerInActive_18_24_Data.length !== 0 &&
                      "NA"}
                  </td>
                  <td>
                    <br />
                    {customerInActive_18_24_Data !== undefined &&
                      customerInActive_18_24_Data.length !== 0 &&
                      "NA"}
                  </td>
                  <td>
                    <br />
                    {customerInActive_18_24_Data !== undefined &&
                      customerInActive_18_24_Data.length !== 0 &&
                      "NA"}
                  </td>
                  <td>
                    <br />{" "}
                    {customerInActive_18_24_Data !== undefined &&
                      customerInActive_18_24_Data.length !== 0 &&
                      "NA"}
                  </td>
                  <td>
                    <br />{" "}
                    {customerInActive_18_24_Data !== undefined &&
                      customerInActive_18_24_Data.length !== 0 &&
                      "NA"}
                  </td>
                  <td>
                    <br />
                    {customerInActive_18_24_Data !== undefined &&
                      customerInActive_18_24_Data.length !== 0 &&
                      "NA"}
                  </td>
                </>
              )}
            </tr>
            {selectedCategoryId === "BPLUS" ||
            selectedCategoryId === "CC" ||
            selectedCategoryId === "BC" ? (
              <tr className="align-middle">
                <td className="tableCol">{"Inactive (24m+)"}</td>
                {loading.Inactive_24mp ? (
                  <>
                    <LoaderForRow tdCount={10} />
                  </>
                ) : (
                  <>
                    <td>
                      {customerInActive_24plus_Data !== undefined &&
                        customerInActive_24plus_Data.length !== 0 &&
                        (customerInActive_24plus_Data[0].CUST_COUNT_TY ===
                        "-999999"
                          ? "-"
                          : currencyFormat(
                              Number(
                                customerInActive_24plus_Data[0].CUST_COUNT_TY
                              )
                            ))}
                      <br />
                      {customerInActive_24plus_Data !== undefined &&
                      customerInActive_24plus_Data.length !== 0 &&
                      Number(customerInActive_24plus_Data[0].TY_VS_LY)
                        .toFixed(2)
                        .includes("-") ? (
                        <span style={{ color: "green", fontSize: "12px" }}>
                          {customerInActive_24plus_Data !== undefined &&
                            customerInActive_24plus_Data.length !== 0 &&
                            (customerInActive_24plus_Data[0].TY_VS_LY ===
                            "-999999"
                              ? "-"
                              : `LY ${Number(
                                  customerInActive_24plus_Data[0].TY_VS_LY
                                ).toFixed(2)}%`)}
                        </span>
                      ) : (
                        <span style={{ color: "red", fontSize: "12px" }}>
                          {customerInActive_24plus_Data !== undefined &&
                            customerInActive_24plus_Data.length !== 0 &&
                            (customerInActive_24plus_Data[0].TY_VS_LY ===
                            "-999999"
                              ? "-"
                              : `LY +${Number(
                                  customerInActive_24plus_Data[0].TY_VS_LY
                                ).toFixed(2)}%`)}
                        </span>
                      )}
                      <br />
                      {customerInActive_24plus_Data !== undefined &&
                      customerInActive_24plus_Data.length !== 0 &&
                      Number(customerInActive_24plus_Data[0].TY_VS_LLY)
                        .toFixed(2)
                        .includes("-") ? (
                        <span style={{ color: "green", fontSize: "11px" }}>
                          {customerInActive_24plus_Data !== undefined &&
                            customerInActive_24plus_Data.length !== 0 &&
                            (customerInActive_24plus_Data[0].TY_VS_LLY ===
                            "-999999"
                              ? "-"
                              : `LLY ${Number(
                                  customerInActive_24plus_Data[0].TY_VS_LLY
                                ).toFixed(2)}%`)}
                        </span>
                      ) : (
                        <span style={{ color: "red", fontSize: "11px" }}>
                          {customerInActive_24plus_Data !== undefined &&
                            customerInActive_24plus_Data.length !== 0 &&
                            (customerInActive_24plus_Data[0].TY_VS_LLY ===
                            "-999999"
                              ? "-"
                              : `LLY +${Number(
                                  customerInActive_24plus_Data[0].TY_VS_LLY
                                ).toFixed(2)}%`)}
                        </span>
                      )}
                    </td>
                    <td>
                      <br />
                      {customerInActive_24plus_Data !== undefined &&
                        customerInActive_24plus_Data.length !== 0 &&
                        "NA"}
                    </td>
                    <td>
                      <br />
                      {customerInActive_24plus_Data !== undefined &&
                        customerInActive_24plus_Data.length !== 0 &&
                        "NA"}
                    </td>
                    <td>
                      <br />
                      {customerInActive_24plus_Data !== undefined &&
                        customerInActive_24plus_Data.length !== 0 &&
                        "NA"}
                    </td>
                    <td>
                      <br />
                      {customerInActive_24plus_Data !== undefined &&
                        customerInActive_24plus_Data.length !== 0 &&
                        "NA"}
                    </td>
                    <td>
                      <br />
                      {customerInActive_24plus_Data !== undefined &&
                        customerInActive_24plus_Data.length !== 0 &&
                        "NA"}
                    </td>
                    <td>
                      <br />
                      {customerInActive_24plus_Data !== undefined &&
                        customerInActive_24plus_Data.length !== 0 &&
                        "NA"}
                    </td>
                    <td>
                      <br />{" "}
                      {customerInActive_24plus_Data !== undefined &&
                        customerInActive_24plus_Data.length !== 0 &&
                        "NA"}
                    </td>
                    <td>
                      <br />{" "}
                      {customerInActive_24plus_Data !== undefined &&
                        customerInActive_24plus_Data.length !== 0 &&
                        "NA"}
                    </td>
                    <td>
                      <br />
                      {customerInActive_24plus_Data !== undefined &&
                        customerInActive_24plus_Data.length !== 0 &&
                        "NA"}
                    </td>
                  </>
                )}
              </tr>
            ) : (
              ""
            )}
            <tr className="align-middle">
              <td className="tableTotalCol">
                <b>{"Sub Total"}</b>
              </td>
              {loading.second_half_total ? (
                <>
                  <LoaderForRow tdCount={10} />
                </>
              ) : (
                <>
                  <th>
                    {secondhalftotalData !== undefined &&
                      secondhalftotalData.length !== 0 &&
                      (secondhalftotalData[0].CUST_COUNT_TY === "-999999"
                        ? "-"
                        : currencyFormat(
                            Number(secondhalftotalData[0].CUST_COUNT_TY)
                          ))}
                    <br />
                    {secondhalftotalData !== undefined &&
                    secondhalftotalData.length !== 0 &&
                    Number(secondhalftotalData[0].CUST_TY_VS_LY)
                      .toFixed(2)
                      .includes("-") ? (
                      <span style={{ color: "green", fontSize: "12px" }}>
                        {secondhalftotalData !== undefined &&
                          secondhalftotalData.length !== 0 &&
                          (secondhalftotalData[0].CUST_TY_VS_LY === "-999999"
                            ? "-"
                            : `LY ${Number(
                                secondhalftotalData[0].CUST_TY_VS_LY
                              ).toFixed(2)}%`)}
                      </span>
                    ) : (
                      <span style={{ color: "red", fontSize: "12px" }}>
                        {secondhalftotalData !== undefined &&
                          secondhalftotalData.length !== 0 &&
                          (secondhalftotalData[0].CUST_TY_VS_LY === "-999999"
                            ? "-"
                            : `LY +${Number(
                                secondhalftotalData[0].CUST_TY_VS_LY
                              ).toFixed(2)}%`)}
                      </span>
                    )}
                    <br />
                    {secondhalftotalData !== undefined &&
                    secondhalftotalData.length !== 0 &&
                    Number(secondhalftotalData[0].CUST_TY_VS_LLY)
                      .toFixed(2)
                      .includes("-") ? (
                      <span style={{ color: "green", fontSize: "11px" }}>
                        {secondhalftotalData !== undefined &&
                          secondhalftotalData.length !== 0 &&
                          (secondhalftotalData[0].CUST_TY_VS_LLY === "-999999"
                            ? "-"
                            : `LLY ${Number(
                                secondhalftotalData[0].CUST_TY_VS_LLY
                              ).toFixed(2)}%`)}
                      </span>
                    ) : (
                      <span style={{ color: "red", fontSize: "11px" }}>
                        {secondhalftotalData !== undefined &&
                          secondhalftotalData.length !== 0 &&
                          (secondhalftotalData[0].CUST_TY_VS_LLY === "-999999"
                            ? "-"
                            : `LLY +${Number(
                                secondhalftotalData[0].CUST_TY_VS_LLY
                              ).toFixed(2)}%`)}
                      </span>
                    )}
                  </th>
                  <th></th>
                  <th></th>
                  <th></th>
                  <th></th>
                  <th></th>
                  <th></th>
                  <th></th>
                  <th></th>
                  <th></th>
                </>
              )}
            </tr>
            <tr className="align-middle">
              <td className="tableTotalColumn">
                <b>{"Total"}</b>{" "}
                {gettooltip(
                  "TotalInfoIcon",
                  "Total",
                  "Total",
                  "Active Customers + Inactive Customers"
                )}
              </td>
              {loading.total ? (
                <>
                  <LoaderForRow tdCount={10} />
                </>
              ) : (
                <>
                  <th>
                    {customerTotal !== undefined &&
                      customerTotal.length !== 0 &&
                      (customerTotal[0].CUST_COUNT_TY === "-999999"
                        ? "-"
                        : currencyFormat(
                            Number(customerTotal[0].CUST_COUNT_TY)
                          ))}
                    <br />
                    {customerTotal !== undefined &&
                    customerTotal.length !== 0 &&
                    Number(customerTotal[0].CUST_TY_VS_LY)
                      .toFixed(2)
                      .includes("-") ? (
                      <span style={{ color: "red", fontSize: "12px" }}>
                        {customerTotal !== undefined &&
                          customerTotal.length !== 0 &&
                          (customerTotal[0].CUST_TY_VS_LY === "-999999"
                            ? "-"
                            : `LY ${Number(
                                customerTotal[0].CUST_TY_VS_LY
                              ).toFixed(2)}%`)}
                      </span>
                    ) : (
                      <span style={{ color: "green", fontSize: "12px" }}>
                        {customerTotal !== undefined &&
                          customerTotal.length !== 0 &&
                          (customerTotal[0].CUST_TY_VS_LY === "-999999"
                            ? "-"
                            : `LY +${Number(
                                customerTotal[0].CUST_TY_VS_LY
                              ).toFixed(2)}%`)}
                      </span>
                    )}
                    <br />
                    {customerTotal !== undefined &&
                    customerTotal.length !== 0 &&
                    Number(customerTotal[0].CUST_TY_VS_LLY)
                      .toFixed(2)
                      .includes("-") ? (
                      <span style={{ color: "red", fontSize: "11px" }}>
                        {customerTotal !== undefined &&
                          customerTotal.length !== 0 &&
                          (customerTotal[0].CUST_TY_VS_LLY === "-999999"
                            ? "-"
                            : `LLY ${Number(
                                customerTotal[0].CUST_TY_VS_LLY
                              ).toFixed(2)}%`)}
                      </span>
                    ) : (
                      <span style={{ color: "green", fontSize: "11px" }}>
                        {customerTotal !== undefined &&
                          customerTotal.length !== 0 &&
                          (customerTotal[0].CUST_TY_VS_LLY === "-999999"
                            ? "-"
                            : `LLY +${Number(
                                customerTotal[0].CUST_TY_VS_LLY
                              ).toFixed(2)}%`)}
                      </span>
                    )}
                  </th>
                  <th>
                    {customerTotal !== undefined &&
                      customerTotal.length !== 0 &&
                      (customerTotal[0].NET_SALES_TY === "-999999"
                        ? "-"
                        : "$" +
                          currencyFormat(
                            Number(customerTotal[0].NET_SALES_TY)
                          ))}
                    <br />
                    {customerTotal !== undefined &&
                    customerTotal.length !== 0 &&
                    Number(customerTotal[0].NET_SALES_TY_VS_LY)
                      .toFixed(2)
                      .includes("-") ? (
                      <span style={{ color: "red", fontSize: "12px" }}>
                        {customerTotal !== undefined &&
                          customerTotal.length !== 0 &&
                          (customerTotal[0].NET_SALES_TY_VS_LY === "-999999"
                            ? "-"
                            : `LY ${Number(
                                customerTotal[0].NET_SALES_TY_VS_LY
                              ).toFixed(2)}%`)}
                      </span>
                    ) : (
                      <span style={{ color: "green", fontSize: "12px" }}>
                        {customerTotal !== undefined &&
                          customerTotal.length !== 0 &&
                          (customerTotal[0].NET_SALES_TY_VS_LY === "-999999"
                            ? "-"
                            : `LY +${Number(
                                customerTotal[0].NET_SALES_TY_VS_LY
                              ).toFixed(2)}%`)}
                      </span>
                    )}
                    <br />
                    {customerTotal !== undefined &&
                    customerTotal.length !== 0 &&
                    Number(customerTotal[0].NET_SALES_TY_VS_LLY)
                      .toFixed(2)
                      .includes("-") ? (
                      <span style={{ color: "red", fontSize: "11px" }}>
                        {customerTotal !== undefined &&
                          customerTotal.length !== 0 &&
                          (customerTotal[0].NET_SALES_TY_VS_LLY === "-999999"
                            ? "-"
                            : `LLY ${Number(
                                customerTotal[0].NET_SALES_TY_VS_LLY
                              ).toFixed(2)}%`)}
                      </span>
                    ) : (
                      <span style={{ color: "green", fontSize: "11px" }}>
                        {customerTotal !== undefined &&
                          customerTotal.length !== 0 &&
                          (customerTotal[0].NET_SALES_TY_VS_LLY === "-999999"
                            ? "-"
                            : `LLY +${Number(
                                customerTotal[0].NET_SALES_TY_VS_LLY
                              ).toFixed(2)}%`)}
                      </span>
                    )}
                  </th>
                  <th>
                    {customerTotal !== undefined &&
                      customerTotal.length !== 0 &&
                      (customerTotal[0].TRANS_COUNT_TY === "-999999"
                        ? "-"
                        : currencyFormat(
                            Number(customerTotal[0].TRANS_COUNT_TY)
                          ))}
                    <br />
                    {customerTotal !== undefined &&
                    customerTotal.length !== 0 &&
                    Number(customerTotal[0].TRANS_TY_VS_LY)
                      .toFixed(2)
                      .includes("-") ? (
                      <span style={{ color: "red", fontSize: "12px" }}>
                        {customerTotal !== undefined &&
                          customerTotal.length !== 0 &&
                          (customerTotal[0].TRANS_TY_VS_LY === "-999999"
                            ? "-"
                            : `LY ${Number(
                                customerTotal[0].TRANS_TY_VS_LY
                              ).toFixed(2)}%`)}
                      </span>
                    ) : (
                      <span style={{ color: "green", fontSize: "12px" }}>
                        {customerTotal !== undefined &&
                          customerTotal.length !== 0 &&
                          (customerTotal[0].TRANS_TY_VS_LY === "-999999"
                            ? "-"
                            : `LY +${Number(
                                customerTotal[0].TRANS_TY_VS_LY
                              ).toFixed(2)}%`)}
                      </span>
                    )}
                    <br />
                    {customerTotal !== undefined &&
                    customerTotal.length !== 0 &&
                    Number(customerTotal[0].TRANS_TY_VS_LLY)
                      .toFixed(2)
                      .includes("-") ? (
                      <span style={{ color: "red", fontSize: "11px" }}>
                        {customerTotal !== undefined &&
                          customerTotal.length !== 0 &&
                          (customerTotal[0].TRANS_TY_VS_LLY === "-999999"
                            ? "-"
                            : `LLY ${Number(
                                customerTotal[0].TRANS_TY_VS_LLY
                              ).toFixed(2)}%`)}
                      </span>
                    ) : (
                      <span style={{ color: "green", fontSize: "11px" }}>
                        {customerTotal !== undefined &&
                          customerTotal.length !== 0 &&
                          (customerTotal[0].TRANS_TY_VS_LLY === "-999999"
                            ? "-"
                            : `LLY +${Number(
                                customerTotal[0].TRANS_TY_VS_LLY
                              ).toFixed(2)}%`)}
                      </span>
                    )}
                  </th>
                  <th>
                    {customerTotal !== undefined &&
                      customerTotal.length !== 0 &&
                      (customerTotal[0].PM_TY === "-999999"
                        ? "-"
                        : "$" + currencyFormat(Number(customerTotal[0].PM_TY)))}
                    <br />
                    {customerTotal !== undefined &&
                    customerTotal.length !== 0 &&
                    Number(customerTotal[0].PM_TY_VS_LY)
                      .toFixed(2)
                      .includes("-") ? (
                      <span style={{ color: "red", fontSize: "12px" }}>
                        {customerTotal !== undefined &&
                          customerTotal.length !== 0 &&
                          (customerTotal[0].PM_TY_VS_LY === "-999999"
                            ? "-"
                            : `LY ${Number(
                                customerTotal[0].PM_TY_VS_LY
                              ).toFixed(2)}%`)}
                      </span>
                    ) : (
                      <span style={{ color: "green", fontSize: "12px" }}>
                        {customerTotal !== undefined &&
                          customerTotal.length !== 0 &&
                          (customerTotal[0].PM_TY_VS_LY === "-999999"
                            ? "-"
                            : `LY +${Number(
                                customerTotal[0].PM_TY_VS_LY
                              ).toFixed(2)}%`)}
                      </span>
                    )}
                    <br />
                    {customerTotal !== undefined &&
                    customerTotal.length !== 0 &&
                    Number(customerTotal[0].PM_TY_VS_LLY)
                      .toFixed(2)
                      .includes("-") ? (
                      <span style={{ color: "red", fontSize: "11px" }}>
                        {customerTotal !== undefined &&
                          customerTotal.length !== 0 &&
                          (customerTotal[0].PM_TY_VS_LLY === "-999999"
                            ? "-"
                            : `LLY ${Number(
                                customerTotal[0].PM_TY_VS_LLY
                              ).toFixed(2)}%`)}
                      </span>
                    ) : (
                      <span style={{ color: "green", fontSize: "11px" }}>
                        {customerTotal !== undefined &&
                          customerTotal.length !== 0 &&
                          (customerTotal[0].PM_TY_VS_LLY === "-999999"
                            ? "-"
                            : `LLY +${Number(
                                customerTotal[0].PM_TY_VS_LLY
                              ).toFixed(2)}%`)}
                      </span>
                    )}
                  </th>
                  <th>
                    {customerTotal !== undefined &&
                      customerTotal.length !== 0 &&
                      (customerTotal[0].AOV_TY === "-999999"
                        ? "-"
                        : "$" + Number(customerTotal[0].AOV_TY).toFixed(2))}
                    <br />
                    {customerTotal !== undefined &&
                    customerTotal.length !== 0 &&
                    Number(customerTotal[0].AOV_TY_VS_LY)
                      .toFixed(2)
                      .includes("-") ? (
                      <span style={{ color: "red", fontSize: "12px" }}>
                        {customerTotal !== undefined &&
                          customerTotal.length !== 0 &&
                          (customerTotal[0].AOV_TY_VS_LY === "-999999"
                            ? "-"
                            : `LY ${Number(
                                customerTotal[0].AOV_TY_VS_LY
                              ).toFixed(2)}%`)}
                      </span>
                    ) : (
                      <span style={{ color: "green", fontSize: "12px" }}>
                        {customerTotal !== undefined &&
                          customerTotal.length !== 0 &&
                          (customerTotal[0].AOV_TY_VS_LY === "-999999"
                            ? "-"
                            : `LY +${Number(
                                customerTotal[0].AOV_TY_VS_LY
                              ).toFixed(2)}%`)}
                      </span>
                    )}
                    <br />
                    {customerTotal !== undefined &&
                    customerTotal.length !== 0 &&
                    Number(customerTotal[0].AOV_TY_VS_LLY)
                      .toFixed(2)
                      .includes("-") ? (
                      <span style={{ color: "red", fontSize: "11px" }}>
                        {customerTotal !== undefined &&
                          customerTotal.length !== 0 &&
                          (customerTotal[0].AOV_TY_VS_LLY === "-999999"
                            ? "-"
                            : `LLY ${Number(
                                customerTotal[0].AOV_TY_VS_LLY
                              ).toFixed(2)}%`)}
                      </span>
                    ) : (
                      <span style={{ color: "green", fontSize: "11px" }}>
                        {customerTotal !== undefined &&
                          customerTotal.length !== 0 &&
                          (customerTotal[0].AOV_TY_VS_LLY === "-999999"
                            ? "-"
                            : `LLY +${Number(
                                customerTotal[0].AOV_TY_VS_LLY
                              ).toFixed(2)}%`)}
                      </span>
                    )}
                  </th>
                  <th>
                    {customerTotal !== undefined &&
                      customerTotal.length !== 0 &&
                      (customerTotal[0].UPT_TY === "-999999"
                        ? "-"
                        : Number(customerTotal[0].UPT_TY).toFixed(1))}
                    <br />
                    {customerTotal !== undefined &&
                    customerTotal.length !== 0 &&
                    Number(customerTotal[0].UPT_TY_VS_LY)
                      .toFixed(2)
                      .includes("-") ? (
                      <span style={{ color: "red", fontSize: "12px" }}>
                        {customerTotal !== undefined &&
                          customerTotal.length !== 0 &&
                          (customerTotal[0].UPT_TY_VS_LY === "-999999"
                            ? "-"
                            : `LY ${Number(
                                customerTotal[0].UPT_TY_VS_LY
                              ).toFixed(2)}%`)}
                      </span>
                    ) : (
                      <span style={{ color: "green", fontSize: "12px" }}>
                        {customerTotal !== undefined &&
                          customerTotal.length !== 0 &&
                          (customerTotal[0].UPT_TY_VS_LY === "-999999"
                            ? "-"
                            : `LY +${Number(
                                customerTotal[0].UPT_TY_VS_LY
                              ).toFixed(2)}%`)}
                      </span>
                    )}
                    <br />
                    {customerTotal !== undefined &&
                    customerTotal.length !== 0 &&
                    Number(customerTotal[0].UPT_TY_VS_LLY)
                      .toFixed(2)
                      .includes("-") ? (
                      <span style={{ color: "red", fontSize: "11px" }}>
                        {customerTotal !== undefined &&
                          customerTotal.length !== 0 &&
                          (customerTotal[0].UPT_TY_VS_LLY === "-999999"
                            ? "-"
                            : `LLY ${Number(
                                customerTotal[0].UPT_TY_VS_LLY
                              ).toFixed(2)}%`)}
                      </span>
                    ) : (
                      <span style={{ color: "green", fontSize: "11px" }}>
                        {customerTotal !== undefined &&
                          customerTotal.length !== 0 &&
                          (customerTotal[0].UPT_TY_VS_LLY === "-999999"
                            ? "-"
                            : `LLY +${Number(
                                customerTotal[0].UPT_TY_VS_LLY
                              ).toFixed(2)}%`)}
                      </span>
                    )}
                  </th>
                  <th>
                    {customerTotal !== undefined &&
                      customerTotal.length !== 0 &&
                      (customerTotal[0].AUR_TY === "-999999"
                        ? "-"
                        : "$" + Number(customerTotal[0].AUR_TY).toFixed(2))}
                    <br />
                    {customerTotal !== undefined &&
                    customerTotal.length !== 0 &&
                    Number(customerTotal[0].AUR_TY_VS_LY)
                      .toFixed(2)
                      .includes("-") ? (
                      <span style={{ color: "red", fontSize: "12px" }}>
                        {customerTotal !== undefined &&
                          customerTotal.length !== 0 &&
                          (customerTotal[0].AUR_TY_VS_LY === "-999999"
                            ? "-"
                            : `LY ${Number(
                                customerTotal[0].AUR_TY_VS_LY
                              ).toFixed(2)}%`)}
                      </span>
                    ) : (
                      <span style={{ color: "green", fontSize: "12px" }}>
                        {customerTotal !== undefined &&
                          customerTotal.length !== 0 &&
                          (customerTotal[0].AUR_TY_VS_LY === "-999999"
                            ? "-"
                            : `LY +${Number(
                                customerTotal[0].AUR_TY_VS_LY
                              ).toFixed(2)}%`)}
                      </span>
                    )}
                    <br />
                    {customerTotal !== undefined &&
                    customerTotal.length !== 0 &&
                    Number(customerTotal[0].AUR_TY_VS_LLY)
                      .toFixed(2)
                      .includes("-") ? (
                      <span style={{ color: "red", fontSize: "11px" }}>
                        {customerTotal !== undefined &&
                          customerTotal.length !== 0 &&
                          (customerTotal[0].AUR_TY_VS_LLY === "-999999"
                            ? "-"
                            : `LLY ${Number(
                                customerTotal[0].AUR_TY_VS_LLY
                              ).toFixed(2)}%`)}
                      </span>
                    ) : (
                      <span style={{ color: "green", fontSize: "11px" }}>
                        {customerTotal !== undefined &&
                          customerTotal.length !== 0 &&
                          (customerTotal[0].AUR_TY_VS_LLY === "-999999"
                            ? "-"
                            : `LLY +${Number(
                                customerTotal[0].AUR_TY_VS_LLY
                              ).toFixed(2)}%`)}
                      </span>
                    )}
                  </th>
                  <th>
                    {customerTotal !== undefined &&
                      customerTotal.length !== 0 &&
                      (customerTotal[0].MARGIN_RATE_PER_TY === "-999999"
                        ? "-"
                        : Number(customerTotal[0].MARGIN_RATE_PER_TY).toFixed(
                            2
                          ))}
                    <br />
                    {customerTotal !== undefined &&
                    customerTotal.length !== 0 &&
                    Number(customerTotal[0].MARGIN_RATE_PER_TY_VS_LY)
                      .toFixed(2)
                      .includes("-") ? (
                      <span style={{ color: "red", fontSize: "12px" }}>
                        {customerTotal !== undefined &&
                          customerTotal.length !== 0 &&
                          (customerTotal[0].MARGIN_RATE_PER_TY_VS_LY ===
                          "-999999"
                            ? "-"
                            : `LY ${Number(
                                customerTotal[0].MARGIN_RATE_PER_TY_VS_LY
                              ).toFixed(2)}%`)}
                      </span>
                    ) : (
                      <span style={{ color: "green", fontSize: "12px" }}>
                        {customerTotal !== undefined &&
                          customerTotal.length !== 0 &&
                          (customerTotal[0].MARGIN_RATE_PER_TY_VS_LY ===
                          "-999999"
                            ? "-"
                            : `LY +${Number(
                                customerTotal[0].MARGIN_RATE_PER_TY_VS_LY
                              ).toFixed(2)}%`)}
                      </span>
                    )}
                    <br />
                    {customerTotal !== undefined &&
                    customerTotal.length !== 0 &&
                    Number(customerTotal[0].MARGIN_RATE_PER_TY_VS_LLY)
                      .toFixed(2)
                      .includes("-") ? (
                      <span style={{ color: "red", fontSize: "11px" }}>
                        {customerTotal !== undefined &&
                          customerTotal.length !== 0 &&
                          (customerTotal[0].MARGIN_RATE_PER_TY_VS_LLY ===
                          "-999999"
                            ? "-"
                            : `LLY ${Number(
                                customerTotal[0].MARGIN_RATE_PER_TY_VS_LLY
                              ).toFixed(2)}%`)}
                      </span>
                    ) : (
                      <span style={{ color: "green", fontSize: "11px" }}>
                        {customerTotal !== undefined &&
                          customerTotal.length !== 0 &&
                          (customerTotal[0].MARGIN_RATE_PER_TY_VS_LLY ===
                          "-999999"
                            ? "-"
                            : `LLY +${Number(
                                customerTotal[0].MARGIN_RATE_PER_TY_VS_LLY
                              ).toFixed(2)}%`)}
                      </span>
                    )}
                  </th>
                  <th>
                    {customerTotal !== undefined &&
                      customerTotal.length !== 0 &&
                      (customerTotal[0].NET_SALES_PER_CUST_TY === "-999999"
                        ? "-"
                        : "$" +
                          Number(
                            customerTotal[0].NET_SALES_PER_CUST_TY
                          ).toFixed(2))}
                    <br />
                    {customerTotal !== undefined &&
                    customerTotal.length !== 0 &&
                    Number(customerTotal[0].NET_SALES_PER_CUST_TY_VS_LY)
                      .toFixed(2)
                      .includes("-") ? (
                      <span style={{ color: "red", fontSize: "12px" }}>
                        {customerTotal !== undefined &&
                          customerTotal.length !== 0 &&
                          (customerTotal[0].NET_SALES_PER_CUST_TY_VS_LY ===
                          "-999999"
                            ? "-"
                            : `LY ${Number(
                                customerTotal[0].NET_SALES_PER_CUST_TY_VS_LY
                              ).toFixed(2)}%`)}
                      </span>
                    ) : (
                      <span style={{ color: "green", fontSize: "12px" }}>
                        {customerTotal !== undefined &&
                          customerTotal.length !== 0 &&
                          (customerTotal[0].NET_SALES_PER_CUST_TY_VS_LY ===
                          "-999999"
                            ? "-"
                            : `LY +${Number(
                                customerTotal[0].NET_SALES_PER_CUST_TY_VS_LY
                              ).toFixed(2)}%`)}
                      </span>
                    )}
                    <br />
                    {customerTotal !== undefined &&
                    customerTotal.length !== 0 &&
                    Number(customerTotal[0].NET_SALES_PER_CUST_TY_VS_LLY)
                      .toFixed(2)
                      .includes("-") ? (
                      <span style={{ color: "red", fontSize: "11px" }}>
                        {customerTotal !== undefined &&
                          customerTotal.length !== 0 &&
                          (customerTotal[0].NET_SALES_PER_CUST_TY_VS_LLY ===
                          "-999999"
                            ? "-"
                            : `LLY ${Number(
                                customerTotal[0].NET_SALES_PER_CUST_TY_VS_LLY
                              ).toFixed(2)}%`)}
                      </span>
                    ) : (
                      <span style={{ color: "green", fontSize: "11px" }}>
                        {customerTotal !== undefined &&
                          customerTotal.length !== 0 &&
                          (customerTotal[0].NET_SALES_PER_CUST_TY_VS_LLY ===
                          "-999999"
                            ? "-"
                            : `LLY +${Number(
                                customerTotal[0].NET_SALES_PER_CUST_TY_VS_LLY
                              ).toFixed(2)}%`)}
                      </span>
                    )}
                  </th>
                  <th>
                    {customerTotal !== undefined &&
                      customerTotal.length !== 0 &&
                      (customerTotal[0].AVG_TRAN_TY === "-999999"
                        ? "-"
                        : Number(customerTotal[0].AVG_TRAN_TY).toFixed(2))}
                    <br />
                    {customerTotal !== undefined &&
                    customerTotal.length !== 0 &&
                    Number(customerTotal[0].AVG_TRAN_TY_VS_LY)
                      .toFixed(2)
                      .includes("-") ? (
                      <span style={{ color: "red", fontSize: "12px" }}>
                        {customerTotal !== undefined &&
                          customerTotal.length !== 0 &&
                          (customerTotal[0].AVG_TRAN_TY_VS_LY === "-999999"
                            ? "-"
                            : `LY ${Number(
                                customerTotal[0].AVG_TRAN_TY_VS_LY
                              ).toFixed(2)}%`)}
                      </span>
                    ) : (
                      <span style={{ color: "green", fontSize: "12px" }}>
                        {customerTotal !== undefined &&
                          customerTotal.length !== 0 &&
                          (customerTotal[0].AVG_TRAN_TY_VS_LY === "-999999"
                            ? "-"
                            : `LY +${Number(
                                customerTotal[0].AVG_TRAN_TY_VS_LY
                              ).toFixed(2)}%`)}
                      </span>
                    )}
                    <br />
                    {customerTotal !== undefined &&
                    customerTotal.length !== 0 &&
                    Number(customerTotal[0].AVG_TRAN_TY_VS_LLY)
                      .toFixed(2)
                      .includes("-") ? (
                      <span style={{ color: "red", fontSize: "11px" }}>
                        {customerTotal !== undefined &&
                          customerTotal.length !== 0 &&
                          (customerTotal[0].AVG_TRAN_TY_VS_LLY === "-999999"
                            ? "-"
                            : `LLY ${Number(
                                customerTotal[0].AVG_TRAN_TY_VS_LLY
                              ).toFixed(2)}%`)}
                      </span>
                    ) : (
                      <span style={{ color: "green", fontSize: "11px" }}>
                        {customerTotal !== undefined &&
                          customerTotal.length !== 0 &&
                          (customerTotal[0].AVG_TRAN_TY_VS_LLY === "-999999"
                            ? "-"
                            : `LLY +${Number(
                                customerTotal[0].AVG_TRAN_TY_VS_LLY
                              ).toFixed(2)}%`)}
                      </span>
                    )}
                  </th>
                </>
              )}
            </tr>
          </tbody>
        </Table>
      </div>
    </div>
  );
}

export default CdhHome;
