import React from 'react'
import {Table,Tab, Tabs} from 'react-bootstrap'
function AtRiskTable_9_12() {
  return (
    <div>
      <div
        className="d-flex justify-content-start p-3 align-items-center"
        style={{ fontSize: "20px", fontWeight: "bold" }}
      >
        {"At risk(9m-12m)"}
      </div>
      <Tabs className="pt-3" style={{ paddingLeft: "1rem" }}>
        <Tab eventKey="home" title="Marketing Channel"></Tab>
        <Tab eventKey="profile" title="Persona" disabled></Tab>
        <Tab eventKey="profile" title="Purchase Channel" disabled></Tab>
        <Tab eventKey="profile" title="Program" disabled></Tab>
        <Tab eventKey="contact" title="Loyalty" disabled></Tab>
        <Tab eventKey="profile" title="Coupon/Promo Users" disabled></Tab>
        <Tab eventKey="contact" title="CLV Buckets " disabled></Tab>
        <Tab eventKey="profile" title="State" disabled></Tab>
      </Tabs>
      <div className="p-3">
        <Table p-3 striped bordered hover size="sm">
          <thead>
            <tr>
              <th>Channels</th>
              <th>Customers</th>
              <th>Transactions</th>
              <th>Net Sales</th>
              <th>AUR</th>
              <th>UPT</th>
              <th>AOV</th>
              <th>Product Margin</th>
            </tr>
          </thead>
          <tbody>
            <tr>
              <th>{"DM"}</th>
              <th></th>
              <th></th>
              <th></th>
              <th></th>
              <th></th>
              <th></th>
              <th></th>
            </tr>
            <tr>
              <td className="tableCol">{"DM only"}</td>
              <td>
                {"136K"}
                <br />
                <span style={{ color: "green" }}>{"LY +23%"}</span>
                <br />
                <span style={{ color: "red" }}>{"LLY -3%"}</span>
              </td>
              <td>
                {"136K"}
                <br />
                <span style={{ color: "green" }}>{"LY +23%"}</span>
                <br />
                <span style={{ color: "red" }}>{"LLY -3%"}</span>
              </td>
              <td>
                {"136K"}
                <br />
                <span style={{ color: "green" }}>{"LY +23%"}</span>
                <br />
                <span style={{ color: "red" }}>{"LLY -3%"}</span>
              </td>
              <td>
                {"136K"}
                <br />
                <span style={{ color: "green" }}>{"LY +23%"}</span>
                <br />
                <span style={{ color: "red" }}>{"LLY -3%"}</span>
              </td>
              <td>
                {"136K"}
                <br />
                <span style={{ color: "green" }}>{"LY +23%"}</span>
                <br />
                <span style={{ color: "red" }}>{"LLY -3%"}</span>
              </td>
              <td>
                {"136K"}
                <br />
                <span style={{ color: "green" }}>{"LY +23%"}</span>
                <br />
                <span style={{ color: "red" }}>{"LLY -3%"}</span>
              </td>
              <td>
                {"136K"}
                <br />
                <span style={{ color: "green" }}>{"LY +23%"}</span>
                <br />
                <span style={{ color: "red" }}>{"LLY -3%"}</span>
              </td>
            </tr>
            <tr>
              <td className="tableCol">{"DM and EM"}</td>
              <td>
                {"136K"}
                <br />
                <span style={{ color: "green" }}>{"LY +23%"}</span>
                <br />
                <span style={{ color: "red" }}>{"LLY -3%"}</span>
              </td>
              <td>
                {"136K"}
                <br />
                <span style={{ color: "green" }}>{"LY +23%"}</span>
                <br />
                <span style={{ color: "red" }}>{"LLY -3%"}</span>
              </td>
              <td>
                {"136K"}
                <br />
                <span style={{ color: "green" }}>{"LY +23%"}</span>
                <br />
                <span style={{ color: "red" }}>{"LLY -3%"}</span>
              </td>
              <td>
                {"136K"}
                <br />
                <span style={{ color: "green" }}>{"LY +23%"}</span>
                <br />
                <span style={{ color: "red" }}>{"LLY -3%"}</span>
              </td>
              <td>
                {"136K"}
                <br />
                <span style={{ color: "green" }}>{"LY +23%"}</span>
                <br />
                <span style={{ color: "red" }}>{"LLY -3%"}</span>
              </td>
              <td>
                {"136K"}
                <br />
                <span style={{ color: "green" }}>{"LY +23%"}</span>
                <br />
                <span style={{ color: "red" }}>{"LLY -3%"}</span>
              </td>
              <td>
                {"136K"}
                <br />
                <span style={{ color: "green" }}>{"LY +23%"}</span>
                <br />
                <span style={{ color: "red" }}>{"LLY -3%"}</span>
              </td>
            </tr>
            <tr>
              <td className="tableCol">{"DM, EM and SMS"}</td>
              <td>
                {"136K"}
                <br />
                <span style={{ color: "green" }}>{"LY +23%"}</span>
                <br />
                <span style={{ color: "red" }}>{"LLY -3%"}</span>
              </td>
              <td>
                {"136K"}
                <br />
                <span style={{ color: "green" }}>{"LY +23%"}</span>
                <br />
                <span style={{ color: "red" }}>{"LLY -3%"}</span>
              </td>
              <td>
                {"136K"}
                <br />
                <span style={{ color: "green" }}>{"LY +23%"}</span>
                <br />
                <span style={{ color: "red" }}>{"LLY -3%"}</span>
              </td>
              <td>
                {"136K"}
                <br />
                <span style={{ color: "green" }}>{"LY +23%"}</span>
                <br />
                <span style={{ color: "red" }}>{"LLY -3%"}</span>
              </td>
              <td>
                {"136K"}
                <br />
                <span style={{ color: "green" }}>{"LY +23%"}</span>
                <br />
                <span style={{ color: "red" }}>{"LLY -3%"}</span>
              </td>
              <td>
                {"136K"}
                <br />
                <span style={{ color: "green" }}>{"LY +23%"}</span>
                <br />
                <span style={{ color: "red" }}>{"LLY -3%"}</span>
              </td>
              <td>
                {"136K"}
                <br />
                <span style={{ color: "green" }}>{"LY +23%"}</span>
                <br />
                <span style={{ color: "red" }}>{"LLY -3%"}</span>
              </td>
            </tr>
            <tr>
              <th>{"EM"}</th>
              <th></th>
              <th></th>
              <th></th>
              <th></th>
              <th></th>
              <th></th>
              <th></th>
            </tr>
            <tr>
              <td className="tableCol">{"EM only"}</td>
              <td>
                {"136K"}
                <br />
                <span style={{ color: "green" }}>{"LY +23%"}</span>
                <br />
                <span style={{ color: "red" }}>{"LLY -3%"}</span>
              </td>
              <td>
                {"136K"}
                <br />
                <span style={{ color: "green" }}>{"LY +23%"}</span>
                <br />
                <span style={{ color: "red" }}>{"LLY -3%"}</span>
              </td>
              <td>
                {"136K"}
                <br />
                <span style={{ color: "green" }}>{"LY +23%"}</span>
                <br />
                <span style={{ color: "red" }}>{"LLY -3%"}</span>
              </td>
              <td>
                {"136K"}
                <br />
                <span style={{ color: "green" }}>{"LY +23%"}</span>
                <br />
                <span style={{ color: "red" }}>{"LLY -3%"}</span>
              </td>
              <td>
                {"136K"}
                <br />
                <span style={{ color: "green" }}>{"LY +23%"}</span>
                <br />
                <span style={{ color: "red" }}>{"LLY -3%"}</span>
              </td>
              <td>
                {"136K"}
                <br />
                <span style={{ color: "green" }}>{"LY +23%"}</span>
                <br />
                <span style={{ color: "red" }}>{"LLY -3%"}</span>
              </td>
              <td>
                {"136K"}
                <br />
                <span style={{ color: "green" }}>{"LY +23%"}</span>
                <br />
                <span style={{ color: "red" }}>{"LLY -3%"}</span>
              </td>
            </tr>
            <tr>
              <td className="tableCol">{"DM and EM"}</td>
              <td>
                {"136K"}
                <br />
                <span style={{ color: "green" }}>{"LY +23%"}</span>
                <br />
                <span style={{ color: "red" }}>{"LLY -3%"}</span>
              </td>
              <td>
                {"136K"}
                <br />
                <span style={{ color: "green" }}>{"LY +23%"}</span>
                <br />
                <span style={{ color: "red" }}>{"LLY -3%"}</span>
              </td>
              <td>
                {"136K"}
                <br />
                <span style={{ color: "green" }}>{"LY +23%"}</span>
                <br />
                <span style={{ color: "red" }}>{"LLY -3%"}</span>
              </td>
              <td>
                {"136K"}
                <br />
                <span style={{ color: "green" }}>{"LY +23%"}</span>
                <br />
                <span style={{ color: "red" }}>{"LLY -3%"}</span>
              </td>
              <td>
                {"136K"}
                <br />
                <span style={{ color: "green" }}>{"LY +23%"}</span>
                <br />
                <span style={{ color: "red" }}>{"LLY -3%"}</span>
              </td>
              <td>
                {"136K"}
                <br />
                <span style={{ color: "green" }}>{"LY +23%"}</span>
                <br />
                <span style={{ color: "red" }}>{"LLY -3%"}</span>
              </td>
              <td>
                {"136K"}
                <br />
                <span style={{ color: "green" }}>{"LY +23%"}</span>
                <br />
                <span style={{ color: "red" }}>{"LLY -3%"}</span>
              </td>
            </tr>
            <tr>
              <td className="tableCol">{"DM, EM and SMS"}</td>
              <td>
                {"136K"}
                <br />
                <span style={{ color: "green" }}>{"LY +23%"}</span>
                <br />
                <span style={{ color: "red" }}>{"LLY -3%"}</span>
              </td>
              <td>
                {"136K"}
                <br />
                <span style={{ color: "green" }}>{"LY +23%"}</span>
                <br />
                <span style={{ color: "red" }}>{"LLY -3%"}</span>
              </td>
              <td>
                {"136K"}
                <br />
                <span style={{ color: "green" }}>{"LY +23%"}</span>
                <br />
                <span style={{ color: "red" }}>{"LLY -3%"}</span>
              </td>
              <td>
                {"136K"}
                <br />
                <span style={{ color: "green" }}>{"LY +23%"}</span>
                <br />
                <span style={{ color: "red" }}>{"LLY -3%"}</span>
              </td>
              <td>
                {"136K"}
                <br />
                <span style={{ color: "green" }}>{"LY +23%"}</span>
                <br />
                <span style={{ color: "red" }}>{"LLY -3%"}</span>
              </td>
              <td>
                {"136K"}
                <br />
                <span style={{ color: "green" }}>{"LY +23%"}</span>
                <br />
                <span style={{ color: "red" }}>{"LLY -3%"}</span>
              </td>
              <td>
                {"136K"}
                <br />
                <span style={{ color: "green" }}>{"LY +23%"}</span>
                <br />
                <span style={{ color: "red" }}>{"LLY -3%"}</span>
              </td>
            </tr>
            <tr>
              <th>{"SMS"}</th>
              <th></th>
              <th></th>
              <th></th>
              <th></th>
              <th></th>
              <th></th>
              <th></th>
            </tr>
            <tr>
              <td className="tableCol">{"SMS only"}</td>
              <td>
                {"136K"}
                <br />
                <span style={{ color: "green" }}>{"LY +23%"}</span>
                <br />
                <span style={{ color: "red" }}>{"LLY -3%"}</span>
              </td>
              <td>
                {"136K"}
                <br />
                <span style={{ color: "green" }}>{"LY +23%"}</span>
                <br />
                <span style={{ color: "red" }}>{"LLY -3%"}</span>
              </td>
              <td>
                {"136K"}
                <br />
                <span style={{ color: "green" }}>{"LY +23%"}</span>
                <br />
                <span style={{ color: "red" }}>{"LLY -3%"}</span>
              </td>
              <td>
                {"136K"}
                <br />
                <span style={{ color: "green" }}>{"LY +23%"}</span>
                <br />
                <span style={{ color: "red" }}>{"LLY -3%"}</span>
              </td>
              <td>
                {"136K"}
                <br />
                <span style={{ color: "green" }}>{"LY +23%"}</span>
                <br />
                <span style={{ color: "red" }}>{"LLY -3%"}</span>
              </td>
              <td>
                {"136K"}
                <br />
                <span style={{ color: "green" }}>{"LY +23%"}</span>
                <br />
                <span style={{ color: "red" }}>{"LLY -3%"}</span>
              </td>
              <td>
                {"136K"}
                <br />
                <span style={{ color: "green" }}>{"LY +23%"}</span>
                <br />
                <span style={{ color: "red" }}>{"LLY -3%"}</span>
              </td>
            </tr>
            <tr>
              <td className="tableCol">{"SMS and DM"}</td>
              <td>
                {"136K"}
                <br />
                <span style={{ color: "green" }}>{"LY +23%"}</span>
                <br />
                <span style={{ color: "red" }}>{"LLY -3%"}</span>
              </td>
              <td>
                {"136K"}
                <br />
                <span style={{ color: "green" }}>{"LY +23%"}</span>
                <br />
                <span style={{ color: "red" }}>{"LLY -3%"}</span>
              </td>
              <td>
                {"136K"}
                <br />
                <span style={{ color: "green" }}>{"LY +23%"}</span>
                <br />
                <span style={{ color: "red" }}>{"LLY -3%"}</span>
              </td>
              <td>
                {"136K"}
                <br />
                <span style={{ color: "green" }}>{"LY +23%"}</span>
                <br />
                <span style={{ color: "red" }}>{"LLY -3%"}</span>
              </td>
              <td>
                {"136K"}
                <br />
                <span style={{ color: "green" }}>{"LY +23%"}</span>
                <br />
                <span style={{ color: "red" }}>{"LLY -3%"}</span>
              </td>
              <td>
                {"136K"}
                <br />
                <span style={{ color: "green" }}>{"LY +23%"}</span>
                <br />
                <span style={{ color: "red" }}>{"LLY -3%"}</span>
              </td>
              <td>
                {"136K"}
                <br />
                <span style={{ color: "green" }}>{"LY +23%"}</span>
                <br />
                <span style={{ color: "red" }}>{"LLY -3%"}</span>
              </td>
            </tr>
            <tr>
              <td className="tableCol">{"DM, EM and SMS"}</td>
              <td>
                {"136K"}
                <br />
                <span style={{ color: "green" }}>{"LY +23%"}</span>
                <br />
                <span style={{ color: "red" }}>{"LLY -3%"}</span>
              </td>
              <td>
                {"136K"}
                <br />
                <span style={{ color: "green" }}>{"LY +23%"}</span>
                <br />
                <span style={{ color: "red" }}>{"LLY -3%"}</span>
              </td>
              <td>
                {"136K"}
                <br />
                <span style={{ color: "green" }}>{"LY +23%"}</span>
                <br />
                <span style={{ color: "red" }}>{"LLY -3%"}</span>
              </td>
              <td>
                {"136K"}
                <br />
                <span style={{ color: "green" }}>{"LY +23%"}</span>
                <br />
                <span style={{ color: "red" }}>{"LLY -3%"}</span>
              </td>
              <td>
                {"136K"}
                <br />
                <span style={{ color: "green" }}>{"LY +23%"}</span>
                <br />
                <span style={{ color: "red" }}>{"LLY -3%"}</span>
              </td>
              <td>
                {"136K"}
                <br />
                <span style={{ color: "green" }}>{"LY +23%"}</span>
                <br />
                <span style={{ color: "red" }}>{"LLY -3%"}</span>
              </td>
              <td>
                {"136K"}
                <br />
                <span style={{ color: "green" }}>{"LY +23%"}</span>
                <br />
                <span style={{ color: "red" }}>{"LLY -3%"}</span>
              </td>
            </tr>
          </tbody>
        </Table>
      </div>
    </div>
  );
}

export default AtRiskTable_9_12
