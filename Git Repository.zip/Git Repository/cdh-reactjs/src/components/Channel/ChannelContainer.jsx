import React, { useState, useEffect, useCallback } from "react";
import { useSelector, useDispatch } from "react-redux";
import { Dropdown, Form, Placeholder } from "react-bootstrap";
import DatePicker from "react-datetime";
import moment from "moment";
import axios from "axios";
import ChannelHome from "./ChannelHome";
import "../HomePage/HomePage.css";
import { handleChannelDateChange } from "../../Redux/Actions/DateChangeActions";
import { handleChannelBannerChange } from "../../Redux/Actions/BannerChangeActions";
import {
  handleChannelCategoryChange,
  handleChannelCustChange,
} from "../../Redux/Actions/CategoryChangeActions";
import calender from "../../assests/images/calender.svg";
import { getDateFormat, getDateMinusTwoYear } from "../Utils";
import { UTCtoEST } from "../Utils";
import NotificationMessage from "../NotificationMessage/NotificationMessage";
import NoAccess from "../NoAccess/NoAccess";

const ChannelBanners = [
  { value: "All Banner", id: "0" },
  { value: "BBBY US", id: "1" },
  { value: "BBBY CA", id: "2" },
  { value: "buy buy Baby", id: "3" },
  { value: "Harmon", id: "5" },
];

const ChannelCategory = [
  { value: "All Customers", id: "ALL" },
  { value: "Beyond+", id: "BPLUS" },
  { value: "Credit Card", id: "CC" },
  { value: "Beyond+ & Credit Card", id: "BC" },
  { value: "App", id: "APP" },
];

function ChannelContainer() {
  const dispatch = useDispatch();
  let dateObjforMax = new Date();
  dateObjforMax.setUTCDate(dateObjforMax.getUTCDate() - 2);
  let Maxday = dateObjforMax.getUTCDate();
  let Maxyear = dateObjforMax.getUTCFullYear();
  let Maxmonth = dateObjforMax.getUTCMonth() + 1; //months from 1-12
  let MaxDayforPicker =
    Maxyear +
    "-" +
    (Maxmonth < 10 ? `0${Maxmonth}` : Maxmonth) +
    "-" +
    (Maxday < 10 ? `0${Maxday}` : Maxday);

  const [selectedChannelBanner, setSelectedChannelBanner] = useState(
    ChannelBanners[0]
  );
  const [selectedChannelCategory, setSelectedChannelCategory] = useState(
    ChannelCategory[0]
  );
  const [customerChannelActiveData, setCustomerChannelActiveData] = useState();
  const [customerChannelActiveExisting, setCustomerChannelActiveExisting] =
    useState();
  const [customerChannelDataSixMonths, setCustomerChannelDataSixMonths] =
    useState();
  const [customerChannelDataNineMonths, setCustomerChannelDataNineMonths] =
    useState();
  const [
    firstCustomerChannelFourTotalData,
    setCustomerChanneFirst_Four_Total_Data,
  ] = useState();
  const [
    customerChannelInActive_12_18_Data,
    setCustomerChannelInActive_12_18_Data,
  ] = useState();
  const [
    customerChannelInActive_18_24_Data,
    setCustomerChannelInActive_18_24_Data,
  ] = useState();
  const [
    secondCustomerChannelhalftotalData,
    setCustomerChannelSecond_half_total_Data,
  ] = useState();
  const [customerChannelTotal, setChannelTotal] = useState();
  const [channelRecordAvailableDates, setChannelRecordAvailableDates] =
    useState();
  const [periodStartDate, setPeriodStartDate] = useState("");
  const [periodEndDate, setPeriodEndDate] = useState("");
  const [refreshTime, setRefreshTime] = useState("");

  const refreshDate =
    refreshTime.length > 0 && UTCtoEST(refreshTime[0].end_time * 1000);

  const [loading, setloader] = useState({
    AtRisk_6m_9m: false,
    AtRisk_9m_12m: false,
    Active_Existing: false,
    Active_L12m: false,
    Inactive_12m_18m: false,
    Inactive_18m_24m: false,
    UnIdentifed_Customers: false,
    first_half_total: false,
    second_half_total: false,
    total: false,
    first_Four_Total: false,
    Inactive_24mp: false,
    record_dates: false,
    refreshTime: false,
  });
  const [chkBox, isChkBox] = useState({
    isAllCust: true,
    isBPlus: false,
    isOnline: true,
    isStore: false,
    isMulti: false,
  });
  const selectedChannelBannerId = useSelector(
    (store) => store.ChannelBanner.id
  );
  const selectedChannelCategoryId = useSelector(
    (store) => store.ChannelCategory.id
  );
  const selectedChannelDate = useSelector((store) => store.ChannelDate.value);

  const selectedChannelCustId = useSelector((store) => store.ChannelCust.id);

  const [defaultDate, setDefaultDate] = useState(moment().subtract(2, "days"));

  if (selectedChannelCategoryId === "ONLINE") {
    chkBox.isOnline = true;
  }

  const handleChannelBanner = useCallback(
    (event) => {
      setSelectedChannelBanner((prevsValue) => ({
        ...prevsValue,
        value: event.target.innerText,
        id: event.target.id,
      }));
      dispatch(
        handleChannelBannerChange({
          value: event.target.innerText,
          id: event.target.id,
        })
      );
    },
    [selectedChannelBannerId]
  );

  const handleChannelCategory = useCallback(
    (event) => {
      if (event.target.id === "BPLUS" || event.target.id === "BC") {
        setSelectedChannelBanner({ value: "BBBY US", id: "1" });
        setSelectedChannelCategory((prevsValue) => ({
          ...prevsValue,
          value: event.target.innerText,
          id: event.target.id,
        }));
        dispatch(
          handleChannelCustChange({
            value: event.target.innerText,
            id: event.target.id,
          })
        );
        dispatch(handleChannelBannerChange({ value: "BBBY US", id: "1" }));
      } else {
        setSelectedChannelCategory((prevsValue) => ({
          ...prevsValue,
          value: event.target.innerText,
          id: event.target.id,
        }));
        dispatch(
          handleChannelCustChange({
            value: event.target.innerText,
            id: event.target.id,
          })
        );
      }
    },
    [selectedChannelCategoryId]
  );

  // const handleChannelDate = (event) => {
  //   dispatch(handleChannelDateChange(event));
  // };

  const handleChannelDate = (dateSelected) => {
    setPeriodStartDate(getDateMinusTwoYear(dateSelected));
    setPeriodEndDate(moment(dateSelected));
    if (moment(dateSelected, "MM/DD/YYYY", true).isValid()) {
      setDefaultDate();
      dispatch(handleChannelDateChange(dateSelected.format("YYYY-MM-DD")));
    } else {
      setDefaultDate(moment().subtract(2, "days"));
    }
  };

  const onChangeCheck = useCallback(
    (e) => {
      if (e.target.value === "ONLINE") {
        isChkBox((value) => ({
          ...value,
          isOnline: !chkBox.isOnline,
        }));
        if (e.target.checked) {
          dispatch(
            handleChannelCategoryChange({
              value:
                chkBox.isStore && chkBox.isMulti
                  ? "ONLINE_STORE_MULTI"
                  : chkBox.isMulti
                  ? "ONLINE_MULTI"
                  : chkBox.isStore
                  ? "ONLINE_STORE"
                  : e.target.id,
              id:
                chkBox.isStore && chkBox.isMulti
                  ? "ONLINE_STORE_MULTI"
                  : chkBox.isMulti
                  ? "ONLINE_MULTI"
                  : chkBox.isStore
                  ? "ONLINE_STORE"
                  : e.target.value,
            })
          );
        } else {
          dispatch(
            handleChannelCategoryChange({
              value:
                chkBox.isStore && chkBox.isMulti
                  ? "STORE_MULTI"
                  : chkBox.isMulti
                  ? "MULTI"
                  : chkBox.isStore
                  ? "STORE"
                  : "ONLINE",
              id:
                chkBox.isStore && chkBox.isMulti
                  ? "STORE_MULTI"
                  : chkBox.isMulti
                  ? "MULTI"
                  : chkBox.isStore
                  ? "STORE"
                  : "ONLINE",
            })
          );
        }
      } else if (e.target.value === "STORE") {
        isChkBox((value) => ({
          ...value,
          isStore: !chkBox.isStore,
        }));
        if (e.target.checked) {
          dispatch(
            handleChannelCategoryChange({
              value:
                chkBox.isOnline && chkBox.isMulti
                  ? "ONLINE_STORE_MULTI"
                  : chkBox.isMulti
                  ? "STORE_MULTI"
                  : chkBox.isOnline
                  ? "ONLINE_STORE"
                  : e.target.id,
              id:
                chkBox.isOnline && chkBox.isMulti
                  ? "ONLINE_STORE_MULTI"
                  : chkBox.isMulti
                  ? "STORE_MULTI"
                  : chkBox.isOnline
                  ? "ONLINE_STORE"
                  : e.target.value,
            })
          );
        } else {
          dispatch(
            handleChannelCategoryChange({
              value:
                chkBox.isOnline && chkBox.isMulti
                  ? "ONLINE_MULTI"
                  : chkBox.isMulti
                  ? "MULTI"
                  : chkBox.isOnline
                  ? "ONLINE"
                  : "ONLINE",
              id:
                chkBox.isOnline && chkBox.isMulti
                  ? "ONLINE_MULTI"
                  : chkBox.isMulti
                  ? "MULTI"
                  : chkBox.isOnline
                  ? "ONLINE"
                  : "ONLINE",
            })
          );
        }
      } else if (e.target.value === "MULTI") {
        // omni
        isChkBox((value) => ({
          ...value,
          isMulti: !chkBox.isMulti,
        }));
        if (e.target.checked) {
          dispatch(
            handleChannelCategoryChange({
              value:
                chkBox.isOnline && chkBox.isStore
                  ? "ONLINE_STORE_MULTI"
                  : chkBox.isStore
                  ? "STORE_MULTI"
                  : chkBox.isOnline
                  ? "ONLINE_MULTI"
                  : e.target.id,
              id:
                chkBox.isOnline && chkBox.isStore
                  ? "ONLINE_STORE_MULTI"
                  : chkBox.isStore
                  ? "STORE_MULTI"
                  : chkBox.isOnline
                  ? "ONLINE_MULTI"
                  : e.target.value,
            })
          );
        } else {
          dispatch(
            handleChannelCategoryChange({
              value:
                chkBox.isOnline && chkBox.isStore
                  ? "ONLINE_STORE"
                  : chkBox.isStore
                  ? "STORE"
                  : chkBox.isOnline
                  ? "ONLINE"
                  : "ONLINE",
              id:
                chkBox.isOnline && chkBox.isStore
                  ? "ONLINE_STORE"
                  : chkBox.isStore
                  ? "STORE"
                  : chkBox.isOnline
                  ? "ONLINE"
                  : "ONLINE",
            })
          );
        }
      }
      // else if (e.target.value === "ALL") {
      //   isChkBox((value) => ({
      //     ...value,
      //     isAllCust: true,
      //     isBPlus: false,
      //   }));
      //   dispatch(
      //     handleChannelCustChange({
      //       value: e.target.id,
      //       id: e.target.value,
      //     })
      //   );
      // } else if (e.target.value === "BPLUS") {
      //   isChkBox((value) => ({
      //     ...value,
      //     isAllCust: false,
      //     isBPlus: true,
      //   }));
      //   dispatch(
      //     handleChannelCustChange({
      //       value: e.target.id,
      //       id: e.target.value,
      //     })
      //   );
      //   setSelectedChannelBanner({ value: "BBBY US", id: "1" });
      //   dispatch(handleChannelBannerChange({ value: "BBBY US", id: "1" }));
      // }
    },
    [selectedChannelCategoryId, selectedChannelCustId]
  );

  useEffect(() => {
    setPeriodStartDate(getDateMinusTwoYear(defaultDate));
    setPeriodEndDate(moment(defaultDate));
  }, []);

  useEffect(() => {
    const getChannelRecordAvailableDates = async () => {
      try {
        setloader((currValue) => ({
          ...currValue,
          record_dates: true,
        }));
        let url =
          process.env.REACT_APP_API_ENDPOINT +
          process.env.REACT_APP_RECORD_AVAILABLE_DATES +
          "concept=" +
          selectedChannelBannerId +
          "&channelType=" +
          selectedChannelCategoryId +
          "&customerType=" +
          selectedChannelCustId;
        await axios({ url }).then((res) => {
          setloader((currValue) => ({
            ...currValue,
            record_dates: false,
          }));
          setChannelRecordAvailableDates(res.data);
        });
      } catch (err) {
        console.log("err-getChannelRecordAvailableDates", err);
        setloader((currValue) => ({
          ...currValue,
          record_dates: false,
        }));
      }
    };

    getChannelRecordAvailableDates();
  }, [selectedChannelBannerId, selectedChannelCategoryId]);

  useEffect(() => {
    const fetchCustomerChannelDataActive = async () => {
      try {
        setloader((currValue) => ({
          ...currValue,
          channel_data: true,
        }));
        let url =
          process.env.REACT_APP_API_ENDPOINT +
          process.env.REACT_APP_CUSTOMER_Active +
          "concept=" +
          selectedChannelBannerId +
          "&date=" +
          selectedChannelDate +
          "&channelType=" +
          selectedChannelCategoryId +
          "&customerType=" +
          selectedChannelCustId;
        await axios({ url }).then((res) => {
          setCustomerChannelActiveData(res.data);
          setloader((currValue) => ({
            ...currValue,
            channel_data: false,
          }));
        });
      } catch (err) {
        console.log("err-fetchCustomerChannelDataActive", err);
        setloader((currValue) => ({
          ...currValue,
          channel_data: false,
        }));
      }
    };

    const fetchCustomerChannelDataActiveExisting = async () => {
      try {
        setloader((currValue) => ({
          ...currValue,
          Active_Existing: true,
        }));
        let url =
          process.env.REACT_APP_API_ENDPOINT +
          process.env.REACT_APP_CUSTOMER_Active_Existing +
          "concept=" +
          selectedChannelBannerId +
          "&date=" +
          selectedChannelDate +
          "&channelType=" +
          selectedChannelCategoryId +
          "&customerType=" +
          selectedChannelCustId;
        await axios({ url }).then((res) => {
          setCustomerChannelActiveExisting(res.data);
          setloader((currValue) => ({
            ...currValue,
            Active_Existing: false,
          }));
        });
      } catch (err) {
        console.log("err-fetchCustomerChannelDataActiveExisting", err);
        setloader((currValue) => ({
          ...currValue,
          Active_Existing: false,
        }));
      }
    };

    const fetchChannelCustomerDataSixMonths = async () => {
      try {
        setloader((currValue) => ({
          ...currValue,
          AtRisk_6m_9m: true,
        }));
        let url =
          process.env.REACT_APP_API_ENDPOINT +
          process.env.REACT_APP_CUSTOMER_6m_9m +
          "concept=" +
          selectedChannelBannerId +
          "&date=" +
          selectedChannelDate +
          "&channelType=" +
          selectedChannelCategoryId +
          "&customerType=" +
          selectedChannelCustId;
        await axios({ url }).then((res) => {
          setloader((currValue) => ({
            ...currValue,
            AtRisk_6m_9m: false,
          }));
          setCustomerChannelDataSixMonths(res.data);
        });
      } catch (err) {
        console.log("err-fetchChannelCustomerDataSixMonths", err);
        setloader((currValue) => ({
          ...currValue,
          AtRisk_6m_9m: false,
        }));
      }
    };

    const fetchChannelCustomerDataNineMonths = async () => {
      try {
        setloader((currValue) => ({
          ...currValue,
          AtRisk_9m_12m: true,
        }));
        let url =
          process.env.REACT_APP_API_ENDPOINT +
          process.env.REACT_APP_CUSTOMER_9m_12m +
          "concept=" +
          selectedChannelBannerId +
          "&date=" +
          selectedChannelDate +
          "&channelType=" +
          selectedChannelCategoryId +
          "&customerType=" +
          selectedChannelCustId;
        await axios({ url }).then((res) => {
          setCustomerChannelDataNineMonths(res.data);
          setloader((currValue) => ({
            ...currValue,
            AtRisk_9m_12m: false,
          }));
        });
      } catch (err) {
        console.log("err-fetchCustomerChannelDataNineMonths", err);
        setloader((currValue) => ({
          ...currValue,
          AtRisk_9m_12m: false,
        }));
      }
    };

    const fetchChannelfirstFourTotal = async () => {
      try {
        setloader((currValue) => ({
          ...currValue,
          first_half_total: true,
        }));
        let url =
          process.env.REACT_APP_API_ENDPOINT +
          process.env.REACT_APP_CUSTOMER_First_Four_Total +
          "concept=" +
          selectedChannelBannerId +
          "&date=" +
          selectedChannelDate +
          "&channelType=" +
          selectedChannelCategoryId +
          "&customerType=" +
          selectedChannelCustId;
        await axios({ url }).then((res) => {
          setCustomerChanneFirst_Four_Total_Data(res.data);
          setloader((currValue) => ({
            ...currValue,
            first_Four_Total: false,
          }));
        });
      } catch (err) {
        console.log("err-fetchChannelfirstFourTotal", err);
        setloader((currValue) => ({
          ...currValue,
          first_Four_Total: false,
        }));
      }
    };

    const fetchChannelCustomerDataInActive_12_18 = async () => {
      try {
        setloader((currValue) => ({
          ...currValue,
          Inactive_12m_18m: true,
        }));
        let url =
          process.env.REACT_APP_API_ENDPOINT +
          process.env.REACT_APP_CUSTOMER_InActive_12_18 +
          "concept=" +
          selectedChannelBannerId +
          "&date=" +
          selectedChannelDate +
          "&channelType=" +
          selectedChannelCategoryId +
          "&customerType=" +
          selectedChannelCustId;
        await axios({ url }).then((res) => {
          setCustomerChannelInActive_12_18_Data(res.data);
          setloader((currValue) => ({
            ...currValue,
            Inactive_12m_18m: false,
          }));
        });
      } catch (err) {
        console.log("err-fetchChannelCustomerDataInActive_12_18", err);
        setloader((currValue) => ({
          ...currValue,
          Inactive_12m_18m: false,
        }));
      }
    };

    const fetchChannelCustomerDataInActive_18_24 = async () => {
      try {
        setloader((currValue) => ({
          ...currValue,
          Inactive_18m_24m: true,
        }));
        let url =
          process.env.REACT_APP_API_ENDPOINT +
          process.env.REACT_APP_CUSTOMER_InActive_18_24 +
          "concept=" +
          selectedChannelBannerId +
          "&date=" +
          selectedChannelDate +
          "&channelType=" +
          selectedChannelCategoryId +
          "&customerType=" +
          selectedChannelCustId;
        await axios({ url }).then((res) => {
          setCustomerChannelInActive_18_24_Data(res.data);
          setloader((currValue) => ({
            ...currValue,
            Inactive_18m_24m: false,
          }));
        });
      } catch (err) {
        console.log("err-fetchChannelCustomerDataInActive_18_24", err);
        setloader((currValue) => ({
          ...currValue,
          Inactive_18m_24m: false,
        }));
      }
    };

    const fetchChannelTotalsecondHalf = async () => {
      try {
        setloader((currValue) => ({
          ...currValue,
          second_half_total: true,
        }));
        let url =
          process.env.REACT_APP_API_ENDPOINT +
          process.env.REACT_APP_CUSTOMER_Second_half_total +
          "concept=" +
          selectedChannelBannerId +
          "&date=" +
          selectedChannelDate +
          "&channelType=" +
          selectedChannelCategoryId +
          "&customerType=" +
          selectedChannelCustId;
        await axios({ url }).then((res) => {
          setCustomerChannelSecond_half_total_Data(res.data);
          setloader((currValue) => ({
            ...currValue,
            second_half_total: false,
          }));
        });
      } catch (err) {
        console.log("err-fetchChannelTotalsecondHalf", err);
        setloader((currValue) => ({
          ...currValue,
          second_half_total: false,
        }));
      }
    };

    const fetchCustomerChannelTotal = async () => {
      try {
        setloader((currValue) => ({
          ...currValue,
          total: true,
        }));
        let url =
          process.env.REACT_APP_API_ENDPOINT +
          process.env.REACT_APP_CUSTOMER_total +
          "concept=" +
          selectedChannelBannerId +
          "&date=" +
          selectedChannelDate +
          "&channelType=" +
          selectedChannelCategoryId +
          "&customerType=" +
          selectedChannelCustId;
        await axios({ url }).then((res) => {
          setChannelTotal(res.data);
          setloader((currValue) => ({
            ...currValue,
            total: false,
          }));
        });
      } catch (err) {
        console.log("err-fetchCustomerChannelTotal", err);
        setloader((currValue) => ({
          ...currValue,
          total: false,
        }));
      }
    };
    if (localStorage.getItem("isCHANNEL") === "Y") {
      fetchCustomerChannelDataActive();
      fetchCustomerChannelDataActiveExisting();
      fetchChannelCustomerDataSixMonths();
      fetchChannelCustomerDataNineMonths();
      fetchChannelfirstFourTotal();
      fetchChannelCustomerDataInActive_12_18();
      fetchChannelCustomerDataInActive_18_24();
      fetchChannelTotalsecondHalf();
      fetchCustomerChannelTotal();
    }
  }, [
    selectedChannelDate,
    selectedChannelBannerId,
    selectedChannelCategoryId,
    selectedChannelCustId,
  ]);

  let customDatess =
    channelRecordAvailableDates &&
    channelRecordAvailableDates.map((item) => {
      return item["TRANS_DATE"];
    });
  // const maxDay = moment().subtract(2, "days");
  const disableCustomDt = (current) => {
    return (
      customDatess && customDatess.includes(current.format("YYYY-MM-DD")) //&&
      //current.isBefore(maxDay) // &&
      // !current.isBefore(moment("2022-02-28").toDate())
    );
  };

  useEffect(() => {
    const getLastRefreshTime = async () => {
      try {
        setloader((currValue) => ({
          ...currValue,
          refreshTime: true,
        }));
        let url =
          process.env.REACT_APP_API_ENDPOINT +
          process.env.REACT_APP_REFRESH_TIME +
          "dagId=CHANNEL";
        await axios({ url }).then((res) => {
          setloader((currValue) => ({
            ...currValue,
            refreshTime: false,
          }));
          setRefreshTime(res.data);
        });
      } catch (err) {
        setloader((currValue) => ({
          ...currValue,
          refreshTime: true,
        }));
        console.log("err-getLastRefreshTime", err);
      }
    };
    getLastRefreshTime();
  }, []);

  return localStorage.getItem("isCHANNEL") === "Y" ? (
    <div>
      {refreshTime.length > 0 && <NotificationMessage message={refreshDate} />}
      <div className="mt-1 d-flex align-items-center headings">
        <div className="d-flex justify-content-start p-3">
          <span className="progselectupText">Concept</span>
        </div>
        <div className="d-flex justify-content-start p-3">
          <span className="progselectupText">Cust Type</span>
        </div>
        <div className="d-flex justify-content-start p-3">
          <span className="progselectupText"></span>
        </div>
        <div className="d-flex justify-content-start p-3">
          <span className="progselectupText">Channel Type</span>
        </div>
      </div>
      <div className="mt-3 d-flex align-items-center">
        <div className="d-flex justify-content-start p-3">
          <Dropdown className="d-inline">
            <Dropdown.Toggle>{selectedChannelBanner.value}</Dropdown.Toggle>
            <Dropdown.Menu
              className="dropdown-menu-ext"
              onClick={(e) => handleChannelBanner(e)}
            >
              {selectedChannelCustId === "BPLUS" ||
              selectedChannelCustId === "BC"
                ? ChannelBanners.filter((data) => {
                    return data.id === "1";
                  }).map((data) => {
                    return (
                      <Dropdown.Item
                        key={data.id}
                        className="dropdown-item-ext"
                        id={data.id}
                      >
                        {data.value}
                      </Dropdown.Item>
                    );
                  })
                : ChannelBanners.map((data) => {
                    return (
                      <Dropdown.Item
                        key={data.id}
                        className="dropdown-item-ext"
                        id={data.id}
                      >
                        {data.value}
                      </Dropdown.Item>
                    );
                  })}
            </Dropdown.Menu>
          </Dropdown>
        </div>
        <div className="d-flex justify-content-start p-3">
          <Dropdown className="d-inline">
            <Dropdown.Toggle>{selectedChannelCategory.value}</Dropdown.Toggle>
            <Dropdown.Menu
              className="dropdown-menu-ext"
              onClick={(e) => handleChannelCategory(e)}
            >
              {ChannelCategory.map((data) => {
                return (
                  <Dropdown.Item
                    key={data.id}
                    className="dropdown-item-ext"
                    id={data.id}
                  >
                    {data.value}
                  </Dropdown.Item>
                );
              })}
            </Dropdown.Menu>
          </Dropdown>
        </div>
        <div className="d-flex justify-content-start p-3">
          <label className="chkBox-label">
            <input
              type="checkbox"
              checked={chkBox.isOnline}
              onChange={onChangeCheck}
              value="ONLINE"
              id="ONLINE"
              className="chkBox"
            />{" "}
            Online only
          </label>
        </div>
        <div className="d-flex justify-content-start p-3">
          <label className="chkBox-label">
            <input
              type="checkbox"
              checked={chkBox.isStore}
              onChange={onChangeCheck}
              value="STORE"
              id="STORE"
              className="chkBox"
            />{" "}
            In store only
          </label>
        </div>
        <div className="d-flex justify-content-start p-3">
          <label className="chkBox-label">
            <input
              type="checkbox"
              checked={chkBox.isMulti}
              onChange={onChangeCheck}
              value="MULTI"
              id="MULTI"
              className="chkBox"
            />{" "}
            Omni
          </label>
        </div>
        {/* <div className="d-flex justify-content-start p-3">
          <Form.Group controlId="duedate">
            <Form.Control
              type="date"
              name="datePicker"
              placeholder="select a Date"
              value={selectedChannelDate}
              onChange={(e) => handleChannelDate(e.target.value)}
              max={MaxDayforPicker}
            />
          </Form.Group>
        </div> */}
        {loading.record_dates ? (
          <Placeholder.Button xs={1} />
        ) : (
          <div className="d-flex justify-content-start p-3">
            <label
              className="d-flex datepicker"
              onClick={(e) => e.preventDefault()}
            >
              <DatePicker
                timeFormat={false}
                value={
                  defaultDate
                    ? defaultDate
                    : moment(selectedChannelDate).format("MM/DD/YYYY")
                }
                isValidDate={disableCustomDt}
                onChange={(date) => handleChannelDate(date)}
                closeOnSelect
                inputProps={{ readOnly: true }}
              />
              <img src={calender} className="date-picker-icon" />
            </label>
          </div>
        )}
        <div
          className="d-flex justify-content-start p-3"
          style={{ marginLeft: "-6rem" }}
        >
          {!loading.record_dates && periodStartDate !== "" ? (
            <div>
              <span>{`(${getDateFormat(periodStartDate)} - ${getDateFormat(
                periodEndDate
              )})`}</span>
            </div>
          ) : (
            ""
          )}
        </div>
      </div>
      <ChannelHome
        loading={loading}
        customerChannelActiveData={customerChannelActiveData}
        customerChannelActiveExisting={customerChannelActiveExisting}
        customerChannelDataSixMonths={customerChannelDataSixMonths}
        customerChannelDataNineMonths={customerChannelDataNineMonths}
        firstCustomerChannelFourTotalData={firstCustomerChannelFourTotalData}
        customerChannelInActive_12_18_Data={customerChannelInActive_12_18_Data}
        customerChannelInActive_18_24_Data={customerChannelInActive_18_24_Data}
        secondCustomerChannelhalftotalData={secondCustomerChannelhalftotalData}
        customerChannelTotal={customerChannelTotal}
      />
    </div>
  ) : (
    <NoAccess tabName="Channel" />
  );
}

export default ChannelContainer;
