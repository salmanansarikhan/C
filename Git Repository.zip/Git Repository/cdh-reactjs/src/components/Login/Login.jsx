import React, { useState } from "react";
import { useHistory } from "react-router-dom";
import axios from "axios";
// import logo_BBB from '../../assests/images/logo_BBB.png';
import "./Login.css";
import { BsFillEyeFill, BsFillEyeSlashFill } from "react-icons/bs";
// import Countdown, { zeroPad } from 'react-countdown';
// import Alert from 'react-bootstrap/Alert';

const Login = () => {
  let history = useHistory();
  const [userName, setuserName] = useState();
  const [password, setpassword] = useState();
  const [ErrorMsg, setErrorMsg] = useState();
  const [isPasswordShown, setisPasswordShown] = useState();
  const [loading, setloading] = useState();

  const spinner = () => {
    setloading(true);
  };

  const togglePasswordVisibility = () => {
    // const { isPasswordShown } = stateValue;
    //this.setLoginState({ isPasswordShown: !isPasswordShown });
    //setisPasswordShown((PrevsValue) => !PrevsValue);
  };

  const handleChangeUserName = (event) => {
    setuserName(event.target.value);
    let data = {
      userName,
      password,
    };
    let ussy = data.userName;
    if (ussy === "") {
      setErrorMsg("Please Enter your BBID");
    }
  };
  const handleChangePass = (event) => {
    setpassword(event.target.value);
    let data = {
      userName,
      password,
    };
    let pssy = data.password;
    if (pssy === "") {
      setErrorMsg("Please Enter your Password");
    }
  };

  const handleSubmit = (event) => {
    setErrorMsg("");
    event.preventDefault();
    let data = {
      userName,
      password,
    };
    let axiosConfig = {
      headers: {
        "Content-Type": "application/json;charset=UTF-8",
        "Access-Control-Allow-Origin": "*",
        "Access-Control-Allow-Methods": "GET,PUT,POST,DELETE,PATCH,OPTIONS",
      },
    };

    const url =
      process.env.REACT_APP_API_ENDPOINT + process.env.REACT_APP_LOGIN;
    axios
      .post(url, data, axiosConfig)
      .then((response) => {
        setloading({ loading: true });
        const data = response.data;
        const loginDetails = data.fullName[0];
        localStorage.setItem("username", loginDetails);
        localStorage.setItem("userId", data.userId);

        localStorage.setItem("isOVERALL_HEALTH", data && data.overallhealth);
        //localStorage.setItem("isADMIN", "Y");
        localStorage.setItem("isCHANNEL", data && data.channel);
        localStorage.setItem(
          "isCUSTOMER_FEEDBACK",
          data && data.customerFeedback
        );
        localStorage.setItem("isDECILES", data && data.deciles);
        localStorage.setItem("isFUNNEL", data && data.funnel);
        localStorage.setItem("isLOYALTY", data && data.loyalty);
        localStorage.setItem("isMARKETING", data && data.marketing);
        localStorage.setItem("isPROGRAM", data && data.program);
        localStorage.setItem("isSCORECARD", data && data.scorecard);
        localStorage.setItem("isSTORES", data && data.stores);
        localStorage.setItem(
          "isCUSTOMERFILEHEALTH",
          data && data.customerFileHealth
        );
        //localStorage.setItem("isSUPER_ADMIN", "N");

        setloading((currValue) => false);
        if (data.statusCode === "200") {
          if (localStorage.getItem("isOVERALL_HEALTH") === "Y")
            history.push("/cdh/home");
          else if (localStorage.getItem("isSCORECARD") === "Y")
            history.push("/cdh/scorecard");
          else if (localStorage.getItem("isDECILES") === "Y")
            history.push("/cdh/deciles");
          else if (localStorage.getItem("isCHANNEL") === "Y")
            history.push("/cdh/channel");
          else if (localStorage.getItem("isCUSTOMER_FEEDBACK") === "Y")
            history.push("/cdh/feedback");
          else if (localStorage.getItem("isFUNNEL") === "Y")
            history.push("/cdh/funnel");
          else if (localStorage.getItem("isLOYALTY") === "Y")
            history.push("/cdh/loyalty");
          else if (localStorage.getItem("isMARKETING") === "Y")
            history.push("/cdh/marketing");
          else if (localStorage.getItem("isPROGRAM") === "Y")
            history.push("/cdh/program");
          else if (localStorage.getItem("isSTORES") === "Y")
            history.push("/cdh/stores");
          else if (localStorage.getItem("isCUSTOMERFILEHEALTH") === "Y")
            history.push("/cdh/customerfilehealth");
          localStorage.setItem("isLoggedIn", true);
        }
      })
      .catch((err) => {
        console.log(err + ", errtype=" + typeof err.toString());

        if (err.toString().includes("500")) {
          setErrorMsg("Failed connect to server");
          setloading((currValue) => false);
        } else if (err.toString().includes("403")) {
          setErrorMsg("Invalid User ID or Password");
          setloading((currValue) => false);
        } else if (err.toString().includes("Network Error")) {
          setErrorMsg("Network Error");
          setloading((currValue) => false);
        } else {
          setErrorMsg("Unknown");
          setloading((currValue) => false);
        }
      });
  };
  return (
    <div>
      <div className=" d-flex HeaderStyle justify-content-between align-items-center">
        <div className="d-flex BrandName">Customer Data Hub</div>
      </div>
      <div className="row-login">
        <div className="signIn_container">
          <span className="signIn">
            <b>Sign In</b>
          </span>
          <form className="form" onSubmit={handleSubmit} noValidate>
            <div className="form-group form-fields">
              <input
                type="email"
                className="form-control {classes.input} inputClass"
                id="email"
                placeholder="BBB ID"
                name="userName"
                onChange={handleChangeUserName}
              />
            </div>
            <div className="form-group form-fields">
              <input
                type={isPasswordShown ? "text" : "password"}
                className="form-control inputClass"
                placeholder="Password"
                name="password"
                onChange={handleChangePass}
              />
              {/* <span onClick={() => togglePasswordVisibility()}>
                {!isPasswordShown ? <BsFillEyeFill /> : <BsFillEyeSlashFill />}
              </span> */}

              <div style={{ color: "red", fontSize: "14px" }}>
                {ErrorMsg && <p className="ml-0">{ErrorMsg}</p>}
              </div>
            </div>

            <button className="signBtn" type="submit" onClick={spinner}>
              {loading && (
                <span
                  className="spinner-border spinner-border-sm"
                  role="status"
                  aria-hidden="true"
                ></span>
              )}
              {loading && <span> Signing In...</span>}
              {!loading && <span>Sign In</span>}
            </button>
          </form>
        </div>
      </div>
      <div className=" copyright_container copyright">
        <p> @2020 Bed Bath & Beyond Inc. and subsidiaries</p>
      </div>
    </div>
  );
};

export default Login;
