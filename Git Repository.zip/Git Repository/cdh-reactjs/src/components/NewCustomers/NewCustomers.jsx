import React, { useState, useCallback } from "react";
import { Table, Tab, Tabs,Dropdown } from "react-bootstrap";
import Footer from "../Footer/Footer";
import Header from "../Header/Header";
const CustomerStatus = [
  { value: "Returning Customers", id: "Stable_Exist" },
  { value: "New Customers", id: "Stable_New_L12m" },
  { value: "At risk (6m-9m)", id: "Atrisk_6m_9m" },
  { value: "At risk (9m-12m)", id: "Atrisk_9m-12m" },
  { value: "Inactive (13m-18m)", id: "Inactive_13m_18m" },
  { value: "Inactive (18m-24m)", id: "Inactive_18m_24m" },
];
function NewCustomers() {
  const [selectedPopulationId, setSelectedPopulationId] = useState("");
  const [selectedPopulationType, setSelectedPopulationType] = useState("");
  const handlePopulationChange = useCallback(
    (event) => {
      setSelectedPopulationId(event.target.id);
      setSelectedPopulationType(event.target.innerText);
    },
    [selectedPopulationId]
  );
  return (
    <div>
      <Header />
      {/* <div
        className="d-flex justify-content-start p-3 align-items-center"
        style={{ fontSize: "20px", fontWeight: "bold" }}
      >
        {"Returning Customers"}
      </div> */}
      <div className="d-flex justify-content-start p-3">
        <Dropdown className="d-inline">
          <Dropdown.Toggle>
            {selectedPopulationType
              ? selectedPopulationType
              : "Returning Customers"}
          </Dropdown.Toggle>
          <Dropdown.Menu
            className="dropdown-menu-ext"
            onClick={(e) => handlePopulationChange(e)}
          >
            {CustomerStatus.map((data) => {
              return (
                <Dropdown.Item
                  key={data.id}
                  className="dropdown-item-ext"
                  id={data.id}
                >
                  {data.value}
                </Dropdown.Item>
              );
            })}
          </Dropdown.Menu>
        </Dropdown>
      </div>
      <Tabs className="pt-3" style={{ paddingLeft: "1rem" }}>
        <Tab eventKey="home" title="Marketing Channel"></Tab>
        <Tab eventKey="profile" title="Persona" disabled></Tab>
        <Tab eventKey="profile" title="Purchase Channel" disabled></Tab>
        <Tab eventKey="profile" title="Program" disabled></Tab>
        <Tab eventKey="contact" title="Loyalty" disabled></Tab>
        <Tab eventKey="profile" title="Coupon/Promo Users" disabled></Tab>
        <Tab eventKey="contact" title="CLV Buckets " disabled></Tab>
        <Tab eventKey="profile" title="State" disabled></Tab>
      </Tabs>

      <div className="p-3">
        <Table striped bordered hover size="sm">
          <thead>
            <tr>
              <th>Channel</th>
              <th>Customers</th>
              <th>Transactions</th>
              <th>Net Sales</th>
              <th>AUR</th>
              <th>UPT</th>
              <th>AOV</th>
              <th>Product Margin</th>
            </tr>
          </thead>
          <tbody>
            <tr>
              <td className="tableCol">{"DM only"}</td>
              <td>
                {"136K"}
                <br />
                <span style={{ color: "green" }}>{"LY +23%"}</span>
                <br />
                <span style={{ color: "red" }}>{"LLY -3%"}</span>
              </td>
              <td>
                {"136K"}
                <br />
                <span style={{ color: "green" }}>{"LY +23%"}</span>
                <br />
                <span style={{ color: "red" }}>{"LLY -3%"}</span>
              </td>
              <td>
                {"136K"}
                <br />
                <span style={{ color: "green" }}>{"LY +23%"}</span>
                <br />
                <span style={{ color: "red" }}>{"LLY -3%"}</span>
              </td>
              <td>
                {"136K"}
                <br />
                <span style={{ color: "green" }}>{"LY +23%"}</span>
                <br />
                <span style={{ color: "red" }}>{"LLY -3%"}</span>
              </td>
              <td>
                {"136K"}
                <br />
                <span style={{ color: "green" }}>{"LY +23%"}</span>
                <br />
                <span style={{ color: "red" }}>{"LLY -3%"}</span>
              </td>
              <td>
                {"136K"}
                <br />
                <span style={{ color: "green" }}>{"LY +23%"}</span>
                <br />
                <span style={{ color: "red" }}>{"LLY -3%"}</span>
              </td>
              <td>
                {"136K"}
                <br />
                <span style={{ color: "green" }}>{"LY +23%"}</span>
                <br />
                <span style={{ color: "red" }}>{"LLY -3%"}</span>
              </td>
            </tr>
            <tr>
              <td className="tableCol">{"EM only"}</td>
              <td>
                {"136K"}
                <br />
                <span style={{ color: "green" }}>{"LY +23%"}</span>
                <br />
                <span style={{ color: "red" }}>{"LLY -3%"}</span>
              </td>
              <td>
                {"136K"}
                <br />
                <span style={{ color: "green" }}>{"LY +23%"}</span>
                <br />
                <span style={{ color: "red" }}>{"LLY -3%"}</span>
              </td>
              <td>
                {"136K"}
                <br />
                <span style={{ color: "green" }}>{"LY +23%"}</span>
                <br />
                <span style={{ color: "red" }}>{"LLY -3%"}</span>
              </td>
              <td>
                {"136K"}
                <br />
                <span style={{ color: "green" }}>{"LY +23%"}</span>
                <br />
                <span style={{ color: "red" }}>{"LLY -3%"}</span>
              </td>
              <td>
                {"136K"}
                <br />
                <span style={{ color: "green" }}>{"LY +23%"}</span>
                <br />
                <span style={{ color: "red" }}>{"LLY -3%"}</span>
              </td>
              <td>
                {"136K"}
                <br />
                <span style={{ color: "green" }}>{"LY +23%"}</span>
                <br />
                <span style={{ color: "red" }}>{"LLY -3%"}</span>
              </td>
              <td>
                {"136K"}
                <br />
                <span style={{ color: "green" }}>{"LY +23%"}</span>
                <br />
                <span style={{ color: "red" }}>{"LLY -3%"}</span>
              </td>
            </tr>
            <tr>
              <td className="tableCol">{"SMS only"}</td>
              <td>
                {"136K"}
                <br />
                <span style={{ color: "green" }}>{"LY +23%"}</span>
                <br />
                <span style={{ color: "red" }}>{"LLY -3%"}</span>
              </td>
              <td>
                {"136K"}
                <br />
                <span style={{ color: "green" }}>{"LY +23%"}</span>
                <br />
                <span style={{ color: "red" }}>{"LLY -3%"}</span>
              </td>
              <td>
                {"136K"}
                <br />
                <span style={{ color: "green" }}>{"LY +23%"}</span>
                <br />
                <span style={{ color: "red" }}>{"LLY -3%"}</span>
              </td>
              <td>
                {"136K"}
                <br />
                <span style={{ color: "green" }}>{"LY +23%"}</span>
                <br />
                <span style={{ color: "red" }}>{"LLY -3%"}</span>
              </td>
              <td>
                {"136K"}
                <br />
                <span style={{ color: "green" }}>{"LY +23%"}</span>
                <br />
                <span style={{ color: "red" }}>{"LLY -3%"}</span>
              </td>
              <td>
                {"136K"}
                <br />
                <span style={{ color: "green" }}>{"LY +23%"}</span>
                <br />
                <span style={{ color: "red" }}>{"LLY -3%"}</span>
              </td>
              <td>
                {"136K"}
                <br />
                <span style={{ color: "green" }}>{"LY +23%"}</span>
                <br />
                <span style={{ color: "red" }}>{"LLY -3%"}</span>
              </td>
            </tr>
            <tr>
              <td className="tableCol">{"DM and EM"}</td>
              <td>
                {"136K"}
                <br />
                <span style={{ color: "green" }}>{"LY +23%"}</span>
                <br />
                <span style={{ color: "red" }}>{"LLY -3%"}</span>
              </td>
              <td>
                {"136K"}
                <br />
                <span style={{ color: "green" }}>{"LY +23%"}</span>
                <br />
                <span style={{ color: "red" }}>{"LLY -3%"}</span>
              </td>
              <td>
                {"136K"}
                <br />
                <span style={{ color: "green" }}>{"LY +23%"}</span>
                <br />
                <span style={{ color: "red" }}>{"LLY -3%"}</span>
              </td>
              <td>
                {"136K"}
                <br />
                <span style={{ color: "green" }}>{"LY +23%"}</span>
                <br />
                <span style={{ color: "red" }}>{"LLY -3%"}</span>
              </td>
              <td>
                {"136K"}
                <br />
                <span style={{ color: "green" }}>{"LY +23%"}</span>
                <br />
                <span style={{ color: "red" }}>{"LLY -3%"}</span>
              </td>
              <td>
                {"136K"}
                <br />
                <span style={{ color: "green" }}>{"LY +23%"}</span>
                <br />
                <span style={{ color: "red" }}>{"LLY -3%"}</span>
              </td>
              <td>
                {"136K"}
                <br />
                <span style={{ color: "green" }}>{"LY +23%"}</span>
                <br />
                <span style={{ color: "red" }}>{"LLY -3%"}</span>
              </td>
            </tr>
            <tr>
              <td className="tableCol">{"SMS and DM"}</td>
              <td>
                {"136K"}
                <br />
                <span style={{ color: "green" }}>{"LY +23%"}</span>
                <br />
                <span style={{ color: "red" }}>{"LLY -3%"}</span>
              </td>
              <td>
                {"136K"}
                <br />
                <span style={{ color: "green" }}>{"LY +23%"}</span>
                <br />
                <span style={{ color: "red" }}>{"LLY -3%"}</span>
              </td>
              <td>
                {"136K"}
                <br />
                <span style={{ color: "green" }}>{"LY +23%"}</span>
                <br />
                <span style={{ color: "red" }}>{"LLY -3%"}</span>
              </td>
              <td>
                {"136K"}
                <br />
                <span style={{ color: "green" }}>{"LY +23%"}</span>
                <br />
                <span style={{ color: "red" }}>{"LLY -3%"}</span>
              </td>
              <td>
                {"136K"}
                <br />
                <span style={{ color: "green" }}>{"LY +23%"}</span>
                <br />
                <span style={{ color: "red" }}>{"LLY -3%"}</span>
              </td>
              <td>
                {"136K"}
                <br />
                <span style={{ color: "green" }}>{"LY +23%"}</span>
                <br />
                <span style={{ color: "red" }}>{"LLY -3%"}</span>
              </td>
              <td>
                {"136K"}
                <br />
                <span style={{ color: "green" }}>{"LY +23%"}</span>
                <br />
                <span style={{ color: "red" }}>{"LLY -3%"}</span>
              </td>
            </tr>
            <tr>
              <td className="tableCol">{"EM and SMS"}</td>
              <td>
                {"136K"}
                <br />
                <span style={{ color: "green" }}>{"LY +23%"}</span>
                <br />
                <span style={{ color: "red" }}>{"LLY -3%"}</span>
              </td>
              <td>
                {"136K"}
                <br />
                <span style={{ color: "green" }}>{"LY +23%"}</span>
                <br />
                <span style={{ color: "red" }}>{"LLY -3%"}</span>
              </td>
              <td>
                {"136K"}
                <br />
                <span style={{ color: "green" }}>{"LY +23%"}</span>
                <br />
                <span style={{ color: "red" }}>{"LLY -3%"}</span>
              </td>
              <td>
                {"136K"}
                <br />
                <span style={{ color: "green" }}>{"LY +23%"}</span>
                <br />
                <span style={{ color: "red" }}>{"LLY -3%"}</span>
              </td>
              <td>
                {"136K"}
                <br />
                <span style={{ color: "green" }}>{"LY +23%"}</span>
                <br />
                <span style={{ color: "red" }}>{"LLY -3%"}</span>
              </td>
              <td>
                {"136K"}
                <br />
                <span style={{ color: "green" }}>{"LY +23%"}</span>
                <br />
                <span style={{ color: "red" }}>{"LLY -3%"}</span>
              </td>
              <td>
                {"136K"}
                <br />
                <span style={{ color: "green" }}>{"LY +23%"}</span>
                <br />
                <span style={{ color: "red" }}>{"LLY -3%"}</span>
              </td>
            </tr>
            <tr>
              <td className="tableCol">{"DM, EM and SMS"}</td>
              <td>
                {"136K"}
                <br />
                <span style={{ color: "green" }}>{"LY +23%"}</span>
                <br />
                <span style={{ color: "red" }}>{"LLY -3%"}</span>
              </td>
              <td>
                {"136K"}
                <br />
                <span style={{ color: "green" }}>{"LY +23%"}</span>
                <br />
                <span style={{ color: "red" }}>{"LLY -3%"}</span>
              </td>
              <td>
                {"136K"}
                <br />
                <span style={{ color: "green" }}>{"LY +23%"}</span>
                <br />
                <span style={{ color: "red" }}>{"LLY -3%"}</span>
              </td>
              <td>
                {"136K"}
                <br />
                <span style={{ color: "green" }}>{"LY +23%"}</span>
                <br />
                <span style={{ color: "red" }}>{"LLY -3%"}</span>
              </td>
              <td>
                {"136K"}
                <br />
                <span style={{ color: "green" }}>{"LY +23%"}</span>
                <br />
                <span style={{ color: "red" }}>{"LLY -3%"}</span>
              </td>
              <td>
                {"136K"}
                <br />
                <span style={{ color: "green" }}>{"LY +23%"}</span>
                <br />
                <span style={{ color: "red" }}>{"LLY -3%"}</span>
              </td>
              <td>
                {"136K"}
                <br />
                <span style={{ color: "green" }}>{"LY +23%"}</span>
                <br />
                <span style={{ color: "red" }}>{"LLY -3%"}</span>
              </td>
            </tr>
            <tr>
              <td className="tableCol">{"Not Reachable"}</td>
              <td>
                {"136K"}
                <br />
                <span style={{ color: "green" }}>{"LY +23%"}</span>
                <br />
                <span style={{ color: "red" }}>{"LLY -3%"}</span>
              </td>
              <td>
                {"136K"}
                <br />
                <span style={{ color: "green" }}>{"LY +23%"}</span>
                <br />
                <span style={{ color: "red" }}>{"LLY -3%"}</span>
              </td>
              <td>
                {"136K"}
                <br />
                <span style={{ color: "green" }}>{"LY +23%"}</span>
                <br />
                <span style={{ color: "red" }}>{"LLY -3%"}</span>
              </td>
              <td>
                {"136K"}
                <br />
                <span style={{ color: "green" }}>{"LY +23%"}</span>
                <br />
                <span style={{ color: "red" }}>{"LLY -3%"}</span>
              </td>
              <td>
                {"136K"}
                <br />
                <span style={{ color: "green" }}>{"LY +23%"}</span>
                <br />
                <span style={{ color: "red" }}>{"LLY -3%"}</span>
              </td>
              <td>
                {"136K"}
                <br />
                <span style={{ color: "green" }}>{"LY +23%"}</span>
                <br />
                <span style={{ color: "red" }}>{"LLY -3%"}</span>
              </td>
              <td>
                {"136K"}
                <br />
                <span style={{ color: "green" }}>{"LY +23%"}</span>
                <br />
                <span style={{ color: "red" }}>{"LLY -3%"}</span>
              </td>
            </tr>
          </tbody>
        </Table>
      </div>
      <Footer />
    </div>
  );
}

export default NewCustomers;
