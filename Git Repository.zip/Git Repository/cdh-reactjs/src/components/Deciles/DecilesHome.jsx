import { React, useState } from "react";
import "../CdhHome/CdhHome.css";
import { Table } from "react-bootstrap";
import LoaderForRow from "../LoaderForTable/LoaderForRow";
import { currencyFormat } from "../CdhHome/CdhHome";
import { gettooltip } from "../Utils";
function DecilesHome({
  loading,
  DecilesHomeData,
  DecilesHomeTotalData,
  DecilesHomeSubTotalData,
}) {
  return (
    <div>
      <div className="p-3" style={{ marginBottom: "50px" }}>
        <Table striped bordered hover size="sm">
          <thead style={{ fontSize: "13px" }}>
            <tr key={"#Header"}>
              <th>Deciles</th>
              <th>
                No. of
                <br />
                Customers{" "}
                {gettooltip(
                  "customersInfoIcon",
                  "Customers",
                  "Customers",
                  "Data based on two years"
                )}
              </th>
              <th>
                Net Sales{" "}
                {gettooltip(
                  "NetSalesInfoIcon",
                  "NetSales",
                  "NetSales",
                  "Net Sales for customers in one year"
                )}
              </th>
              <th>
                % of total <br />
                Net sales
              </th>
              <th>
                Transactions{" "}
                {gettooltip(
                  "TransactionsInfoIcon",
                  "Transactions",
                  "Transactions",
                  "Number of distinct transaction for customer in one year"
                )}
              </th>
              <th>
                % of total <br />
                Transactions
              </th>
              <th>
                Product Margin{" "}
                {gettooltip(
                  "ProductMarginInfoIcon",
                  "ProductMargin",
                  "ProductMargin",
                  "Product Margin for customers in one year",
                  "(Net Sales - Cost of Sales)"
                )}
              </th>
              <th>
                % of <br /> total PM
              </th>
              <th>
                AOV{" "}
                {gettooltip(
                  "AOVInfoIcon",
                  "AOV",
                  "AOV",
                  "Net Sales divided by number of transaction"
                )}
              </th>
              <th>
                UPT{" "}
                {gettooltip(
                  "UPTInfoIcon",
                  "UPT",
                  "UPT",
                  "Unit Sold per transaction"
                )}
              </th>
              <th>
                AUR{" "}
                {gettooltip(
                  "AURInfoIcon",
                  "AUR",
                  "AUR",
                  "Net Sales divided by unit sold"
                )}
              </th>
              <th>
                Net Sales <br /> per customer{" "}
                {gettooltip(
                  "NPCInfoIcon",
                  "NPC",
                  "NPC",
                  "Net Sales per Customer"
                )}
              </th>
              <th>
                Margin <br /> per customer
              </th>
              <th>
                Transactions <br /> per customer{" "}
                {gettooltip(
                  "TPCInfoIcon",
                  "TPC",
                  "TPC",
                  "Number of Transactions per customer"
                )}
              </th>
            </tr>
          </thead>
          <tbody>
            {loading.DecileHome ? (
              <tr>
                <LoaderForRow height={"500px"} tdCount={14} />
              </tr>
            ) : (
              DecilesHomeData !== undefined &&
              DecilesHomeData.length !== 0 &&
              DecilesHomeData.map((data) => {
                return (
                  <tr key={"Decile-" + Number(data.DECILE)}>
                    <td class="tableCol">
                      {data.DECILE === "-999999"
                        ? "-"
                        : "Decile-" + Number(data.DECILE)}
                    </td>
                    <td>
                      {data.CUST_COUNT_TY === "-999999"
                        ? "-"
                        : currencyFormat(Number(data.CUST_COUNT_TY))}
                      <br />
                      {data !== undefined &&
                      data.length !== 0 &&
                      Number(data.CUST_TY_VS_LY).toFixed(2).includes("-") ? (
                        <span style={{ color: "red", fontSize: "12px" }}>
                          {data !== undefined &&
                            data.length !== 0 &&
                            (data.CUST_TY_VS_LY === "-999999"
                              ? "-"
                              : `LY ${Number(data.CUST_TY_VS_LY).toFixed(2)}%`)}
                        </span>
                      ) : (
                        <span style={{ color: "green", fontSize: "12px" }}>
                          {data !== undefined &&
                            data.length !== 0 &&
                            (data.CUST_TY_VS_LY === "-999999"
                              ? "-"
                              : `LY +${Number(data.CUST_TY_VS_LY).toFixed(
                                  2
                                )}%`)}
                        </span>
                      )}
                      <br />
                      {data !== undefined &&
                      data.length !== 0 &&
                      Number(data.CUST_TY_VS_LLY).toFixed(2).includes("-") ? (
                        <span style={{ color: "red", fontSize: "11px" }}>
                          {data !== undefined &&
                            data.length !== 0 &&
                            (data.CUST_TY_VS_LLY === "-999999"
                              ? "-"
                              : `LLY ${Number(data.CUST_TY_VS_LLY).toFixed(
                                  2
                                )}%`)}
                        </span>
                      ) : (
                        <span style={{ color: "green", fontSize: "11px" }}>
                          {data !== undefined &&
                            data.length !== 0 &&
                            (data.CUST_TY_VS_LLY === "-999999"
                              ? "-"
                              : `LLY +${Number(data.CUST_TY_VS_LLY).toFixed(
                                  2
                                )}%`)}
                        </span>
                      )}
                    </td>
                    <td>
                      {data !== undefined &&
                        data.length !== 0 &&
                        (data.NET_SALES_TY === "-999999"
                          ? "-"
                          : "$" + currencyFormat(Number(data.NET_SALES_TY)))}
                      <br />
                      {data !== undefined &&
                      data.length !== 0 &&
                      Number(data.NET_SALES_TY_VS_LY)
                        .toFixed(2)
                        .includes("-") ? (
                        <span style={{ color: "red", fontSize: "12px" }}>
                          {data !== undefined &&
                            data.length !== 0 &&
                            (data.NET_SALES_TY_VS_LY === "-999999"
                              ? "-"
                              : `LY ${Number(data.NET_SALES_TY_VS_LY).toFixed(
                                  2
                                )}%`)}
                        </span>
                      ) : (
                        <span style={{ color: "green", fontSize: "12px" }}>
                          {data !== undefined &&
                            data.length !== 0 &&
                            (data.NET_SALES_TY_VS_LY === "-999999"
                              ? "-"
                              : `LY +${Number(data.NET_SALES_TY_VS_LY).toFixed(
                                  2
                                )}%`)}
                        </span>
                      )}
                      <br />
                      {data !== undefined &&
                      data.length !== 0 &&
                      Number(data.NET_SALES_TY_VS_LLY)
                        .toFixed(2)
                        .includes("-") ? (
                        <span style={{ color: "red", fontSize: "11px" }}>
                          {data !== undefined &&
                            data.length !== 0 &&
                            (data.NET_SALES_TY_VS_LLY === "-999999"
                              ? "-"
                              : `LLY ${Number(data.NET_SALES_TY_VS_LLY).toFixed(
                                  2
                                )}%`)}
                        </span>
                      ) : (
                        <span style={{ color: "green", fontSize: "11px" }}>
                          {data !== undefined &&
                            data.length !== 0 &&
                            (data.NET_SALES_TY_VS_LLY === "-999999"
                              ? "-"
                              : `LLY +${Number(
                                  data.NET_SALES_TY_VS_LLY
                                ).toFixed(2)}%`)}
                        </span>
                      )}
                    </td>
                    <td>
                      {data.PER_TOTAL_NET_SALES_TY === "-999999"
                        ? "-"
                        : `${Number(data.PER_TOTAL_NET_SALES_TY).toFixed(2)}%`}
                      <br />
                      {data !== undefined &&
                      data.length !== 0 &&
                      Number(data.PER_TOTAL_NET_SALES_TY_VS_LY)
                        .toFixed(2)
                        .includes("-") ? (
                        <span style={{ color: "red", fontSize: "12px" }}>
                          {data !== undefined &&
                            data.length !== 0 &&
                            (data.PER_TOTAL_NET_SALES_TY_VS_LY === "-999999"
                              ? "-"
                              : `LY ${Number(
                                  data.PER_TOTAL_NET_SALES_TY_VS_LY
                                ).toFixed(2)}%`)}
                        </span>
                      ) : (
                        <span style={{ color: "green", fontSize: "12px" }}>
                          {data !== undefined &&
                            data.length !== 0 &&
                            (data.PER_TOTAL_NET_SALES_TY_VS_LY === "-999999"
                              ? "-"
                              : `LY +${Number(
                                  data.PER_TOTAL_NET_SALES_TY_VS_LY
                                ).toFixed(2)}%`)}
                        </span>
                      )}
                      <br />
                      {data !== undefined &&
                      data.length !== 0 &&
                      Number(data.PER_TOTAL_NET_SALES_TY_VS_LLY)
                        .toFixed(2)
                        .includes("-") ? (
                        <span style={{ color: "red", fontSize: "11px" }}>
                          {data !== undefined &&
                            data.length !== 0 &&
                            (data.PER_TOTAL_NET_SALES_TY_VS_LLY === "-999999"
                              ? "-"
                              : `LLY ${Number(
                                  data.PER_TOTAL_NET_SALES_TY_VS_LLY
                                ).toFixed(2)}%`)}
                        </span>
                      ) : (
                        <span style={{ color: "green", fontSize: "11px" }}>
                          {data !== undefined &&
                            data.length !== 0 &&
                            (data.PER_TOTAL_NET_SALES_TY_VS_LLY === "-999999"
                              ? "-"
                              : `LLY +${Number(
                                  data.PER_TOTAL_NET_SALES_TY_VS_LLY
                                ).toFixed(2)}%`)}
                        </span>
                      )}
                    </td>
                    <td>
                      {data !== undefined &&
                        data.length !== 0 &&
                        (data.TRANS_COUNT_TY === "-999999"
                          ? "-"
                          : currencyFormat(Number(data.TRANS_COUNT_TY)))}
                      <br />
                      {data !== undefined &&
                      data.length !== 0 &&
                      Number(data.TRANS_COUNT_TY_VS_LY)
                        .toFixed(2)
                        .includes("-") ? (
                        <span style={{ color: "red", fontSize: "12px" }}>
                          {data !== undefined &&
                            data.length !== 0 &&
                            (data.TRANS_COUNT_TY_VS_LY === "-999999"
                              ? "-"
                              : `LY ${Number(data.TRANS_COUNT_TY_VS_LY).toFixed(
                                  2
                                )}%`)}
                        </span>
                      ) : (
                        <span style={{ color: "green", fontSize: "12px" }}>
                          {data !== undefined &&
                            data.length !== 0 &&
                            (data.TRANS_COUNT_TY_VS_LY === "-999999"
                              ? "-"
                              : `LY +${Number(
                                  data.TRANS_COUNT_TY_VS_LY
                                ).toFixed(2)}%`)}
                        </span>
                      )}
                      <br />
                      {data !== undefined &&
                      data.length !== 0 &&
                      Number(data.TRANS_COUNT_TY_VS_LLY)
                        .toFixed(2)
                        .includes("-") ? (
                        <span style={{ color: "red", fontSize: "11px" }}>
                          {data !== undefined &&
                            data.length !== 0 &&
                            (data.TRANS_COUNT_TY_VS_LLY === "-999999"
                              ? "-"
                              : `LLY ${Number(
                                  data.TRANS_COUNT_TY_VS_LLY
                                ).toFixed(2)}`)}
                        </span>
                      ) : (
                        <span style={{ color: "green", fontSize: "11px" }}>
                          {data !== undefined &&
                            data.length !== 0 &&
                            (data.TRANS_COUNT_TY_VS_LLY === "-999999"
                              ? "-"
                              : `LLY +${Number(
                                  data.TRANS_COUNT_TY_VS_LLY
                                ).toFixed(2)}`)}
                        </span>
                      )}
                    </td>
                    <td>
                      {data.PER_TOTAL_TRANS_COUNT_TY === "-999999"
                        ? "-"
                        : `${Number(data.PER_TOTAL_TRANS_COUNT_TY).toFixed(
                            2
                          )}%`}
                      <br />
                      {data !== undefined &&
                      data.length !== 0 &&
                      Number(data.PER_TOTAL_TRANS_COUNT_TY_VS_LY)
                        .toFixed(2)
                        .includes("-") ? (
                        <span style={{ color: "red", fontSize: "12px" }}>
                          {data !== undefined &&
                            data.length !== 0 &&
                            (data.PER_TOTAL_TRANS_COUNT_TY_VS_LY === "-999999"
                              ? "-"
                              : `LY ${Number(
                                  data.PER_TOTAL_TRANS_COUNT_TY_VS_LY
                                ).toFixed(2)}%`)}
                        </span>
                      ) : (
                        <span style={{ color: "green", fontSize: "12px" }}>
                          {data !== undefined &&
                            data.length !== 0 &&
                            (data.PER_TOTAL_TRANS_COUNT_TY_VS_LY === "-999999"
                              ? "-"
                              : `LY +${Number(
                                  data.PER_TOTAL_TRANS_COUNT_TY_VS_LY
                                ).toFixed(2)}%`)}
                        </span>
                      )}
                      <br />
                      {data !== undefined &&
                      data.length !== 0 &&
                      Number(data.PER_TOTAL_TRANS_COUNT_TY_VS_LLY)
                        .toFixed(2)
                        .includes("-") ? (
                        <span style={{ color: "red", fontSize: "11px" }}>
                          {data !== undefined &&
                            data.length !== 0 &&
                            (data.PER_TOTAL_TRANS_COUNT_TY_VS_LLY === "-999999"
                              ? "-"
                              : `LLY ${Number(
                                  data.PER_TOTAL_TRANS_COUNT_TY_VS_LLY
                                ).toFixed(2)}%`)}
                        </span>
                      ) : (
                        <span style={{ color: "green", fontSize: "11px" }}>
                          {data !== undefined &&
                            data.length !== 0 &&
                            (data.PER_TOTAL_TRANS_COUNT_TY_VS_LLY === "-999999"
                              ? "-"
                              : `LLY +${Number(
                                  data.PER_TOTAL_TRANS_COUNT_TY_VS_LLY
                                ).toFixed(2)}%`)}
                        </span>
                      )}
                    </td>
                    <td>
                      {data !== undefined &&
                        data.length !== 0 &&
                        (data.PM_TY === "-999999"
                          ? "-"
                          : "$" + currencyFormat(Number(data.PM_TY)))}
                      <br />
                      {data !== undefined &&
                      data.length !== 0 &&
                      Number(data.PM_TY_VS_LY).toFixed(2).includes("-") ? (
                        <span style={{ color: "red", fontSize: "12px" }}>
                          {data !== undefined &&
                            data.length !== 0 &&
                            (data.PM_TY_VS_LY === "-999999"
                              ? "-"
                              : `LY ${Number(data.PM_TY_VS_LY).toFixed(2)}%`)}
                        </span>
                      ) : (
                        <span style={{ color: "green", fontSize: "12px" }}>
                          {data !== undefined &&
                            data.length !== 0 &&
                            (data.PM_TY_VS_LY === "-999999"
                              ? "-"
                              : `LY +${Number(data.PM_TY_VS_LY).toFixed(2)}%`)}
                        </span>
                      )}
                      <br />
                      {data !== undefined &&
                      data.length !== 0 &&
                      Number(data.PM_TY_VS_LLY).toFixed(2).includes("-") ? (
                        <span style={{ color: "red", fontSize: "11px" }}>
                          {data !== undefined &&
                            data.length !== 0 &&
                            (data.PM_TY_VS_LLY === "-999999"
                              ? "-"
                              : `LLY ${Number(data.PM_TY_VS_LLY).toFixed(2)}%`)}
                        </span>
                      ) : (
                        <span style={{ color: "green", fontSize: "11px" }}>
                          {data !== undefined &&
                            data.length !== 0 &&
                            (data.PM_TY_VS_LLY === "-999999"
                              ? "-"
                              : `LLY +${Number(data.PM_TY_VS_LLY).toFixed(
                                  2
                                )}%`)}
                        </span>
                      )}
                    </td>
                    <td>
                      {data.PER_TOTAL_PM_TY === "-999999"
                        ? "-"
                        : `${Number(data.PER_TOTAL_PM_TY).toFixed(2)}%`}
                      <br />
                      {data !== undefined &&
                      data.length !== 0 &&
                      Number(data.PER_TOTAL_PM_TY_VS_LY)
                        .toFixed(2)
                        .includes("-") ? (
                        <span style={{ color: "red", fontSize: "12px" }}>
                          {data !== undefined &&
                            data.length !== 0 &&
                            (data.PER_TOTAL_PM_TY_VS_LY === "-999999"
                              ? "-"
                              : `LY ${Number(
                                  data.PER_TOTAL_PM_TY_VS_LY
                                ).toFixed(2)}%`)}
                        </span>
                      ) : (
                        <span style={{ color: "green", fontSize: "12px" }}>
                          {data !== undefined &&
                            data.length !== 0 &&
                            (data.PER_TOTAL_PM_TY_VS_LY === "-999999"
                              ? "-"
                              : `LY +${Number(
                                  data.PER_TOTAL_PM_TY_VS_LY
                                ).toFixed(2)}%`)}
                        </span>
                      )}
                      <br />
                      {data !== undefined &&
                      data.length !== 0 &&
                      Number(data.PER_TOTAL_PM_TY_VS_LLY)
                        .toFixed(2)
                        .includes("-") ? (
                        <span style={{ color: "red", fontSize: "11px" }}>
                          {data !== undefined &&
                            data.length !== 0 &&
                            (data.PER_TOTAL_PM_TY_VS_LLY === "-999999"
                              ? "-"
                              : `LLY ${Number(
                                  data.PER_TOTAL_PM_TY_VS_LLY
                                ).toFixed(2)}%`)}
                        </span>
                      ) : (
                        <span style={{ color: "green", fontSize: "11px" }}>
                          {data !== undefined &&
                            data.length !== 0 &&
                            (data.PER_TOTAL_PM_TY_VS_LLY === "-999999"
                              ? "-"
                              : `LLY +${Number(
                                  data.PER_TOTAL_PM_TY_VS_LLY
                                ).toFixed(2)}%`)}
                        </span>
                      )}
                    </td>
                    <td>
                      {data.AOV_TY === "-999999"
                        ? "-"
                        : "$" + Number(data.AOV_TY).toFixed(2)}
                      <br />
                      {data !== undefined &&
                      data.length !== 0 &&
                      Number(data.AOV_TY_VS_LY).toFixed(2).includes("-") ? (
                        <span style={{ color: "red", fontSize: "12px" }}>
                          {data !== undefined &&
                            data.length !== 0 &&
                            (data.AOV_TY_VS_LY === "-999999"
                              ? "-"
                              : `LY ${Number(data.AOV_TY_VS_LY).toFixed(2)}%`)}
                        </span>
                      ) : (
                        <span style={{ color: "green", fontSize: "12px" }}>
                          {data !== undefined &&
                            data.length !== 0 &&
                            (data.AOV_TY_VS_LY === "-999999"
                              ? "-"
                              : `LY +${Number(data.AOV_TY_VS_LY).toFixed(2)}%`)}
                        </span>
                      )}
                      <br />
                      {data !== undefined &&
                      data.length !== 0 &&
                      Number(data.AOV_TY_VS_LLY).toFixed(2).includes("-") ? (
                        <span style={{ color: "red", fontSize: "11px" }}>
                          {data !== undefined &&
                            data.length !== 0 &&
                            (data.AOV_TY_VS_LLY === "-999999"
                              ? "-"
                              : `LLY ${Number(data.AOV_TY_VS_LLY).toFixed(
                                  2
                                )}%`)}
                        </span>
                      ) : (
                        <span style={{ color: "green", fontSize: "11px" }}>
                          {data !== undefined &&
                            data.length !== 0 &&
                            (data.AOV_TY_VS_LLY === "-999999"
                              ? "-"
                              : `LLY +${Number(data.AOV_TY_VS_LLY).toFixed(
                                  2
                                )}%`)}
                        </span>
                      )}
                    </td>
                    <td>
                      {data.UPT_TY === "-999999"
                        ? "-"
                        : Number(data.UPT_TY).toFixed(2)}
                      <br />
                      {data !== undefined &&
                      data.length !== 0 &&
                      Number(data.UPT_TY_VS_LY).toFixed(2).includes("-") ? (
                        <span style={{ color: "red", fontSize: "12px" }}>
                          {data !== undefined &&
                            data.length !== 0 &&
                            (data.UPT_TY_VS_LY === "-999999"
                              ? "-"
                              : `LY ${Number(data.UPT_TY_VS_LY).toFixed(2)}%`)}
                        </span>
                      ) : (
                        <span style={{ color: "green", fontSize: "12px" }}>
                          {data !== undefined &&
                            data.length !== 0 &&
                            (data.UPT_TY_VS_LY === "-999999"
                              ? "-"
                              : `LY +${Number(data.UPT_TY_VS_LY).toFixed(2)}%`)}
                        </span>
                      )}
                      <br />
                      {data !== undefined &&
                      data.length !== 0 &&
                      Number(data.UPT_TY_VS_LLY).toFixed(2).includes("-") ? (
                        <span style={{ color: "red", fontSize: "11px" }}>
                          {data !== undefined &&
                            data.length !== 0 &&
                            (data.UPT_TY_VS_LLY === "-999999"
                              ? "-"
                              : `LLY ${Number(data.UPT_TY_VS_LLY).toFixed(
                                  2
                                )}%`)}
                        </span>
                      ) : (
                        <span style={{ color: "green", fontSize: "11px" }}>
                          {data !== undefined &&
                            data.length !== 0 &&
                            (data.UPT_TY_VS_LLY === "-999999"
                              ? "-"
                              : `LLY +${Number(data.UPT_TY_VS_LLY).toFixed(
                                  2
                                )}%`)}
                        </span>
                      )}
                    </td>
                    <td>
                      {data.AUR_TY === "-999999"
                        ? "-"
                        : "$" + Number(data.AUR_TY).toFixed(2)}
                      <br />
                      {data !== undefined &&
                      data.length !== 0 &&
                      Number(data.AUR_TY_VS_LY).toFixed(2).includes("-") ? (
                        <span style={{ color: "red", fontSize: "12px" }}>
                          {data !== undefined &&
                            data.length !== 0 &&
                            (data.AUR_TY_VS_LY === "-999999"
                              ? "-"
                              : `LY ${Number(data.AUR_TY_VS_LY).toFixed(2)}%`)}
                        </span>
                      ) : (
                        <span style={{ color: "green", fontSize: "12px" }}>
                          {data !== undefined &&
                            data.length !== 0 &&
                            (data.AUR_TY_VS_LY === "-999999"
                              ? "-"
                              : `LY +${Number(data.AUR_TY_VS_LY).toFixed(2)}%`)}
                        </span>
                      )}
                      <br />
                      {data !== undefined &&
                      data.length !== 0 &&
                      Number(data.AUR_TY_VS_LLY).toFixed(2).includes("-") ? (
                        <span style={{ color: "red", fontSize: "11px" }}>
                          {data !== undefined &&
                            data.length !== 0 &&
                            (data.AUR_TY_VS_LLY === "-999999"
                              ? "-"
                              : `LLY ${Number(data.AUR_TY_VS_LLY).toFixed(
                                  2
                                )}%`)}
                        </span>
                      ) : (
                        <span style={{ color: "green", fontSize: "11px" }}>
                          {data !== undefined &&
                            data.length !== 0 &&
                            (data.AUR_TY_VS_LLY === "-999999"
                              ? "-"
                              : `LLY +${Number(data.AUR_TY_VS_LLY).toFixed(
                                  2
                                )}%`)}
                        </span>
                      )}
                    </td>
                    <td>
                      {data.NET_SALES_PER_CUST_TY === "-999999"
                        ? "-"
                        : "$" + Number(data.NET_SALES_PER_CUST_TY).toFixed(2)}
                      <br />
                      {data !== undefined &&
                      data.length !== 0 &&
                      Number(data.NET_SALES_PER_CUST_TY_VS_LY)
                        .toFixed(2)
                        .includes("-") ? (
                        <span style={{ color: "red", fontSize: "12px" }}>
                          {data !== undefined &&
                            data.length !== 0 &&
                            (data.NET_SALES_PER_CUST_TY_VS_LY === "-999999"
                              ? "-"
                              : `LY ${Number(
                                  data.NET_SALES_PER_CUST_TY_VS_LY
                                ).toFixed(2)}%`)}
                        </span>
                      ) : (
                        <span style={{ color: "green", fontSize: "12px" }}>
                          {data !== undefined &&
                            data.length !== 0 &&
                            (data.NET_SALES_PER_CUST_TY_VS_LY === "-999999"
                              ? "-"
                              : `LY +${Number(
                                  data.NET_SALES_PER_CUST_TY_VS_LY
                                ).toFixed(2)}%`)}
                        </span>
                      )}
                      <br />
                      {data !== undefined &&
                      data.length !== 0 &&
                      Number(data.NET_SALES_PER_CUST_TY_VS_LLY)
                        .toFixed(2)
                        .includes("-") ? (
                        <span style={{ color: "red", fontSize: "11px" }}>
                          {data !== undefined &&
                            data.length !== 0 &&
                            (data.NET_SALES_PER_CUST_TY_VS_LLY === "-999999"
                              ? "-"
                              : `LLY ${Number(
                                  data.NET_SALES_PER_CUST_TY_VS_LLY
                                ).toFixed(2)}%`)}
                        </span>
                      ) : (
                        <span style={{ color: "green", fontSize: "11px" }}>
                          {data !== undefined &&
                            data.length !== 0 &&
                            (data.NET_SALES_PER_CUST_TY_VS_LLY === "-999999"
                              ? "-"
                              : `LLY +${Number(
                                  data.NET_SALES_PER_CUST_TY_VS_LLY
                                ).toFixed(2)}%`)}
                        </span>
                      )}
                    </td>
                    <td>
                      {data.MARGIN_RATE_PER_TY === "-999999"
                        ? "-"
                        : "$" + Number(data.MARGIN_RATE_PER_TY).toFixed(2)}
                      <br />
                      {data !== undefined &&
                      data.length !== 0 &&
                      Number(data.MARGIN_RATE_PER_TY_VS_LY)
                        .toFixed(2)
                        .includes("-") ? (
                        <span style={{ color: "red", fontSize: "12px" }}>
                          {data !== undefined &&
                            data.length !== 0 &&
                            (data.MARGIN_RATE_PER_TY_VS_LY === "-999999"
                              ? "-"
                              : `LY ${Number(
                                  data.MARGIN_RATE_PER_TY_VS_LY
                                ).toFixed(2)}%`)}
                        </span>
                      ) : (
                        <span style={{ color: "green", fontSize: "12px" }}>
                          {data !== undefined &&
                            data.length !== 0 &&
                            (data.MARGIN_RATE_PER_TY_VS_LY === "-999999"
                              ? "-"
                              : `LY +${Number(
                                  data.MARGIN_RATE_PER_TY_VS_LY
                                ).toFixed(2)}%`)}
                        </span>
                      )}
                      <br />
                      {data !== undefined &&
                      data.length !== 0 &&
                      Number(data.MARGIN_RATE_PER_TY_VS_LLY)
                        .toFixed(2)
                        .includes("-") ? (
                        <span style={{ color: "red", fontSize: "11px" }}>
                          {data !== undefined &&
                            data.length !== 0 &&
                            (data.MARGIN_RATE_PER_TY_VS_LLY === "-999999"
                              ? "-"
                              : `LLY ${Number(
                                  data.MARGIN_RATE_PER_TY_VS_LLY
                                ).toFixed(2)}%`)}
                        </span>
                      ) : (
                        <span style={{ color: "green", fontSize: "11px" }}>
                          {data !== undefined &&
                            data.length !== 0 &&
                            (data.MARGIN_RATE_PER_TY_VS_LLY === "-999999"
                              ? "-"
                              : `LLY +${Number(
                                  data.MARGIN_RATE_PER_TY_VS_LLY
                                ).toFixed(2)}%`)}
                        </span>
                      )}
                    </td>
                    <td>
                      {data.AVG_TRAN_TY === "-999999"
                        ? "-"
                        : Number(data.AVG_TRAN_TY).toFixed(2)}
                      <br />
                      {data !== undefined &&
                      data.length !== 0 &&
                      Number(data.AVG_TRAN_TY_VS_LY)
                        .toFixed(2)
                        .includes("-") ? (
                        <span style={{ color: "red", fontSize: "12px" }}>
                          {data !== undefined &&
                            data.length !== 0 &&
                            (data.AVG_TRAN_TY_VS_LY === "-999999"
                              ? "-"
                              : `LY ${Number(data.AVG_TRAN_TY_VS_LY).toFixed(
                                  2
                                )}%`)}
                        </span>
                      ) : (
                        <span style={{ color: "green", fontSize: "12px" }}>
                          {data !== undefined &&
                            data.length !== 0 &&
                            (data.AVG_TRAN_TY_VS_LY === "-999999"
                              ? "-"
                              : `LY +${Number(data.AVG_TRAN_TY_VS_LY).toFixed(
                                  2
                                )}%`)}
                        </span>
                      )}
                      <br />
                      {data !== undefined &&
                      data.length !== 0 &&
                      Number(data.AVG_TRAN_TY_VS_LLY)
                        .toFixed(2)
                        .includes("-") ? (
                        <span style={{ color: "red", fontSize: "11px" }}>
                          {data !== undefined &&
                            data.length !== 0 &&
                            (data.AVG_TRAN_TY_VS_LLY === "-999999"
                              ? "-"
                              : `LLY ${Number(data.AVG_TRAN_TY_VS_LLY).toFixed(
                                  2
                                )}%`)}
                        </span>
                      ) : (
                        <span style={{ color: "green", fontSize: "11px" }}>
                          {data !== undefined &&
                            data.length !== 0 &&
                            (data.AVG_TRAN_TY_VS_LLY === "-999999"
                              ? "-"
                              : `LLY +${Number(data.AVG_TRAN_TY_VS_LLY).toFixed(
                                  2
                                )}%`)}
                        </span>
                      )}
                    </td>
                  </tr>
                );
              })
            )}
            {loading.DecileHomeSubTotal ? (
              <tr key={"#SubTotal"}>
                <LoaderForRow height={"50px"} tdCount={14} />
              </tr>
            ) : (
              DecilesHomeSubTotalData !== undefined &&
              DecilesHomeSubTotalData.length !== 0 &&
              DecilesHomeSubTotalData.map((data) => {
                return (
                  <tr>
                    <td class="tableCol" style={{ fontSize: "12px" }}>
                      Not <br />
                      Transacted
                      <br /> Customers
                    </td>
                    <td>
                      {data.CUST_COUNT_TY === "-999999"
                        ? "-"
                        : currencyFormat(Number(data.CUST_COUNT_TY))}
                      <br />
                      {data !== undefined &&
                      data.length !== 0 &&
                      Number(data.CUST_TY_VS_LY).toFixed(2).includes("-") ? (
                        <span style={{ color: "green", fontSize: "12px" }}>
                          {data !== undefined &&
                            data.length !== 0 &&
                            (data.CUST_TY_VS_LY === "-999999"
                              ? "-"
                              : `LY ${Number(data.CUST_TY_VS_LY).toFixed(2)}%`)}
                        </span>
                      ) : (
                        <span style={{ color: "red", fontSize: "12px" }}>
                          {data !== undefined &&
                            data.length !== 0 &&
                            (data.CUST_TY_VS_LY === "-999999"
                              ? "-"
                              : `LY +${Number(data.CUST_TY_VS_LY).toFixed(
                                  2
                                )}%`)}
                        </span>
                      )}
                      <br />
                      {data !== undefined &&
                      data.length !== 0 &&
                      Number(data.CUST_TY_VS_LLY).toFixed(2).includes("-") ? (
                        <span style={{ color: "green", fontSize: "11px" }}>
                          {data !== undefined &&
                            data.length !== 0 &&
                            (data.CUST_TY_VS_LLY === "-999999"
                              ? "-"
                              : `LLY ${Number(data.CUST_TY_VS_LLY).toFixed(
                                  2
                                )}%`)}
                        </span>
                      ) : (
                        <span style={{ color: "red", fontSize: "11px" }}>
                          {data !== undefined &&
                            data.length !== 0 &&
                            (data.CUST_TY_VS_LLY === "-999999"
                              ? "-"
                              : `LLY +${Number(data.CUST_TY_VS_LLY).toFixed(
                                  2
                                )}%`)}
                        </span>
                      )}
                    </td>
                  </tr>
                );
              })
            )}
            {loading.DecileHomeTotal ? (
              <tr key={"#Total"}>
                <LoaderForRow height={"50px"} tdCount={14} />
              </tr>
            ) : (
              DecilesHomeTotalData !== undefined &&
              DecilesHomeTotalData.length !== 0 &&
              DecilesHomeTotalData.map((data) => {
                return (
                  <tr>
                    <th>Total</th>
                    <th>
                      {data.CUST_COUNT_TY === "-999999"
                        ? "-"
                        : currencyFormat(Number(data.CUST_COUNT_TY))}
                    </th>
                    <th>
                      {data &&
                        data !== undefined &&
                        data.length !== 0 &&
                        (data.NET_SALES_TY === "-999999"
                          ? "-"
                          : "$" + currencyFormat(Number(data.NET_SALES_TY)))}
                    </th>
                    <th>
                      {data.PER_TOTAL_NET_SALES_TY === "-999999"
                        ? "-"
                        : `${Number(data.PER_TOTAL_NET_SALES_TY).toFixed(2)}%`}
                    </th>
                    <th>
                      {data &&
                        data !== undefined &&
                        data.length !== 0 &&
                        (data.TRANS_COUNT_TY === "-999999"
                          ? "-"
                          : currencyFormat(Number(data.TRANS_COUNT_TY)))}
                    </th>
                    <th>
                      {data.TOTAL_TRANS_COUNT_TY === "-999999"
                        ? "-"
                        : `${Number(data.TOTAL_TRANS_COUNT_TY).toFixed(2)}%`}
                    </th>
                    <th>
                      {data &&
                        data !== undefined &&
                        data.length !== 0 &&
                        (data.PM_TY === "-999999"
                          ? "-"
                          : "$" + currencyFormat(Number(data.PM_TY)))}
                    </th>
                    <th>
                      {data.PER_TOTAL_PM_TY === "-999999"
                        ? "-"
                        : `${Number(data.PER_TOTAL_PM_TY).toFixed(2)}%`}
                    </th>
                    <th>
                      {data.AOV_TY === "-999999"
                        ? "-"
                        : "$" + Number(data.AOV_TY).toFixed(2)}
                    </th>
                    <th>
                      {data.UPT_TY === "-999999"
                        ? "-"
                        : Number(data.UPT_TY).toFixed(2)}
                    </th>
                    <th>
                      {data.AUR_TY === "-999999"
                        ? "-"
                        : "$" + Number(data.AUR_TY).toFixed(2)}
                    </th>
                    <th>
                      {data.NET_SALES_PER_CUST_TY === "-999999"
                        ? "-"
                        : "$" + Number(data.NET_SALES_PER_CUST_TY).toFixed(2)}
                    </th>
                    <th>
                      {data.MARGIN_RATE_PER_CUST_TY === "-999999"
                        ? "-"
                        : "$" + Number(data.MARGIN_RATE_PER_CUST_TY).toFixed(2)}
                    </th>
                    <th>
                      {data.AVG_TRAN_TY === "-999999"
                        ? "-"
                        : Number(data.AVG_TRAN_TY).toFixed(2)}
                    </th>
                  </tr>
                );
              })
            )}
          </tbody>
        </Table>
      </div>
    </div>
  );
}

export default DecilesHome;
