import React, { useState, useEffect, useCallback } from "react";
import { useSelector, useDispatch } from "react-redux";
import { Dropdown, Form, Placeholder } from "react-bootstrap";
import axios from "axios";
import DatePicker from "react-datetime";
import moment from "moment";
import "../HomePage/HomePage.css";
import { handleDecilesDateChange } from "../../Redux/Actions/DateChangeActions";
import { handleDecilesBannerChange } from "../../Redux/Actions/BannerChangeActions";
import { handleDecilesCategoryChange } from "../../Redux/Actions/CategoryChangeActions";
import { handleCategoryChange } from "../../Redux/Actions/CategoryChangeActions";
import DecilesHome from "./DecilesHome";
import calender from "../../assests/images/calender.svg";
import { getDateFormat, getDateMinusTwoYear } from "../Utils";
import { UTCtoEST } from "../Utils";
import NotificationMessage from "../NotificationMessage/NotificationMessage";
import NoAccess from "../NoAccess/NoAccess";

const DecileBanners = [
  { value: "All Banner", id: "0" },
  { value: "BBBY US", id: "1" },
  { value: "BBBY CA", id: "2" },
  { value: "buy buy Baby", id: "3" },
  { value: "Harmon", id: "5" },
];
const Deciles = [
  { value: "Net Sales", id: "NET" },
  { value: "Transactions", id: "TR" },
  { value: "Product Margin", id: "PR" },
];
function DecilesContainer() {
  const dispatch = useDispatch();
  let dateObjforMax = new Date();
  dateObjforMax.setUTCDate(dateObjforMax.getUTCDate() - 2);
  let Maxday = dateObjforMax.getUTCDate();
  let Maxyear = dateObjforMax.getUTCFullYear();
  let Maxmonth = dateObjforMax.getUTCMonth() + 1; //months from 1-12
  let MaxDayforPicker =
    Maxyear +
    "-" +
    (Maxmonth < 10 ? `0${Maxmonth}` : Maxmonth) +
    "-" +
    (Maxday < 10 ? `0${Maxday}` : Maxday);

  const [selectedDecileBanner, setSelectedDecileBanner] = useState(
    DecileBanners[0]
  );
  const [selectedDecile, setSelectedDecile] = useState(Deciles[0]);
  const selectedDecileBannerId = useSelector((store) => store.DecileBanner.id);
  const selectedDecileId = useSelector((store) => store.DecileCategory.id);
  const selectedDate = useSelector((store) => store.DecileDate.value);
  const selectedCategoryId = useSelector((store) => store.Category.id);
  const [DecilesHomeData, setDecilesHomeData] = useState();
  const [DecilesHomeTotalData, setDecilesHomeTotalData] = useState();
  const [DecilesHomeSubTotalData, setDecilesHomeSubTotalData] = useState();
  const [decileRecordAvailableDates, setDecileRecordAvailableDates] =
    useState();
  const [periodStartDate, setPeriodStartDate] = useState("");
  const [periodEndDate, setPeriodEndDate] = useState("");
  const [refreshTime, setRefreshTime] = useState("");

  const refreshDate =
    refreshTime.length > 0 && UTCtoEST(refreshTime[0].end_time * 1000);

  const [loading, setloader] = useState({
    DecileHome: false,
    DecileHomeTotal: false,
    record_dates: false,
    DecileHomeSubTotal: false,
    refreshTime: false,
  });
  const [chkBox, isChkBox] = useState({
    isAllCust: true,
    isBPlus: false,
    isCc: false,
    isBcc: false,
    isApp: false,
  });
  const [defaultDate, setDefaultDate] = useState(moment().subtract(2, "days"));

  if (selectedCategoryId === "ALL") {
    chkBox.isAllCust = true;
  }
  const [disableBplus, isdisableBplus] = useState(false);
  const handleDecileBanner = useCallback(
    (event) => {
      setSelectedDecileBanner((prevsValue) => ({
        ...prevsValue,
        value: event.target.innerText,
        id: event.target.id,
      }));
      dispatch(
        handleDecilesBannerChange({
          value: event.target.innerText,
          id: event.target.id,
        })
      );
    },
    [selectedDecileBannerId]
  );
  // const handleDate = (event) => {
  //   dispatch(handleDecilesDateChange(event));
  // };

  const handleDate = (dateSelected) => {
    setPeriodStartDate(getDateMinusTwoYear(dateSelected));
    setPeriodEndDate(moment(dateSelected));
    if (moment(dateSelected, "MM/DD/YYYY", true).isValid()) {
      setDefaultDate();
      dispatch(handleDecilesDateChange(dateSelected.format("YYYY-MM-DD")));
    } else {
      setDefaultDate(moment().subtract(2, "days"));
    }
  };

  const handleDecile = useCallback((event) => {
    setSelectedDecile((prevsValue) => ({
      ...prevsValue,
      value: event.target.innerText,
      id: event.target.id,
    }));
    dispatch(
      handleDecilesCategoryChange({
        value: event.target.innerText,
        id: event.target.id,
      })
    );
  }, []);

  const onChangeCheck = useCallback(
    (e) => {
      if (e.target.value === "ALL") {
        isChkBox(() => ({
          isAllCust: true,
          isBPlus: false,
          isCc: false,
          isApp: false,
        }));
        dispatch(
          handleCategoryChange({
            value: e.target.id,
            id: e.target.value,
          })
        );
      } else if (e.target.value === "BPLUS") {
        isChkBox((value) => ({
          ...value,
          isAllCust: false,
          isBPlus: !chkBox.isBPlus,
        }));
        if (e.target.checked) {
          setSelectedDecileBanner({ value: "BBBY US", id: "1" });
          dispatch(
            handleCategoryChange({
              value:
                chkBox.isCc && chkBox.isApp
                  ? "BCA"
                  : chkBox.isCc
                  ? "BC"
                  : chkBox.isApp
                  ? "BA"
                  : e.target.id,
              id:
                chkBox.isCc && chkBox.isApp
                  ? "BCA"
                  : chkBox.isCc
                  ? "BC"
                  : chkBox.isApp
                  ? "BA"
                  : e.target.value,
            })
          );
          dispatch(handleDecilesBannerChange({ value: "BBBY US", id: "1" }));
        } else {
          setSelectedDecileBanner({ value: "BBBY US", id: "1" });
          dispatch(
            handleCategoryChange({
              value:
                chkBox.isCc && chkBox.isApp
                  ? "CA"
                  : chkBox.isCc
                  ? "CC"
                  : chkBox.isApp
                  ? "APP"
                  : "ALL",
              id:
                chkBox.isCc && chkBox.isApp
                  ? "CA"
                  : chkBox.isCc
                  ? "CC"
                  : chkBox.isApp
                  ? "APP"
                  : "ALL",
            })
          );
          dispatch(handleDecilesBannerChange({ value: "BBBY US", id: "1" }));
        }
      } else if (e.target.value === "CC") {
        isChkBox((value) => ({
          ...value,
          isAllCust: false,
          isCc: !chkBox.isCc,
        }));
        if (e.target.checked) {
          setSelectedDecileBanner({ value: "BBBY US", id: "1" });
          dispatch(
            handleCategoryChange({
              value:
                chkBox.isBPlus && chkBox.isApp
                  ? "BCA"
                  : chkBox.isApp
                  ? "CA"
                  : chkBox.isBPlus
                  ? "BC"
                  : e.target.id,
              id:
                chkBox.isBPlus && chkBox.isApp
                  ? "BCA"
                  : chkBox.isApp
                  ? "CA"
                  : chkBox.isBPlus
                  ? "BC"
                  : e.target.value,
            })
          );
          dispatch(handleDecilesBannerChange({ value: "BBBY US", id: "1" }));
        } else {
          setSelectedDecileBanner({ value: "BBBY US", id: "1" });
          dispatch(
            handleCategoryChange({
              value:
                chkBox.isBPlus && chkBox.isApp
                  ? "BA"
                  : chkBox.isBPlus
                  ? "BPLUS"
                  : chkBox.isApp
                  ? "APP"
                  : "ALL",
              id:
                chkBox.isBPlus && chkBox.isApp
                  ? "BA"
                  : chkBox.isBPlus
                  ? "BPLUS"
                  : chkBox.isApp
                  ? "APP"
                  : "ALL",
            })
          );
          dispatch(handleDecilesBannerChange({ value: "BBBY US", id: "1" }));
        }
      } else if (e.target.value === "APP") {
        isChkBox((value) => ({
          ...value,
          isAllCust: false,
          isApp: !chkBox.isApp,
        }));
        if (e.target.checked) {
          dispatch(
            handleCategoryChange({
              value:
                chkBox.isBPlus && chkBox.isCc
                  ? "BCA"
                  : chkBox.isCc
                  ? "CA"
                  : chkBox.isBPlus
                  ? "BA"
                  : e.target.id,
              id:
                chkBox.isBPlus && chkBox.isCc
                  ? "BCA"
                  : chkBox.isCc
                  ? "CA"
                  : chkBox.isBPlus
                  ? "BA"
                  : e.target.value,
            })
          );
        } else {
          dispatch(
            handleCategoryChange({
              value:
                chkBox.isBPlus && chkBox.isCc
                  ? "BC"
                  : chkBox.isBPlus
                  ? "BPLUS"
                  : chkBox.isCc
                  ? "CC"
                  : "ALL",
              id:
                chkBox.isBPlus && chkBox.isCc
                  ? "BC"
                  : chkBox.isBPlus
                  ? "BPLUS"
                  : chkBox.isCc
                  ? "CC"
                  : "ALL",
            })
          );
        }
      }
      if (selectedCategoryId === "BCA") {
        setSelectedDecileBanner({ value: "BBBY US", id: "1" });
        dispatch(handleDecilesBannerChange({ value: "BBBY US", id: "1" }));
      }
    },
    [selectedCategoryId]
  );

  useEffect(() => {
    setPeriodStartDate(getDateMinusTwoYear(defaultDate));
    setPeriodEndDate(moment(defaultDate));
  }, []);

  useEffect(() => {
    const getDecileRecordAvailableDates = async () => {
      try {
        setloader((currValue) => ({
          ...currValue,
          record_dates: true,
        }));
        let url =
          process.env.REACT_APP_API_ENDPOINT +
          process.env.REACT_APP_DECILE_RECORD_AVAILABLE_DATES +
          "concept=" +
          selectedDecileBannerId +
          "&decileInd=" +
          selectedDecileId +
          "&customerType=" +
          selectedCategoryId;
        await axios({ url }).then((res) => {
          setloader((currValue) => ({
            ...currValue,
            record_dates: false,
          }));
          setDecileRecordAvailableDates(res.data);
        });
      } catch (err) {
        console.log("err-getDecileRecordAvailableDates", err);
        setloader((currValue) => ({
          ...currValue,
          record_dates: false,
        }));
      }
    };

    getDecileRecordAvailableDates();
  }, [selectedDecileId, selectedDecileBannerId, selectedCategoryId]);

  useEffect(() => {
    const fatchDecileHome = async () => {
      try {
        setloader((currValue) => ({
          ...currValue,
          DecileHome: true,
        }));
        let url =
          process.env.REACT_APP_API_ENDPOINT +
          process.env.REACT_APP_DECILE_HOME +
          "concept=" +
          selectedDecileBannerId +
          "&date=" +
          selectedDate +
          "&decileInd=" +
          selectedDecileId +
          "&customerType=" +
          selectedCategoryId;
        await axios({ url }).then((res) => {
          setloader((currValue) => ({
            ...currValue,
            DecileHome: false,
          }));
          setDecilesHomeData(
            res.data.sort((a, b) => {
              return Number(a.DECILE) - Number(b.DECILE);
            })
          );
        });
      } catch (err) {
        console.log("err-fatchDecileHome", err);
        setloader((currValue) => ({
          ...currValue,
          DecileHome: false,
        }));
      }
    };
    const fatchDecileHomeTotal = async () => {
      try {
        setloader((currValue) => ({
          ...currValue,
          DecileHomeTotal: true,
        }));
        let url =
          process.env.REACT_APP_API_ENDPOINT +
          process.env.REACT_APP_DECILE_HOME_TOTAL +
          "concept=" +
          selectedDecileBannerId +
          "&date=" +
          selectedDate +
          "&decileInd=" +
          selectedDecileId +
          "&customerType=" +
          selectedCategoryId;
        await axios({ url }).then((res) => {
          setloader((currValue) => ({
            ...currValue,
            DecileHomeTotal: false,
          }));
          setDecilesHomeTotalData(res.data);
        });
      } catch (err) {
        console.log("err-fatchDecileHomeTotal", err);
        setloader((currValue) => ({
          ...currValue,
          DecileHomeTotal: false,
        }));
      }
    };

    const fatchDecileHomeBPLUSTotal = async () => {
      try {
        setloader((currValue) => ({
          ...currValue,
          DecileHomeTotal: true,
        }));
        let url =
          process.env.REACT_APP_API_ENDPOINT +
          process.env.REACT_APP_DECILE_HOME_BPLUS_TOTAL +
          "&date=" +
          selectedDate +
          "&decileInd=" +
          selectedDecileId;
        await axios({ url }).then((res) => {
          setloader((currValue) => ({
            ...currValue,
            DecileHomeTotal: false,
          }));
          setDecilesHomeTotalData(res.data);
        });
      } catch (err) {
        console.log("err-fatchDecileHomeBPlusTotal", err);
        setloader((currValue) => ({
          ...currValue,
          DecileHomeTotal: false,
        }));
      }
    };

    const fetchDecileHomeSubTotal = async () => {
      try {
        setloader((currValue) => ({
          ...currValue,
          DecileHomeSubTotal: true,
        }));
        let url =
          process.env.REACT_APP_API_ENDPOINT +
          process.env.REACT_APP_CUSTOMER_Second_half_total +
          "concept=" +
          selectedDecileBannerId +
          "&date=" +
          selectedDate +
          "&customerType=BPLUS" +
          "&channelType=ALL";
        await axios({ url }).then((res) => {
          setloader((currValue) => ({
            ...currValue,
            DecileHomeSubTotal: false,
          }));
          setDecilesHomeSubTotalData(res.data);
        });
      } catch (err) {
        console.log("err-fatchDecileHomeSubTotal", err);
        setloader((currValue) => ({
          ...currValue,
          DecileHomeSubTotal: false,
        }));
      }
    };

    fatchDecileHome();
    if (selectedCategoryId === "BPLUS") {
      fetchDecileHomeSubTotal();
      fatchDecileHomeBPLUSTotal();
    } else {
      setDecilesHomeSubTotalData();
      fatchDecileHomeTotal();
    }
  }, [
    selectedDecileId,
    selectedDecileBannerId,
    selectedDate,
    selectedCategoryId,
  ]);

  let customDatess =
    decileRecordAvailableDates &&
    decileRecordAvailableDates.map((item) => {
      return item["TRANS_DATE"];
    });
  // const maxDay = moment().subtract(2, "days");
  const disableCustomDt = (current) => {
    return (
      customDatess && customDatess.includes(current.format("YYYY-MM-DD")) //&&
      //current.isBefore(maxDay) // &&
      // !current.isBefore(moment("2022-02-28").toDate())
    );
  };

  useEffect(() => {
    const getLastRefreshTime = async () => {
      try {
        setloader((currValue) => ({
          ...currValue,
          refreshTime: true,
        }));
        let url =
          process.env.REACT_APP_API_ENDPOINT +
          process.env.REACT_APP_REFRESH_TIME +
          "dagId=DECILES";
        await axios({ url }).then((res) => {
          setloader((currValue) => ({
            ...currValue,
            refreshTime: false,
          }));
          setRefreshTime(res.data);
        });
      } catch (err) {
        setloader((currValue) => ({
          ...currValue,
          refreshTime: true,
        }));
        console.log("err-getLastRefreshTime", err);
      }
    };
    getLastRefreshTime();
  }, []);

  return localStorage.getItem("isDECILES") === "Y" ? (
    <div>
      {refreshTime.length > 0 && <NotificationMessage message={refreshDate} />}
      <div className="mt-1 d-flex align-items-center headings">
        <div className="d-flex justify-content-start p-3">
          <span className="progselectupText">Concept</span>
        </div>
        <div className="d-flex justify-content-start p-3">
          <span className="progselectupText">Type</span>
        </div>
      </div>
      <div className="mt-3 d-flex align-items-center">
        <div className="d-flex justify-content-start p-3">
          <Dropdown className="d-inline">
            <Dropdown.Toggle>{selectedDecileBanner.value}</Dropdown.Toggle>
            <Dropdown.Menu
              className="dropdown-menu-ext"
              onClick={(e) => handleDecileBanner(e)}
            >
              {selectedCategoryId === "BPLUS" ||
              selectedCategoryId === "BC" ||
              selectedCategoryId === "BCA"
                ? DecileBanners.filter((banner) => {
                    return banner.id === "1";
                  }).map((banner) => {
                    return (
                      <Dropdown.Item
                        key={banner.id}
                        className="dropdown-item-ext"
                        id={banner.id}
                      >
                        {banner.value}
                      </Dropdown.Item>
                    );
                  })
                : DecileBanners.map((data) => {
                    return (
                      <Dropdown.Item
                        key={data.id}
                        className="dropdown-item-ext"
                        id={data.id}
                      >
                        {data.value}
                      </Dropdown.Item>
                    );
                  })}
            </Dropdown.Menu>
          </Dropdown>
        </div>
        <div className="d-flex justify-content-start p-3">
          <label className="chkBox-label">
            <input
              type="checkbox"
              checked={chkBox.isAllCust}
              onChange={onChangeCheck}
              value="ALL"
              id="All Customers"
              className="chkBox"
            />{" "}
            All Customers
          </label>
        </div>
        <div className="d-flex justify-content-start p-3">
          <label className="chkBox-label">
            <input
              type="checkbox"
              checked={chkBox.isBPlus}
              onChange={onChangeCheck}
              value="BPLUS"
              id="Beyond+"
              className="chkBox"
              disabled={disableBplus}
            />{" "}
            Beyond+
          </label>
        </div>
        <div className="d-flex justify-content-start p-3">
          <label className="chkBox-label">
            <input
              type="checkbox"
              checked={chkBox.isCc}
              onChange={onChangeCheck}
              value="CC"
              id="Credit Card"
              className="chkBox"
            />{" "}
            Credit Card
          </label>
        </div>
        {/* <div>
            <label>
              <input type="checkbox"
                checked={chkBox.isBcc}
                onChange={onChangeCheck}
                value='BCC'
                id={`Beyond+ & Credit Card`}
              />
              {`Beyond+ & Credit Card`}
            </label>
          </div> */}
        <div className="d-flex justify-content-start p-3">
          <label className="chkBox-label">
            <input
              type="checkbox"
              checked={chkBox.isApp}
              onChange={onChangeCheck}
              value="APP"
              id="APP"
              className="chkBox"
            />{" "}
            APP
          </label>
        </div>
        <div className="d-flex justify-content-start p-3">
          <Dropdown className="d-inline">
            <Dropdown.Toggle>{selectedDecile.value}</Dropdown.Toggle>
            <Dropdown.Menu
              className="dropdown-menu-ext"
              onClick={(e) => handleDecile(e)}
            >
              {Deciles.map((data) => {
                return (
                  <Dropdown.Item
                    key={data.id}
                    className="dropdown-item-ext"
                    id={data.id}
                  >
                    {data.value}
                  </Dropdown.Item>
                );
              })}
            </Dropdown.Menu>
          </Dropdown>
        </div>
        {/* <div className="d-flex justify-content-start p-3">
          <Form.Group controlId="duedate">
            <Form.Control
              type="date"
              name="datePicker"
              placeholder="select a Date"
              value={selectedDate}
              onChange={(e) => handleDate(e.target.value)}
              max={MaxDayforPicker}
            />
          </Form.Group>
        </div> */}
        {loading.record_dates ? (
          <Placeholder.Button xs={1} />
        ) : (
          <div className="d-flex justify-content-start p-3">
            <label
              className="d-flex datepicker"
              onClick={(e) => e.preventDefault()}
            >
              <DatePicker
                timeFormat={false}
                value={
                  defaultDate
                    ? defaultDate
                    : moment(selectedDate).format("MM/DD/YYYY")
                }
                isValidDate={disableCustomDt}
                onChange={(date) => handleDate(date)}
                closeOnSelect
                inputProps={{ readOnly: true }}
              />
              <img src={calender} className="date-picker-icon" />
            </label>
          </div>
        )}
        <div
          className="d-flex justify-content-start p-3"
          style={{ marginLeft: "-6rem" }}
        >
          {!loading.record_dates && periodStartDate !== "" ? (
            <div>
              <span>{`(${getDateFormat(periodStartDate)} - ${getDateFormat(
                periodEndDate
              )})`}</span>
            </div>
          ) : (
            ""
          )}
        </div>
      </div>

      <DecilesHome
        DecilesHomeData={DecilesHomeData}
        DecilesHomeTotalData={DecilesHomeTotalData}
        loading={loading}
        DecilesHomeSubTotalData={DecilesHomeSubTotalData}
      />
    </div>
  ) : (
    <NoAccess tabName="Deciles" />
  );
}

export default DecilesContainer;
