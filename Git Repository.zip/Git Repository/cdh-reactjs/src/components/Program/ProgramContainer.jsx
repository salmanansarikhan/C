import React, { useState, useEffect, useCallback } from "react";
import { useSelector, useDispatch } from "react-redux";
import { Dropdown, Form, Placeholder } from "react-bootstrap";
import axios from "axios";
import DatePicker from "react-datetime";
import moment from "moment";
import ProgramHome from "./ProgramHome";
import "../HomePage/HomePage.css";
import { handleProgramDateChange } from "../../Redux/Actions/DateChangeActions";
import { handleProgramBannerChange } from "../../Redux/Actions/BannerChangeActions";
import { handleProgramCategoryChange } from "../../Redux/Actions/CategoryChangeActions";
import calender from "../../assests/images/calender.svg";
import { getDateFormat, getDateMinusTwoYear } from "../Utils";
import { UTCtoEST } from "../Utils";
import NotificationMessage from "../NotificationMessage/NotificationMessage";
import NoAccess from "../NoAccess/NoAccess";

const ProgramBanners = [
  { value: "All Banner", id: "0" },
  { value: "BBBY US", id: "1" },
  { value: "BBBY CA", id: "2" },
  { value: "buy buy Baby", id: "3" },
  { value: "Harmon", id: "5" },
];

function ProgramContainer() {
  const dispatch = useDispatch();
  let dateObjforMax = new Date();
  dateObjforMax.setUTCDate(dateObjforMax.getUTCDate() - 2);
  let Maxday = dateObjforMax.getUTCDate();
  let Maxyear = dateObjforMax.getUTCFullYear();
  let Maxmonth = dateObjforMax.getUTCMonth() + 1; //months from 1-12
  let MaxDayforPicker =
    Maxyear +
    "-" +
    (Maxmonth < 10 ? `0${Maxmonth}` : Maxmonth) +
    "-" +
    (Maxday < 10 ? `0${Maxday}` : Maxday);

  const [selectedProgramBanner, setSelectedProgramBanner] = useState(
    ProgramBanners[0]
  );
  const [customerProgramActiveData, setCustomerProgramActiveData] = useState();
  const [customerProgramActiveExisting, setcustomerProgramActiveExisting] =
    useState();
  const [customerProgramDataSixMonths, setcustomerProgramDataSixMonths] =
    useState();
  const [customerProgramDataNineMonths, setcustomerProgramDataNineMonths] =
    useState();
  const [
    firstCustomerProgramFourTotalData,
    setCustomerProgramFirst_Four_Total_Data,
  ] = useState();
  const [
    customerProgramInActive_12_18_Data,
    setcustomerProgramInActive_12_18_Data,
  ] = useState();
  const [
    customerProgramInActive_18_24_Data,
    setcustomerProgramInActive_18_24_Data,
  ] = useState();
  const [
    secondCustomerProgramhalftotalData,
    setCustomerProgramSecond_half_total_Data,
  ] = useState();
  const [customerProgramTotal, setProgramTotal] = useState();
  const [programRecordAvailableDates, setProgramRecordAvailableDates] =
    useState();
  const [periodStartDate, setPeriodStartDate] = useState("");
  const [periodEndDate, setPeriodEndDate] = useState("");
  const [refreshTime, setRefreshTime] = useState("");

  const refreshDate =
    refreshTime.length > 0 && UTCtoEST(refreshTime[0].end_time * 1000);

  const [loading, setloader] = useState({
    AtRisk_6m_9m: false,
    AtRisk_9m_12m: false,
    Active_Existing: false,
    Active_L12m: false,
    Inactive_12m_18m: false,
    Inactive_18m_24m: false,
    UnIdentifed_Customers: false,
    first_half_total: false,
    second_half_total: false,
    total: false,
    first_Four_Total: false,
    Inactive_24mp: false,
    record_dates: false,
    refreshTime: false,
  });
  const [chkBox, isChkBox] = useState({
    isSdd: true,
    isBopis: false,
    isSddBopis: false,
  });
  const selectedProgramBannerId = useSelector(
    (store) => store.ProgramBanner.id
  );
  const selectedProgramCategoryId = useSelector(
    (store) => store.ProgramCategory.id
  );
  const selectedProgramDate = useSelector((store) => store.ProgramDate.value);

  const [defaultDate, setDefaultDate] = useState(moment().subtract(2, "days"));

  if (selectedProgramCategoryId === "SDD") {
    chkBox.isSdd = true;
  }

  const handleProgramBanner = useCallback(
    (event) => {
      setSelectedProgramBanner((prevsValue) => ({
        ...prevsValue,
        value: event.target.innerText,
        id: event.target.id,
      }));
      dispatch(
        handleProgramBannerChange({
          value: event.target.innerText,
          id: event.target.id,
        })
      );
    },
    [selectedProgramBannerId]
  );

  // const handleProgramDate = (event) => {
  //   dispatch(handleProgramDateChange(event));
  // };

  const handleProgramDate = (dateSelected) => {
    setPeriodStartDate(getDateMinusTwoYear(dateSelected));
    setPeriodEndDate(moment(dateSelected));
    if (moment(dateSelected, "MM/DD/YYYY", true).isValid()) {
      setDefaultDate();
      dispatch(handleProgramDateChange(dateSelected.format("YYYY-MM-DD")));
    } else {
      setDefaultDate(moment().subtract(2, "days"));
    }
  };

  const onChangeCheck = useCallback(
    (e) => {
      if (e.target.value === "SDD") {
        isChkBox((value) => ({
          ...value,
          isSdd: !chkBox.isSdd,
        }));
        if (e.target.checked) {
          dispatch(
            handleProgramCategoryChange({
              value:
                chkBox.isBopis && chkBox.isSddBopis
                  ? "SDD_BOPIS_BOPIS_SDD"
                  : chkBox.isBopis
                  ? "SDD_BOPIS"
                  : chkBox.isSddBopis
                  ? "SDD_BOPIS_SDD"
                  : e.target.id,
              id:
                chkBox.isBopis && chkBox.isSddBopis
                  ? "SDD_BOPIS_BOPIS_SDD"
                  : chkBox.isBopis
                  ? "SDD_BOPIS"
                  : chkBox.isSddBopis
                  ? "SDD_BOPIS_SDD"
                  : e.target.value,
            })
          );
        } else {
          dispatch(
            handleProgramCategoryChange({
              value:
                chkBox.isBopis && chkBox.isSddBopis
                  ? "BOPIS_BOPIS_SDD"
                  : chkBox.isBopis
                  ? "BOPIS"
                  : chkBox.isSddBopis
                  ? "BOPIS_SDD"
                  : "SDD",
              id:
                chkBox.isBopis && chkBox.isSddBopis
                  ? "BOPIS_BOPIS_SDD"
                  : chkBox.isBopis
                  ? "BOPIS"
                  : chkBox.isSddBopis
                  ? "BOPIS_SDD"
                  : "SDD",
            })
          );
        }
      } else if (e.target.value === "BOPIS") {
        isChkBox((value) => ({
          ...value,
          isBopis: !chkBox.isBopis,
        }));
        if (e.target.checked) {
          dispatch(
            handleProgramCategoryChange({
              value:
                chkBox.isSdd && chkBox.isSddBopis
                  ? "SDD_BOPIS_BOPIS_SDD"
                  : chkBox.isSdd
                  ? "SDD_BOPIS"
                  : chkBox.isSddBopis
                  ? "BOPIS_BOPIS_SDD"
                  : e.target.id,
              id:
                chkBox.isSdd && chkBox.isSddBopis
                  ? "SDD_BOPIS_BOPIS_SDD"
                  : chkBox.isSdd
                  ? "SDD_BOPIS"
                  : chkBox.isSddBopis
                  ? "BOPIS_BOPIS_SDD"
                  : e.target.value,
            })
          );
        } else {
          dispatch(
            handleProgramCategoryChange({
              value:
                chkBox.isSdd && chkBox.isSddBopis
                  ? "SDD_BOPIS_SDD"
                  : chkBox.isSdd
                  ? "SDD"
                  : chkBox.isSddBopis
                  ? "BOPIS_SDD"
                  : "SDD",
              id:
                chkBox.isSdd && chkBox.isSddBopis
                  ? "SDD_BOPIS_SDD"
                  : chkBox.isSdd
                  ? "SDD"
                  : chkBox.isSddBopis
                  ? "BOPIS_SDD"
                  : "SDD",
            })
          );
        }
      } else if (e.target.value === "BOPIS_SDD") {
        isChkBox((value) => ({
          ...value,
          isSddBopis: !chkBox.isSddBopis,
        }));
        if (e.target.checked) {
          dispatch(
            handleProgramCategoryChange({
              value:
                chkBox.isSdd && chkBox.isBopis
                  ? "SDD_BOPIS_BOPIS_SDD"
                  : chkBox.isSdd
                  ? "SDD_BOPIS_SDD"
                  : chkBox.isBopis
                  ? "BOPIS_BOPIS_SDD"
                  : e.target.id,
              id:
                chkBox.isSdd && chkBox.isBopis
                  ? "SDD_BOPIS_BOPIS_SDD"
                  : chkBox.isSdd
                  ? "SDD_BOPIS_SDD"
                  : chkBox.isBopis
                  ? "BOPIS_BOPIS_SDD"
                  : e.target.value,
            })
          );
        } else {
          dispatch(
            handleProgramCategoryChange({
              value:
                chkBox.isSdd && chkBox.isBopis
                  ? "SDD_BOPIS"
                  : chkBox.isSdd
                  ? "SDD"
                  : chkBox.isBopis
                  ? "BOPIS"
                  : "SDD",
              id:
                chkBox.isSdd && chkBox.isBopis
                  ? "SDD_BOPIS"
                  : chkBox.isSdd
                  ? "SDD"
                  : chkBox.isBopis
                  ? "BOPIS"
                  : "SDD",
            })
          );
        }
      }
    },
    [selectedProgramCategoryId]
  );

  useEffect(() => {
    setPeriodStartDate(getDateMinusTwoYear(defaultDate));
    setPeriodEndDate(moment(defaultDate));
  }, []);

  useEffect(() => {
    const getProgramRecordAvailableDates = async () => {
      try {
        setloader((currValue) => ({
          ...currValue,
          record_dates: true,
        }));
        let url =
          process.env.REACT_APP_API_ENDPOINT +
          process.env.REACT_APP_RECORD_AVAILABLE_DATES +
          "concept=" +
          selectedProgramBannerId +
          "&date=" +
          selectedProgramDate +
          "&channelType=" +
          selectedProgramCategoryId +
          "&customerType=" +
          "ALL";
        await axios({ url }).then((res) => {
          setloader((currValue) => ({
            ...currValue,
            record_dates: false,
          }));
          setProgramRecordAvailableDates(res.data);
        });
      } catch (err) {
        console.log("err-getProgramRecordAvailableDates", err);
        setloader((currValue) => ({
          ...currValue,
          record_dates: false,
        }));
      }
    };

    getProgramRecordAvailableDates();
  }, [selectedProgramBannerId, selectedProgramCategoryId]);

  useEffect(() => {
    const fetchCustomerProgramDataActive = async () => {
      try {
        setloader((currValue) => ({
          ...currValue,
          Active_L12m: true,
        }));
        let url =
          process.env.REACT_APP_API_ENDPOINT +
          process.env.REACT_APP_CUSTOMER_Active +
          "concept=" +
          selectedProgramBannerId +
          "&date=" +
          selectedProgramDate +
          "&channelType=" +
          selectedProgramCategoryId +
          "&customerType=" +
          "ALL";
        await axios({ url }).then((res) => {
          setCustomerProgramActiveData(res.data);
          setloader((currValue) => ({
            ...currValue,
            Active_L12m: false,
          }));
        });
      } catch (err) {
        console.log("err-fetchCustomerProgramDataActive", err);
        setloader((currValue) => ({
          ...currValue,
          Active_L12m: false,
        }));
      }
    };

    const fetchCustomerProgramDataActiveExisting = async () => {
      try {
        setloader((currValue) => ({
          ...currValue,
          Active_Existing: true,
        }));
        let url =
          process.env.REACT_APP_API_ENDPOINT +
          process.env.REACT_APP_CUSTOMER_Active_Existing +
          "concept=" +
          selectedProgramBannerId +
          "&date=" +
          selectedProgramDate +
          "&channelType=" +
          selectedProgramCategoryId +
          "&customerType=" +
          "ALL";
        await axios({ url }).then((res) => {
          setcustomerProgramActiveExisting(res.data);
          setloader((currValue) => ({
            ...currValue,
            Active_Existing: false,
          }));
        });
      } catch (err) {
        console.log("err-fetchCustomerProgramDataActiveExisting", err);
        setloader((currValue) => ({
          ...currValue,
          Active_Existing: false,
        }));
      }
    };

    const fetchProgramCustomerDataSixMonths = async () => {
      try {
        setloader((currValue) => ({
          ...currValue,
          AtRisk_6m_9m: true,
        }));
        let url =
          process.env.REACT_APP_API_ENDPOINT +
          process.env.REACT_APP_CUSTOMER_6m_9m +
          "concept=" +
          selectedProgramBannerId +
          "&date=" +
          selectedProgramDate +
          "&channelType=" +
          selectedProgramCategoryId +
          "&customerType=" +
          "ALL";
        await axios({ url }).then((res) => {
          setloader((currValue) => ({
            ...currValue,
            AtRisk_6m_9m: false,
          }));
          setcustomerProgramDataSixMonths(res.data);
        });
      } catch (err) {
        console.log("err-fetchProgramCustomerDataSixMonths", err);
        setloader((currValue) => ({
          ...currValue,
          AtRisk_6m_9m: false,
        }));
      }
    };

    const fetchProgramCustomerDataNineMonths = async () => {
      try {
        setloader((currValue) => ({
          ...currValue,
          AtRisk_9m_12m: true,
        }));
        let url =
          process.env.REACT_APP_API_ENDPOINT +
          process.env.REACT_APP_CUSTOMER_9m_12m +
          "concept=" +
          selectedProgramBannerId +
          "&date=" +
          selectedProgramDate +
          "&channelType=" +
          selectedProgramCategoryId +
          "&customerType=" +
          "ALL";
        await axios({ url }).then((res) => {
          setcustomerProgramDataNineMonths(res.data);
          setloader((currValue) => ({
            ...currValue,
            AtRisk_9m_12m: false,
          }));
        });
      } catch (err) {
        console.log("err-fetchcustomerProgramDataNineMonths", err);
        setloader((currValue) => ({
          ...currValue,
          AtRisk_9m_12m: false,
        }));
      }
    };

    const fetchProgramfirstFourTotal = async () => {
      try {
        setloader((currValue) => ({
          ...currValue,
          first_half_total: true,
        }));
        let url =
          process.env.REACT_APP_API_ENDPOINT +
          process.env.REACT_APP_CUSTOMER_First_Four_Total +
          "concept=" +
          selectedProgramBannerId +
          "&date=" +
          selectedProgramDate +
          "&channelType=" +
          selectedProgramCategoryId +
          "&customerType=" +
          "ALL";
        await axios({ url }).then((res) => {
          setCustomerProgramFirst_Four_Total_Data(res.data);
          setloader((currValue) => ({
            ...currValue,
            first_Four_Total: false,
          }));
        });
      } catch (err) {
        console.log("err-fetchProgramfirstFourTotal", err);
        setloader((currValue) => ({
          ...currValue,
          first_Four_Total: false,
        }));
      }
    };

    const fetchProgramCustomerDataInActive_12_18 = async () => {
      try {
        setloader((currValue) => ({
          ...currValue,
          Inactive_12m_18m: true,
        }));
        let url =
          process.env.REACT_APP_API_ENDPOINT +
          process.env.REACT_APP_CUSTOMER_InActive_12_18 +
          "concept=" +
          selectedProgramBannerId +
          "&date=" +
          selectedProgramDate +
          "&channelType=" +
          selectedProgramCategoryId +
          "&customerType=" +
          "ALL";
        await axios({ url }).then((res) => {
          setcustomerProgramInActive_12_18_Data(res.data);
          setloader((currValue) => ({
            ...currValue,
            Inactive_12m_18m: false,
          }));
        });
      } catch (err) {
        console.log("err-fetchProgramCustomerDataInActive_12_18", err);
        setloader((currValue) => ({
          ...currValue,
          Inactive_12m_18m: false,
        }));
      }
    };

    const fetchProgramCustomerDataInActive_18_24 = async () => {
      try {
        setloader((currValue) => ({
          ...currValue,
          Inactive_18m_24m: true,
        }));
        let url =
          process.env.REACT_APP_API_ENDPOINT +
          process.env.REACT_APP_CUSTOMER_InActive_18_24 +
          "concept=" +
          selectedProgramBannerId +
          "&date=" +
          selectedProgramDate +
          "&channelType=" +
          selectedProgramCategoryId +
          "&customerType=" +
          "ALL";
        await axios({ url }).then((res) => {
          setcustomerProgramInActive_18_24_Data(res.data);
          setloader((currValue) => ({
            ...currValue,
            Inactive_18m_24m: false,
          }));
        });
      } catch (err) {
        console.log("err-fetchProgramCustomerDataInActive_18_24", err);
        setloader((currValue) => ({
          ...currValue,
          Inactive_18m_24m: false,
        }));
      }
    };

    const fetchProgramTotalsecondHalf = async () => {
      try {
        setloader((currValue) => ({
          ...currValue,
          second_half_total: true,
        }));
        let url =
          process.env.REACT_APP_API_ENDPOINT +
          process.env.REACT_APP_CUSTOMER_Second_half_total +
          "concept=" +
          selectedProgramBannerId +
          "&date=" +
          selectedProgramDate +
          "&channelType=" +
          selectedProgramCategoryId +
          "&customerType=" +
          "ALL";
        await axios({ url }).then((res) => {
          setCustomerProgramSecond_half_total_Data(res.data);
          setloader((currValue) => ({
            ...currValue,
            second_half_total: false,
          }));
        });
      } catch (err) {
        console.log("err-fetchProgramTotalsecondHalf", err);
        setloader((currValue) => ({
          ...currValue,
          second_half_total: false,
        }));
      }
    };

    const fetchcustomerProgramTotal = async () => {
      try {
        setloader((currValue) => ({
          ...currValue,
          total: true,
        }));
        let url =
          process.env.REACT_APP_API_ENDPOINT +
          process.env.REACT_APP_CUSTOMER_total +
          "concept=" +
          selectedProgramBannerId +
          "&date=" +
          selectedProgramDate +
          "&channelType=" +
          selectedProgramCategoryId +
          "&customerType=" +
          "ALL";
        await axios({ url }).then((res) => {
          setProgramTotal(res.data);
          setloader((currValue) => ({
            ...currValue,
            total: false,
          }));
        });
      } catch (err) {
        console.log("err-fetchcustomerProgramTotal", err);
        setloader((currValue) => ({
          ...currValue,
          total: false,
        }));
      }
    };
    if (localStorage.getItem("isPROGRAM") === "Y") {
      fetchCustomerProgramDataActive();
      fetchCustomerProgramDataActiveExisting();
      fetchProgramCustomerDataSixMonths();
      fetchProgramCustomerDataNineMonths();
      fetchProgramfirstFourTotal();
      fetchProgramCustomerDataInActive_12_18();
      fetchProgramCustomerDataInActive_18_24();
      fetchProgramTotalsecondHalf();
      fetchcustomerProgramTotal();
    }
  }, [selectedProgramDate, selectedProgramBannerId, selectedProgramCategoryId]);

  let customDatess =
    programRecordAvailableDates &&
    programRecordAvailableDates.map((item) => {
      return item["TRANS_DATE"];
    });
  // const maxDay = moment().subtract(2, "days");
  const disableCustomDt = (current) => {
    return (
      customDatess && customDatess.includes(current.format("YYYY-MM-DD")) //&&
      //current.isBefore(maxDay) // &&
      // !current.isBefore(moment("2022-02-28").toDate())
    );
  };

  useEffect(() => {
    const getLastRefreshTime = async () => {
      try {
        setloader((currValue) => ({
          ...currValue,
          refreshTime: true,
        }));
        let url =
          process.env.REACT_APP_API_ENDPOINT +
          process.env.REACT_APP_REFRESH_TIME +
          "dagId=PROGRAM";
        await axios({ url }).then((res) => {
          setloader((currValue) => ({
            ...currValue,
            refreshTime: false,
          }));
          setRefreshTime(res.data);
        });
      } catch (err) {
        setloader((currValue) => ({
          ...currValue,
          refreshTime: true,
        }));
        console.log("err-getLastRefreshTime", err);
      }
    };
    getLastRefreshTime();
  }, []);

  return localStorage.getItem("isPROGRAM") === "Y" ? (
    <div>
      {refreshTime.length > 0 && <NotificationMessage message={refreshDate} />}
      <div className="mt-1 d-flex align-items-center headings">
        <div className="d-flex justify-content-start p-3">
          <span className="progselectupText">Concept</span>
        </div>
        <div className="d-flex justify-content-start p-3">
          <span className="progselectupText">Type</span>
        </div>
      </div>
      <div className="mt-3 d-flex align-items-center">
        <div className="d-flex justify-content-start p-3">
          <Dropdown className="d-inline">
            <Dropdown.Toggle>{selectedProgramBanner.value}</Dropdown.Toggle>
            <Dropdown.Menu
              className="dropdown-menu-ext"
              onClick={(e) => handleProgramBanner(e)}
            >
              {ProgramBanners.map((data) => {
                return (
                  <Dropdown.Item
                    key={data.id}
                    className="dropdown-item-ext"
                    id={data.id}
                  >
                    {data.value}
                  </Dropdown.Item>
                );
              })}
            </Dropdown.Menu>
          </Dropdown>
        </div>
        <div className="d-flex justify-content-start p-3">
          <label className="chkBox-label">
            <input
              type="checkbox"
              checked={chkBox.isSdd}
              onChange={onChangeCheck}
              value="SDD"
              id="SDD"
              className="chkBox"
            />{" "}
            SDD
          </label>
        </div>
        <div className="d-flex justify-content-start p-3">
          <label className="chkBox-label">
            <input
              type="checkbox"
              checked={chkBox.isBopis}
              onChange={onChangeCheck}
              value="BOPIS"
              id="BOPIS"
              className="chkBox"
            />{" "}
            BOPIS
          </label>
        </div>
        <div className="d-flex justify-content-start p-3">
          <label className="chkBox-label">
            <input
              type="checkbox"
              checked={chkBox.isSddBopis}
              onChange={onChangeCheck}
              value="BOPIS_SDD"
              id="BOPIS_SDD"
              className="chkBox"
            />{" "}
            SDD and BOPIS
          </label>
        </div>
        {/* <div className="d-flex justify-content-start p-3">
          <Form.Group controlId="duedate">
            <Form.Control
              type="date"
              name="datePicker"
              placeholder="select a Date"
              value={selectedProgramDate}
              onChange={(e) => handleProgramDate(e.target.value)}
              max={MaxDayforPicker}
            />
          </Form.Group>
        </div> */}
        {loading.record_dates ? (
          <Placeholder.Button xs={1} />
        ) : (
          <div className="d-flex justify-content-start p-3">
            <label
              className="d-flex datepicker"
              onClick={(e) => e.preventDefault()}
            >
              <DatePicker
                timeFormat={false}
                value={
                  defaultDate
                    ? defaultDate
                    : moment(selectedProgramDate).format("MM/DD/YYYY")
                }
                isValidDate={disableCustomDt}
                onChange={(date) => handleProgramDate(date)}
                closeOnSelect
                inputProps={{ readOnly: true }}
              />
              <img src={calender} className="date-picker-icon" />
            </label>
          </div>
        )}
        <div
          className="d-flex justify-content-start p-3"
          style={{ marginLeft: "-6rem" }}
        >
          {!loading.record_dates && periodStartDate !== "" ? (
            <div>
              <span>{`(${getDateFormat(periodStartDate)} - ${getDateFormat(
                periodEndDate
              )})`}</span>
            </div>
          ) : (
            ""
          )}
        </div>
      </div>
      <ProgramHome
        loading={loading}
        customerProgramActiveData={customerProgramActiveData}
        customerProgramActiveExisting={customerProgramActiveExisting}
        customerProgramDataSixMonths={customerProgramDataSixMonths}
        customerProgramDataNineMonths={customerProgramDataNineMonths}
        firstCustomerProgramFourTotalData={firstCustomerProgramFourTotalData}
        customerProgramInActive_12_18_Data={customerProgramInActive_12_18_Data}
        customerProgramInActive_18_24_Data={customerProgramInActive_18_24_Data}
        secondCustomerProgramhalftotalData={secondCustomerProgramhalftotalData}
        customerProgramTotal={customerProgramTotal}
      />
    </div>
  ) : (
    <NoAccess tabName="Program" />
  );
}

export default ProgramContainer;
