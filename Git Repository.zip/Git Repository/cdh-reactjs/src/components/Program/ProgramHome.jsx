import { React, useState } from "react";
import { useHistory } from "react-router-dom";
import "../CdhHome/CdhHome.css";
import { Table } from "react-bootstrap";
import LoaderForRow from "../LoaderForTable/LoaderForRow";
import { gettooltip } from "../Utils";
// import { Spinner, SpinnerSize } from 'office-ui-fabric-react';
export const currencyFormat = (value) => {
  return parseFloat(value)
    .toFixed(0)
    .replace(/(\d)(?=(\d{3})+(?!\d))/g, "$1,");
};
function ChannelHome({
  loading,
  customerProgramActiveData,
  customerProgramActiveExisting,
  customerProgramDataSixMonths,
  customerProgramDataNineMonths,
  firstCustomerProgramFourTotalData,
  customerProgramInActive_12_18_Data,
  customerProgramInActive_18_24_Data,
  secondCustomerProgramhalftotalData,
  customerProgramTotal,
}) {
  let history = useHistory();
  return (
    <div className="">
      <div className="p-3" style={{ marginBottom: "50px" }}>
        <Table striped bordered hover size="sm">
          <thead>
            <tr>
              <th style={{ width: "200px" }}>
                L12m Active{" "}
                {gettooltip(
                  "L12mActiveInfoIcon",
                  "L12mActive",
                  "L12mActive",
                  "Inactive (24 months) - The customers",
                  "who were not active in last 24 months"
                )}
              </th>
              <th>
                Customers{" "}
                {gettooltip(
                  "customersInfoIcon",
                  "Customers",
                  "Customers",
                  "Data based on two years"
                )}
              </th>
              <th>
                Net Sales{" "}
                {gettooltip(
                  "NetSalesInfoIcon",
                  "NetSales",
                  "NetSales",
                  "Net Sales for customers in one year"
                )}
              </th>
              <th>
                Transactions{" "}
                {gettooltip(
                  "TransactionsInfoIcon",
                  "Transactions",
                  "Transactions",
                  "Number of distinct transaction for customer in one year"
                )}
              </th>
              <th>
                Product Margin{" "}
                {gettooltip(
                  "ProductMarginInfoIcon",
                  "ProductMargin",
                  "ProductMargin",
                  "Product Margin for customers in one year",
                  "(Net Sales - Cost of Sales)"
                )}
              </th>
              <th>
                AOV{" "}
                {gettooltip(
                  "AOVInfoIcon",
                  "AOV",
                  "AOV",
                  "Net Sales divided by number of transaction"
                )}
              </th>
              <th>
                UPT{" "}
                {gettooltip(
                  "UPTInfoIcon",
                  "UPT",
                  "UPT",
                  "Unit Sold per transaction"
                )}
              </th>
              <th>
                AUR{" "}
                {gettooltip(
                  "AURInfoIcon",
                  "AUR",
                  "AUR",
                  "Net Sales divided by unit sold"
                )}
              </th>
              <th>
                Margin Rate
                <br /> %{" "}
                {gettooltip(
                  "MarginRateInfoIcon",
                  "MarginRate",
                  "MarginRate",
                  "(Net Sales - Cost of Sales) / Net Sales"
                )}
              </th>
              <th>
                Net Sales per <br /> Customer{" "}
                {gettooltip(
                  "NPCInfoIcon",
                  "NPC",
                  "NPC",
                  "Net Sales per Customer"
                )}
              </th>
              <th>
                Transactions per <br /> Customer{" "}
                {gettooltip(
                  "TPCInfoIcon",
                  "TPC",
                  "TPC",
                  "Number of Transactions per customer"
                )}
              </th>
            </tr>
          </thead>
          <tbody>
            <tr>
              <td className="tableCol " id={"Stable_Exist"}>
                {"Returning Customers"}{" "}
                {gettooltip(
                  "ReturningCustomersInfoIcon",
                  "ReturningCustomers",
                  "ReturningCustomers",
                  "Active in L6M and active in L12M to L24M"
                )}
              </td>
              {loading.Active_Existing ? (
                <>
                  <LoaderForRow tdCount={10} />
                </>
              ) : (
                <>
                  <td>
                    {customerProgramActiveExisting !== undefined &&
                      customerProgramActiveExisting.length !== 0 &&
                      (customerProgramActiveExisting[0].ACT_CUST_COUNT_TY ===
                      "-999999"
                        ? "-"
                        : currencyFormat(
                            Number(
                              customerProgramActiveExisting[0].ACT_CUST_COUNT_TY
                            )
                          ))}
                    <br />
                    {customerProgramActiveExisting !== undefined &&
                    customerProgramActiveExisting.length !== 0 &&
                    Number(customerProgramActiveExisting[0].TY_VS_LY)
                      .toFixed(2)
                      .includes("-") ? (
                      <span style={{ color: "red", fontSize: "12px" }}>
                        {customerProgramActiveExisting[0].TY_VS_LY === "-999999"
                          ? "-"
                          : `LY ${Number(
                              customerProgramActiveExisting[0].TY_VS_LY
                            ).toFixed(2)}%`}
                      </span>
                    ) : (
                      <span style={{ color: "green", fontSize: "12px" }}>
                        {customerProgramActiveExisting !== undefined &&
                          customerProgramActiveExisting.length !== 0 &&
                          (customerProgramActiveExisting[0].TY_VS_LY ===
                          "-999999"
                            ? "-"
                            : `LY +${Number(
                                customerProgramActiveExisting[0].TY_VS_LY
                              ).toFixed(2)}%`)}
                      </span>
                    )}
                    <br />
                    {customerProgramActiveExisting !== undefined &&
                    customerProgramActiveExisting.length !== 0 &&
                    Number(customerProgramActiveExisting[0].TY_VS_LLY)
                      .toFixed(2)
                      .includes("-") ? (
                      <span style={{ color: "red", fontSize: "11px" }}>
                        {customerProgramActiveExisting !== undefined &&
                          customerProgramActiveExisting.length !== 0 &&
                          (customerProgramActiveExisting[0].TY_VS_LLY ===
                          "-999999"
                            ? "-"
                            : `LLY ${Number(
                                customerProgramActiveExisting[0].TY_VS_LLY
                              ).toFixed(2)}%`)}
                      </span>
                    ) : (
                      <span style={{ color: "green", fontSize: "11px" }}>
                        {customerProgramActiveExisting !== undefined &&
                          customerProgramActiveExisting.length !== 0 &&
                          (customerProgramActiveExisting[0].TY_VS_LLY ===
                          "-999999"
                            ? "-"
                            : `LLY +${Number(
                                customerProgramActiveExisting[0].TY_VS_LLY
                              ).toFixed(2)}%`)}
                      </span>
                    )}
                  </td>
                  <td>
                    {customerProgramActiveExisting !== undefined &&
                      customerProgramActiveExisting.length !== 0 &&
                      (customerProgramActiveExisting[0].NET_SALES_TY ===
                      "-999999"
                        ? "-"
                        : "$" +
                          currencyFormat(
                            Number(
                              customerProgramActiveExisting[0].NET_SALES_TY
                            )
                          ))}
                    <br />
                    {customerProgramActiveExisting !== undefined &&
                    customerProgramActiveExisting.length !== 0 &&
                    Number(customerProgramActiveExisting[0].NET_SALES_TY_VS_LY)
                      .toFixed(2)
                      .includes("-") ? (
                      <span style={{ color: "red", fontSize: "12px" }}>
                        {customerProgramActiveExisting !== undefined &&
                          customerProgramActiveExisting.length !== 0 &&
                          (customerProgramActiveExisting[0]
                            .NET_SALES_TY_VS_LY === "-999999"
                            ? "-"
                            : `LY ${Number(
                                customerProgramActiveExisting[0]
                                  .NET_SALES_TY_VS_LY
                              ).toFixed(2)}%`)}
                      </span>
                    ) : (
                      <span style={{ color: "green", fontSize: "12px" }}>
                        {customerProgramActiveExisting !== undefined &&
                          customerProgramActiveExisting.length !== 0 &&
                          (customerProgramActiveExisting[0]
                            .NET_SALES_TY_VS_LY === "-999999"
                            ? "-"
                            : `LY +${Number(
                                customerProgramActiveExisting[0]
                                  .NET_SALES_TY_VS_LY
                              ).toFixed(2)}%`)}
                      </span>
                    )}
                    <br />
                    {customerProgramActiveExisting !== undefined &&
                    customerProgramActiveExisting.length !== 0 &&
                    Number(customerProgramActiveExisting[0].NET_SALES_TY_VS_LLY)
                      .toFixed(2)
                      .includes("-") ? (
                      <span style={{ color: "red", fontSize: "11px" }}>
                        {customerProgramActiveExisting !== undefined &&
                          customerProgramActiveExisting.length !== 0 &&
                          (customerProgramActiveExisting[0]
                            .NET_SALES_TY_VS_LLY === "-999999"
                            ? "-"
                            : `LLY ${Number(
                                customerProgramActiveExisting[0]
                                  .NET_SALES_TY_VS_LLY
                              ).toFixed(2)}%`)}
                      </span>
                    ) : (
                      <span style={{ color: "green", fontSize: "11px" }}>
                        {customerProgramActiveExisting !== undefined &&
                          customerProgramActiveExisting.length !== 0 &&
                          (customerProgramActiveExisting[0]
                            .NET_SALES_TY_VS_LLY === "-999999"
                            ? "-"
                            : `LLY +${Number(
                                customerProgramActiveExisting[0]
                                  .NET_SALES_TY_VS_LLY
                              ).toFixed(2)}%`)}
                      </span>
                    )}
                  </td>
                  <td>
                    {customerProgramActiveExisting !== undefined &&
                      customerProgramActiveExisting.length !== 0 &&
                      (customerProgramActiveExisting[0].TRANS_COUNT_TY ===
                      "-999999"
                        ? "-"
                        : currencyFormat(
                            Number(
                              customerProgramActiveExisting[0].TRANS_COUNT_TY
                            )
                          ))}
                    <br />
                    {customerProgramActiveExisting !== undefined &&
                    customerProgramActiveExisting.length !== 0 &&
                    Number(customerProgramActiveExisting[0].TRANS_TY_VS_LY)
                      .toFixed(2)
                      .includes("-") ? (
                      <span style={{ color: "red", fontSize: "12px" }}>
                        {customerProgramActiveExisting !== undefined &&
                          customerProgramActiveExisting.length !== 0 &&
                          (customerProgramActiveExisting[0].TRANS_TY_VS_LY ===
                          "-999999"
                            ? "-"
                            : `LY ${Number(
                                customerProgramActiveExisting[0].TRANS_TY_VS_LY
                              ).toFixed(2)}%`)}
                      </span>
                    ) : (
                      <span style={{ color: "green", fontSize: "12px" }}>
                        {customerProgramActiveExisting !== undefined &&
                          customerProgramActiveExisting.length !== 0 &&
                          (customerProgramActiveExisting[0].TRANS_TY_VS_LY ===
                          "-999999"
                            ? "-"
                            : `LY +${Number(
                                customerProgramActiveExisting[0].TRANS_TY_VS_LY
                              ).toFixed(2)}%`)}
                      </span>
                    )}
                    <br />
                    {customerProgramActiveExisting !== undefined &&
                    customerProgramActiveExisting.length !== 0 &&
                    Number(customerProgramActiveExisting[0].TRANS_TY_VS_LLY)
                      .toFixed(2)
                      .includes("-") ? (
                      <span style={{ color: "red", fontSize: "11px" }}>
                        {customerProgramActiveExisting !== undefined &&
                          customerProgramActiveExisting.length !== 0 &&
                          (customerProgramActiveExisting[0].TRANS_TY_VS_LLY ===
                          "-999999"
                            ? "-"
                            : `LLY ${Number(
                                customerProgramActiveExisting[0].TRANS_TY_VS_LLY
                              ).toFixed(2)}%`)}
                      </span>
                    ) : (
                      <span style={{ color: "green", fontSize: "11px" }}>
                        {customerProgramActiveExisting !== undefined &&
                          customerProgramActiveExisting.length !== 0 &&
                          (customerProgramActiveExisting[0].TRANS_TY_VS_LLY ===
                          "-999999"
                            ? "-"
                            : `LLY +${Number(
                                customerProgramActiveExisting[0].TRANS_TY_VS_LLY
                              ).toFixed(2)}%`)}
                      </span>
                    )}
                  </td>
                  <td>
                    {customerProgramActiveExisting !== undefined &&
                      customerProgramActiveExisting.length !== 0 &&
                      (customerProgramActiveExisting[0].PM_TY === "-999999"
                        ? "-"
                        : "$" +
                          currencyFormat(
                            Number(customerProgramActiveExisting[0].PM_TY)
                          ))}
                    <br />
                    {customerProgramActiveExisting !== undefined &&
                    customerProgramActiveExisting.length !== 0 &&
                    Number(customerProgramActiveExisting[0].PM_TY_VS_LY)
                      .toFixed(2)
                      .includes("-") ? (
                      <span style={{ color: "red", fontSize: "12px" }}>
                        {customerProgramActiveExisting !== undefined &&
                          customerProgramActiveExisting.length !== 0 &&
                          (customerProgramActiveExisting[0].PM_TY_VS_LY ===
                          "-999999"
                            ? "-"
                            : `LY ${Number(
                                customerProgramActiveExisting[0].PM_TY_VS_LY
                              ).toFixed(2)}%`)}
                      </span>
                    ) : (
                      <span style={{ color: "green", fontSize: "12px" }}>
                        {customerProgramActiveExisting !== undefined &&
                          customerProgramActiveExisting.length !== 0 &&
                          (customerProgramActiveExisting[0].PM_TY_VS_LY ===
                          "-999999"
                            ? "-"
                            : `LY +${Number(
                                customerProgramActiveExisting[0].PM_TY_VS_LY
                              ).toFixed(2)}%`)}
                      </span>
                    )}
                    <br />
                    {customerProgramActiveExisting !== undefined &&
                    customerProgramActiveExisting.length !== 0 &&
                    Number(customerProgramActiveExisting[0].PM_TY_VS_LLY)
                      .toFixed(2)
                      .includes("-") ? (
                      <span style={{ color: "red", fontSize: "11px" }}>
                        {customerProgramActiveExisting !== undefined &&
                          customerProgramActiveExisting.length !== 0 &&
                          (customerProgramActiveExisting[0].PM_TY_VS_LLY ===
                          "-999999"
                            ? "-"
                            : `LLY ${Number(
                                customerProgramActiveExisting[0].PM_TY_VS_LLY
                              ).toFixed(2)}%`)}
                      </span>
                    ) : (
                      <span style={{ color: "green", fontSize: "11px" }}>
                        {customerProgramActiveExisting !== undefined &&
                          customerProgramActiveExisting.length !== 0 &&
                          (customerProgramActiveExisting[0].PM_TY_VS_LLY ===
                          "-999999"
                            ? "-"
                            : `LLY +${Number(
                                customerProgramActiveExisting[0].PM_TY_VS_LLY
                              ).toFixed(2)}%`)}
                      </span>
                    )}
                  </td>
                  <td>
                    {customerProgramActiveExisting !== undefined &&
                      customerProgramActiveExisting.length !== 0 &&
                      (customerProgramActiveExisting[0].AOV_TY === "-999999"
                        ? "-"
                        : "$" +
                          Number(
                            customerProgramActiveExisting[0].AOV_TY
                          ).toFixed(2))}
                    <br />
                    {customerProgramActiveExisting !== undefined &&
                    customerProgramActiveExisting.length !== 0 &&
                    Number(customerProgramActiveExisting[0].AOV_TY_VS_LY)
                      .toFixed(2)
                      .includes("-") ? (
                      <span style={{ color: "red", fontSize: "12px" }}>
                        {customerProgramActiveExisting !== undefined &&
                          customerProgramActiveExisting.length !== 0 &&
                          (customerProgramActiveExisting[0].AOV_TY_VS_LY ===
                          "-999999"
                            ? "-"
                            : `LY ${Number(
                                customerProgramActiveExisting[0].AOV_TY_VS_LY
                              ).toFixed(2)}%`)}
                      </span>
                    ) : (
                      <span style={{ color: "green", fontSize: "12px" }}>
                        {customerProgramActiveExisting !== undefined &&
                          customerProgramActiveExisting.length !== 0 &&
                          (customerProgramActiveExisting[0].AOV_TY_VS_LY ===
                          "-999999"
                            ? "-"
                            : `LY +${Number(
                                customerProgramActiveExisting[0].AOV_TY_VS_LY
                              ).toFixed(2)}%`)}
                      </span>
                    )}
                    <br />
                    {customerProgramActiveExisting !== undefined &&
                    customerProgramActiveExisting.length !== 0 &&
                    Number(customerProgramActiveExisting[0].AOV_TY_VS_LLY)
                      .toFixed(2)
                      .includes("-") ? (
                      <span style={{ color: "red", fontSize: "11px" }}>
                        {customerProgramActiveExisting !== undefined &&
                          customerProgramActiveExisting.length !== 0 &&
                          (customerProgramActiveExisting[0].AOV_TY_VS_LLY ===
                          "-999999"
                            ? "-"
                            : `LLY ${Number(
                                customerProgramActiveExisting[0].AOV_TY_VS_LLY
                              ).toFixed(2)}%`)}
                      </span>
                    ) : (
                      <span style={{ color: "green", fontSize: "11px" }}>
                        {customerProgramActiveExisting !== undefined &&
                          customerProgramActiveExisting.length !== 0 &&
                          (customerProgramActiveExisting[0].AOV_TY_VS_LLY ===
                          "-999999"
                            ? "-"
                            : `LLY +${Number(
                                customerProgramActiveExisting[0].AOV_TY_VS_LLY
                              ).toFixed(2)}%`)}
                      </span>
                    )}
                  </td>
                  <td>
                    {customerProgramActiveExisting !== undefined &&
                      customerProgramActiveExisting.length !== 0 &&
                      (customerProgramActiveExisting[0].UPT_TY === "-999999"
                        ? "-"
                        : Number(
                            customerProgramActiveExisting[0].UPT_TY
                          ).toFixed(1))}
                    <br />
                    {customerProgramActiveExisting !== undefined &&
                    customerProgramActiveExisting.length !== 0 &&
                    Number(customerProgramActiveExisting[0].UPT_TY_VS_LY)
                      .toFixed(2)
                      .includes("-") ? (
                      <span style={{ color: "red", fontSize: "12px" }}>
                        {customerProgramActiveExisting !== undefined &&
                          customerProgramActiveExisting.length !== 0 &&
                          (customerProgramActiveExisting[0].UPT_TY_VS_LY ===
                          "-999999"
                            ? "-"
                            : `LY ${Number(
                                customerProgramActiveExisting[0].UPT_TY_VS_LY
                              ).toFixed(2)}%`)}
                      </span>
                    ) : (
                      <span style={{ color: "green", fontSize: "12px" }}>
                        {customerProgramActiveExisting !== undefined &&
                          customerProgramActiveExisting.length !== 0 &&
                          (customerProgramActiveExisting[0].UPT_TY_VS_LY ===
                          "-999999"
                            ? "-"
                            : `LY +${Number(
                                customerProgramActiveExisting[0].UPT_TY_VS_LY
                              ).toFixed(2)}%`)}
                      </span>
                    )}
                    <br />
                    {customerProgramActiveExisting !== undefined &&
                    customerProgramActiveExisting.length !== 0 &&
                    Number(customerProgramActiveExisting[0].UPT_TY_VS_LLY)
                      .toFixed(2)
                      .includes("-") ? (
                      <span style={{ color: "red", fontSize: "11px" }}>
                        {customerProgramActiveExisting !== undefined &&
                          customerProgramActiveExisting.length !== 0 &&
                          (customerProgramActiveExisting[0].UPT_TY_VS_LLY ===
                          "-999999"
                            ? "-"
                            : `LLY ${Number(
                                customerProgramActiveExisting[0].UPT_TY_VS_LLY
                              ).toFixed(2)}%`)}
                      </span>
                    ) : (
                      <span style={{ color: "green", fontSize: "11px" }}>
                        {customerProgramActiveExisting !== undefined &&
                          customerProgramActiveExisting.length !== 0 &&
                          (customerProgramActiveExisting[0].UPT_TY_VS_LLY ===
                          "-999999"
                            ? "-"
                            : `LLY +${Number(
                                customerProgramActiveExisting[0].UPT_TY_VS_LLY
                              ).toFixed(2)}%`)}
                      </span>
                    )}
                  </td>
                  <td>
                    {customerProgramActiveExisting !== undefined &&
                      customerProgramActiveExisting.length !== 0 &&
                      (customerProgramActiveExisting[0].AUR_TY === "-999999"
                        ? "-"
                        : "$" +
                          Number(
                            customerProgramActiveExisting[0].AUR_TY
                          ).toFixed(2))}
                    <br />
                    {customerProgramActiveExisting !== undefined &&
                    customerProgramActiveExisting.length !== 0 &&
                    Number(customerProgramActiveExisting[0].AUR_TY_VS_LY)
                      .toFixed(2)
                      .includes("-") ? (
                      <span style={{ color: "red", fontSize: "12px" }}>
                        {customerProgramActiveExisting !== undefined &&
                          customerProgramActiveExisting.length !== 0 &&
                          (customerProgramActiveExisting[0].AUR_TY_VS_LY ===
                          "-999999"
                            ? "-"
                            : `LY ${Number(
                                customerProgramActiveExisting[0].AUR_TY_VS_LY
                              ).toFixed(2)}%`)}
                      </span>
                    ) : (
                      <span style={{ color: "green", fontSize: "12px" }}>
                        {customerProgramActiveExisting !== undefined &&
                          customerProgramActiveExisting.length !== 0 &&
                          (customerProgramActiveExisting[0].AUR_TY_VS_LY ===
                          "-999999"
                            ? "-"
                            : `LY +${Number(
                                customerProgramActiveExisting[0].AUR_TY_VS_LY
                              ).toFixed(2)}%`)}
                      </span>
                    )}
                    <br />
                    {customerProgramActiveExisting !== undefined &&
                    customerProgramActiveExisting.length !== 0 &&
                    Number(customerProgramActiveExisting[0].AUR_TY_VS_LLY)
                      .toFixed(2)
                      .includes("-") ? (
                      <span style={{ color: "red", fontSize: "11px" }}>
                        {customerProgramActiveExisting !== undefined &&
                          customerProgramActiveExisting.length !== 0 &&
                          (customerProgramActiveExisting[0].AUR_TY_VS_LLY ===
                          "-999999"
                            ? "-"
                            : `LLY ${Number(
                                customerProgramActiveExisting[0].AUR_TY_VS_LLY
                              ).toFixed(2)}%`)}
                      </span>
                    ) : (
                      <span style={{ color: "green", fontSize: "11px" }}>
                        {customerProgramActiveExisting !== undefined &&
                          customerProgramActiveExisting.length !== 0 &&
                          (customerProgramActiveExisting[0].AUR_TY_VS_LLY ===
                          "-999999"
                            ? "-"
                            : `LLY +${Number(
                                customerProgramActiveExisting[0].AUR_TY_VS_LLY
                              ).toFixed(2)}%`)}
                      </span>
                    )}
                  </td>
                  <td>
                    {customerProgramActiveExisting !== undefined &&
                      customerProgramActiveExisting.length !== 0 &&
                      (customerProgramActiveExisting[0].MARGIN_RATE_PER_TY ===
                      "-999999"
                        ? "-"
                        : Number(
                            customerProgramActiveExisting[0].MARGIN_RATE_PER_TY
                          ).toFixed(2))}
                    <br />
                    {customerProgramActiveExisting !== undefined &&
                    customerProgramActiveExisting.length !== 0 &&
                    Number(
                      customerProgramActiveExisting[0].MARGIN_RATE_PER_TY_VS_LY
                    )
                      .toFixed(2)
                      .includes("-") ? (
                      <span style={{ color: "red", fontSize: "12px" }}>
                        {customerProgramActiveExisting !== undefined &&
                          customerProgramActiveExisting.length !== 0 &&
                          (customerProgramActiveExisting[0]
                            .MARGIN_RATE_PER_TY_VS_LY === "-999999"
                            ? "-"
                            : `LY ${Number(
                                customerProgramActiveExisting[0]
                                  .MARGIN_RATE_PER_TY_VS_LY
                              ).toFixed(2)}%`)}
                      </span>
                    ) : (
                      <span style={{ color: "green", fontSize: "12px" }}>
                        {customerProgramActiveExisting !== undefined &&
                          customerProgramActiveExisting.length !== 0 &&
                          (customerProgramActiveExisting[0]
                            .MARGIN_RATE_PER_TY_VS_LY === "-999999"
                            ? "-"
                            : `LY +${Number(
                                customerProgramActiveExisting[0]
                                  .MARGIN_RATE_PER_TY_VS_LY
                              ).toFixed(2)}%`)}
                      </span>
                    )}
                    <br />
                    {customerProgramActiveExisting !== undefined &&
                    customerProgramActiveExisting.length !== 0 &&
                    Number(
                      customerProgramActiveExisting[0].MARGIN_RATE_PER_TY_VS_LLY
                    )
                      .toFixed(2)
                      .includes("-") ? (
                      <span style={{ color: "red", fontSize: "11px" }}>
                        {customerProgramActiveExisting !== undefined &&
                          customerProgramActiveExisting.length !== 0 &&
                          (customerProgramActiveExisting[0]
                            .MARGIN_RATE_PER_TY_VS_LLY === "-999999"
                            ? "-"
                            : `LLY ${Number(
                                customerProgramActiveExisting[0]
                                  .MARGIN_RATE_PER_TY_VS_LLY
                              ).toFixed(2)}%`)}
                      </span>
                    ) : (
                      <span style={{ color: "green", fontSize: "11px" }}>
                        {customerProgramActiveExisting !== undefined &&
                          customerProgramActiveExisting.length !== 0 &&
                          (customerProgramActiveExisting[0]
                            .MARGIN_RATE_PER_TY_VS_LLY === "-999999"
                            ? "-"
                            : `LLY +${Number(
                                customerProgramActiveExisting[0]
                                  .MARGIN_RATE_PER_TY_VS_LLY
                              ).toFixed(2)}%`)}
                      </span>
                    )}
                  </td>
                  <td>
                    {customerProgramActiveExisting !== undefined &&
                      customerProgramActiveExisting.length !== 0 &&
                      (customerProgramActiveExisting[0]
                        .NET_SALES_PER_CUST_TY === "-999999"
                        ? "-"
                        : "$" +
                          Number(
                            customerProgramActiveExisting[0]
                              .NET_SALES_PER_CUST_TY
                          ).toFixed(2))}
                    <br />
                    {customerProgramActiveExisting !== undefined &&
                    customerProgramActiveExisting.length !== 0 &&
                    Number(
                      customerProgramActiveExisting[0]
                        .NET_SALES_PER_CUST_TY_VS_LY
                    )
                      .toFixed(2)
                      .includes("-") ? (
                      <span style={{ color: "red", fontSize: "12px" }}>
                        {customerProgramActiveExisting !== undefined &&
                          customerProgramActiveExisting.length !== 0 &&
                          (customerProgramActiveExisting[0]
                            .NET_SALES_PER_CUST_TY_VS_LY === "-999999"
                            ? "-"
                            : `LY ${Number(
                                customerProgramActiveExisting[0]
                                  .NET_SALES_PER_CUST_TY_VS_LY
                              ).toFixed(2)}%`)}
                      </span>
                    ) : (
                      <span style={{ color: "green", fontSize: "12px" }}>
                        {customerProgramActiveExisting !== undefined &&
                          customerProgramActiveExisting.length !== 0 &&
                          (customerProgramActiveExisting[0]
                            .NET_SALES_PER_CUST_TY_VS_LY === "-999999"
                            ? "-"
                            : `LY +${Number(
                                customerProgramActiveExisting[0]
                                  .NET_SALES_PER_CUST_TY_VS_LY
                              ).toFixed(2)}%`)}
                      </span>
                    )}
                    <br />
                    {customerProgramActiveExisting !== undefined &&
                    customerProgramActiveExisting.length !== 0 &&
                    Number(
                      customerProgramActiveExisting[0]
                        .NET_SALES_PER_CUST_TY_VS_LLY
                    )
                      .toFixed(2)
                      .includes("-") ? (
                      <span style={{ color: "red", fontSize: "11px" }}>
                        {customerProgramActiveExisting !== undefined &&
                          customerProgramActiveExisting.length !== 0 &&
                          (customerProgramActiveExisting[0]
                            .NET_SALES_PER_CUST_TY_VS_LLY === "-999999"
                            ? "-"
                            : `LLY ${Number(
                                customerProgramActiveExisting[0]
                                  .NET_SALES_PER_CUST_TY_VS_LLY
                              ).toFixed(2)}%`)}
                      </span>
                    ) : (
                      <span style={{ color: "green", fontSize: "11px" }}>
                        {customerProgramActiveExisting !== undefined &&
                          customerProgramActiveExisting.length !== 0 &&
                          (customerProgramActiveExisting[0]
                            .NET_SALES_PER_CUST_TY_VS_LLY === "-999999"
                            ? "-"
                            : `LLY +${Number(
                                customerProgramActiveExisting[0]
                                  .NET_SALES_PER_CUST_TY_VS_LLY
                              ).toFixed(2)}%`)}
                      </span>
                    )}
                  </td>
                  <td>
                    {customerProgramActiveExisting !== undefined &&
                      customerProgramActiveExisting.length !== 0 &&
                      (customerProgramActiveExisting[0].AVG_TRAN_TY ===
                      "-999999"
                        ? "-"
                        : Number(
                            customerProgramActiveExisting[0].AVG_TRAN_TY
                          ).toFixed(2))}
                    <br />
                    {customerProgramActiveExisting !== undefined &&
                    customerProgramActiveExisting.length !== 0 &&
                    Number(customerProgramActiveExisting[0].AVG_TRAN_TY_VS_LY)
                      .toFixed(2)
                      .includes("-") ? (
                      <span style={{ color: "red", fontSize: "12px" }}>
                        {customerProgramActiveExisting !== undefined &&
                          customerProgramActiveExisting.length !== 0 &&
                          (customerProgramActiveExisting[0]
                            .AVG_TRAN_TY_VS_LY === "-999999"
                            ? "-"
                            : `LY ${Number(
                                customerProgramActiveExisting[0]
                                  .AVG_TRAN_TY_VS_LY
                              ).toFixed(2)}%`)}
                      </span>
                    ) : (
                      <span style={{ color: "green", fontSize: "12px" }}>
                        {customerProgramActiveExisting !== undefined &&
                          customerProgramActiveExisting.length !== 0 &&
                          (customerProgramActiveExisting[0]
                            .AVG_TRAN_TY_VS_LY === "-999999"
                            ? "-"
                            : `LY +${Number(
                                customerProgramActiveExisting[0]
                                  .AVG_TRAN_TY_VS_LY
                              ).toFixed(2)}%`)}
                      </span>
                    )}
                    <br />
                    {customerProgramActiveExisting !== undefined &&
                    customerProgramActiveExisting.length !== 0 &&
                    Number(customerProgramActiveExisting[0].AVG_TRAN_TY_VS_LLY)
                      .toFixed(2)
                      .includes("-") ? (
                      <span style={{ color: "red", fontSize: "11px" }}>
                        {customerProgramActiveExisting !== undefined &&
                          customerProgramActiveExisting.length !== 0 &&
                          (customerProgramActiveExisting[0]
                            .AVG_TRAN_TY_VS_LLY === "-999999"
                            ? "-"
                            : `LLY ${Number(
                                customerProgramActiveExisting[0]
                                  .AVG_TRAN_TY_VS_LLY
                              ).toFixed(2)}%`)}
                      </span>
                    ) : (
                      <span style={{ color: "green", fontSize: "11px" }}>
                        {customerProgramActiveExisting !== undefined &&
                          customerProgramActiveExisting.length !== 0 &&
                          (customerProgramActiveExisting[0]
                            .AVG_TRAN_TY_VS_LLY === "-999999"
                            ? "-"
                            : `LLY +${Number(
                                customerProgramActiveExisting[0]
                                  .AVG_TRAN_TY_VS_LLY
                              ).toFixed(2)}%`)}
                      </span>
                    )}
                  </td>
                </>
              )}
            </tr>
            <tr>
              <td className="tableCol">
                {"New Customers"}{" "}
                {gettooltip(
                  "NewCustomersInfoIcon",
                  "NewCustomers",
                  "NewCustomers",
                  "Active in L12M but not active in L12M to L24M"
                )}
              </td>
              {loading.Active_L12m ? (
                <>
                  <LoaderForRow tdCount={10} />
                </>
              ) : (
                <>
                  <td>
                    {customerProgramActiveData !== undefined &&
                      customerProgramActiveData.length !== 0 &&
                      (customerProgramActiveData[0].ACT_CUST_COUNT_TY ===
                      "-999999"
                        ? "-"
                        : currencyFormat(
                            Number(
                              customerProgramActiveData[0].ACT_CUST_COUNT_TY
                            )
                          ))}
                    <br />
                    {customerProgramActiveData !== undefined &&
                    customerProgramActiveData.length !== 0 &&
                    Number(customerProgramActiveData[0].TY_VS_LY)
                      .toFixed(2)
                      .includes("-") ? (
                      <span style={{ color: "red", fontSize: "12px" }}>
                        {customerProgramActiveData !== undefined &&
                          customerProgramActiveData.length !== 0 &&
                          (customerProgramActiveData[0].TY_VS_LY === "-999999"
                            ? "-"
                            : `LY ${Number(
                                customerProgramActiveData[0].TY_VS_LY
                              ).toFixed(2)}%`)}
                      </span>
                    ) : (
                      <span style={{ color: "green", fontSize: "12px" }}>
                        {customerProgramActiveData !== undefined &&
                          customerProgramActiveData.length !== 0 &&
                          (customerProgramActiveData[0].TY_VS_LY === "-999999"
                            ? "-"
                            : `LY +${Number(
                                customerProgramActiveData[0].TY_VS_LY
                              ).toFixed(2)}%`)}
                      </span>
                    )}
                    <br />
                    {customerProgramActiveData !== undefined &&
                    customerProgramActiveData.length !== 0 &&
                    Number(customerProgramActiveData[0].TY_VS_LLY)
                      .toFixed(2)
                      .includes("-") ? (
                      <span style={{ color: "red", fontSize: "11px" }}>
                        {customerProgramActiveData !== undefined &&
                          customerProgramActiveData.length !== 0 &&
                          (customerProgramActiveData[0].TY_VS_LLY === "-999999"
                            ? "-"
                            : `LLY ${Number(
                                customerProgramActiveData[0].TY_VS_LLY
                              ).toFixed(2)}%`)}
                      </span>
                    ) : (
                      <span style={{ color: "green", fontSize: "11px" }}>
                        {customerProgramActiveData !== undefined &&
                          customerProgramActiveData.length !== 0 &&
                          (customerProgramActiveData[0].TY_VS_LLY === "-999999"
                            ? "-"
                            : `LLY +${Number(
                                customerProgramActiveData[0].TY_VS_LLY
                              ).toFixed(2)}%`)}
                      </span>
                    )}
                  </td>
                  <td>
                    {customerProgramActiveData !== undefined &&
                      customerProgramActiveData.length !== 0 &&
                      (customerProgramActiveData[0].NET_SALES_TY === "-999999"
                        ? "-"
                        : "$" +
                          currencyFormat(
                            Number(customerProgramActiveData[0].NET_SALES_TY)
                          ))}
                    <br />
                    {customerProgramActiveData !== undefined &&
                    customerProgramActiveData.length !== 0 &&
                    Number(customerProgramActiveData[0].NET_SALES_TY_VS_LY)
                      .toFixed(2)
                      .includes("-") ? (
                      <span style={{ color: "red", fontSize: "12px" }}>
                        {customerProgramActiveData !== undefined &&
                          customerProgramActiveData.length !== 0 &&
                          (customerProgramActiveData[0].NET_SALES_TY_VS_LY ===
                          "-999999"
                            ? "-"
                            : `LY ${Number(
                                customerProgramActiveData[0].NET_SALES_TY_VS_LY
                              ).toFixed(2)}%`)}
                      </span>
                    ) : (
                      <span style={{ color: "green", fontSize: "12px" }}>
                        {customerProgramActiveData !== undefined &&
                          customerProgramActiveData.length !== 0 &&
                          (customerProgramActiveData[0].NET_SALES_TY_VS_LY ===
                          "-999999"
                            ? "-"
                            : `LY +${Number(
                                customerProgramActiveData[0].NET_SALES_TY_VS_LY
                              ).toFixed(2)}%`)}
                      </span>
                    )}
                    <br />
                    {customerProgramActiveData !== undefined &&
                    customerProgramActiveData.length !== 0 &&
                    Number(customerProgramActiveData[0].NET_SALES_TY_VS_LLY)
                      .toFixed(2)
                      .includes("-") ? (
                      <span style={{ color: "red", fontSize: "11px" }}>
                        {customerProgramActiveData !== undefined &&
                          customerProgramActiveData.length !== 0 &&
                          (customerProgramActiveData[0].NET_SALES_TY_VS_LLY ===
                          "-999999"
                            ? "-"
                            : `LLY ${Number(
                                customerProgramActiveData[0].NET_SALES_TY_VS_LLY
                              ).toFixed(2)}%`)}
                      </span>
                    ) : (
                      <span style={{ color: "green", fontSize: "11px" }}>
                        {customerProgramActiveData !== undefined &&
                          customerProgramActiveData.length !== 0 &&
                          (customerProgramActiveData[0].NET_SALES_TY_VS_LLY ===
                          "-999999"
                            ? "-"
                            : `LLY +${Number(
                                customerProgramActiveData[0].NET_SALES_TY_VS_LLY
                              ).toFixed(2)}%`)}
                      </span>
                    )}
                  </td>
                  <td>
                    {customerProgramActiveData !== undefined &&
                      customerProgramActiveData.length !== 0 &&
                      (customerProgramActiveData[0].TRANS_COUNT_TY === "-999999"
                        ? "-"
                        : currencyFormat(
                            Number(customerProgramActiveData[0].TRANS_COUNT_TY)
                          ))}
                    <br />
                    {customerProgramActiveData !== undefined &&
                    customerProgramActiveData.length !== 0 &&
                    Number(customerProgramActiveData[0].TRANS_TY_VS_LY)
                      .toFixed(2)
                      .includes("-") ? (
                      <span style={{ color: "red", fontSize: "12px" }}>
                        {customerProgramActiveData !== undefined &&
                          customerProgramActiveData.length !== 0 &&
                          (customerProgramActiveData[0].TRANS_TY_VS_LY ===
                          "-999999"
                            ? "-"
                            : `LY ${Number(
                                customerProgramActiveData[0].TRANS_TY_VS_LY
                              ).toFixed(2)}%`)}
                      </span>
                    ) : (
                      <span style={{ color: "green", fontSize: "12px" }}>
                        {customerProgramActiveData !== undefined &&
                          customerProgramActiveData.length !== 0 &&
                          (customerProgramActiveData[0].TRANS_TY_VS_LY ===
                          "-999999"
                            ? "-"
                            : `LY +${Number(
                                customerProgramActiveData[0].TRANS_TY_VS_LY
                              ).toFixed(2)}%`)}
                      </span>
                    )}
                    <br />
                    {customerProgramActiveData !== undefined &&
                    customerProgramActiveData.length !== 0 &&
                    Number(customerProgramActiveData[0].TRANS_TY_VS_LLY)
                      .toFixed(2)
                      .includes("-") ? (
                      <span style={{ color: "red", fontSize: "11px" }}>
                        {customerProgramActiveData !== undefined &&
                          customerProgramActiveData.length !== 0 &&
                          (customerProgramActiveData[0].TRANS_TY_VS_LLY ===
                          "-999999"
                            ? "-"
                            : `LLY ${Number(
                                customerProgramActiveData[0].TRANS_TY_VS_LLY
                              ).toFixed(2)}`)}
                      </span>
                    ) : (
                      <span style={{ color: "green", fontSize: "11px" }}>
                        {customerProgramActiveData !== undefined &&
                          customerProgramActiveData.length !== 0 &&
                          (customerProgramActiveData[0].TRANS_TY_VS_LLY ===
                          "-999999"
                            ? "-"
                            : `LLY +${Number(
                                customerProgramActiveData[0].TRANS_TY_VS_LLY
                              ).toFixed(2)}`)}
                      </span>
                    )}
                  </td>
                  <td>
                    {customerProgramActiveData !== undefined &&
                      customerProgramActiveData.length !== 0 &&
                      (customerProgramActiveData[0].PM_TY === "-999999"
                        ? "-"
                        : "$" +
                          currencyFormat(
                            Number(customerProgramActiveData[0].PM_TY)
                          ))}
                    <br />
                    {customerProgramActiveData !== undefined &&
                    customerProgramActiveData.length !== 0 &&
                    Number(customerProgramActiveData[0].PM_TY_VS_LY)
                      .toFixed(2)
                      .includes("-") ? (
                      <span style={{ color: "red", fontSize: "12px" }}>
                        {customerProgramActiveData !== undefined &&
                          customerProgramActiveData.length !== 0 &&
                          (customerProgramActiveData[0].PM_TY_VS_LY ===
                          "-999999"
                            ? "-"
                            : `LY ${Number(
                                customerProgramActiveData[0].PM_TY_VS_LY
                              ).toFixed(2)}%`)}
                      </span>
                    ) : (
                      <span style={{ color: "green", fontSize: "12px" }}>
                        {customerProgramActiveData !== undefined &&
                          customerProgramActiveData.length !== 0 &&
                          (customerProgramActiveData[0].PM_TY_VS_LY ===
                          "-999999"
                            ? "-"
                            : `LY +${Number(
                                customerProgramActiveData[0].PM_TY_VS_LY
                              ).toFixed(2)}%`)}
                      </span>
                    )}
                    <br />
                    {customerProgramActiveData !== undefined &&
                    customerProgramActiveData.length !== 0 &&
                    Number(customerProgramActiveData[0].PM_TY_VS_LLY)
                      .toFixed(2)
                      .includes("-") ? (
                      <span style={{ color: "red", fontSize: "11px" }}>
                        {customerProgramActiveData !== undefined &&
                          customerProgramActiveData.length !== 0 &&
                          (customerProgramActiveData[0].PM_TY_VS_LLY ===
                          "-999999"
                            ? "-"
                            : `LLY ${Number(
                                customerProgramActiveData[0].PM_TY_VS_LLY
                              ).toFixed(2)}%`)}
                      </span>
                    ) : (
                      <span style={{ color: "green", fontSize: "11px" }}>
                        {customerProgramActiveData !== undefined &&
                          customerProgramActiveData.length !== 0 &&
                          (customerProgramActiveData[0].PM_TY_VS_LLY ===
                          "-999999"
                            ? "-"
                            : `LLY +${Number(
                                customerProgramActiveData[0].PM_TY_VS_LLY
                              ).toFixed(2)}%`)}
                      </span>
                    )}
                  </td>
                  <td>
                    {customerProgramActiveData !== undefined &&
                      customerProgramActiveData.length !== 0 &&
                      (customerProgramActiveData[0].AOV_TY === "-999999"
                        ? "-"
                        : "$" +
                          Number(customerProgramActiveData[0].AOV_TY).toFixed(
                            2
                          ))}
                    <br />
                    {customerProgramActiveData !== undefined &&
                    customerProgramActiveData.length !== 0 &&
                    Number(customerProgramActiveData[0].AOV_TY_VS_LY)
                      .toFixed(2)
                      .includes("-") ? (
                      <span style={{ color: "red", fontSize: "12px" }}>
                        {customerProgramActiveData !== undefined &&
                          customerProgramActiveData.length !== 0 &&
                          (customerProgramActiveData[0].AOV_TY_VS_LY ===
                          "-999999"
                            ? "-"
                            : `LY ${Number(
                                customerProgramActiveData[0].AOV_TY_VS_LY
                              ).toFixed(2)}%`)}
                      </span>
                    ) : (
                      <span style={{ color: "green", fontSize: "12px" }}>
                        {customerProgramActiveData !== undefined &&
                          customerProgramActiveData.length !== 0 &&
                          (customerProgramActiveData[0].AOV_TY_VS_LY ===
                          "-999999"
                            ? "-"
                            : `LY +${Number(
                                customerProgramActiveData[0].AOV_TY_VS_LY
                              ).toFixed(2)}%`)}
                      </span>
                    )}
                    <br />
                    {customerProgramActiveData !== undefined &&
                    customerProgramActiveData.length !== 0 &&
                    Number(customerProgramActiveData[0].AOV_TY_VS_LLY)
                      .toFixed(2)
                      .includes("-") ? (
                      <span style={{ color: "red", fontSize: "11px" }}>
                        {customerProgramActiveData !== undefined &&
                          customerProgramActiveData.length !== 0 &&
                          (customerProgramActiveData[0].AOV_TY_VS_LLY ===
                          "-999999"
                            ? "-"
                            : `LLY ${Number(
                                customerProgramActiveData[0].AOV_TY_VS_LLY
                              ).toFixed(2)}%`)}
                      </span>
                    ) : (
                      <span style={{ color: "green", fontSize: "11px" }}>
                        {customerProgramActiveData !== undefined &&
                          customerProgramActiveData.length !== 0 &&
                          (customerProgramActiveData[0].AOV_TY_VS_LLY ===
                          "-999999"
                            ? "-"
                            : `LLY +${Number(
                                customerProgramActiveData[0].AOV_TY_VS_LLY
                              ).toFixed(2)}%`)}
                      </span>
                    )}
                  </td>
                  <td>
                    {customerProgramActiveData !== undefined &&
                      customerProgramActiveData.length !== 0 &&
                      (customerProgramActiveData[0].UPT_TY === "-999999"
                        ? "-"
                        : Number(customerProgramActiveData[0].UPT_TY).toFixed(
                            1
                          ))}
                    <br />
                    {customerProgramActiveData !== undefined &&
                    customerProgramActiveData.length !== 0 &&
                    Number(customerProgramActiveData[0].UPT_TY_VS_LY)
                      .toFixed(2)
                      .includes("-") ? (
                      <span style={{ color: "red", fontSize: "12px" }}>
                        {customerProgramActiveData !== undefined &&
                          customerProgramActiveData.length !== 0 &&
                          (customerProgramActiveData[0].UPT_TY_VS_LY ===
                          "-999999"
                            ? "-"
                            : `LY ${Number(
                                customerProgramActiveData[0].UPT_TY_VS_LY
                              ).toFixed(2)}%`)}
                      </span>
                    ) : (
                      <span style={{ color: "green", fontSize: "12px" }}>
                        {customerProgramActiveData !== undefined &&
                          customerProgramActiveData.length !== 0 &&
                          (customerProgramActiveData[0].UPT_TY_VS_LY ===
                          "-999999"
                            ? "-"
                            : `LY +${Number(
                                customerProgramActiveData[0].UPT_TY_VS_LY
                              ).toFixed(2)}%`)}
                      </span>
                    )}
                    <br />
                    {customerProgramActiveData !== undefined &&
                    customerProgramActiveData.length !== 0 &&
                    Number(customerProgramActiveData[0].UPT_TY_VS_LLY)
                      .toFixed(2)
                      .includes("-") ? (
                      <span style={{ color: "red", fontSize: "11px" }}>
                        {customerProgramActiveData !== undefined &&
                          customerProgramActiveData.length !== 0 &&
                          (customerProgramActiveData[0].UPT_TY_VS_LLY ===
                          "-999999"
                            ? "-"
                            : `LLY ${Number(
                                customerProgramActiveData[0].UPT_TY_VS_LLY
                              ).toFixed(2)}%`)}
                      </span>
                    ) : (
                      <span style={{ color: "green", fontSize: "11px" }}>
                        {customerProgramActiveData !== undefined &&
                          customerProgramActiveData.length !== 0 &&
                          (customerProgramActiveData[0].UPT_TY_VS_LLY ===
                          "-999999"
                            ? "-"
                            : `LLY +${Number(
                                customerProgramActiveData[0].UPT_TY_VS_LLY
                              ).toFixed(2)}%`)}
                      </span>
                    )}
                  </td>
                  <td>
                    {customerProgramActiveData !== undefined &&
                      customerProgramActiveData.length !== 0 &&
                      (customerProgramActiveData[0].AUR_TY === "-999999"
                        ? "-"
                        : "$" +
                          Number(customerProgramActiveData[0].AUR_TY).toFixed(
                            2
                          ))}
                    <br />
                    {customerProgramActiveData !== undefined &&
                    customerProgramActiveData.length !== 0 &&
                    Number(customerProgramActiveData[0].AUR_TY_VS_LY)
                      .toFixed(2)
                      .includes("-") ? (
                      <span style={{ color: "red", fontSize: "12px" }}>
                        {customerProgramActiveData !== undefined &&
                          customerProgramActiveData.length !== 0 &&
                          (customerProgramActiveData[0].AUR_TY_VS_LY ===
                          "-999999"
                            ? "-"
                            : `LY ${Number(
                                customerProgramActiveData[0].AUR_TY_VS_LY
                              ).toFixed(2)}%`)}
                      </span>
                    ) : (
                      <span style={{ color: "green", fontSize: "12px" }}>
                        {customerProgramActiveData !== undefined &&
                          customerProgramActiveData.length !== 0 &&
                          (customerProgramActiveData[0].AUR_TY_VS_LY ===
                          "-999999"
                            ? "-"
                            : `LY +${Number(
                                customerProgramActiveData[0].AUR_TY_VS_LY
                              ).toFixed(2)}%`)}
                      </span>
                    )}
                    <br />
                    {customerProgramActiveData !== undefined &&
                    customerProgramActiveData.length !== 0 &&
                    Number(customerProgramActiveData[0].AUR_TY_VS_LLY)
                      .toFixed(2)
                      .includes("-") ? (
                      <span style={{ color: "red", fontSize: "11px" }}>
                        {customerProgramActiveData !== undefined &&
                          customerProgramActiveData.length !== 0 &&
                          (customerProgramActiveData[0].AUR_TY_VS_LLY ===
                          "-999999"
                            ? "-"
                            : `LLY ${Number(
                                customerProgramActiveData[0].AUR_TY_VS_LLY
                              ).toFixed(2)}%`)}
                      </span>
                    ) : (
                      <span style={{ color: "green", fontSize: "11px" }}>
                        {customerProgramActiveData !== undefined &&
                          customerProgramActiveData.length !== 0 &&
                          (customerProgramActiveData[0].AUR_TY_VS_LLY ===
                          "-999999"
                            ? "-"
                            : `LLY +${Number(
                                customerProgramActiveData[0].AUR_TY_VS_LLY
                              ).toFixed(2)}%`)}
                      </span>
                    )}
                  </td>
                  <td>
                    {customerProgramActiveData !== undefined &&
                      customerProgramActiveData.length !== 0 &&
                      (customerProgramActiveData[0].MARGIN_RATE_PER_TY ===
                      "-999999"
                        ? "-"
                        : Number(
                            customerProgramActiveData[0].MARGIN_RATE_PER_TY
                          ).toFixed(2))}
                    <br />
                    {customerProgramActiveData !== undefined &&
                    customerProgramActiveData.length !== 0 &&
                    Number(
                      customerProgramActiveData[0].MARGIN_RATE_PER_TY_VS_LY
                    )
                      .toFixed(2)
                      .includes("-") ? (
                      <span style={{ color: "red", fontSize: "12px" }}>
                        {customerProgramActiveData !== undefined &&
                          customerProgramActiveData.length !== 0 &&
                          (customerProgramActiveData[0]
                            .MARGIN_RATE_PER_TY_VS_LY === "-999999"
                            ? "-"
                            : `LY ${Number(
                                customerProgramActiveData[0]
                                  .MARGIN_RATE_PER_TY_VS_LY
                              ).toFixed(2)}%`)}
                      </span>
                    ) : (
                      <span style={{ color: "green", fontSize: "12px" }}>
                        {customerProgramActiveData !== undefined &&
                          customerProgramActiveData.length !== 0 &&
                          (customerProgramActiveData[0]
                            .MARGIN_RATE_PER_TY_VS_LY === "-999999"
                            ? "-"
                            : `LY +${Number(
                                customerProgramActiveData[0]
                                  .MARGIN_RATE_PER_TY_VS_LY
                              ).toFixed(2)}%`)}
                      </span>
                    )}
                    <br />
                    {customerProgramActiveData !== undefined &&
                    customerProgramActiveData.length !== 0 &&
                    Number(
                      customerProgramActiveData[0].MARGIN_RATE_PER_TY_VS_LLY
                    )
                      .toFixed(2)
                      .includes("-") ? (
                      <span style={{ color: "red", fontSize: "11px" }}>
                        {customerProgramActiveData !== undefined &&
                          customerProgramActiveData.length !== 0 &&
                          (customerProgramActiveData[0]
                            .MARGIN_RATE_PER_TY_VS_LLY === "-999999"
                            ? "-"
                            : `LLY ${Number(
                                customerProgramActiveData[0]
                                  .MARGIN_RATE_PER_TY_VS_LLY
                              ).toFixed(2)}%`)}
                      </span>
                    ) : (
                      <span style={{ color: "green", fontSize: "11px" }}>
                        {customerProgramActiveData !== undefined &&
                          customerProgramActiveData.length !== 0 &&
                          (customerProgramActiveData[0]
                            .MARGIN_RATE_PER_TY_VS_LLY === "-999999"
                            ? "-"
                            : `LLY +${Number(
                                customerProgramActiveData[0]
                                  .MARGIN_RATE_PER_TY_VS_LLY
                              ).toFixed(2)}%`)}
                      </span>
                    )}
                  </td>
                  <td>
                    {customerProgramActiveData !== undefined &&
                      customerProgramActiveData.length !== 0 &&
                      (customerProgramActiveData[0].NET_SALES_PER_CUST_TY ===
                      "-999999"
                        ? "-"
                        : "$" +
                          Number(
                            customerProgramActiveData[0].NET_SALES_PER_CUST_TY
                          ).toFixed(2))}
                    <br />
                    {customerProgramActiveData !== undefined &&
                    customerProgramActiveData.length !== 0 &&
                    Number(
                      customerProgramActiveData[0].NET_SALES_PER_CUST_TY_VS_LY
                    )
                      .toFixed(2)
                      .includes("-") ? (
                      <span style={{ color: "red", fontSize: "12px" }}>
                        {customerProgramActiveData !== undefined &&
                          customerProgramActiveData.length !== 0 &&
                          (customerProgramActiveData[0]
                            .NET_SALES_PER_CUST_TY_VS_LY === "-999999"
                            ? "-"
                            : `LY ${Number(
                                customerProgramActiveData[0]
                                  .NET_SALES_PER_CUST_TY_VS_LY
                              ).toFixed(2)}%`)}
                      </span>
                    ) : (
                      <span style={{ color: "green", fontSize: "12px" }}>
                        {customerProgramActiveData !== undefined &&
                          customerProgramActiveData.length !== 0 &&
                          (customerProgramActiveData[0]
                            .NET_SALES_PER_CUST_TY_VS_LY === "-999999"
                            ? "-"
                            : `LY +${Number(
                                customerProgramActiveData[0]
                                  .NET_SALES_PER_CUST_TY_VS_LY
                              ).toFixed(2)}%`)}
                      </span>
                    )}
                    <br />
                    {customerProgramActiveData !== undefined &&
                    customerProgramActiveData.length !== 0 &&
                    Number(
                      customerProgramActiveData[0].NET_SALES_PER_CUST_TY_VS_LLY
                    )
                      .toFixed(2)
                      .includes("-") ? (
                      <span style={{ color: "red", fontSize: "11px" }}>
                        {customerProgramActiveData !== undefined &&
                          customerProgramActiveData.length !== 0 &&
                          (customerProgramActiveData[0]
                            .NET_SALES_PER_CUST_TY_VS_LLY === "-999999"
                            ? "-"
                            : `LLY ${Number(
                                customerProgramActiveData[0]
                                  .NET_SALES_PER_CUST_TY_VS_LLY
                              ).toFixed(2)}%`)}
                      </span>
                    ) : (
                      <span style={{ color: "green", fontSize: "11px" }}>
                        {customerProgramActiveData !== undefined &&
                          customerProgramActiveData.length !== 0 &&
                          (customerProgramActiveData[0]
                            .NET_SALES_PER_CUST_TY_VS_LLY === "-999999"
                            ? "-"
                            : `LLY +${Number(
                                customerProgramActiveData[0]
                                  .NET_SALES_PER_CUST_TY_VS_LLY
                              ).toFixed(2)}%`)}
                      </span>
                    )}
                  </td>
                  <td>
                    {customerProgramActiveData !== undefined &&
                      customerProgramActiveData.length !== 0 &&
                      (customerProgramActiveData[0].AVG_TRAN_TY === "-999999"
                        ? "-"
                        : Number(
                            customerProgramActiveData[0].AVG_TRAN_TY
                          ).toFixed(2))}
                    <br />
                    {customerProgramActiveData !== undefined &&
                    customerProgramActiveData.length !== 0 &&
                    Number(customerProgramActiveData[0].AVG_TRAN_TY_VS_LY)
                      .toFixed(2)
                      .includes("-") ? (
                      <span style={{ color: "red", fontSize: "12px" }}>
                        {customerProgramActiveData !== undefined &&
                          customerProgramActiveData.length !== 0 &&
                          (customerProgramActiveData[0].AVG_TRAN_TY_VS_LY ===
                          "-999999"
                            ? "-"
                            : `LY ${Number(
                                customerProgramActiveData[0].AVG_TRAN_TY_VS_LY
                              ).toFixed(2)}%`)}
                      </span>
                    ) : (
                      <span style={{ color: "green", fontSize: "12px" }}>
                        {customerProgramActiveData !== undefined &&
                          customerProgramActiveData.length !== 0 &&
                          (customerProgramActiveData[0].AVG_TRAN_TY_VS_LY ===
                          "-999999"
                            ? "-"
                            : `LY +${Number(
                                customerProgramActiveData[0].AVG_TRAN_TY_VS_LY
                              ).toFixed(2)}%`)}
                      </span>
                    )}
                    <br />
                    {customerProgramActiveData !== undefined &&
                    customerProgramActiveData.length !== 0 &&
                    Number(customerProgramActiveData[0].AVG_TRAN_TY_VS_LLY)
                      .toFixed(2)
                      .includes("-") ? (
                      <span style={{ color: "red", fontSize: "11px" }}>
                        {customerProgramActiveData !== undefined &&
                          customerProgramActiveData.length !== 0 &&
                          (customerProgramActiveData[0].AVG_TRAN_TY_VS_LLY ===
                          "-999999"
                            ? "-"
                            : `LLY ${Number(
                                customerProgramActiveData[0].AVG_TRAN_TY_VS_LLY
                              ).toFixed(2)}%`)}
                      </span>
                    ) : (
                      <span style={{ color: "green", fontSize: "11px" }}>
                        {customerProgramActiveData !== undefined &&
                          customerProgramActiveData.length !== 0 &&
                          (customerProgramActiveData[0].AVG_TRAN_TY_VS_LLY ===
                          "-999999"
                            ? "-"
                            : `LLY +${Number(
                                customerProgramActiveData[0].AVG_TRAN_TY_VS_LLY
                              ).toFixed(2)}%`)}
                      </span>
                    )}
                  </td>
                </>
              )}
            </tr>
            <tr>
              <td className="tableCol" id={"AtRisk_69"}>
                {"At risk (6m-9m)"}{" "}
                {gettooltip(
                  "AtRisk_6_9InfoIcon",
                  "AtRisk_6_9",
                  "AtRisk_6_9",
                  "Active in L9M but not active in L6M"
                )}
              </td>
              {loading.AtRisk_6m_9m ? (
                <>
                  <LoaderForRow tdCount={10} />
                </>
              ) : (
                <>
                  <td>
                    {customerProgramDataSixMonths !== undefined &&
                      customerProgramDataSixMonths.length !== 0 &&
                      (customerProgramDataSixMonths[0].CUST_COUNT_TY ===
                      "-999999"
                        ? "-"
                        : currencyFormat(
                            Number(
                              customerProgramDataSixMonths[0].CUST_COUNT_TY
                            )
                          ))}
                    <br />
                    {customerProgramDataSixMonths !== undefined &&
                    customerProgramDataSixMonths.length !== 0 &&
                    Number(customerProgramDataSixMonths[0].TY_VS_LY)
                      .toFixed(2)
                      .includes("-") ? (
                      <span style={{ color: "green", fontSize: "12px" }}>
                        {customerProgramDataSixMonths !== undefined &&
                          customerProgramDataSixMonths.length !== 0 &&
                          (customerProgramDataSixMonths[0].TY_VS_LY ===
                          "-999999"
                            ? "-"
                            : `LY ${Number(
                                customerProgramDataSixMonths[0].TY_VS_LY
                              ).toFixed(2)}%`)}
                      </span>
                    ) : (
                      <span style={{ color: "red", fontSize: "12px" }}>
                        {customerProgramDataSixMonths !== undefined &&
                          customerProgramDataSixMonths.length !== 0 &&
                          (customerProgramDataSixMonths[0].TY_VS_LY ===
                          "-999999"
                            ? "-"
                            : `LY +${Number(
                                customerProgramDataSixMonths[0].TY_VS_LY
                              ).toFixed(2)}%`)}
                      </span>
                    )}
                    <br />
                    {customerProgramDataSixMonths !== undefined &&
                    customerProgramDataSixMonths.length !== 0 &&
                    Number(customerProgramDataSixMonths[0].TY_VS_LLY)
                      .toFixed(2)
                      .includes("-") ? (
                      <span style={{ color: "green", fontSize: "11px" }}>
                        {customerProgramDataSixMonths !== undefined &&
                          customerProgramDataSixMonths.length !== 0 &&
                          (customerProgramDataSixMonths[0].TY_VS_LLY ===
                          "-999999"
                            ? "-"
                            : `LLY ${Number(
                                customerProgramDataSixMonths[0].TY_VS_LLY
                              ).toFixed(2)}%`)}
                      </span>
                    ) : (
                      <span style={{ color: "red", fontSize: "11px" }}>
                        {customerProgramDataSixMonths !== undefined &&
                          customerProgramDataSixMonths.length !== 0 &&
                          (customerProgramDataSixMonths[0].TY_VS_LLY ===
                          "-999999"
                            ? "-"
                            : `LLY +${Number(
                                customerProgramDataSixMonths[0].TY_VS_LLY
                              ).toFixed(2)}%`)}
                      </span>
                    )}
                  </td>
                  <td>
                    {customerProgramDataSixMonths !== undefined &&
                      customerProgramDataSixMonths.length !== 0 &&
                      (customerProgramDataSixMonths[0].NET_SALES_TY ===
                      "-999999"
                        ? "-"
                        : "$" +
                          currencyFormat(
                            Number(customerProgramDataSixMonths[0].NET_SALES_TY)
                          ))}
                    <br />
                    {customerProgramDataSixMonths !== undefined &&
                    customerProgramDataSixMonths.length !== 0 &&
                    Number(customerProgramDataSixMonths[0].NET_SALES_TY_VS_LY)
                      .toFixed(2)
                      .includes("-") ? (
                      <span style={{ color: "green", fontSize: "12px" }}>
                        {customerProgramDataSixMonths !== undefined &&
                          customerProgramDataSixMonths.length !== 0 &&
                          (customerProgramDataSixMonths[0]
                            .NET_SALES_TY_VS_LY === "-999999"
                            ? "-"
                            : `LY ${Number(
                                customerProgramDataSixMonths[0]
                                  .NET_SALES_TY_VS_LY
                              ).toFixed(2)}%`)}
                      </span>
                    ) : (
                      <span style={{ color: "red", fontSize: "12px" }}>
                        {customerProgramDataSixMonths !== undefined &&
                          customerProgramDataSixMonths.length !== 0 &&
                          (customerProgramDataSixMonths[0]
                            .NET_SALES_TY_VS_LY === "-999999"
                            ? "-"
                            : `LY +${Number(
                                customerProgramDataSixMonths[0]
                                  .NET_SALES_TY_VS_LY
                              ).toFixed(2)}%`)}
                      </span>
                    )}
                    <br />
                    {customerProgramDataSixMonths !== undefined &&
                    customerProgramDataSixMonths.length !== 0 &&
                    Number(customerProgramDataSixMonths[0].NET_SALES_TY_VS_LLY)
                      .toFixed(2)
                      .includes("-") ? (
                      <span style={{ color: "green", fontSize: "11px" }}>
                        {customerProgramDataSixMonths !== undefined &&
                          customerProgramDataSixMonths.length !== 0 &&
                          (customerProgramDataSixMonths[0]
                            .NET_SALES_TY_VS_LLY === "-999999"
                            ? "-"
                            : `LLY ${Number(
                                customerProgramDataSixMonths[0]
                                  .NET_SALES_TY_VS_LLY
                              ).toFixed(2)}%`)}
                      </span>
                    ) : (
                      <span style={{ color: "red", fontSize: "11px" }}>
                        {customerProgramDataSixMonths !== undefined &&
                          customerProgramDataSixMonths.length !== 0 &&
                          (customerProgramDataSixMonths[0]
                            .NET_SALES_TY_VS_LLY === "-999999"
                            ? "-"
                            : `LLY +${Number(
                                customerProgramDataSixMonths[0]
                                  .NET_SALES_TY_VS_LLY
                              ).toFixed(2)}%`)}
                      </span>
                    )}
                  </td>
                  <td>
                    {customerProgramDataSixMonths !== undefined &&
                      customerProgramDataSixMonths.length !== 0 &&
                      (customerProgramDataSixMonths[0].TRANS_COUNT_TY ===
                      "-999999"
                        ? "-"
                        : currencyFormat(
                            Number(
                              customerProgramDataSixMonths[0].TRANS_COUNT_TY
                            )
                          ))}
                    <br />
                    {customerProgramDataSixMonths !== undefined &&
                    customerProgramDataSixMonths.length !== 0 &&
                    Number(customerProgramDataSixMonths[0].TRANS_TY_VS_LY)
                      .toFixed(2)
                      .includes("-") ? (
                      <span style={{ color: "green", fontSize: "12px" }}>
                        {customerProgramDataSixMonths !== undefined &&
                          customerProgramDataSixMonths.length !== 0 &&
                          (customerProgramDataSixMonths[0].TRANS_TY_VS_LY ===
                          "-999999"
                            ? "-"
                            : `LY ${Number(
                                customerProgramDataSixMonths[0].TRANS_TY_VS_LY
                              ).toFixed(2)}%`)}
                      </span>
                    ) : (
                      <span style={{ color: "red", fontSize: "12px" }}>
                        {customerProgramDataSixMonths !== undefined &&
                          customerProgramDataSixMonths.length !== 0 &&
                          (customerProgramDataSixMonths[0].TRANS_TY_VS_LY ===
                          "-999999"
                            ? "-"
                            : `LY ${Number(
                                customerProgramDataSixMonths[0].TRANS_TY_VS_LY
                              ).toFixed(2)}%`)}
                      </span>
                    )}
                    <br />
                    {customerProgramDataSixMonths !== undefined &&
                    customerProgramDataSixMonths.length !== 0 &&
                    Number(customerProgramDataSixMonths[0].TRANS_TY_VS_LLY)
                      .toFixed(2)
                      .includes("-") ? (
                      <span style={{ color: "green", fontSize: "11px" }}>
                        {customerProgramDataSixMonths !== undefined &&
                          customerProgramDataSixMonths.length !== 0 &&
                          (customerProgramDataSixMonths[0].TRANS_TY_VS_LLY ===
                          "-999999"
                            ? "-"
                            : `LLY ${Number(
                                customerProgramDataSixMonths[0].TRANS_TY_VS_LLY
                              ).toFixed(2)}%`)}
                      </span>
                    ) : (
                      <span style={{ color: "red", fontSize: "11px" }}>
                        {customerProgramDataSixMonths !== undefined &&
                          customerProgramDataSixMonths.length !== 0 &&
                          (customerProgramDataSixMonths[0].TRANS_TY_VS_LLY ===
                          "-999999"
                            ? "-"
                            : `LLY +${Number(
                                customerProgramDataSixMonths[0].TRANS_TY_VS_LLY
                              ).toFixed(2)}%`)}
                      </span>
                    )}
                  </td>
                  <td>
                    {customerProgramDataSixMonths !== undefined &&
                      customerProgramDataSixMonths.length !== 0 &&
                      (customerProgramDataSixMonths[0].PM_TY === "-999999"
                        ? "-"
                        : "$" +
                          currencyFormat(
                            Number(customerProgramDataSixMonths[0].PM_TY)
                          ))}
                    <br />
                    {customerProgramDataSixMonths !== undefined &&
                    customerProgramDataSixMonths.length !== 0 &&
                    Number(customerProgramDataSixMonths[0].PM_TY_VS_LY)
                      .toFixed(2)
                      .includes("-") ? (
                      <span style={{ color: "green", fontSize: "12px" }}>
                        {customerProgramDataSixMonths !== undefined &&
                          customerProgramDataSixMonths.length !== 0 &&
                          (customerProgramDataSixMonths[0].PM_TY_VS_LY ===
                          "-999999"
                            ? "-"
                            : `LY ${Number(
                                customerProgramDataSixMonths[0].PM_TY_VS_LY
                              ).toFixed(2)}%`)}
                      </span>
                    ) : (
                      <span style={{ color: "red", fontSize: "12px" }}>
                        {customerProgramDataSixMonths !== undefined &&
                          customerProgramDataSixMonths.length !== 0 &&
                          (customerProgramDataSixMonths[0].PM_TY_VS_LY ===
                          "-999999"
                            ? "-"
                            : `LY +${Number(
                                customerProgramDataSixMonths[0].PM_TY_VS_LY
                              ).toFixed(2)}%`)}
                      </span>
                    )}
                    <br />
                    {customerProgramDataSixMonths !== undefined &&
                    customerProgramDataSixMonths.length !== 0 &&
                    Number(customerProgramDataSixMonths[0].PM_TY_VS_LLY)
                      .toFixed(2)
                      .includes("-") ? (
                      <span style={{ color: "green", fontSize: "11px" }}>
                        {customerProgramDataSixMonths !== undefined &&
                          customerProgramDataSixMonths.length !== 0 &&
                          (customerProgramDataSixMonths[0].PM_TY_VS_LLY ===
                          "-999999"
                            ? "-"
                            : `LLY ${Number(
                                customerProgramDataSixMonths[0].PM_TY_VS_LLY
                              ).toFixed(2)}%`)}
                      </span>
                    ) : (
                      <span style={{ color: "red", fontSize: "11px" }}>
                        {customerProgramDataSixMonths !== undefined &&
                          customerProgramDataSixMonths.length !== 0 &&
                          (customerProgramDataSixMonths[0].PM_TY_VS_LLY ===
                          "-999999"
                            ? "-"
                            : `LLY +${Number(
                                customerProgramDataSixMonths[0].PM_TY_VS_LLY
                              ).toFixed(2)}%`)}
                      </span>
                    )}
                  </td>
                  <td>
                    {customerProgramDataSixMonths !== undefined &&
                      customerProgramDataSixMonths.length !== 0 &&
                      (customerProgramDataSixMonths[0].AOV_TY === "-999999"
                        ? "-"
                        : "$" +
                          Number(
                            customerProgramDataSixMonths[0].AOV_TY
                          ).toFixed(2))}
                    <br />
                    {customerProgramDataSixMonths !== undefined &&
                    customerProgramDataSixMonths.length !== 0 &&
                    Number(customerProgramDataSixMonths[0].AOV_TY_VS_LY)
                      .toFixed(2)
                      .includes("-") ? (
                      <span style={{ color: "green", fontSize: "12px" }}>
                        {customerProgramDataSixMonths !== undefined &&
                          customerProgramDataSixMonths.length !== 0 &&
                          (customerProgramDataSixMonths[0].AOV_TY_VS_LY ===
                          "-999999"
                            ? "-"
                            : `LY ${Number(
                                customerProgramDataSixMonths[0].AOV_TY_VS_LY
                              ).toFixed(2)}%`)}
                      </span>
                    ) : (
                      <span style={{ color: "red", fontSize: "12px" }}>
                        {customerProgramDataSixMonths !== undefined &&
                          customerProgramDataSixMonths.length !== 0 &&
                          (customerProgramDataSixMonths[0].AOV_TY_VS_LY ===
                          "-999999"
                            ? "-"
                            : `LY +${Number(
                                customerProgramDataSixMonths[0].AOV_TY_VS_LY
                              ).toFixed(2)}%`)}
                      </span>
                    )}
                    <br />
                    {customerProgramDataSixMonths !== undefined &&
                    customerProgramDataSixMonths.length !== 0 &&
                    Number(customerProgramDataSixMonths[0].AOV_TY_VS_LLY)
                      .toFixed(2)
                      .includes("-") ? (
                      <span style={{ color: "green", fontSize: "11px" }}>
                        {customerProgramDataSixMonths !== undefined &&
                          customerProgramDataSixMonths.length !== 0 &&
                          (customerProgramDataSixMonths[0].AOV_TY_VS_LLY ===
                          "-999999"
                            ? "-"
                            : `LLY ${Number(
                                customerProgramDataSixMonths[0].AOV_TY_VS_LLY
                              ).toFixed(2)}%`)}
                      </span>
                    ) : (
                      <span style={{ color: "red", fontSize: "11px" }}>
                        {customerProgramDataSixMonths !== undefined &&
                          customerProgramDataSixMonths.length !== 0 &&
                          (customerProgramDataSixMonths[0].AOV_TY_VS_LLY ===
                          "-999999"
                            ? "-"
                            : `LLY +${Number(
                                customerProgramDataSixMonths[0].AOV_TY_VS_LLY
                              ).toFixed(2)}%`)}
                      </span>
                    )}
                  </td>
                  <td>
                    {customerProgramDataSixMonths !== undefined &&
                      customerProgramDataSixMonths.length !== 0 &&
                      (customerProgramDataSixMonths[0].UPT_TY === "-999999"
                        ? "-"
                        : Number(
                            customerProgramDataSixMonths[0].UPT_TY
                          ).toFixed(1))}
                    <br />
                    {customerProgramDataSixMonths !== undefined &&
                    customerProgramDataSixMonths.length !== 0 &&
                    Number(customerProgramDataSixMonths[0].UPT_TY_VS_LY)
                      .toFixed(2)
                      .includes("-") ? (
                      <span style={{ color: "green", fontSize: "12px" }}>
                        {customerProgramDataSixMonths !== undefined &&
                          customerProgramDataSixMonths.length !== 0 &&
                          (customerProgramDataSixMonths[0].UPT_TY_VS_LY ===
                          "-999999"
                            ? "-"
                            : `LY ${Number(
                                customerProgramDataSixMonths[0].UPT_TY_VS_LY
                              ).toFixed(2)}%`)}
                      </span>
                    ) : (
                      <span style={{ color: "red", fontSize: "12px" }}>
                        {customerProgramDataSixMonths !== undefined &&
                          customerProgramDataSixMonths.length !== 0 &&
                          (customerProgramDataSixMonths[0].UPT_TY_VS_LY ===
                          "-999999"
                            ? "-"
                            : `LY +${Number(
                                customerProgramDataSixMonths[0].UPT_TY_VS_LY
                              ).toFixed(2)}%`)}
                      </span>
                    )}
                    <br />
                    {customerProgramDataSixMonths !== undefined &&
                    customerProgramDataSixMonths.length !== 0 &&
                    Number(customerProgramDataSixMonths[0].UPT_TY_VS_LLY)
                      .toFixed(2)
                      .includes("-") ? (
                      <span style={{ color: "green", fontSize: "11px" }}>
                        {customerProgramDataSixMonths !== undefined &&
                          customerProgramDataSixMonths.length !== 0 &&
                          (customerProgramDataSixMonths[0].UPT_TY_VS_LLY ===
                          "-999999"
                            ? "-"
                            : `LLY ${Number(
                                customerProgramDataSixMonths[0].UPT_TY_VS_LLY
                              ).toFixed(2)}%`)}
                      </span>
                    ) : (
                      <span style={{ color: "red", fontSize: "11px" }}>
                        {customerProgramDataSixMonths !== undefined &&
                          customerProgramDataSixMonths.length !== 0 &&
                          (customerProgramDataSixMonths[0].UPT_TY_VS_LLY ===
                          "-999999"
                            ? "-"
                            : `LLY +${Number(
                                customerProgramDataSixMonths[0].UPT_TY_VS_LLY
                              ).toFixed(2)}%`)}
                      </span>
                    )}
                  </td>
                  <td>
                    {customerProgramDataSixMonths !== undefined &&
                      customerProgramDataSixMonths.length !== 0 &&
                      (customerProgramDataSixMonths[0].AUR_TY === "-999999"
                        ? "-"
                        : "$" +
                          Number(
                            customerProgramDataSixMonths[0].AUR_TY
                          ).toFixed(2))}
                    <br />
                    {customerProgramDataSixMonths !== undefined &&
                    customerProgramDataSixMonths.length !== 0 &&
                    Number(customerProgramDataSixMonths[0].AUR_TY_VS_LY)
                      .toFixed(2)
                      .includes("-") ? (
                      <span style={{ color: "green", fontSize: "12px" }}>
                        {customerProgramDataSixMonths !== undefined &&
                          customerProgramDataSixMonths.length !== 0 &&
                          (customerProgramDataSixMonths[0].AUR_TY_VS_LY ===
                          "-999999"
                            ? "-"
                            : `LY ${Number(
                                customerProgramDataSixMonths[0].AUR_TY_VS_LY
                              ).toFixed(2)}%`)}
                      </span>
                    ) : (
                      <span style={{ color: "red", fontSize: "12px" }}>
                        {customerProgramDataSixMonths !== undefined &&
                          customerProgramDataSixMonths.length !== 0 &&
                          (customerProgramDataSixMonths[0].AUR_TY_VS_LY ===
                          "-999999"
                            ? "-"
                            : `LY +${Number(
                                customerProgramDataSixMonths[0].AUR_TY_VS_LY
                              ).toFixed(2)}%`)}
                      </span>
                    )}
                    <br />
                    {customerProgramDataSixMonths !== undefined &&
                    customerProgramDataSixMonths.length !== 0 &&
                    Number(customerProgramDataSixMonths[0].AUR_TY_VS_LLY)
                      .toFixed(2)
                      .includes("-") ? (
                      <span style={{ color: "green", fontSize: "11px" }}>
                        {customerProgramDataSixMonths !== undefined &&
                          customerProgramDataSixMonths.length !== 0 &&
                          (customerProgramDataSixMonths[0].AUR_TY_VS_LLY ===
                          "-999999"
                            ? "-"
                            : `LLY ${Number(
                                customerProgramDataSixMonths[0].AUR_TY_VS_LLY
                              ).toFixed(2)}%`)}
                      </span>
                    ) : (
                      <span style={{ color: "red", fontSize: "11px" }}>
                        {customerProgramDataSixMonths !== undefined &&
                          customerProgramDataSixMonths.length !== 0 &&
                          (customerProgramDataSixMonths[0].AUR_TY_VS_LLY ===
                          "-999999"
                            ? "-"
                            : `LLY +${Number(
                                customerProgramDataSixMonths[0].AUR_TY_VS_LLY
                              ).toFixed(2)}%`)}
                      </span>
                    )}
                  </td>
                  <td>
                    {customerProgramDataSixMonths !== undefined &&
                      customerProgramDataSixMonths.length !== 0 &&
                      (customerProgramDataSixMonths[0].MARGIN_RATE_PER_TY ===
                      "-999999"
                        ? "-"
                        : Number(
                            customerProgramDataSixMonths[0].MARGIN_RATE_PER_TY
                          ).toFixed(2))}
                    <br />
                    {customerProgramDataSixMonths !== undefined &&
                    customerProgramDataSixMonths.length !== 0 &&
                    Number(
                      customerProgramDataSixMonths[0].MARGIN_RATE_PER_TY_VS_LY
                    )
                      .toFixed(2)
                      .includes("-") ? (
                      <span style={{ color: "green", fontSize: "12px" }}>
                        {customerProgramDataSixMonths !== undefined &&
                          customerProgramDataSixMonths.length !== 0 &&
                          (customerProgramDataSixMonths[0]
                            .MARGIN_RATE_PER_TY_VS_LY === "-999999"
                            ? "-"
                            : `LY ${Number(
                                customerProgramDataSixMonths[0]
                                  .MARGIN_RATE_PER_TY_VS_LY
                              ).toFixed(2)}%`)}
                      </span>
                    ) : (
                      <span style={{ color: "red", fontSize: "12px" }}>
                        {customerProgramDataSixMonths !== undefined &&
                          customerProgramDataSixMonths.length !== 0 &&
                          (customerProgramDataSixMonths[0]
                            .MARGIN_RATE_PER_TY_VS_LY === "-999999"
                            ? "-"
                            : `LY +${Number(
                                customerProgramDataSixMonths[0]
                                  .MARGIN_RATE_PER_TY_VS_LY
                              ).toFixed(2)}%`)}
                      </span>
                    )}
                    <br />
                    {customerProgramDataSixMonths !== undefined &&
                    customerProgramDataSixMonths.length !== 0 &&
                    Number(
                      customerProgramDataSixMonths[0].MARGIN_RATE_PER_TY_VS_LLY
                    )
                      .toFixed(2)
                      .includes("-") ? (
                      <span style={{ color: "green", fontSize: "11px" }}>
                        {customerProgramDataSixMonths !== undefined &&
                          customerProgramDataSixMonths.length !== 0 &&
                          (customerProgramDataSixMonths[0]
                            .MARGIN_RATE_PER_TY_VS_LLY === "-999999"
                            ? "-"
                            : `LLY ${Number(
                                customerProgramDataSixMonths[0]
                                  .MARGIN_RATE_PER_TY_VS_LLY
                              ).toFixed(2)}%`)}
                      </span>
                    ) : (
                      <span style={{ color: "red", fontSize: "11px" }}>
                        {customerProgramDataSixMonths !== undefined &&
                          customerProgramDataSixMonths.length !== 0 &&
                          (customerProgramDataSixMonths[0]
                            .MARGIN_RATE_PER_TY_VS_LLY === "-999999"
                            ? "-"
                            : `LLY +${Number(
                                customerProgramDataSixMonths[0]
                                  .MARGIN_RATE_PER_TY_VS_LLY
                              ).toFixed(2)}%`)}
                      </span>
                    )}
                  </td>
                  <td>
                    {customerProgramDataSixMonths !== undefined &&
                      customerProgramDataSixMonths.length !== 0 &&
                      (customerProgramDataSixMonths[0].NET_SALES_PER_CUST_TY ===
                      "-999999"
                        ? "-"
                        : "$" +
                          Number(
                            customerProgramDataSixMonths[0]
                              .NET_SALES_PER_CUST_TY
                          ).toFixed(2))}
                    <br />
                    {customerProgramDataSixMonths !== undefined &&
                    customerProgramDataSixMonths.length !== 0 &&
                    Number(
                      customerProgramDataSixMonths[0]
                        .NET_SALES_PER_CUST_TY_VS_LY
                    )
                      .toFixed(2)
                      .includes("-") ? (
                      <span style={{ color: "green", fontSize: "12px" }}>
                        {customerProgramDataSixMonths !== undefined &&
                          customerProgramDataSixMonths.length !== 0 &&
                          (customerProgramDataSixMonths[0]
                            .NET_SALES_PER_CUST_TY_VS_LY === "-999999"
                            ? "-"
                            : `LY ${Number(
                                customerProgramDataSixMonths[0]
                                  .NET_SALES_PER_CUST_TY_VS_LY
                              ).toFixed(2)}%`)}
                      </span>
                    ) : (
                      <span style={{ color: "red", fontSize: "12px" }}>
                        {customerProgramDataSixMonths !== undefined &&
                          customerProgramDataSixMonths.length !== 0 &&
                          (customerProgramDataSixMonths[0]
                            .NET_SALES_PER_CUST_TY_VS_LY === "-999999"
                            ? "-"
                            : `LY +${Number(
                                customerProgramDataSixMonths[0]
                                  .NET_SALES_PER_CUST_TY_VS_LY
                              ).toFixed(2)}%`)}
                      </span>
                    )}
                    <br />
                    {customerProgramDataSixMonths !== undefined &&
                    customerProgramDataSixMonths.length !== 0 &&
                    Number(
                      customerProgramDataSixMonths[0]
                        .NET_SALES_PER_CUST_TY_VS_LLY
                    )
                      .toFixed(2)
                      .includes("-") ? (
                      <span style={{ color: "green", fontSize: "11px" }}>
                        {customerProgramDataSixMonths !== undefined &&
                          customerProgramDataSixMonths.length !== 0 &&
                          (customerProgramDataSixMonths[0]
                            .NET_SALES_PER_CUST_TY_VS_LLY === "-999999"
                            ? "-"
                            : `LLY ${Number(
                                customerProgramDataSixMonths[0]
                                  .NET_SALES_PER_CUST_TY_VS_LLY
                              ).toFixed(2)}%`)}
                      </span>
                    ) : (
                      <span style={{ color: "red", fontSize: "11px" }}>
                        {customerProgramDataSixMonths !== undefined &&
                          customerProgramDataSixMonths.length !== 0 &&
                          (customerProgramDataSixMonths[0]
                            .NET_SALES_PER_CUST_TY_VS_LLY === "-999999"
                            ? "-"
                            : `LLY +${Number(
                                customerProgramDataSixMonths[0]
                                  .NET_SALES_PER_CUST_TY_VS_LLY
                              ).toFixed(2)}%`)}
                      </span>
                    )}
                  </td>
                  <td>
                    {customerProgramDataSixMonths !== undefined &&
                      customerProgramDataSixMonths.length !== 0 &&
                      (customerProgramDataSixMonths[0].AVG_TRAN_TY === "-999999"
                        ? "-"
                        : Number(
                            customerProgramDataSixMonths[0].AVG_TRAN_TY
                          ).toFixed(2))}
                    <br />
                    {customerProgramDataSixMonths !== undefined &&
                    customerProgramDataSixMonths.length !== 0 &&
                    Number(customerProgramDataSixMonths[0].AVG_TRAN_TY_VS_LY)
                      .toFixed(2)
                      .includes("-") ? (
                      <span style={{ color: "green", fontSize: "12px" }}>
                        {customerProgramDataSixMonths !== undefined &&
                          customerProgramDataSixMonths.length !== 0 &&
                          (customerProgramDataSixMonths[0].AVG_TRAN_TY_VS_LY ===
                          "-999999"
                            ? "-"
                            : `LY ${Number(
                                customerProgramDataSixMonths[0]
                                  .AVG_TRAN_TY_VS_LY
                              ).toFixed(2)}%`)}
                      </span>
                    ) : (
                      <span style={{ color: "red", fontSize: "12px" }}>
                        {customerProgramDataSixMonths !== undefined &&
                          customerProgramDataSixMonths.length !== 0 &&
                          (customerProgramDataSixMonths[0].AVG_TRAN_TY_VS_LY ===
                          "-999999"
                            ? "-"
                            : `LY +${Number(
                                customerProgramDataSixMonths[0]
                                  .AVG_TRAN_TY_VS_LY
                              ).toFixed(2)}%`)}
                      </span>
                    )}
                    <br />
                    {customerProgramDataSixMonths !== undefined &&
                    customerProgramDataSixMonths.length !== 0 &&
                    Number(customerProgramDataSixMonths[0].AVG_TRAN_TY_VS_LLY)
                      .toFixed(2)
                      .includes("-") ? (
                      <span style={{ color: "green", fontSize: "11px" }}>
                        {customerProgramDataSixMonths !== undefined &&
                          customerProgramDataSixMonths.length !== 0 &&
                          (customerProgramDataSixMonths[0]
                            .AVG_TRAN_TY_VS_LLY === "-999999"
                            ? "-"
                            : `LLY ${Number(
                                customerProgramDataSixMonths[0]
                                  .AVG_TRAN_TY_VS_LLY
                              ).toFixed(2)}%`)}
                      </span>
                    ) : (
                      <span style={{ color: "red", fontSize: "11px" }}>
                        {customerProgramDataSixMonths !== undefined &&
                          customerProgramDataSixMonths.length !== 0 &&
                          (customerProgramDataSixMonths[0]
                            .AVG_TRAN_TY_VS_LLY === "-999999"
                            ? "-"
                            : `LLY +${Number(
                                customerProgramDataSixMonths[0]
                                  .AVG_TRAN_TY_VS_LLY
                              ).toFixed(2)}%`)}
                      </span>
                    )}
                  </td>
                </>
              )}
            </tr>
            <tr>
              <td className="tableCol" id={"AtRisk_9_12"}>
                {"At risk (9m-12m)"}{" "}
                {gettooltip(
                  "AtRisk_9_12InfoIcon",
                  "AtRisk_9_12",
                  "AtRisk_9_12",
                  "Active in L12M but not active in L9M"
                )}
              </td>
              {loading.AtRisk_9m_12m ? (
                <>
                  <LoaderForRow tdCount={10} />
                </>
              ) : (
                <>
                  <td>
                    {customerProgramDataNineMonths !== undefined &&
                      customerProgramDataNineMonths.length !== 0 &&
                      (customerProgramDataNineMonths[0].CUST_COUNT_TY ===
                      "-999999"
                        ? "-"
                        : currencyFormat(
                            Number(
                              customerProgramDataNineMonths[0].CUST_COUNT_TY
                            )
                          ))}
                    <br />
                    {customerProgramDataNineMonths !== undefined &&
                    customerProgramDataNineMonths.length !== 0 &&
                    Number(customerProgramDataNineMonths[0].TY_VS_LY)
                      .toFixed(2)
                      .includes("-") ? (
                      <span style={{ color: "green", fontSize: "12px" }}>
                        {customerProgramDataNineMonths !== undefined &&
                          customerProgramDataNineMonths.length !== 0 &&
                          (customerProgramDataNineMonths[0].TY_VS_LY ===
                          "-999999"
                            ? "-"
                            : `LY ${Number(
                                customerProgramDataNineMonths[0].TY_VS_LY
                              ).toFixed(2)}%`)}
                      </span>
                    ) : (
                      <span style={{ color: "red", fontSize: "12px" }}>
                        {customerProgramDataNineMonths !== undefined &&
                          customerProgramDataNineMonths.length !== 0 &&
                          (customerProgramDataNineMonths[0].TY_VS_LY ===
                          "-999999"
                            ? "-"
                            : `LY +${Number(
                                customerProgramDataNineMonths[0].TY_VS_LY
                              ).toFixed(2)}%`)}
                      </span>
                    )}
                    <br />
                    {customerProgramDataNineMonths !== undefined &&
                    customerProgramDataNineMonths.length !== 0 &&
                    Number(customerProgramDataNineMonths[0].TY_VS_LLY)
                      .toFixed(2)
                      .includes("-") ? (
                      <span style={{ color: "green", fontSize: "11px" }}>
                        {customerProgramDataNineMonths !== undefined &&
                          customerProgramDataNineMonths.length !== 0 &&
                          (customerProgramDataNineMonths[0].TY_VS_LLY ===
                          "-999999"
                            ? "-"
                            : `LLY ${Number(
                                customerProgramDataNineMonths[0].TY_VS_LLY
                              ).toFixed(2)}%`)}
                      </span>
                    ) : (
                      <span style={{ color: "red", fontSize: "11px" }}>
                        {customerProgramDataNineMonths !== undefined &&
                          customerProgramDataNineMonths.length !== 0 &&
                          (customerProgramDataNineMonths[0].TY_VS_LLY ===
                          "-999999"
                            ? "-"
                            : `LLY +${Number(
                                customerProgramDataNineMonths[0].TY_VS_LLY
                              ).toFixed(2)}%`)}
                      </span>
                    )}
                  </td>
                  <td>
                    {customerProgramDataNineMonths !== undefined &&
                      customerProgramDataNineMonths.length !== 0 &&
                      (customerProgramDataNineMonths[0].NET_SALES_TY ===
                      "-999999"
                        ? "-"
                        : "$" +
                          currencyFormat(
                            Number(
                              customerProgramDataNineMonths[0].NET_SALES_TY
                            )
                          ))}
                    <br />
                    {customerProgramDataNineMonths !== undefined &&
                    customerProgramDataNineMonths.length !== 0 &&
                    Number(customerProgramDataNineMonths[0].NET_SALES_TY_VS_LY)
                      .toFixed(2)
                      .includes("-") ? (
                      <span style={{ color: "green", fontSize: "12px" }}>
                        {customerProgramDataNineMonths !== undefined &&
                          customerProgramDataNineMonths.length !== 0 &&
                          (customerProgramDataNineMonths[0]
                            .NET_SALES_TY_VS_LY === "-999999"
                            ? "-"
                            : `LY ${Number(
                                customerProgramDataNineMonths[0]
                                  .NET_SALES_TY_VS_LY
                              ).toFixed(2)}%`)}
                      </span>
                    ) : (
                      <span style={{ color: "red", fontSize: "12px" }}>
                        {customerProgramDataNineMonths !== undefined &&
                          customerProgramDataNineMonths.length !== 0 &&
                          (customerProgramDataNineMonths[0]
                            .NET_SALES_TY_VS_LY === "-999999"
                            ? "-"
                            : `LY +${Number(
                                customerProgramDataNineMonths[0]
                                  .NET_SALES_TY_VS_LY
                              ).toFixed(2)}%`)}
                      </span>
                    )}
                    <br />
                    {customerProgramDataNineMonths !== undefined &&
                    customerProgramDataNineMonths.length !== 0 &&
                    Number(customerProgramDataNineMonths[0].NET_SALES_TY_VS_LLY)
                      .toFixed(2)
                      .includes("-") ? (
                      <span style={{ color: "green", fontSize: "11px" }}>
                        {customerProgramDataNineMonths !== undefined &&
                          customerProgramDataNineMonths.length !== 0 &&
                          (customerProgramDataNineMonths[0]
                            .NET_SALES_TY_VS_LLY === "-999999"
                            ? "-"
                            : `LLY ${Number(
                                customerProgramDataNineMonths[0]
                                  .NET_SALES_TY_VS_LLY
                              ).toFixed(2)}%`)}
                      </span>
                    ) : (
                      <span style={{ color: "red", fontSize: "11px" }}>
                        {customerProgramDataNineMonths !== undefined &&
                          customerProgramDataNineMonths.length !== 0 &&
                          (customerProgramDataNineMonths[0]
                            .NET_SALES_TY_VS_LLY === "-999999"
                            ? "-"
                            : `LLY +${Number(
                                customerProgramDataNineMonths[0]
                                  .NET_SALES_TY_VS_LLY
                              ).toFixed(2)}%`)}
                      </span>
                    )}
                  </td>
                  <td>
                    {customerProgramDataNineMonths !== undefined &&
                      customerProgramDataNineMonths.length !== 0 &&
                      (customerProgramDataNineMonths[0].TRANS_COUNT_TY ===
                      "-999999"
                        ? "-"
                        : currencyFormat(
                            Number(
                              customerProgramDataNineMonths[0].TRANS_COUNT_TY
                            )
                          ))}
                    <br />
                    {customerProgramDataNineMonths !== undefined &&
                    customerProgramDataNineMonths.length !== 0 &&
                    Number(customerProgramDataNineMonths[0].TRANS_TY_VS_LY)
                      .toFixed(2)
                      .includes("-") ? (
                      <span style={{ color: "green", fontSize: "12px" }}>
                        {customerProgramDataNineMonths !== undefined &&
                          customerProgramDataNineMonths.length !== 0 &&
                          (customerProgramDataNineMonths[0].TRANS_TY_VS_LY ===
                          "-999999"
                            ? "-"
                            : `LY ${Number(
                                customerProgramDataNineMonths[0].TRANS_TY_VS_LY
                              ).toFixed(2)}%`)}
                      </span>
                    ) : (
                      <span style={{ color: "red", fontSize: "12px" }}>
                        {customerProgramDataNineMonths !== undefined &&
                          customerProgramDataNineMonths.length !== 0 &&
                          (customerProgramDataNineMonths[0].TRANS_TY_VS_LY ===
                          "-999999"
                            ? "-"
                            : `LY +${Number(
                                customerProgramDataNineMonths[0].TRANS_TY_VS_LY
                              ).toFixed(2)}%`)}
                      </span>
                    )}
                    <br />
                    {customerProgramDataNineMonths !== undefined &&
                    customerProgramDataNineMonths.length !== 0 &&
                    Number(customerProgramDataNineMonths[0].TRANS_TY_VS_LLY)
                      .toFixed(2)
                      .includes("-") ? (
                      <span style={{ color: "green", fontSize: "11px" }}>
                        {customerProgramDataNineMonths !== undefined &&
                          customerProgramDataNineMonths.length !== 0 &&
                          (customerProgramDataNineMonths[0].TRANS_TY_VS_LLY ===
                          "-999999"
                            ? "-"
                            : `LLY ${Number(
                                customerProgramDataNineMonths[0].TRANS_TY_VS_LLY
                              ).toFixed(2)}%`)}
                      </span>
                    ) : (
                      <span style={{ color: "red", fontSize: "11px" }}>
                        {customerProgramDataNineMonths !== undefined &&
                          customerProgramDataNineMonths.length !== 0 &&
                          (customerProgramDataNineMonths[0].TRANS_TY_VS_LLY ===
                          "-999999"
                            ? "-"
                            : `LLY +${Number(
                                customerProgramDataNineMonths[0].TRANS_TY_VS_LLY
                              ).toFixed(2)}%`)}
                      </span>
                    )}
                  </td>
                  <td>
                    {customerProgramDataNineMonths !== undefined &&
                      customerProgramDataNineMonths.length !== 0 &&
                      (customerProgramDataNineMonths[0].PM_TY === "-999999"
                        ? "-"
                        : "$" +
                          currencyFormat(
                            Number(customerProgramDataNineMonths[0].PM_TY)
                          ))}
                    <br />
                    {customerProgramDataNineMonths !== undefined &&
                    customerProgramDataNineMonths.length !== 0 &&
                    Number(customerProgramDataNineMonths[0].PM_TY_VS_LY)
                      .toFixed(2)
                      .includes("-") ? (
                      <span style={{ color: "green", fontSize: "12px" }}>
                        {customerProgramDataNineMonths !== undefined &&
                          customerProgramDataNineMonths.length !== 0 &&
                          (customerProgramDataNineMonths[0].PM_TY_VS_LY ===
                          "-999999"
                            ? "-"
                            : `LY ${Number(
                                customerProgramDataNineMonths[0].PM_TY_VS_LY
                              ).toFixed(2)}%`)}
                      </span>
                    ) : (
                      <span style={{ color: "red", fontSize: "12px" }}>
                        {customerProgramDataNineMonths !== undefined &&
                          customerProgramDataNineMonths.length !== 0 &&
                          (customerProgramDataNineMonths[0].PM_TY_VS_LY ===
                          "-999999"
                            ? "-"
                            : `LY +${Number(
                                customerProgramDataNineMonths[0].PM_TY_VS_LY
                              ).toFixed(2)}%`)}
                      </span>
                    )}
                    <br />
                    {customerProgramDataNineMonths !== undefined &&
                    customerProgramDataNineMonths.length !== 0 &&
                    Number(customerProgramDataNineMonths[0].PM_TY_VS_LLY)
                      .toFixed(2)
                      .includes("-") ? (
                      <span style={{ color: "green", fontSize: "11px" }}>
                        {customerProgramDataNineMonths !== undefined &&
                          customerProgramDataNineMonths.length !== 0 &&
                          (customerProgramDataNineMonths[0].PM_TY_VS_LLY ===
                          "-999999"
                            ? "-"
                            : `LLY ${Number(
                                customerProgramDataNineMonths[0].PM_TY_VS_LLY
                              ).toFixed(2)}%`)}
                      </span>
                    ) : (
                      <span style={{ color: "red", fontSize: "11px" }}>
                        {customerProgramDataNineMonths !== undefined &&
                          customerProgramDataNineMonths.length !== 0 &&
                          (customerProgramDataNineMonths[0].PM_TY_VS_LLY ===
                          "-999999"
                            ? "-"
                            : `LLY +${Number(
                                customerProgramDataNineMonths[0].PM_TY_VS_LLY
                              ).toFixed(2)}%`)}
                      </span>
                    )}
                  </td>
                  <td>
                    {customerProgramDataNineMonths !== undefined &&
                      customerProgramDataNineMonths.length !== 0 &&
                      (customerProgramDataNineMonths[0].AOV_TY === "-999999"
                        ? "-"
                        : "$" +
                          Number(
                            customerProgramDataNineMonths[0].AOV_TY
                          ).toFixed(2))}
                    <br />
                    {customerProgramDataNineMonths !== undefined &&
                    customerProgramDataNineMonths.length !== 0 &&
                    Number(customerProgramDataNineMonths[0].AOV_TY_VS_LY)
                      .toFixed(2)
                      .includes("-") ? (
                      <span style={{ color: "green", fontSize: "12px" }}>
                        {customerProgramDataNineMonths !== undefined &&
                          customerProgramDataNineMonths.length !== 0 &&
                          (customerProgramDataNineMonths[0].AOV_TY_VS_LY ===
                          "-999999"
                            ? "-"
                            : `LY ${Number(
                                customerProgramDataNineMonths[0].AOV_TY_VS_LY
                              ).toFixed(2)}%`)}
                      </span>
                    ) : (
                      <span style={{ color: "red", fontSize: "12px" }}>
                        {customerProgramDataNineMonths !== undefined &&
                          customerProgramDataNineMonths.length !== 0 &&
                          (customerProgramDataNineMonths[0].AOV_TY_VS_LY ===
                          "-999999"
                            ? "-"
                            : `LY +${Number(
                                customerProgramDataNineMonths[0].AOV_TY_VS_LY
                              ).toFixed(2)}%`)}
                      </span>
                    )}
                    <br />
                    {customerProgramDataNineMonths !== undefined &&
                    customerProgramDataNineMonths.length !== 0 &&
                    Number(customerProgramDataNineMonths[0].AOV_TY_VS_LLY)
                      .toFixed(2)
                      .includes("-") ? (
                      <span style={{ color: "green", fontSize: "11px" }}>
                        {customerProgramDataNineMonths !== undefined &&
                          customerProgramDataNineMonths.length !== 0 &&
                          (customerProgramDataNineMonths[0].AOV_TY_VS_LLY ===
                          "-999999"
                            ? "-"
                            : `LLY ${Number(
                                customerProgramDataNineMonths[0].AOV_TY_VS_LLY
                              ).toFixed(2)}%`)}
                      </span>
                    ) : (
                      <span style={{ color: "red", fontSize: "11px" }}>
                        {customerProgramDataNineMonths !== undefined &&
                          customerProgramDataNineMonths.length !== 0 &&
                          (customerProgramDataNineMonths[0].AOV_TY_VS_LLY ===
                          "-999999"
                            ? "-"
                            : `LLY +${Number(
                                customerProgramDataNineMonths[0].AOV_TY_VS_LLY
                              ).toFixed(2)}%`)}
                      </span>
                    )}
                  </td>
                  <td>
                    {customerProgramDataNineMonths !== undefined &&
                      customerProgramDataNineMonths.length !== 0 &&
                      (customerProgramDataNineMonths[0].UPT_TY === "-999999"
                        ? "-"
                        : Number(
                            customerProgramDataNineMonths[0].UPT_TY
                          ).toFixed(1))}
                    <br />
                    {customerProgramDataNineMonths !== undefined &&
                    customerProgramDataNineMonths.length !== 0 &&
                    Number(customerProgramDataNineMonths[0].UPT_TY_VS_LY)
                      .toFixed(2)
                      .includes("-") ? (
                      <span style={{ color: "green", fontSize: "12px" }}>
                        {customerProgramDataNineMonths !== undefined &&
                          customerProgramDataNineMonths.length !== 0 &&
                          (customerProgramDataNineMonths[0].UPT_TY_VS_LY ===
                          "-999999"
                            ? "-"
                            : `LY ${Number(
                                customerProgramDataNineMonths[0].UPT_TY_VS_LY
                              ).toFixed(2)}%`)}
                      </span>
                    ) : (
                      <span style={{ color: "red", fontSize: "12px" }}>
                        {customerProgramDataNineMonths !== undefined &&
                          customerProgramDataNineMonths.length !== 0 &&
                          (customerProgramDataNineMonths[0].UPT_TY_VS_LY ===
                          "-999999"
                            ? "-"
                            : `LY +${Number(
                                customerProgramDataNineMonths[0].UPT_TY_VS_LY
                              ).toFixed(2)}%`)}
                      </span>
                    )}
                    <br />
                    {customerProgramDataNineMonths !== undefined &&
                    customerProgramDataNineMonths.length !== 0 &&
                    Number(customerProgramDataNineMonths[0].UPT_TY_VS_LLY)
                      .toFixed(2)
                      .includes("-") ? (
                      <span style={{ color: "green", fontSize: "11px" }}>
                        {customerProgramDataNineMonths !== undefined &&
                          customerProgramDataNineMonths.length !== 0 &&
                          (customerProgramDataNineMonths[0].UPT_TY_VS_LLY ===
                          "-999999"
                            ? "-"
                            : `LLY ${Number(
                                customerProgramDataNineMonths[0].UPT_TY_VS_LLY
                              ).toFixed(2)}%`)}
                      </span>
                    ) : (
                      <span style={{ color: "red", fontSize: "11px" }}>
                        {customerProgramDataNineMonths !== undefined &&
                          customerProgramDataNineMonths.length !== 0 &&
                          (customerProgramDataNineMonths[0].UPT_TY_VS_LLY ===
                          "-999999"
                            ? "-"
                            : `LLY +${Number(
                                customerProgramDataNineMonths[0].UPT_TY_VS_LLY
                              ).toFixed(2)}%`)}
                      </span>
                    )}
                  </td>
                  <td>
                    {customerProgramDataNineMonths !== undefined &&
                      customerProgramDataNineMonths.length !== 0 &&
                      (customerProgramDataNineMonths[0].AUR_TY === "-999999"
                        ? "-"
                        : "$" +
                          Number(
                            customerProgramDataNineMonths[0].AUR_TY
                          ).toFixed(2))}
                    <br />
                    {customerProgramDataNineMonths !== undefined &&
                    customerProgramDataNineMonths.length !== 0 &&
                    Number(customerProgramDataNineMonths[0].AUR_TY_VS_LY)
                      .toFixed(2)
                      .includes("-") ? (
                      <span style={{ color: "green", fontSize: "12px" }}>
                        {customerProgramDataNineMonths !== undefined &&
                          customerProgramDataNineMonths.length !== 0 &&
                          (customerProgramDataNineMonths[0].AUR_TY_VS_LY ===
                          "-999999"
                            ? "-"
                            : `LY ${Number(
                                customerProgramDataNineMonths[0].AUR_TY_VS_LY
                              ).toFixed(2)}%`)}
                      </span>
                    ) : (
                      <span style={{ color: "red", fontSize: "12px" }}>
                        {customerProgramDataNineMonths !== undefined &&
                          customerProgramDataNineMonths.length !== 0 &&
                          (customerProgramDataNineMonths[0].AUR_TY_VS_LY ===
                          "-999999"
                            ? "-"
                            : `LY +${Number(
                                customerProgramDataNineMonths[0].AUR_TY_VS_LY
                              ).toFixed(2)}%`)}
                      </span>
                    )}
                    <br />
                    {customerProgramDataNineMonths !== undefined &&
                    customerProgramDataNineMonths.length !== 0 &&
                    Number(customerProgramDataNineMonths[0].AUR_TY_VS_LLY)
                      .toFixed(2)
                      .includes("-") ? (
                      <span style={{ color: "green", fontSize: "11px" }}>
                        {customerProgramDataNineMonths !== undefined &&
                          customerProgramDataNineMonths.length !== 0 &&
                          (customerProgramDataNineMonths[0].AUR_TY_VS_LLY ===
                          "-999999"
                            ? "-"
                            : `LLY ${Number(
                                customerProgramDataNineMonths[0].AUR_TY_VS_LLY
                              ).toFixed(2)}%`)}
                      </span>
                    ) : (
                      <span style={{ color: "red", fontSize: "11px" }}>
                        {customerProgramDataNineMonths !== undefined &&
                          customerProgramDataNineMonths.length !== 0 &&
                          (customerProgramDataNineMonths[0].AUR_TY_VS_LLY ===
                          "-999999"
                            ? "-"
                            : `LLY +${Number(
                                customerProgramDataNineMonths[0].AUR_TY_VS_LLY
                              ).toFixed(2)}%`)}
                      </span>
                    )}
                  </td>
                  <td>
                    {customerProgramDataNineMonths !== undefined &&
                      customerProgramDataNineMonths.length !== 0 &&
                      (customerProgramDataNineMonths[0].MARGIN_RATE_PER_TY ===
                      "-999999"
                        ? "-"
                        : Number(
                            customerProgramDataNineMonths[0].MARGIN_RATE_PER_TY
                          ).toFixed(2))}
                    <br />
                    {customerProgramDataNineMonths !== undefined &&
                    customerProgramDataNineMonths.length !== 0 &&
                    Number(
                      customerProgramDataNineMonths[0].MARGIN_RATE_PER_TY_VS_LY
                    )
                      .toFixed(2)
                      .includes("-") ? (
                      <span style={{ color: "green", fontSize: "12px" }}>
                        {customerProgramDataNineMonths !== undefined &&
                          customerProgramDataNineMonths.length !== 0 &&
                          (customerProgramDataNineMonths[0]
                            .MARGIN_RATE_PER_TY_VS_LY === "-999999"
                            ? "-"
                            : `LY ${Number(
                                customerProgramDataNineMonths[0]
                                  .MARGIN_RATE_PER_TY_VS_LY
                              ).toFixed(2)}%`)}
                      </span>
                    ) : (
                      <span style={{ color: "red", fontSize: "12px" }}>
                        {customerProgramDataNineMonths !== undefined &&
                          customerProgramDataNineMonths.length !== 0 &&
                          (customerProgramDataNineMonths[0]
                            .MARGIN_RATE_PER_TY_VS_LY === "-999999"
                            ? "-"
                            : `LY +${Number(
                                customerProgramDataNineMonths[0]
                                  .MARGIN_RATE_PER_TY_VS_LY
                              ).toFixed(2)}%`)}
                      </span>
                    )}
                    <br />
                    {customerProgramDataNineMonths !== undefined &&
                    customerProgramDataNineMonths.length !== 0 &&
                    Number(
                      customerProgramDataNineMonths[0].MARGIN_RATE_PER_TY_VS_LLY
                    )
                      .toFixed(2)
                      .includes("-") ? (
                      <span style={{ color: "green", fontSize: "11px" }}>
                        {customerProgramDataNineMonths !== undefined &&
                          customerProgramDataNineMonths.length !== 0 &&
                          (customerProgramDataNineMonths[0]
                            .MARGIN_RATE_PER_TY_VS_LLY === "-999999"
                            ? "-"
                            : `LLY ${Number(
                                customerProgramDataNineMonths[0]
                                  .MARGIN_RATE_PER_TY_VS_LLY
                              ).toFixed(2)}%`)}
                      </span>
                    ) : (
                      <span style={{ color: "red", fontSize: "11px" }}>
                        {customerProgramDataNineMonths !== undefined &&
                          customerProgramDataNineMonths.length !== 0 &&
                          (customerProgramDataNineMonths[0]
                            .MARGIN_RATE_PER_TY_VS_LLY === "-999999"
                            ? "-"
                            : `LLY +${Number(
                                customerProgramDataNineMonths[0]
                                  .MARGIN_RATE_PER_TY_VS_LLY
                              ).toFixed(2)}%`)}
                      </span>
                    )}
                  </td>
                  <td>
                    {customerProgramDataNineMonths !== undefined &&
                      customerProgramDataNineMonths.length !== 0 &&
                      (customerProgramDataNineMonths[0]
                        .NET_SALES_PER_CUST_TY === "-999999"
                        ? "-"
                        : "$" +
                          Number(
                            customerProgramDataNineMonths[0]
                              .NET_SALES_PER_CUST_TY
                          ).toFixed(2))}
                    <br />
                    {customerProgramDataNineMonths !== undefined &&
                    customerProgramDataNineMonths.length !== 0 &&
                    Number(
                      customerProgramDataNineMonths[0]
                        .NET_SALES_PER_CUST_TY_VS_LY
                    )
                      .toFixed(2)
                      .includes("-") ? (
                      <span style={{ color: "green", fontSize: "12px" }}>
                        {customerProgramDataNineMonths !== undefined &&
                          customerProgramDataNineMonths.length !== 0 &&
                          (customerProgramDataNineMonths[0]
                            .NET_SALES_PER_CUST_TY_VS_LY === "-999999"
                            ? "-"
                            : `LY ${Number(
                                customerProgramDataNineMonths[0]
                                  .NET_SALES_PER_CUST_TY_VS_LY
                              ).toFixed(2)}%`)}
                      </span>
                    ) : (
                      <span style={{ color: "red", fontSize: "12px" }}>
                        {customerProgramDataNineMonths !== undefined &&
                          customerProgramDataNineMonths.length !== 0 &&
                          (customerProgramDataNineMonths[0]
                            .NET_SALES_PER_CUST_TY_VS_LY === "-999999"
                            ? "-"
                            : `LY +${Number(
                                customerProgramDataNineMonths[0]
                                  .NET_SALES_PER_CUST_TY_VS_LY
                              ).toFixed(2)}%`)}
                      </span>
                    )}
                    <br />
                    {customerProgramDataNineMonths !== undefined &&
                    customerProgramDataNineMonths.length !== 0 &&
                    Number(
                      customerProgramDataNineMonths[0]
                        .NET_SALES_PER_CUST_TY_VS_LLY
                    )
                      .toFixed(2)
                      .includes("-") ? (
                      <span style={{ color: "green", fontSize: "11px" }}>
                        {customerProgramDataNineMonths !== undefined &&
                          customerProgramDataNineMonths.length !== 0 &&
                          (customerProgramDataNineMonths[0]
                            .NET_SALES_PER_CUST_TY_VS_LLY === "-999999"
                            ? "-"
                            : `LLY ${Number(
                                customerProgramDataNineMonths[0]
                                  .NET_SALES_PER_CUST_TY_VS_LLY
                              ).toFixed(2)}%`)}
                      </span>
                    ) : (
                      <span style={{ color: "red", fontSize: "11px" }}>
                        {customerProgramDataNineMonths !== undefined &&
                          customerProgramDataNineMonths.length !== 0 &&
                          (customerProgramDataNineMonths[0]
                            .NET_SALES_PER_CUST_TY_VS_LLY === "-999999"
                            ? "-"
                            : `LLY +${Number(
                                customerProgramDataNineMonths[0]
                                  .NET_SALES_PER_CUST_TY_VS_LLY
                              ).toFixed(2)}%`)}
                      </span>
                    )}
                  </td>
                  <td>
                    {customerProgramDataNineMonths !== undefined &&
                      customerProgramDataNineMonths.length !== 0 &&
                      (customerProgramDataNineMonths[0].AVG_TRAN_TY ===
                      "-999999"
                        ? "-"
                        : Number(
                            customerProgramDataNineMonths[0].AVG_TRAN_TY
                          ).toFixed(2))}
                    <br />
                    {customerProgramDataNineMonths !== undefined &&
                    customerProgramDataNineMonths.length !== 0 &&
                    Number(customerProgramDataNineMonths[0].AVG_TRAN_TY_VS_LY)
                      .toFixed(2)
                      .includes("-") ? (
                      <span style={{ color: "green", fontSize: "12px" }}>
                        {customerProgramDataNineMonths !== undefined &&
                          customerProgramDataNineMonths.length !== 0 &&
                          (customerProgramDataNineMonths[0]
                            .AVG_TRAN_TY_VS_LY === "-999999"
                            ? "-"
                            : `LY ${Number(
                                customerProgramDataNineMonths[0]
                                  .AVG_TRAN_TY_VS_LY
                              ).toFixed(2)}%`)}
                      </span>
                    ) : (
                      <span style={{ color: "red", fontSize: "12px" }}>
                        {customerProgramDataNineMonths !== undefined &&
                          customerProgramDataNineMonths.length !== 0 &&
                          (customerProgramDataNineMonths[0]
                            .AVG_TRAN_TY_VS_LY === "-999999"
                            ? "-"
                            : `LY +${Number(
                                customerProgramDataNineMonths[0]
                                  .AVG_TRAN_TY_VS_LY
                              ).toFixed(2)}%`)}
                      </span>
                    )}
                    <br />
                    {customerProgramDataNineMonths !== undefined &&
                    customerProgramDataNineMonths.length !== 0 &&
                    Number(customerProgramDataNineMonths[0].AVG_TRAN_TY_VS_LLY)
                      .toFixed(2)
                      .includes("-") ? (
                      <span style={{ color: "green", fontSize: "11px" }}>
                        {customerProgramDataNineMonths !== undefined &&
                          customerProgramDataNineMonths.length !== 0 &&
                          (customerProgramDataNineMonths[0]
                            .AVG_TRAN_TY_VS_LLY === "-999999"
                            ? "-"
                            : `LLY ${Number(
                                customerProgramDataNineMonths[0]
                                  .AVG_TRAN_TY_VS_LLY
                              ).toFixed(2)}%`)}
                      </span>
                    ) : (
                      <span style={{ color: "red", fontSize: "11px" }}>
                        {customerProgramDataNineMonths !== undefined &&
                          customerProgramDataNineMonths.length !== 0 &&
                          (customerProgramDataNineMonths[0]
                            .AVG_TRAN_TY_VS_LLY === "-999999"
                            ? "-"
                            : `LLY +${Number(
                                customerProgramDataNineMonths[0]
                                  .AVG_TRAN_TY_VS_LLY
                              ).toFixed(2)}%`)}
                      </span>
                    )}
                  </td>
                </>
              )}
            </tr>
            <tr>
              <td className="tableTotalCol">
                <b>{"Sub Total"}</b>
              </td>
              {loading.first_four_total ? (
                <>
                  <LoaderForRow tdCount={10} />
                </>
              ) : (
                <>
                  <th>
                    {firstCustomerProgramFourTotalData &&
                      firstCustomerProgramFourTotalData !== undefined &&
                      firstCustomerProgramFourTotalData.length !== 0 &&
                      (firstCustomerProgramFourTotalData[0].CUST_COUNT_TY ===
                      "-999999"
                        ? "-"
                        : currencyFormat(
                            Number(
                              firstCustomerProgramFourTotalData[0].CUST_COUNT_TY
                            )
                          ))}
                    <br />
                    {firstCustomerProgramFourTotalData !== undefined &&
                    firstCustomerProgramFourTotalData.length !== 0 &&
                    Number(firstCustomerProgramFourTotalData[0].CUST_TY_VS_LY)
                      .toFixed(2)
                      .includes("-") ? (
                      <span style={{ color: "red", fontSize: "12px" }}>
                        {firstCustomerProgramFourTotalData !== undefined &&
                          firstCustomerProgramFourTotalData.length !== 0 &&
                          (firstCustomerProgramFourTotalData[0]
                            .CUST_TY_VS_LY === "-999999"
                            ? "-"
                            : `LY ${Number(
                                firstCustomerProgramFourTotalData[0]
                                  .CUST_TY_VS_LY
                              ).toFixed(2)}%`)}
                      </span>
                    ) : (
                      <span style={{ color: "green", fontSize: "12px" }}>
                        {firstCustomerProgramFourTotalData !== undefined &&
                          firstCustomerProgramFourTotalData.length !== 0 &&
                          (firstCustomerProgramFourTotalData[0]
                            .CUST_TY_VS_LY === "-999999"
                            ? "-"
                            : `LY +${Number(
                                firstCustomerProgramFourTotalData[0]
                                  .CUST_TY_VS_LY
                              ).toFixed(2)}%`)}
                      </span>
                    )}
                    <br />
                    {firstCustomerProgramFourTotalData !== undefined &&
                    firstCustomerProgramFourTotalData.length !== 0 &&
                    Number(firstCustomerProgramFourTotalData[0].CUST_TY_VS_LLY)
                      .toFixed(2)
                      .includes("-") ? (
                      <span style={{ color: "red", fontSize: "11px" }}>
                        {firstCustomerProgramFourTotalData !== undefined &&
                          firstCustomerProgramFourTotalData.length !== 0 &&
                          (firstCustomerProgramFourTotalData[0]
                            .CUST_TY_VS_LLY === "-999999"
                            ? "-"
                            : `LLY ${Number(
                                firstCustomerProgramFourTotalData[0]
                                  .CUST_TY_VS_LLY
                              ).toFixed(2)}%`)}
                      </span>
                    ) : (
                      <span style={{ color: "green", fontSize: "11px" }}>
                        {firstCustomerProgramFourTotalData !== undefined &&
                          firstCustomerProgramFourTotalData.length !== 0 &&
                          (firstCustomerProgramFourTotalData[0]
                            .CUST_TY_VS_LLY === "-999999"
                            ? "-"
                            : `LLY +${Number(
                                firstCustomerProgramFourTotalData[0]
                                  .CUST_TY_VS_LLY
                              ).toFixed(2)}%`)}
                      </span>
                    )}
                  </th>
                  <th>
                    {firstCustomerProgramFourTotalData &&
                      firstCustomerProgramFourTotalData !== undefined &&
                      firstCustomerProgramFourTotalData.length !== 0 &&
                      (firstCustomerProgramFourTotalData[0].NET_SALES_TY ===
                      "-999999"
                        ? "-"
                        : "$" +
                          currencyFormat(
                            Number(
                              firstCustomerProgramFourTotalData[0].NET_SALES_TY
                            )
                          ))}
                    <br />
                    {firstCustomerProgramFourTotalData !== undefined &&
                    firstCustomerProgramFourTotalData.length !== 0 &&
                    Number(
                      firstCustomerProgramFourTotalData[0].NET_SALES_TY_VS_LY
                    )
                      .toFixed(2)
                      .includes("-") ? (
                      <span style={{ color: "red", fontSize: "12px" }}>
                        {firstCustomerProgramFourTotalData !== undefined &&
                          firstCustomerProgramFourTotalData.length !== 0 &&
                          (firstCustomerProgramFourTotalData[0]
                            .NET_SALES_TY_VS_LY === "-999999"
                            ? "-"
                            : `LY ${Number(
                                firstCustomerProgramFourTotalData[0]
                                  .NET_SALES_TY_VS_LY
                              ).toFixed(2)}%`)}
                      </span>
                    ) : (
                      <span style={{ color: "green", fontSize: "12px" }}>
                        {firstCustomerProgramFourTotalData !== undefined &&
                          firstCustomerProgramFourTotalData.length !== 0 &&
                          (firstCustomerProgramFourTotalData[0]
                            .NET_SALES_TY_VS_LY === "-999999"
                            ? "-"
                            : `LY +${Number(
                                firstCustomerProgramFourTotalData[0]
                                  .NET_SALES_TY_VS_LY
                              ).toFixed(2)}%`)}
                      </span>
                    )}
                    <br />
                    {firstCustomerProgramFourTotalData !== undefined &&
                    firstCustomerProgramFourTotalData.length !== 0 &&
                    Number(
                      firstCustomerProgramFourTotalData[0].NET_SALES_TY_VS_LLY
                    )
                      .toFixed(2)
                      .includes("-") ? (
                      <span style={{ color: "red", fontSize: "11px" }}>
                        {firstCustomerProgramFourTotalData !== undefined &&
                          firstCustomerProgramFourTotalData.length !== 0 &&
                          (firstCustomerProgramFourTotalData[0]
                            .NET_SALES_TY_VS_LLY === "-999999"
                            ? "-"
                            : `LLY ${Number(
                                firstCustomerProgramFourTotalData[0]
                                  .NET_SALES_TY_VS_LLY
                              ).toFixed(2)}%`)}
                      </span>
                    ) : (
                      <span style={{ color: "green", fontSize: "11px" }}>
                        {firstCustomerProgramFourTotalData !== undefined &&
                          firstCustomerProgramFourTotalData.length !== 0 &&
                          (firstCustomerProgramFourTotalData[0]
                            .NET_SALES_TY_VS_LLY === "-999999"
                            ? "-"
                            : `LLY +${Number(
                                firstCustomerProgramFourTotalData[0]
                                  .NET_SALES_TY_VS_LLY
                              ).toFixed(2)}%`)}
                      </span>
                    )}
                  </th>
                  <th>
                    {firstCustomerProgramFourTotalData &&
                      firstCustomerProgramFourTotalData !== undefined &&
                      firstCustomerProgramFourTotalData.length !== 0 &&
                      (firstCustomerProgramFourTotalData[0].TRANS_COUNT_TY ===
                      "-999999"
                        ? "-"
                        : currencyFormat(
                            Number(
                              firstCustomerProgramFourTotalData[0]
                                .TRANS_COUNT_TY
                            )
                          ))}
                    <br />
                    {firstCustomerProgramFourTotalData !== undefined &&
                    firstCustomerProgramFourTotalData.length !== 0 &&
                    Number(firstCustomerProgramFourTotalData[0].TRANS_TY_VS_LY)
                      .toFixed(2)
                      .includes("-") ? (
                      <span style={{ color: "red", fontSize: "12px" }}>
                        {firstCustomerProgramFourTotalData !== undefined &&
                          firstCustomerProgramFourTotalData.length !== 0 &&
                          (firstCustomerProgramFourTotalData[0]
                            .TRANS_TY_VS_LY === "-999999"
                            ? "-"
                            : `LY ${Number(
                                firstCustomerProgramFourTotalData[0]
                                  .TRANS_TY_VS_LY
                              ).toFixed(2)}%`)}
                      </span>
                    ) : (
                      <span style={{ color: "green", fontSize: "12px" }}>
                        {firstCustomerProgramFourTotalData !== undefined &&
                          firstCustomerProgramFourTotalData.length !== 0 &&
                          (firstCustomerProgramFourTotalData[0]
                            .TRANS_TY_VS_LY === "-999999"
                            ? "-"
                            : `LY +${Number(
                                firstCustomerProgramFourTotalData[0]
                                  .TRANS_TY_VS_LY
                              ).toFixed(2)}%`)}
                      </span>
                    )}
                    <br />
                    {firstCustomerProgramFourTotalData !== undefined &&
                    firstCustomerProgramFourTotalData.length !== 0 &&
                    Number(firstCustomerProgramFourTotalData[0].TRANS_TY_VS_LLY)
                      .toFixed(2)
                      .includes("-") ? (
                      <span style={{ color: "red", fontSize: "11px" }}>
                        {firstCustomerProgramFourTotalData !== undefined &&
                          firstCustomerProgramFourTotalData.length !== 0 &&
                          (firstCustomerProgramFourTotalData[0]
                            .TRANS_TY_VS_LLY === "-999999"
                            ? "-"
                            : `LLY ${Number(
                                firstCustomerProgramFourTotalData[0]
                                  .TRANS_TY_VS_LLY
                              ).toFixed(2)}%`)}
                      </span>
                    ) : (
                      <span style={{ color: "green", fontSize: "11px" }}>
                        {firstCustomerProgramFourTotalData !== undefined &&
                          firstCustomerProgramFourTotalData.length !== 0 &&
                          (firstCustomerProgramFourTotalData[0]
                            .TRANS_TY_VS_LLY === "-999999"
                            ? "-"
                            : `LLY +${Number(
                                firstCustomerProgramFourTotalData[0]
                                  .TRANS_TY_VS_LLY
                              ).toFixed(2)}%`)}
                      </span>
                    )}
                  </th>
                  <th>
                    {firstCustomerProgramFourTotalData &&
                      firstCustomerProgramFourTotalData !== undefined &&
                      firstCustomerProgramFourTotalData.length !== 0 &&
                      (firstCustomerProgramFourTotalData[0].PM_TY === "-999999"
                        ? "-"
                        : "$" +
                          currencyFormat(
                            Number(firstCustomerProgramFourTotalData[0].PM_TY)
                          ))}
                    <br />
                    {firstCustomerProgramFourTotalData !== undefined &&
                    firstCustomerProgramFourTotalData.length !== 0 &&
                    Number(firstCustomerProgramFourTotalData[0].PM_TY_VS_LY)
                      .toFixed(2)
                      .includes("-") ? (
                      <span style={{ color: "red", fontSize: "12px" }}>
                        {firstCustomerProgramFourTotalData !== undefined &&
                          firstCustomerProgramFourTotalData.length !== 0 &&
                          (firstCustomerProgramFourTotalData[0].PM_TY_VS_LY ===
                          "-999999"
                            ? "-"
                            : `LY ${Number(
                                firstCustomerProgramFourTotalData[0].PM_TY_VS_LY
                              ).toFixed(2)}%`)}
                      </span>
                    ) : (
                      <span style={{ color: "green", fontSize: "12px" }}>
                        {firstCustomerProgramFourTotalData !== undefined &&
                          firstCustomerProgramFourTotalData.length !== 0 &&
                          (firstCustomerProgramFourTotalData[0].PM_TY_VS_LY ===
                          "-999999"
                            ? "-"
                            : `LY +${Number(
                                firstCustomerProgramFourTotalData[0].PM_TY_VS_LY
                              ).toFixed(2)}%`)}
                      </span>
                    )}
                    <br />
                    {firstCustomerProgramFourTotalData !== undefined &&
                    firstCustomerProgramFourTotalData.length !== 0 &&
                    Number(firstCustomerProgramFourTotalData[0].PM_TY_VS_LLY)
                      .toFixed(2)
                      .includes("-") ? (
                      <span style={{ color: "red", fontSize: "11px" }}>
                        {firstCustomerProgramFourTotalData !== undefined &&
                          firstCustomerProgramFourTotalData.length !== 0 &&
                          (firstCustomerProgramFourTotalData[0].PM_TY_VS_LLY ===
                          "-999999"
                            ? "-"
                            : `LLY ${Number(
                                firstCustomerProgramFourTotalData[0]
                                  .PM_TY_VS_LLY
                              ).toFixed(2)}%`)}
                      </span>
                    ) : (
                      <span style={{ color: "green", fontSize: "11px" }}>
                        {firstCustomerProgramFourTotalData !== undefined &&
                          firstCustomerProgramFourTotalData.length !== 0 &&
                          (firstCustomerProgramFourTotalData[0].PM_TY_VS_LLY ===
                          "-999999"
                            ? "-"
                            : `LLY +${Number(
                                firstCustomerProgramFourTotalData[0]
                                  .PM_TY_VS_LLY
                              ).toFixed(2)}%`)}
                      </span>
                    )}
                  </th>
                  <th>
                    {firstCustomerProgramFourTotalData &&
                      firstCustomerProgramFourTotalData !== undefined &&
                      firstCustomerProgramFourTotalData.length !== 0 &&
                      (firstCustomerProgramFourTotalData[0].AOV_TY === "-999999"
                        ? "-"
                        : "$" +
                          Number(
                            firstCustomerProgramFourTotalData[0].AOV_TY
                          ).toFixed(2))}
                    <br />
                    {firstCustomerProgramFourTotalData !== undefined &&
                    firstCustomerProgramFourTotalData.length !== 0 &&
                    Number(firstCustomerProgramFourTotalData[0].AOV_TY_VS_LY)
                      .toFixed(2)
                      .includes("-") ? (
                      <span style={{ color: "red", fontSize: "12px" }}>
                        {firstCustomerProgramFourTotalData !== undefined &&
                          firstCustomerProgramFourTotalData.length !== 0 &&
                          (firstCustomerProgramFourTotalData[0].AOV_TY_VS_LY ===
                          "-999999"
                            ? "-"
                            : `LY ${Number(
                                firstCustomerProgramFourTotalData[0]
                                  .AOV_TY_VS_LY
                              ).toFixed(2)}%`)}
                      </span>
                    ) : (
                      <span style={{ color: "green", fontSize: "12px" }}>
                        {firstCustomerProgramFourTotalData !== undefined &&
                          firstCustomerProgramFourTotalData.length !== 0 &&
                          (firstCustomerProgramFourTotalData[0].AOV_TY_VS_LY ===
                          "-999999"
                            ? "-"
                            : `LY +${Number(
                                firstCustomerProgramFourTotalData[0]
                                  .AOV_TY_VS_LY
                              ).toFixed(2)}%`)}
                      </span>
                    )}
                    <br />
                    {firstCustomerProgramFourTotalData !== undefined &&
                    firstCustomerProgramFourTotalData.length !== 0 &&
                    Number(firstCustomerProgramFourTotalData[0].AOV_TY_VS_LLY)
                      .toFixed(2)
                      .includes("-") ? (
                      <span style={{ color: "red", fontSize: "11px" }}>
                        {firstCustomerProgramFourTotalData !== undefined &&
                          firstCustomerProgramFourTotalData.length !== 0 &&
                          (firstCustomerProgramFourTotalData[0]
                            .AOV_TY_VS_LLY === "-999999"
                            ? "-"
                            : `LLY ${Number(
                                firstCustomerProgramFourTotalData[0]
                                  .AOV_TY_VS_LLY
                              ).toFixed(2)}%`)}
                      </span>
                    ) : (
                      <span style={{ color: "green", fontSize: "11px" }}>
                        {firstCustomerProgramFourTotalData !== undefined &&
                          firstCustomerProgramFourTotalData.length !== 0 &&
                          (firstCustomerProgramFourTotalData[0]
                            .AOV_TY_VS_LLY === "-999999"
                            ? "-"
                            : `LLY +${Number(
                                firstCustomerProgramFourTotalData[0]
                                  .AOV_TY_VS_LLY
                              ).toFixed(2)}%`)}
                      </span>
                    )}
                  </th>
                  <th>
                    {firstCustomerProgramFourTotalData &&
                      firstCustomerProgramFourTotalData !== undefined &&
                      firstCustomerProgramFourTotalData.length !== 0 &&
                      (firstCustomerProgramFourTotalData[0].UPT_TY === "-999999"
                        ? "-"
                        : Number(
                            firstCustomerProgramFourTotalData[0].UPT_TY
                          ).toFixed(1))}
                    <br />
                    {firstCustomerProgramFourTotalData !== undefined &&
                    firstCustomerProgramFourTotalData.length !== 0 &&
                    Number(firstCustomerProgramFourTotalData[0].UPT_TY_VS_LY)
                      .toFixed(2)
                      .includes("-") ? (
                      <span style={{ color: "red", fontSize: "12px" }}>
                        {firstCustomerProgramFourTotalData !== undefined &&
                          firstCustomerProgramFourTotalData.length !== 0 &&
                          (firstCustomerProgramFourTotalData[0].UPT_TY_VS_LY ===
                          "-999999"
                            ? "-"
                            : `LY ${Number(
                                firstCustomerProgramFourTotalData[0]
                                  .UPT_TY_VS_LY
                              ).toFixed(2)}%`)}
                      </span>
                    ) : (
                      <span style={{ color: "green", fontSize: "12px" }}>
                        {firstCustomerProgramFourTotalData !== undefined &&
                          firstCustomerProgramFourTotalData.length !== 0 &&
                          (firstCustomerProgramFourTotalData[0].UPT_TY_VS_LY ===
                          "-999999"
                            ? "-"
                            : `LY +${Number(
                                firstCustomerProgramFourTotalData[0]
                                  .UPT_TY_VS_LY
                              ).toFixed(2)}%`)}
                      </span>
                    )}
                    <br />
                    {firstCustomerProgramFourTotalData !== undefined &&
                    firstCustomerProgramFourTotalData.length !== 0 &&
                    Number(firstCustomerProgramFourTotalData[0].UPT_TY_VS_LLY)
                      .toFixed(2)
                      .includes("-") ? (
                      <span style={{ color: "red", fontSize: "11px" }}>
                        {firstCustomerProgramFourTotalData !== undefined &&
                          firstCustomerProgramFourTotalData.length !== 0 &&
                          (firstCustomerProgramFourTotalData[0]
                            .UPT_TY_VS_LLY === "-999999"
                            ? "-"
                            : `LLY ${Number(
                                firstCustomerProgramFourTotalData[0]
                                  .UPT_TY_VS_LLY
                              ).toFixed(2)}%`)}
                      </span>
                    ) : (
                      <span style={{ color: "green", fontSize: "11px" }}>
                        {firstCustomerProgramFourTotalData !== undefined &&
                          firstCustomerProgramFourTotalData.length !== 0 &&
                          (firstCustomerProgramFourTotalData[0]
                            .UPT_TY_VS_LLY === "-999999"
                            ? "-"
                            : `LLY +${Number(
                                firstCustomerProgramFourTotalData[0]
                                  .UPT_TY_VS_LLY
                              ).toFixed(2)}%`)}
                      </span>
                    )}
                  </th>
                  <th>
                    {firstCustomerProgramFourTotalData &&
                      firstCustomerProgramFourTotalData !== undefined &&
                      firstCustomerProgramFourTotalData.length !== 0 &&
                      (firstCustomerProgramFourTotalData[0].AUR_TY === "-999999"
                        ? "-"
                        : "$" +
                          Number(
                            firstCustomerProgramFourTotalData[0].AUR_TY
                          ).toFixed(2))}
                    <br />
                    {firstCustomerProgramFourTotalData !== undefined &&
                    firstCustomerProgramFourTotalData.length !== 0 &&
                    Number(firstCustomerProgramFourTotalData[0].AUR_TY_VS_LY)
                      .toFixed(2)
                      .includes("-") ? (
                      <span style={{ color: "red", fontSize: "12px" }}>
                        {firstCustomerProgramFourTotalData !== undefined &&
                          firstCustomerProgramFourTotalData.length !== 0 &&
                          (firstCustomerProgramFourTotalData[0].AUR_TY_VS_LY ===
                          "-999999"
                            ? "-"
                            : `LY ${Number(
                                firstCustomerProgramFourTotalData[0]
                                  .AUR_TY_VS_LY
                              ).toFixed(2)}%`)}
                      </span>
                    ) : (
                      <span style={{ color: "green", fontSize: "12px" }}>
                        {firstCustomerProgramFourTotalData !== undefined &&
                          firstCustomerProgramFourTotalData.length !== 0 &&
                          (firstCustomerProgramFourTotalData[0].AUR_TY_VS_LY ===
                          "-999999"
                            ? "-"
                            : `LY +${Number(
                                firstCustomerProgramFourTotalData[0]
                                  .AUR_TY_VS_LY
                              ).toFixed(2)}%`)}
                      </span>
                    )}
                    <br />
                    {firstCustomerProgramFourTotalData !== undefined &&
                    firstCustomerProgramFourTotalData.length !== 0 &&
                    Number(firstCustomerProgramFourTotalData[0].AUR_TY_VS_LLY)
                      .toFixed(2)
                      .includes("-") ? (
                      <span style={{ color: "red", fontSize: "11px" }}>
                        {firstCustomerProgramFourTotalData !== undefined &&
                          firstCustomerProgramFourTotalData.length !== 0 &&
                          (firstCustomerProgramFourTotalData[0]
                            .AUR_TY_VS_LLY === "-999999"
                            ? "-"
                            : `LLY ${Number(
                                firstCustomerProgramFourTotalData[0]
                                  .AUR_TY_VS_LLY
                              ).toFixed(2)}%`)}
                      </span>
                    ) : (
                      <span style={{ color: "green", fontSize: "11px" }}>
                        {firstCustomerProgramFourTotalData !== undefined &&
                          firstCustomerProgramFourTotalData.length !== 0 &&
                          (firstCustomerProgramFourTotalData[0]
                            .AUR_TY_VS_LLY === "-999999"
                            ? "-"
                            : `LLY +${Number(
                                firstCustomerProgramFourTotalData[0]
                                  .AUR_TY_VS_LLY
                              ).toFixed(2)}%`)}
                      </span>
                    )}
                  </th>
                  <th>
                    {firstCustomerProgramFourTotalData &&
                      firstCustomerProgramFourTotalData !== undefined &&
                      firstCustomerProgramFourTotalData.length !== 0 &&
                      (firstCustomerProgramFourTotalData[0]
                        .MARGIN_RATE_PER_TY === "-999999"
                        ? "-"
                        : Number(
                            firstCustomerProgramFourTotalData[0]
                              .MARGIN_RATE_PER_TY
                          ).toFixed(2))}
                    <br />
                    {firstCustomerProgramFourTotalData !== undefined &&
                    firstCustomerProgramFourTotalData.length !== 0 &&
                    Number(
                      firstCustomerProgramFourTotalData[0]
                        .MARGIN_RATE_PER_TY_VS_LY
                    )
                      .toFixed(2)
                      .includes("-") ? (
                      <span style={{ color: "red", fontSize: "12px" }}>
                        {firstCustomerProgramFourTotalData !== undefined &&
                          firstCustomerProgramFourTotalData.length !== 0 &&
                          (firstCustomerProgramFourTotalData[0]
                            .MARGIN_RATE_PER_TY_VS_LY === "-999999"
                            ? "-"
                            : `LY ${Number(
                                firstCustomerProgramFourTotalData[0]
                                  .MARGIN_RATE_PER_TY_VS_LY
                              ).toFixed(2)}%`)}
                      </span>
                    ) : (
                      <span style={{ color: "green", fontSize: "12px" }}>
                        {firstCustomerProgramFourTotalData !== undefined &&
                          firstCustomerProgramFourTotalData.length !== 0 &&
                          (firstCustomerProgramFourTotalData[0]
                            .MARGIN_RATE_PER_TY_VS_LY === "-999999"
                            ? "-"
                            : `LY +${Number(
                                firstCustomerProgramFourTotalData[0]
                                  .MARGIN_RATE_PER_TY_VS_LY
                              ).toFixed(2)}%`)}
                      </span>
                    )}
                    <br />
                    {firstCustomerProgramFourTotalData !== undefined &&
                    firstCustomerProgramFourTotalData.length !== 0 &&
                    Number(
                      firstCustomerProgramFourTotalData[0]
                        .MARGIN_RATE_PER_TY_VS_LLY
                    )
                      .toFixed(2)
                      .includes("-") ? (
                      <span style={{ color: "red", fontSize: "11px" }}>
                        {firstCustomerProgramFourTotalData !== undefined &&
                          firstCustomerProgramFourTotalData.length !== 0 &&
                          (firstCustomerProgramFourTotalData[0]
                            .MARGIN_RATE_PER_TY_VS_LLY === "-999999"
                            ? "-"
                            : `LLY ${Number(
                                firstCustomerProgramFourTotalData[0]
                                  .MARGIN_RATE_PER_TY_VS_LLY
                              ).toFixed(2)}%`)}
                      </span>
                    ) : (
                      <span style={{ color: "green", fontSize: "11px" }}>
                        {firstCustomerProgramFourTotalData !== undefined &&
                          firstCustomerProgramFourTotalData.length !== 0 &&
                          (firstCustomerProgramFourTotalData[0]
                            .MARGIN_RATE_PER_TY_VS_LLY === "-999999"
                            ? "-"
                            : `LLY +${Number(
                                firstCustomerProgramFourTotalData[0]
                                  .MARGIN_RATE_PER_TY_VS_LLY
                              ).toFixed(2)}%`)}
                      </span>
                    )}
                  </th>
                  <th>
                    {firstCustomerProgramFourTotalData &&
                      firstCustomerProgramFourTotalData !== undefined &&
                      firstCustomerProgramFourTotalData.length !== 0 &&
                      (firstCustomerProgramFourTotalData[0]
                        .NET_SALES_PER_CUST_TY === "-999999"
                        ? "-"
                        : "$" +
                          Number(
                            firstCustomerProgramFourTotalData[0]
                              .NET_SALES_PER_CUST_TY
                          ).toFixed(2))}
                    <br />
                    {firstCustomerProgramFourTotalData !== undefined &&
                    firstCustomerProgramFourTotalData.length !== 0 &&
                    Number(
                      firstCustomerProgramFourTotalData[0]
                        .NET_SALES_PER_CUST_TY_VS_LY
                    )
                      .toFixed(2)
                      .includes("-") ? (
                      <span style={{ color: "red", fontSize: "12px" }}>
                        {firstCustomerProgramFourTotalData !== undefined &&
                          firstCustomerProgramFourTotalData.length !== 0 &&
                          (firstCustomerProgramFourTotalData[0]
                            .NET_SALES_PER_CUST_TY_VS_LY === "-999999"
                            ? "-"
                            : `LY ${Number(
                                firstCustomerProgramFourTotalData[0]
                                  .NET_SALES_PER_CUST_TY_VS_LY
                              ).toFixed(2)}%`)}
                      </span>
                    ) : (
                      <span style={{ color: "green", fontSize: "12px" }}>
                        {firstCustomerProgramFourTotalData !== undefined &&
                          firstCustomerProgramFourTotalData.length !== 0 &&
                          (firstCustomerProgramFourTotalData[0]
                            .NET_SALES_PER_CUST_TY_VS_LY === "-999999"
                            ? "-"
                            : `LY +${Number(
                                firstCustomerProgramFourTotalData[0]
                                  .NET_SALES_PER_CUST_TY_VS_LY
                              ).toFixed(2)}%`)}
                      </span>
                    )}
                    <br />
                    {firstCustomerProgramFourTotalData !== undefined &&
                    firstCustomerProgramFourTotalData.length !== 0 &&
                    Number(
                      firstCustomerProgramFourTotalData[0]
                        .NET_SALES_PER_CUST_TY_VS_LLY
                    )
                      .toFixed(2)
                      .includes("-") ? (
                      <span style={{ color: "red", fontSize: "11px" }}>
                        {firstCustomerProgramFourTotalData !== undefined &&
                          firstCustomerProgramFourTotalData.length !== 0 &&
                          (firstCustomerProgramFourTotalData[0]
                            .NET_SALES_PER_CUST_TY_VS_LLY === "-999999"
                            ? "-"
                            : `LLY ${Number(
                                firstCustomerProgramFourTotalData[0]
                                  .NET_SALES_PER_CUST_TY_VS_LLY
                              ).toFixed(2)}%`)}
                      </span>
                    ) : (
                      <span style={{ color: "green", fontSize: "11px" }}>
                        {firstCustomerProgramFourTotalData !== undefined &&
                          firstCustomerProgramFourTotalData.length !== 0 &&
                          (firstCustomerProgramFourTotalData[0]
                            .NET_SALES_PER_CUST_TY_VS_LLY === "-999999"
                            ? "-"
                            : `LLY +${Number(
                                firstCustomerProgramFourTotalData[0]
                                  .NET_SALES_PER_CUST_TY_VS_LLY
                              ).toFixed(2)}%`)}
                      </span>
                    )}
                  </th>
                  <th>
                    {firstCustomerProgramFourTotalData &&
                      firstCustomerProgramFourTotalData !== undefined &&
                      firstCustomerProgramFourTotalData.length !== 0 &&
                      (firstCustomerProgramFourTotalData[0].AVG_TRAN_TY ===
                      "-999999"
                        ? "-"
                        : Number(
                            firstCustomerProgramFourTotalData[0].AVG_TRAN_TY
                          ).toFixed(2))}
                    <br />
                    {firstCustomerProgramFourTotalData !== undefined &&
                    firstCustomerProgramFourTotalData.length !== 0 &&
                    Number(
                      firstCustomerProgramFourTotalData[0].AVG_TRAN_TY_VS_LY
                    )
                      .toFixed(2)
                      .includes("-") ? (
                      <span style={{ color: "red", fontSize: "12px" }}>
                        {firstCustomerProgramFourTotalData !== undefined &&
                          firstCustomerProgramFourTotalData.length !== 0 &&
                          (firstCustomerProgramFourTotalData[0]
                            .AVG_TRAN_TY_VS_LY === "-999999"
                            ? "-"
                            : `LY ${Number(
                                firstCustomerProgramFourTotalData[0]
                                  .AVG_TRAN_TY_VS_LY
                              ).toFixed(2)}%`)}
                      </span>
                    ) : (
                      <span style={{ color: "green", fontSize: "12px" }}>
                        {firstCustomerProgramFourTotalData !== undefined &&
                          firstCustomerProgramFourTotalData.length !== 0 &&
                          (firstCustomerProgramFourTotalData[0]
                            .AVG_TRAN_TY_VS_LY === "-999999"
                            ? "-"
                            : `LY +${Number(
                                firstCustomerProgramFourTotalData[0]
                                  .AVG_TRAN_TY_VS_LY
                              ).toFixed(2)}%`)}
                      </span>
                    )}
                    <br />
                    {firstCustomerProgramFourTotalData !== undefined &&
                    firstCustomerProgramFourTotalData.length !== 0 &&
                    Number(
                      firstCustomerProgramFourTotalData[0].AVG_TRAN_TY_VS_LLY
                    )
                      .toFixed(2)
                      .includes("-") ? (
                      <span style={{ color: "red", fontSize: "11px" }}>
                        {firstCustomerProgramFourTotalData !== undefined &&
                          firstCustomerProgramFourTotalData.length !== 0 &&
                          (firstCustomerProgramFourTotalData[0]
                            .AVG_TRAN_TY_VS_LLY === "-999999"
                            ? "-"
                            : `LLY ${Number(
                                firstCustomerProgramFourTotalData[0]
                                  .AVG_TRAN_TY_VS_LLY
                              ).toFixed(2)}%`)}
                      </span>
                    ) : (
                      <span style={{ color: "green", fontSize: "11px" }}>
                        {firstCustomerProgramFourTotalData !== undefined &&
                          firstCustomerProgramFourTotalData.length !== 0 &&
                          (firstCustomerProgramFourTotalData[0]
                            .AVG_TRAN_TY_VS_LLY === "-999999"
                            ? "-"
                            : `LLY +${Number(
                                firstCustomerProgramFourTotalData[0]
                                  .AVG_TRAN_TY_VS_LLY
                              ).toFixed(2)}%`)}
                      </span>
                    )}
                  </th>
                </>
              )}
            </tr>
            <tr>
              <td className="tableCol">
                {"Inactive (12m-18m)"}{" "}
                {gettooltip(
                  "InActive_12_18InfoIcon",
                  "InActive_12_18",
                  "InActive_12_18",
                  "Active in L12M-L18M but not active in L12M"
                )}
              </td>
              {loading.Inactive_12m_18m ? (
                <>
                  <LoaderForRow tdCount={10} />
                </>
              ) : (
                <>
                  <td>
                    {customerProgramInActive_12_18_Data !== undefined &&
                      customerProgramInActive_12_18_Data.length !== 0 &&
                      (customerProgramInActive_12_18_Data[0].CUST_COUNT_TY ===
                      "-999999"
                        ? "-"
                        : currencyFormat(
                            Number(
                              customerProgramInActive_12_18_Data[0]
                                .CUST_COUNT_TY
                            )
                          ))}
                    <br />
                    {customerProgramInActive_12_18_Data !== undefined &&
                    customerProgramInActive_12_18_Data.length !== 0 &&
                    Number(customerProgramInActive_12_18_Data[0].TY_VS_LY)
                      .toFixed(2)
                      .includes("-") ? (
                      <span style={{ color: "green", fontSize: "12px" }}>
                        {customerProgramInActive_12_18_Data !== undefined &&
                          customerProgramInActive_12_18_Data.length !== 0 &&
                          (customerProgramInActive_12_18_Data[0].TY_VS_LY ===
                          "-999999"
                            ? "-"
                            : `LY ${Number(
                                customerProgramInActive_12_18_Data[0].TY_VS_LY
                              ).toFixed(2)}%`)}
                      </span>
                    ) : (
                      <span style={{ color: "red", fontSize: "12px" }}>
                        {customerProgramInActive_12_18_Data !== undefined &&
                          customerProgramInActive_12_18_Data.length !== 0 &&
                          (customerProgramInActive_12_18_Data[0].TY_VS_LY ===
                          "-999999"
                            ? "-"
                            : `LY +${Number(
                                customerProgramInActive_12_18_Data[0].TY_VS_LY
                              ).toFixed(2)}%`)}
                      </span>
                    )}
                    <br />
                    {customerProgramInActive_12_18_Data !== undefined &&
                    customerProgramInActive_12_18_Data.length !== 0 &&
                    Number(customerProgramInActive_12_18_Data[0].TY_VS_LLY)
                      .toFixed(2)
                      .includes("-") ? (
                      <span style={{ color: "green", fontSize: "11px" }}>
                        {customerProgramInActive_12_18_Data !== undefined &&
                          customerProgramInActive_12_18_Data.length !== 0 &&
                          (customerProgramInActive_12_18_Data[0].TY_VS_LLY ===
                          "-999999"
                            ? "-"
                            : `LLY ${Number(
                                customerProgramInActive_12_18_Data[0].TY_VS_LLY
                              ).toFixed(2)}%`)}
                      </span>
                    ) : (
                      <span style={{ color: "red", fontSize: "11px" }}>
                        {customerProgramInActive_12_18_Data !== undefined &&
                          customerProgramInActive_12_18_Data.length !== 0 &&
                          (customerProgramInActive_12_18_Data[0].TY_VS_LLY ===
                          "-999999"
                            ? "-"
                            : `LLY +${Number(
                                customerProgramInActive_12_18_Data[0].TY_VS_LLY
                              ).toFixed(2)}%`)}
                      </span>
                    )}
                  </td>
                  <td>
                    <br />
                    {customerProgramInActive_12_18_Data !== undefined &&
                      customerProgramInActive_12_18_Data.length !== 0 &&
                      "NA"}
                  </td>
                  <td>
                    <br />
                    {customerProgramInActive_12_18_Data !== undefined &&
                      customerProgramInActive_12_18_Data.length !== 0 &&
                      "NA"}
                  </td>
                  <td>
                    <br />
                    {customerProgramInActive_12_18_Data !== undefined &&
                      customerProgramInActive_12_18_Data.length !== 0 &&
                      "NA"}
                  </td>
                  <td>
                    <br />
                    {customerProgramInActive_12_18_Data !== undefined &&
                      customerProgramInActive_12_18_Data.length !== 0 &&
                      "NA"}
                  </td>
                  <td>
                    <br />
                    {customerProgramInActive_12_18_Data !== undefined &&
                      customerProgramInActive_12_18_Data.length !== 0 &&
                      "NA"}
                  </td>
                  <td>
                    <br />
                    {customerProgramInActive_12_18_Data !== undefined &&
                      customerProgramInActive_12_18_Data.length !== 0 &&
                      "NA"}
                  </td>
                  <td>
                    <br />
                    {customerProgramInActive_12_18_Data !== undefined &&
                      customerProgramInActive_12_18_Data.length !== 0 &&
                      "NA"}
                  </td>
                  <td>
                    <br />
                    {customerProgramInActive_12_18_Data !== undefined &&
                      customerProgramInActive_12_18_Data.length !== 0 &&
                      "NA"}
                  </td>
                  <td>
                    <br />
                    {customerProgramInActive_12_18_Data !== undefined &&
                      customerProgramInActive_12_18_Data.length !== 0 &&
                      "NA"}
                  </td>
                </>
              )}
            </tr>
            <tr>
              <td className="tableCol">
                {"Inactive (18m-24m)"}{" "}
                {gettooltip(
                  "InActive_18_24InfoIcon",
                  "InActive_18_24",
                  "InActive_18_24",
                  "Active in L18M-L24M but not active in L18M"
                )}
              </td>
              {loading.Inactive_18m_24m ? (
                <>
                  <LoaderForRow tdCount={10} />
                </>
              ) : (
                <>
                  <td>
                    {customerProgramInActive_18_24_Data !== undefined &&
                      customerProgramInActive_18_24_Data.length !== 0 &&
                      (customerProgramInActive_18_24_Data[0].CUST_COUNT_TY ===
                      "-999999"
                        ? "-"
                        : currencyFormat(
                            Number(
                              customerProgramInActive_18_24_Data[0]
                                .CUST_COUNT_TY
                            )
                          ))}
                    <br />
                    {customerProgramInActive_18_24_Data !== undefined &&
                    customerProgramInActive_18_24_Data.length !== 0 &&
                    Number(customerProgramInActive_18_24_Data[0].TY_VS_LY)
                      .toFixed(2)
                      .includes("-") ? (
                      <span style={{ color: "green", fontSize: "12px" }}>
                        {customerProgramInActive_18_24_Data !== undefined &&
                          customerProgramInActive_18_24_Data.length !== 0 &&
                          (customerProgramInActive_18_24_Data[0].TY_VS_LY ===
                          "-999999"
                            ? "-"
                            : `LY ${Number(
                                customerProgramInActive_18_24_Data[0].TY_VS_LY
                              ).toFixed(2)}%`)}
                      </span>
                    ) : (
                      <span style={{ color: "red", fontSize: "12px" }}>
                        {customerProgramInActive_18_24_Data !== undefined &&
                          customerProgramInActive_18_24_Data.length !== 0 &&
                          (customerProgramInActive_18_24_Data[0].TY_VS_LY ===
                          "-999999"
                            ? "-"
                            : `LY +${Number(
                                customerProgramInActive_18_24_Data[0].TY_VS_LY
                              ).toFixed(2)}%`)}
                      </span>
                    )}
                    <br />
                    {customerProgramInActive_18_24_Data !== undefined &&
                    customerProgramInActive_18_24_Data.length !== 0 &&
                    Number(customerProgramInActive_18_24_Data[0].TY_VS_LLY)
                      .toFixed(2)
                      .includes("-") ? (
                      <span style={{ color: "green", fontSize: "11px" }}>
                        {customerProgramInActive_18_24_Data !== undefined &&
                          customerProgramInActive_18_24_Data.length !== 0 &&
                          (customerProgramInActive_18_24_Data[0].TY_VS_LLY ===
                          "-999999"
                            ? "-"
                            : `LLY ${Number(
                                customerProgramInActive_18_24_Data[0].TY_VS_LLY
                              ).toFixed(2)}%`)}
                      </span>
                    ) : (
                      <span style={{ color: "red", fontSize: "11px" }}>
                        {customerProgramInActive_18_24_Data !== undefined &&
                          customerProgramInActive_18_24_Data.length !== 0 &&
                          (customerProgramInActive_18_24_Data[0].TY_VS_LLY ===
                          "-999999"
                            ? "-"
                            : `LLY +${Number(
                                customerProgramInActive_18_24_Data[0].TY_VS_LLY
                              ).toFixed(2)}%`)}
                      </span>
                    )}
                  </td>
                  <td>
                    <br />
                    {customerProgramInActive_18_24_Data !== undefined &&
                      customerProgramInActive_18_24_Data.length !== 0 &&
                      "NA"}
                  </td>
                  <td>
                    <br />
                    {customerProgramInActive_18_24_Data !== undefined &&
                      customerProgramInActive_18_24_Data.length !== 0 &&
                      "NA"}
                  </td>
                  <td>
                    <br />
                    {customerProgramInActive_18_24_Data !== undefined &&
                      customerProgramInActive_18_24_Data.length !== 0 &&
                      "NA"}
                  </td>
                  <td>
                    <br />
                    {customerProgramInActive_18_24_Data !== undefined &&
                      customerProgramInActive_18_24_Data.length !== 0 &&
                      "NA"}
                  </td>
                  <td>
                    <br />
                    {customerProgramInActive_18_24_Data !== undefined &&
                      customerProgramInActive_18_24_Data.length !== 0 &&
                      "NA"}
                  </td>
                  <td>
                    <br />
                    {customerProgramInActive_18_24_Data !== undefined &&
                      customerProgramInActive_18_24_Data.length !== 0 &&
                      "NA"}
                  </td>
                  <td>
                    <br />{" "}
                    {customerProgramInActive_18_24_Data !== undefined &&
                      customerProgramInActive_18_24_Data.length !== 0 &&
                      "NA"}
                  </td>
                  <td>
                    <br />{" "}
                    {customerProgramInActive_18_24_Data !== undefined &&
                      customerProgramInActive_18_24_Data.length !== 0 &&
                      "NA"}
                  </td>
                  <td>
                    <br />
                    {customerProgramInActive_18_24_Data !== undefined &&
                      customerProgramInActive_18_24_Data.length !== 0 &&
                      "NA"}
                  </td>
                </>
              )}
            </tr>
            <tr>
              <td className="tableTotalCol">
                <b>{"Sub Total"}</b>
              </td>
              {loading.second_half_total ? (
                <>
                  <LoaderForRow tdCount={10} />
                </>
              ) : (
                <>
                  <th>
                    {secondCustomerProgramhalftotalData !== undefined &&
                      secondCustomerProgramhalftotalData.length !== 0 &&
                      (secondCustomerProgramhalftotalData[0].CUST_COUNT_TY ===
                      "-999999"
                        ? "-"
                        : currencyFormat(
                            Number(
                              secondCustomerProgramhalftotalData[0]
                                .CUST_COUNT_TY
                            )
                          ))}
                    <br />
                    {secondCustomerProgramhalftotalData !== undefined &&
                    secondCustomerProgramhalftotalData.length !== 0 &&
                    Number(secondCustomerProgramhalftotalData[0].CUST_TY_VS_LY)
                      .toFixed(2)
                      .includes("-") ? (
                      <span style={{ color: "green", fontSize: "12px" }}>
                        {secondCustomerProgramhalftotalData !== undefined &&
                          secondCustomerProgramhalftotalData.length !== 0 &&
                          (secondCustomerProgramhalftotalData[0]
                            .CUST_TY_VS_LY === "-999999"
                            ? "-"
                            : `LY ${Number(
                                secondCustomerProgramhalftotalData[0]
                                  .CUST_TY_VS_LY
                              ).toFixed(2)}%`)}
                      </span>
                    ) : (
                      <span style={{ color: "red", fontSize: "12px" }}>
                        {secondCustomerProgramhalftotalData !== undefined &&
                          secondCustomerProgramhalftotalData.length !== 0 &&
                          (secondCustomerProgramhalftotalData[0]
                            .CUST_TY_VS_LY === "-999999"
                            ? "-"
                            : `LY +${Number(
                                secondCustomerProgramhalftotalData[0]
                                  .CUST_TY_VS_LY
                              ).toFixed(2)}%`)}
                      </span>
                    )}
                    <br />
                    {secondCustomerProgramhalftotalData !== undefined &&
                    secondCustomerProgramhalftotalData.length !== 0 &&
                    Number(secondCustomerProgramhalftotalData[0].CUST_TY_VS_LLY)
                      .toFixed(2)
                      .includes("-") ? (
                      <span style={{ color: "green", fontSize: "11px" }}>
                        {secondCustomerProgramhalftotalData !== undefined &&
                          secondCustomerProgramhalftotalData.length !== 0 &&
                          (secondCustomerProgramhalftotalData[0]
                            .CUST_TY_VS_LLY === "-999999"
                            ? "-"
                            : `LLY ${Number(
                                secondCustomerProgramhalftotalData[0]
                                  .CUST_TY_VS_LLY
                              ).toFixed(2)}%`)}
                      </span>
                    ) : (
                      <span style={{ color: "red", fontSize: "11px" }}>
                        {secondCustomerProgramhalftotalData !== undefined &&
                          secondCustomerProgramhalftotalData.length !== 0 &&
                          (secondCustomerProgramhalftotalData[0]
                            .CUST_TY_VS_LLY === "-999999"
                            ? "-"
                            : `LLY +${Number(
                                secondCustomerProgramhalftotalData[0]
                                  .CUST_TY_VS_LLY
                              ).toFixed(2)}%`)}
                      </span>
                    )}
                  </th>
                  <th></th>
                  <th></th>
                  <th></th>
                  <th></th>
                  <th></th>
                  <th></th>
                  <th></th>
                  <th></th>
                  <th></th>
                </>
              )}
            </tr>
            <tr>
              <td className="tableTotalColumn">
                <b>{"Total"}</b>{" "}
                {gettooltip(
                  "TotalInfoIcon",
                  "Total",
                  "Total",
                  "Active Customers + Inactive Customers"
                )}
              </td>
              {loading.total ? (
                <>
                  <LoaderForRow tdCount={10} />
                </>
              ) : (
                <>
                  <th>
                    {customerProgramTotal !== undefined &&
                      customerProgramTotal.length !== 0 &&
                      (customerProgramTotal[0].CUST_COUNT_TY === "-999999"
                        ? "-"
                        : currencyFormat(
                            Number(customerProgramTotal[0].CUST_COUNT_TY)
                          ))}
                    <br />
                    {customerProgramTotal !== undefined &&
                    customerProgramTotal.length !== 0 &&
                    Number(customerProgramTotal[0].CUST_TY_VS_LY)
                      .toFixed(2)
                      .includes("-") ? (
                      <span style={{ color: "red", fontSize: "12px" }}>
                        {customerProgramTotal !== undefined &&
                          customerProgramTotal.length !== 0 &&
                          (customerProgramTotal[0].CUST_TY_VS_LY === "-999999"
                            ? "-"
                            : `LY ${Number(
                                customerProgramTotal[0].CUST_TY_VS_LY
                              ).toFixed(2)}%`)}
                      </span>
                    ) : (
                      <span style={{ color: "green", fontSize: "12px" }}>
                        {customerProgramTotal !== undefined &&
                          customerProgramTotal.length !== 0 &&
                          (customerProgramTotal[0].CUST_TY_VS_LY === "-999999"
                            ? "-"
                            : `LY +${Number(
                                customerProgramTotal[0].CUST_TY_VS_LY
                              ).toFixed(2)}%`)}
                      </span>
                    )}
                    <br />
                    {customerProgramTotal !== undefined &&
                    customerProgramTotal.length !== 0 &&
                    Number(customerProgramTotal[0].CUST_TY_VS_LLY)
                      .toFixed(2)
                      .includes("-") ? (
                      <span style={{ color: "red", fontSize: "11px" }}>
                        {customerProgramTotal !== undefined &&
                          customerProgramTotal.length !== 0 &&
                          (customerProgramTotal[0].CUST_TY_VS_LLY === "-999999"
                            ? "-"
                            : `LLY ${Number(
                                customerProgramTotal[0].CUST_TY_VS_LLY
                              ).toFixed(2)}%`)}
                      </span>
                    ) : (
                      <span style={{ color: "green", fontSize: "11px" }}>
                        {customerProgramTotal !== undefined &&
                          customerProgramTotal.length !== 0 &&
                          (customerProgramTotal[0].CUST_TY_VS_LLY === "-999999"
                            ? "-"
                            : `LLY +${Number(
                                customerProgramTotal[0].CUST_TY_VS_LLY
                              ).toFixed(2)}%`)}
                      </span>
                    )}
                  </th>
                  <th>
                    {customerProgramTotal !== undefined &&
                      customerProgramTotal.length !== 0 &&
                      (customerProgramTotal[0].NET_SALES_TY === "-999999"
                        ? "-"
                        : "$" +
                          currencyFormat(
                            Number(customerProgramTotal[0].NET_SALES_TY)
                          ))}
                    <br />
                    {customerProgramTotal !== undefined &&
                    customerProgramTotal.length !== 0 &&
                    Number(customerProgramTotal[0].NET_SALES_TY_VS_LY)
                      .toFixed(2)
                      .includes("-") ? (
                      <span style={{ color: "red", fontSize: "12px" }}>
                        {customerProgramTotal !== undefined &&
                          customerProgramTotal.length !== 0 &&
                          (customerProgramTotal[0].NET_SALES_TY_VS_LY ===
                          "-999999"
                            ? "-"
                            : `LY ${Number(
                                customerProgramTotal[0].NET_SALES_TY_VS_LY
                              ).toFixed(2)}%`)}
                      </span>
                    ) : (
                      <span style={{ color: "green", fontSize: "12px" }}>
                        {customerProgramTotal !== undefined &&
                          customerProgramTotal.length !== 0 &&
                          (customerProgramTotal[0].NET_SALES_TY_VS_LY ===
                          "-999999"
                            ? "-"
                            : `LY +${Number(
                                customerProgramTotal[0].NET_SALES_TY_VS_LY
                              ).toFixed(2)}%`)}
                      </span>
                    )}
                    <br />
                    {customerProgramTotal !== undefined &&
                    customerProgramTotal.length !== 0 &&
                    Number(customerProgramTotal[0].NET_SALES_TY_VS_LLY)
                      .toFixed(2)
                      .includes("-") ? (
                      <span style={{ color: "red", fontSize: "11px" }}>
                        {customerProgramTotal !== undefined &&
                          customerProgramTotal.length !== 0 &&
                          (customerProgramTotal[0].NET_SALES_TY_VS_LLY ===
                          "-999999"
                            ? "-"
                            : `LLY ${Number(
                                customerProgramTotal[0].NET_SALES_TY_VS_LLY
                              ).toFixed(2)}%`)}
                      </span>
                    ) : (
                      <span style={{ color: "green", fontSize: "11px" }}>
                        {customerProgramTotal !== undefined &&
                          customerProgramTotal.length !== 0 &&
                          (customerProgramTotal[0].NET_SALES_TY_VS_LLY ===
                          "-999999"
                            ? "-"
                            : `LLY +${Number(
                                customerProgramTotal[0].NET_SALES_TY_VS_LLY
                              ).toFixed(2)}%`)}
                      </span>
                    )}
                  </th>
                  <th>
                    {customerProgramTotal !== undefined &&
                      customerProgramTotal.length !== 0 &&
                      (customerProgramTotal[0].TRANS_COUNT_TY === "-999999"
                        ? "-"
                        : currencyFormat(
                            Number(customerProgramTotal[0].TRANS_COUNT_TY)
                          ))}
                    <br />
                    {customerProgramTotal !== undefined &&
                    customerProgramTotal.length !== 0 &&
                    Number(customerProgramTotal[0].TRANS_TY_VS_LY)
                      .toFixed(2)
                      .includes("-") ? (
                      <span style={{ color: "red", fontSize: "12px" }}>
                        {customerProgramTotal !== undefined &&
                          customerProgramTotal.length !== 0 &&
                          (customerProgramTotal[0].TRANS_TY_VS_LY === "-999999"
                            ? "-"
                            : `LY ${Number(
                                customerProgramTotal[0].TRANS_TY_VS_LY
                              ).toFixed(2)}%`)}
                      </span>
                    ) : (
                      <span style={{ color: "green", fontSize: "12px" }}>
                        {customerProgramTotal !== undefined &&
                          customerProgramTotal.length !== 0 &&
                          (customerProgramTotal[0].TRANS_TY_VS_LY === "-999999"
                            ? "-"
                            : `LY +${Number(
                                customerProgramTotal[0].TRANS_TY_VS_LY
                              ).toFixed(2)}%`)}
                      </span>
                    )}
                    <br />
                    {customerProgramTotal !== undefined &&
                    customerProgramTotal.length !== 0 &&
                    Number(customerProgramTotal[0].TRANS_TY_VS_LLY)
                      .toFixed(2)
                      .includes("-") ? (
                      <span style={{ color: "red", fontSize: "11px" }}>
                        {customerProgramTotal !== undefined &&
                          customerProgramTotal.length !== 0 &&
                          (customerProgramTotal[0].TRANS_TY_VS_LLY === "-999999"
                            ? "-"
                            : `LLY ${Number(
                                customerProgramTotal[0].TRANS_TY_VS_LLY
                              ).toFixed(2)}%`)}
                      </span>
                    ) : (
                      <span style={{ color: "green", fontSize: "11px" }}>
                        {customerProgramTotal !== undefined &&
                          customerProgramTotal.length !== 0 &&
                          (customerProgramTotal[0].TRANS_TY_VS_LLY === "-999999"
                            ? "-"
                            : `LLY +${Number(
                                customerProgramTotal[0].TRANS_TY_VS_LLY
                              ).toFixed(2)}%`)}
                      </span>
                    )}
                  </th>
                  <th>
                    {customerProgramTotal !== undefined &&
                      customerProgramTotal.length !== 0 &&
                      (customerProgramTotal[0].PM_TY === "-999999"
                        ? "-"
                        : "$" +
                          currencyFormat(
                            Number(customerProgramTotal[0].PM_TY)
                          ))}
                    <br />
                    {customerProgramTotal !== undefined &&
                    customerProgramTotal.length !== 0 &&
                    Number(customerProgramTotal[0].PM_TY_VS_LY)
                      .toFixed(2)
                      .includes("-") ? (
                      <span style={{ color: "red", fontSize: "12px" }}>
                        {customerProgramTotal !== undefined &&
                          customerProgramTotal.length !== 0 &&
                          (customerProgramTotal[0].PM_TY_VS_LY === "-999999"
                            ? "-"
                            : `LY ${Number(
                                customerProgramTotal[0].PM_TY_VS_LY
                              ).toFixed(2)}%`)}
                      </span>
                    ) : (
                      <span style={{ color: "green", fontSize: "12px" }}>
                        {customerProgramTotal !== undefined &&
                          customerProgramTotal.length !== 0 &&
                          (customerProgramTotal[0].PM_TY_VS_LY === "-999999"
                            ? "-"
                            : `LY +${Number(
                                customerProgramTotal[0].PM_TY_VS_LY
                              ).toFixed(2)}%`)}
                      </span>
                    )}
                    <br />
                    {customerProgramTotal !== undefined &&
                    customerProgramTotal.length !== 0 &&
                    Number(customerProgramTotal[0].PM_TY_VS_LLY)
                      .toFixed(2)
                      .includes("-") ? (
                      <span style={{ color: "red", fontSize: "11px" }}>
                        {customerProgramTotal !== undefined &&
                          customerProgramTotal.length !== 0 &&
                          (customerProgramTotal[0].PM_TY_VS_LLY === "-999999"
                            ? "-"
                            : `LLY ${Number(
                                customerProgramTotal[0].PM_TY_VS_LLY
                              ).toFixed(2)}%`)}
                      </span>
                    ) : (
                      <span style={{ color: "green", fontSize: "11px" }}>
                        {customerProgramTotal !== undefined &&
                          customerProgramTotal.length !== 0 &&
                          (customerProgramTotal[0].PM_TY_VS_LLY === "-999999"
                            ? "-"
                            : `LLY +${Number(
                                customerProgramTotal[0].PM_TY_VS_LLY
                              ).toFixed(2)}%`)}
                      </span>
                    )}
                  </th>
                  <th>
                    {customerProgramTotal !== undefined &&
                      customerProgramTotal.length !== 0 &&
                      (customerProgramTotal[0].AOV_TY === "-999999"
                        ? "-"
                        : "$" +
                          Number(customerProgramTotal[0].AOV_TY).toFixed(2))}
                    <br />
                    {customerProgramTotal !== undefined &&
                    customerProgramTotal.length !== 0 &&
                    Number(customerProgramTotal[0].AOV_TY_VS_LY)
                      .toFixed(2)
                      .includes("-") ? (
                      <span style={{ color: "red", fontSize: "12px" }}>
                        {customerProgramTotal !== undefined &&
                          customerProgramTotal.length !== 0 &&
                          (customerProgramTotal[0].AOV_TY_VS_LY === "-999999"
                            ? "-"
                            : `LY ${Number(
                                customerProgramTotal[0].AOV_TY_VS_LY
                              ).toFixed(2)}%`)}
                      </span>
                    ) : (
                      <span style={{ color: "green", fontSize: "12px" }}>
                        {customerProgramTotal !== undefined &&
                          customerProgramTotal.length !== 0 &&
                          (customerProgramTotal[0].AOV_TY_VS_LY === "-999999"
                            ? "-"
                            : `LY +${Number(
                                customerProgramTotal[0].AOV_TY_VS_LY
                              ).toFixed(2)}%`)}
                      </span>
                    )}
                    <br />
                    {customerProgramTotal !== undefined &&
                    customerProgramTotal.length !== 0 &&
                    Number(customerProgramTotal[0].AOV_TY_VS_LLY)
                      .toFixed(2)
                      .includes("-") ? (
                      <span style={{ color: "red", fontSize: "11px" }}>
                        {customerProgramTotal !== undefined &&
                          customerProgramTotal.length !== 0 &&
                          (customerProgramTotal[0].AOV_TY_VS_LLY === "-999999"
                            ? "-"
                            : `LLY ${Number(
                                customerProgramTotal[0].AOV_TY_VS_LLY
                              ).toFixed(2)}%`)}
                      </span>
                    ) : (
                      <span style={{ color: "green", fontSize: "11px" }}>
                        {customerProgramTotal !== undefined &&
                          customerProgramTotal.length !== 0 &&
                          (customerProgramTotal[0].AOV_TY_VS_LLY === "-999999"
                            ? "-"
                            : `LLY +${Number(
                                customerProgramTotal[0].AOV_TY_VS_LLY
                              ).toFixed(2)}%`)}
                      </span>
                    )}
                  </th>
                  <th>
                    {customerProgramTotal !== undefined &&
                      customerProgramTotal.length !== 0 &&
                      (customerProgramTotal[0].UPT_TY === "-999999"
                        ? "-"
                        : Number(customerProgramTotal[0].UPT_TY).toFixed(1))}
                    <br />
                    {customerProgramTotal !== undefined &&
                    customerProgramTotal.length !== 0 &&
                    Number(customerProgramTotal[0].UPT_TY_VS_LY)
                      .toFixed(2)
                      .includes("-") ? (
                      <span style={{ color: "red", fontSize: "12px" }}>
                        {customerProgramTotal !== undefined &&
                          customerProgramTotal.length !== 0 &&
                          (customerProgramTotal[0].UPT_TY_VS_LY === "-999999"
                            ? "-"
                            : `LY ${Number(
                                customerProgramTotal[0].UPT_TY_VS_LY
                              ).toFixed(2)}%`)}
                      </span>
                    ) : (
                      <span style={{ color: "green", fontSize: "12px" }}>
                        {customerProgramTotal !== undefined &&
                          customerProgramTotal.length !== 0 &&
                          (customerProgramTotal[0].UPT_TY_VS_LY === "-999999"
                            ? "-"
                            : `LY +${Number(
                                customerProgramTotal[0].UPT_TY_VS_LY
                              ).toFixed(2)}%`)}
                      </span>
                    )}
                    <br />
                    {customerProgramTotal !== undefined &&
                    customerProgramTotal.length !== 0 &&
                    Number(customerProgramTotal[0].UPT_TY_VS_LLY)
                      .toFixed(2)
                      .includes("-") ? (
                      <span style={{ color: "red", fontSize: "11px" }}>
                        {customerProgramTotal !== undefined &&
                          customerProgramTotal.length !== 0 &&
                          (customerProgramTotal[0].UPT_TY_VS_LLY === "-999999"
                            ? "-"
                            : `LLY ${Number(
                                customerProgramTotal[0].UPT_TY_VS_LLY
                              ).toFixed(2)}%`)}
                      </span>
                    ) : (
                      <span style={{ color: "green", fontSize: "11px" }}>
                        {customerProgramTotal !== undefined &&
                          customerProgramTotal.length !== 0 &&
                          (customerProgramTotal[0].UPT_TY_VS_LLY === "-999999"
                            ? "-"
                            : `LLY +${Number(
                                customerProgramTotal[0].UPT_TY_VS_LLY
                              ).toFixed(2)}%`)}
                      </span>
                    )}
                  </th>
                  <th>
                    {customerProgramTotal !== undefined &&
                      customerProgramTotal.length !== 0 &&
                      (customerProgramTotal[0].AUR_TY === "-999999"
                        ? "-"
                        : "$" +
                          Number(customerProgramTotal[0].AUR_TY).toFixed(2))}
                    <br />
                    {customerProgramTotal !== undefined &&
                    customerProgramTotal.length !== 0 &&
                    Number(customerProgramTotal[0].AUR_TY_VS_LY)
                      .toFixed(2)
                      .includes("-") ? (
                      <span style={{ color: "red", fontSize: "12px" }}>
                        {customerProgramTotal !== undefined &&
                          customerProgramTotal.length !== 0 &&
                          (customerProgramTotal[0].AUR_TY_VS_LY === "-999999"
                            ? "-"
                            : `LY ${Number(
                                customerProgramTotal[0].AUR_TY_VS_LY
                              ).toFixed(2)}%`)}
                      </span>
                    ) : (
                      <span style={{ color: "green", fontSize: "12px" }}>
                        {customerProgramTotal !== undefined &&
                          customerProgramTotal.length !== 0 &&
                          (customerProgramTotal[0].AUR_TY_VS_LY === "-999999"
                            ? "-"
                            : `LY +${Number(
                                customerProgramTotal[0].AUR_TY_VS_LY
                              ).toFixed(2)}%`)}
                      </span>
                    )}
                    <br />
                    {customerProgramTotal !== undefined &&
                    customerProgramTotal.length !== 0 &&
                    Number(customerProgramTotal[0].AUR_TY_VS_LLY)
                      .toFixed(2)
                      .includes("-") ? (
                      <span style={{ color: "red", fontSize: "11px" }}>
                        {customerProgramTotal !== undefined &&
                          customerProgramTotal.length !== 0 &&
                          (customerProgramTotal[0].AUR_TY_VS_LLY === "-999999"
                            ? "-"
                            : `LLY ${Number(
                                customerProgramTotal[0].AUR_TY_VS_LLY
                              ).toFixed(2)}%`)}
                      </span>
                    ) : (
                      <span style={{ color: "green", fontSize: "11px" }}>
                        {customerProgramTotal !== undefined &&
                          customerProgramTotal.length !== 0 &&
                          (customerProgramTotal[0].AUR_TY_VS_LLY === "-999999"
                            ? "-"
                            : `LLY +${Number(
                                customerProgramTotal[0].AUR_TY_VS_LLY
                              ).toFixed(2)}%`)}
                      </span>
                    )}
                  </th>
                  <th>
                    {customerProgramTotal !== undefined &&
                      customerProgramTotal.length !== 0 &&
                      (customerProgramTotal[0].MARGIN_RATE_PER_TY === "-999999"
                        ? "-"
                        : Number(
                            customerProgramTotal[0].MARGIN_RATE_PER_TY
                          ).toFixed(2))}
                    <br />
                    {customerProgramTotal !== undefined &&
                    customerProgramTotal.length !== 0 &&
                    Number(customerProgramTotal[0].MARGIN_RATE_PER_TY_VS_LY)
                      .toFixed(2)
                      .includes("-") ? (
                      <span style={{ color: "red", fontSize: "12px" }}>
                        {customerProgramTotal !== undefined &&
                          customerProgramTotal.length !== 0 &&
                          (customerProgramTotal[0].MARGIN_RATE_PER_TY_VS_LY ===
                          "-999999"
                            ? "-"
                            : `LY ${Number(
                                customerProgramTotal[0].MARGIN_RATE_PER_TY_VS_LY
                              ).toFixed(2)}%`)}
                      </span>
                    ) : (
                      <span style={{ color: "green", fontSize: "12px" }}>
                        {customerProgramTotal !== undefined &&
                          customerProgramTotal.length !== 0 &&
                          (customerProgramTotal[0].MARGIN_RATE_PER_TY_VS_LY ===
                          "-999999"
                            ? "-"
                            : `LY +${Number(
                                customerProgramTotal[0].MARGIN_RATE_PER_TY_VS_LY
                              ).toFixed(2)}%`)}
                      </span>
                    )}
                    <br />
                    {customerProgramTotal !== undefined &&
                    customerProgramTotal.length !== 0 &&
                    Number(customerProgramTotal[0].MARGIN_RATE_PER_TY_VS_LLY)
                      .toFixed(2)
                      .includes("-") ? (
                      <span style={{ color: "red", fontSize: "11px" }}>
                        {customerProgramTotal !== undefined &&
                          customerProgramTotal.length !== 0 &&
                          (customerProgramTotal[0].MARGIN_RATE_PER_TY_VS_LLY ===
                          "-999999"
                            ? "-"
                            : `LLY ${Number(
                                customerProgramTotal[0]
                                  .MARGIN_RATE_PER_TY_VS_LLY
                              ).toFixed(2)}%`)}
                      </span>
                    ) : (
                      <span style={{ color: "green", fontSize: "11px" }}>
                        {customerProgramTotal !== undefined &&
                          customerProgramTotal.length !== 0 &&
                          (customerProgramTotal[0].MARGIN_RATE_PER_TY_VS_LLY ===
                          "-999999"
                            ? "-"
                            : `LLY +${Number(
                                customerProgramTotal[0]
                                  .MARGIN_RATE_PER_TY_VS_LLY
                              ).toFixed(2)}%`)}
                      </span>
                    )}
                  </th>
                  <th>
                    {customerProgramTotal !== undefined &&
                      customerProgramTotal.length !== 0 &&
                      (customerProgramTotal[0].NET_SALES_PER_CUST_TY ===
                      "-999999"
                        ? "-"
                        : "$" +
                          Number(
                            customerProgramTotal[0].NET_SALES_PER_CUST_TY
                          ).toFixed(2))}
                    <br />
                    {customerProgramTotal !== undefined &&
                    customerProgramTotal.length !== 0 &&
                    Number(customerProgramTotal[0].NET_SALES_PER_CUST_TY_VS_LY)
                      .toFixed(2)
                      .includes("-") ? (
                      <span style={{ color: "red", fontSize: "12px" }}>
                        {customerProgramTotal !== undefined &&
                          customerProgramTotal.length !== 0 &&
                          (customerProgramTotal[0]
                            .NET_SALES_PER_CUST_TY_VS_LY === "-999999"
                            ? "-"
                            : `LY ${Number(
                                customerProgramTotal[0]
                                  .NET_SALES_PER_CUST_TY_VS_LY
                              ).toFixed(2)}%`)}
                      </span>
                    ) : (
                      <span style={{ color: "green", fontSize: "12px" }}>
                        {customerProgramTotal !== undefined &&
                          customerProgramTotal.length !== 0 &&
                          (customerProgramTotal[0]
                            .NET_SALES_PER_CUST_TY_VS_LY === "-999999"
                            ? "-"
                            : `LY +${Number(
                                customerProgramTotal[0]
                                  .NET_SALES_PER_CUST_TY_VS_LY
                              ).toFixed(2)}%`)}
                      </span>
                    )}
                    <br />
                    {customerProgramTotal !== undefined &&
                    customerProgramTotal.length !== 0 &&
                    Number(customerProgramTotal[0].NET_SALES_PER_CUST_TY_VS_LLY)
                      .toFixed(2)
                      .includes("-") ? (
                      <span style={{ color: "red", fontSize: "11px" }}>
                        {customerProgramTotal !== undefined &&
                          customerProgramTotal.length !== 0 &&
                          (customerProgramTotal[0]
                            .NET_SALES_PER_CUST_TY_VS_LLY === "-999999"
                            ? "-"
                            : `LLY ${Number(
                                customerProgramTotal[0]
                                  .NET_SALES_PER_CUST_TY_VS_LLY
                              ).toFixed(2)}%`)}
                      </span>
                    ) : (
                      <span style={{ color: "green", fontSize: "11px" }}>
                        {customerProgramTotal !== undefined &&
                          customerProgramTotal.length !== 0 &&
                          (customerProgramTotal[0]
                            .NET_SALES_PER_CUST_TY_VS_LLY === "-999999"
                            ? "-"
                            : `LLY +${Number(
                                customerProgramTotal[0]
                                  .NET_SALES_PER_CUST_TY_VS_LLY
                              ).toFixed(2)}%`)}
                      </span>
                    )}
                  </th>
                  <th>
                    {customerProgramTotal !== undefined &&
                      customerProgramTotal.length !== 0 &&
                      (customerProgramTotal[0].AVG_TRAN_TY === "-999999"
                        ? "-"
                        : Number(customerProgramTotal[0].AVG_TRAN_TY).toFixed(
                            2
                          ))}
                    <br />
                    {customerProgramTotal !== undefined &&
                    customerProgramTotal.length !== 0 &&
                    Number(customerProgramTotal[0].AVG_TRAN_TY_VS_LY)
                      .toFixed(2)
                      .includes("-") ? (
                      <span style={{ color: "red", fontSize: "12px" }}>
                        {customerProgramTotal !== undefined &&
                          customerProgramTotal.length !== 0 &&
                          (customerProgramTotal[0].AVG_TRAN_TY_VS_LY ===
                          "-999999"
                            ? "-"
                            : `LY ${Number(
                                customerProgramTotal[0].AVG_TRAN_TY_VS_LY
                              ).toFixed(2)}%`)}
                      </span>
                    ) : (
                      <span style={{ color: "green", fontSize: "12px" }}>
                        {customerProgramTotal !== undefined &&
                          customerProgramTotal.length !== 0 &&
                          (customerProgramTotal[0].AVG_TRAN_TY_VS_LY ===
                          "-999999"
                            ? "-"
                            : `LY +${Number(
                                customerProgramTotal[0].AVG_TRAN_TY_VS_LY
                              ).toFixed(2)}%`)}
                      </span>
                    )}
                    <br />
                    {customerProgramTotal !== undefined &&
                    customerProgramTotal.length !== 0 &&
                    Number(customerProgramTotal[0].AVG_TRAN_TY_VS_LLY)
                      .toFixed(2)
                      .includes("-") ? (
                      <span style={{ color: "red", fontSize: "11px" }}>
                        {customerProgramTotal !== undefined &&
                          customerProgramTotal.length !== 0 &&
                          (customerProgramTotal[0].AVG_TRAN_TY_VS_LLY ===
                          "-999999"
                            ? "-"
                            : `LLY ${Number(
                                customerProgramTotal[0].AVG_TRAN_TY_VS_LLY
                              ).toFixed(2)}%`)}
                      </span>
                    ) : (
                      <span style={{ color: "green", fontSize: "11px" }}>
                        {customerProgramTotal !== undefined &&
                          customerProgramTotal.length !== 0 &&
                          (customerProgramTotal[0].AVG_TRAN_TY_VS_LLY ===
                          "-999999"
                            ? "-"
                            : `LLY +${Number(
                                customerProgramTotal[0].AVG_TRAN_TY_VS_LLY
                              ).toFixed(2)}%`)}
                      </span>
                    )}
                  </th>
                </>
              )}
            </tr>
          </tbody>
        </Table>
      </div>
    </div>
  );
}

export default ChannelHome;
