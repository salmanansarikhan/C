import React, { useState } from "react";
import Alert from "react-bootstrap/Alert";
// import Footer from "../Footer/Footer";
// import Header from "../Header/Header";

const NoAccess = ({ tabName }) => {
  return (
    <>
      {/* <Header />{" "} */}
      <div style={{ height: "100vh" }}>
        <Alert variant="danger">Don't have access to {tabName} Dashboard</Alert>
      </div>
      {/* <Footer /> */}
    </>
  );
};

export default NoAccess;
