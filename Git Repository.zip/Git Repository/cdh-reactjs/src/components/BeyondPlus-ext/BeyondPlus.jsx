import { React, useState } from "react";
import { useHistory } from "react-router-dom";
import "./BeyondPlus.css";
import { Table } from "react-bootstrap";
import LoaderForRow from "../LoaderForTable/LoaderForRow";
import { gettooltip } from "../Utils";
// import { Spinner, SpinnerSize } from 'office-ui-fabric-react';
function BeyondPlus({}) {
  return (
    <div className="">
      <div className="p-3" style={{ marginBottom: "50px" }}>
        <Table striped bordered hover size="sm">
          <thead>
            <tr>
              <th style={{ width: "200px" }}>L12m Active</th>
              <th>Customers</th>
              <th>Transactions</th>
              <th>Net Sales</th>
              <th>AUR</th>
              <th>UPT</th>
              <th>AOV</th>
              <th>Product Margin</th>
            </tr>
          </thead>
          <tbody>
            <tr>
              <td className="tableCol " id={"Stable_Exist"}>
                {"Returning Customers"}{" "}
                {gettooltip(
                  "ReturningCustomersInfoIcon",
                  "ReturningCustomers",
                  "ReturningCustomers",
                  "Active in L6M and active in L12M to L24M"
                )}
              </td>
            </tr>
            <tr>
              <td className="tableCol">
                {"New Customers"}{" "}
                {gettooltip(
                  "NewCustomersInfoIcon",
                  "NewCustomers",
                  "NewCustomers",
                  "Active in L12M but not active in L12M to L24M"
                )}
              </td>
            </tr>
            <tr>
              <td className="tableCol" id={"AtRisk_69"}>
                {"At risk (6m-9m)"}{" "}
                {gettooltip(
                  "AtRisk_6_9InfoIcon",
                  "AtRisk_6_9",
                  "AtRisk_6_9",
                  "Active in L9M but not active in L6M"
                )}
              </td>
            </tr>
            <tr>
              <td className="tableCol" id={"AtRisk_9_12"}>
                {"At risk (9m-12m)"}{" "}
                {gettooltip(
                  "AtRisk_9_12InfoIcon",
                  "AtRisk_9_12",
                  "AtRisk_9_12",
                  "Active in L12M but not active in L9M"
                )}
              </td>
            </tr>
            <tr>
              <td className="tableCol">
                {"Inactive (12m-18m)"}{" "}
                {gettooltip(
                  "InActive_12_18InfoIcon",
                  "InActive_12_18",
                  "InActive_12_18",
                  "Active in L12M-L18M but not active in L12M"
                )}
              </td>
            </tr>
            <tr>
              <td className="tableCol">
                {"Inactive (18m-24m)"}{" "}
                {gettooltip(
                  "InActive_18_24InfoIcon",
                  "InActive_18_24",
                  "InActive_18_24",
                  "Active in L18M-L24M but not active in L18M"
                )}
              </td>
            </tr>
            <tr>
              <td className="tableTotalCol">
                <b>{"Total"}</b>
              </td>
              <th></th>
              <th></th>
              <th></th>
              <th></th>
              <th></th>
              <th></th>
              <th></th>
            </tr>
          </tbody>
        </Table>
      </div>
    </div>
  );
}

export default BeyondPlus;
