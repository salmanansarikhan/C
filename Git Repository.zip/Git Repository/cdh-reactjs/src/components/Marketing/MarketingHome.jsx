import { React, useState } from "react";
import { useHistory } from "react-router-dom";
import { Table, Modal } from "react-bootstrap";
import LoaderForRow from "../LoaderForTable/LoaderForRow";
import ReturningCustomerModal from "./ReturningCustomerModal";
import { gettooltip } from "../Utils";

export const currencyFormat = (value) => {
  return parseFloat(value)
    .toFixed(0)
    .replace(/(\d)(?=(\d{3})+(?!\d))/g, "$1,");
};

function MarketingHome({
  loading,
  customerMarketingActiveExisting,
  customerMarketingActiveData,
  customerMarketingDataSixMonths,
  customerMarketingDataNineMonths,
  customerMarketingFirst_Four_Total_Data,
  customerMarketingInActive_12_18_Data,
  customerMarketingInActive_18_24_Data,
  customerMarketingSecond_half_total_Data,
  marketingTotal,
  selectedMarketingCategoryId,
  selectedMarketingBannerId,
  selectedMarketingDate,
  periodStartDate,
  periodEndDate,
}) {
  const [modalFlag, setModalFlag] = useState(false);
  const [modalHeaderText, setModalHeader] = useState();
  const handleModalOpen = (type) => {
    setModalFlag(true);
    setModalHeader(type);
  };
  const handleModalClose = () => {
    setModalFlag(false);
  };
  return (
    <div className="">
      {selectedMarketingCategoryId === "NR" ? (
        ""
      ) : (
        <ReturningCustomerModal
          modalFlag={modalFlag}
          handleModalClose={handleModalClose}
          selectedMarketingCategoryId={selectedMarketingCategoryId}
          modalHeaderText={modalHeaderText}
          selectedMarketingBannerId={selectedMarketingBannerId}
          selectedMarketingDate={selectedMarketingDate}
          loadingHome={loading}
          periodStartDate={periodStartDate}
          periodEndDate={periodEndDate}
        />
      )}
      <div className="p-3" style={{ marginBottom: "50px" }}>
        <Table striped bordered hover size="sm">
          <thead>
            <tr>
              <th style={{ width: "200px" }}>
                L12m Active{" "}
                {gettooltip(
                  "L12mActiveInfoIcon",
                  "L12mActive",
                  "L12mActive",
                  "Inactive (24 months) - The customers",
                  "who were not active in last 24 months"
                )}
              </th>
              <th>
                Customers{" "}
                {gettooltip(
                  "customersInfoIcon",
                  "Customers",
                  "Customers",
                  "Data based on two years"
                )}
              </th>
              <th>
                Net Sales{" "}
                {gettooltip(
                  "NetSalesInfoIcon",
                  "NetSales",
                  "NetSales",
                  "Net Sales for customers in one year"
                )}
              </th>
              <th>
                Transactions{" "}
                {gettooltip(
                  "TransactionsInfoIcon",
                  "Transactions",
                  "Transactions",
                  "Number of distinct transaction for customer in one year"
                )}
              </th>
              <th>
                Product Margin{" "}
                {gettooltip(
                  "ProductMarginInfoIcon",
                  "ProductMargin",
                  "ProductMargin",
                  "Product Margin for customers in one year",
                  "(Net Sales - Cost of Sales)"
                )}
              </th>
              <th>
                AOV{" "}
                {gettooltip(
                  "AOVInfoIcon",
                  "AOV",
                  "AOV",
                  "Net Sales divided by number of transaction"
                )}
              </th>
              <th>
                UPT{" "}
                {gettooltip(
                  "UPTInfoIcon",
                  "UPT",
                  "UPT",
                  "Unit Sold per transaction"
                )}
              </th>
              <th>
                AUR{" "}
                {gettooltip(
                  "AURInfoIcon",
                  "AUR",
                  "AUR",
                  "Net Sales divided by unit sold"
                )}
              </th>
              <th>
                Margin Rate
                <br /> %{" "}
                {gettooltip(
                  "MarginRateInfoIcon",
                  "MarginRate",
                  "MarginRate",
                  "(Net Sales - Cost of Sales) / Net Sales"
                )}
              </th>
              <th>
                Net Sales per <br /> Customer{" "}
                {gettooltip(
                  "NPCInfoIcon",
                  "NPC",
                  "NPC",
                  "Net Sales per Customer"
                )}
              </th>
              <th>
                Transactions per <br /> Customer{" "}
                {gettooltip(
                  "TPCInfoIcon",
                  "TPC",
                  "TPC",
                  "Number of Transactions per customer"
                )}
              </th>
            </tr>
          </thead>
          <tbody>
            <tr>
              <td
                className="tableCol"
                id={
                  selectedMarketingCategoryId !== "NR"
                    ? "Stable_Exist"
                    : "StableExist"
                }
                onClick={() =>
                  selectedMarketingCategoryId !== "NR"
                    ? handleModalOpen("Returning Customers")
                    : ""
                }
              >
                {"Returning Customers"}{" "}
                {gettooltip(
                  "ReturningCustomersInfoIcon",
                  "ReturningCustomers",
                  "ReturningCustomers",
                  "Active in L6M and active in L12M to L24M"
                )}
              </td>
              {loading.Active_Existing ? (
                <>
                  <LoaderForRow tdCount={10} />
                </>
              ) : (
                <>
                  <td>
                    {customerMarketingActiveExisting !== undefined &&
                      customerMarketingActiveExisting.length !== 0 &&
                      (customerMarketingActiveExisting[0].CUST_COUNT_TY ===
                      "-999999"
                        ? "-"
                        : currencyFormat(
                            Number(
                              customerMarketingActiveExisting[0].CUST_COUNT_TY
                            )
                          ))}
                    <br />
                    {customerMarketingActiveExisting !== undefined &&
                    customerMarketingActiveExisting.length !== 0 &&
                    Number(customerMarketingActiveExisting[0].CUST_TY_VS_LY)
                      .toFixed(2)
                      .includes("-") ? (
                      <span style={{ color: "red", fontSize: "12px" }}>
                        {customerMarketingActiveExisting[0].CUST_TY_VS_LY ===
                        "-999999"
                          ? "-"
                          : `LY ${Number(
                              customerMarketingActiveExisting[0].CUST_TY_VS_LY
                            ).toFixed(2)}%`}
                      </span>
                    ) : (
                      <span style={{ color: "green", fontSize: "12px" }}>
                        {customerMarketingActiveExisting !== undefined &&
                          customerMarketingActiveExisting.length !== 0 &&
                          (customerMarketingActiveExisting[0].CUST_TY_VS_LY ===
                          "-999999"
                            ? "-"
                            : `LY +${Number(
                                customerMarketingActiveExisting[0].CUST_TY_VS_LY
                              ).toFixed(2)}%`)}
                      </span>
                    )}
                    <br />
                    {customerMarketingActiveExisting !== undefined &&
                    customerMarketingActiveExisting.length !== 0 &&
                    Number(customerMarketingActiveExisting[0].CUST_TY_VS_LLY)
                      .toFixed(2)
                      .includes("-") ? (
                      <span style={{ color: "red", fontSize: "11px" }}>
                        {customerMarketingActiveExisting !== undefined &&
                          customerMarketingActiveExisting.length !== 0 &&
                          (customerMarketingActiveExisting[0].CUST_TY_VS_LLY ===
                          "-999999"
                            ? "-"
                            : `LLY ${Number(
                                customerMarketingActiveExisting[0]
                                  .CUST_TY_VS_LLY
                              ).toFixed(2)}%`)}
                      </span>
                    ) : (
                      <span style={{ color: "green", fontSize: "11px" }}>
                        {customerMarketingActiveExisting !== undefined &&
                          customerMarketingActiveExisting.length !== 0 &&
                          (customerMarketingActiveExisting[0].CUST_TY_VS_LLY ===
                          "-999999"
                            ? "-"
                            : `LLY +${Number(
                                customerMarketingActiveExisting[0]
                                  .CUST_TY_VS_LLY
                              ).toFixed(2)}%`)}
                      </span>
                    )}
                  </td>
                  <td>
                    {customerMarketingActiveExisting !== undefined &&
                      customerMarketingActiveExisting.length !== 0 &&
                      (customerMarketingActiveExisting[0].NET_SALES_TY ===
                      "-999999"
                        ? "-"
                        : "$" +
                          currencyFormat(
                            Number(
                              customerMarketingActiveExisting[0].NET_SALES_TY
                            )
                          ))}
                    <br />
                    {customerMarketingActiveExisting !== undefined &&
                    customerMarketingActiveExisting.length !== 0 &&
                    Number(
                      customerMarketingActiveExisting[0].NET_SALES_TY_VS_LY
                    )
                      .toFixed(2)
                      .includes("-") ? (
                      <span style={{ color: "red", fontSize: "12px" }}>
                        {customerMarketingActiveExisting !== undefined &&
                          customerMarketingActiveExisting.length !== 0 &&
                          (customerMarketingActiveExisting[0]
                            .NET_SALES_TY_VS_LY === "-999999"
                            ? "-"
                            : `LY ${Number(
                                customerMarketingActiveExisting[0]
                                  .NET_SALES_TY_VS_LY
                              ).toFixed(2)}%`)}
                      </span>
                    ) : (
                      <span style={{ color: "green", fontSize: "12px" }}>
                        {customerMarketingActiveExisting !== undefined &&
                          customerMarketingActiveExisting.length !== 0 &&
                          (customerMarketingActiveExisting[0]
                            .NET_SALES_TY_VS_LY === "-999999"
                            ? "-"
                            : `LY +${Number(
                                customerMarketingActiveExisting[0]
                                  .NET_SALES_TY_VS_LY
                              ).toFixed(2)}%`)}
                      </span>
                    )}
                    <br />
                    {customerMarketingActiveExisting !== undefined &&
                    customerMarketingActiveExisting.length !== 0 &&
                    Number(
                      customerMarketingActiveExisting[0].NET_SALES_TY_VS_LLY
                    )
                      .toFixed(2)
                      .includes("-") ? (
                      <span style={{ color: "red", fontSize: "11px" }}>
                        {customerMarketingActiveExisting !== undefined &&
                          customerMarketingActiveExisting.length !== 0 &&
                          (customerMarketingActiveExisting[0]
                            .NET_SALES_TY_VS_LLY === "-999999"
                            ? "-"
                            : `LLY ${Number(
                                customerMarketingActiveExisting[0]
                                  .NET_SALES_TY_VS_LLY
                              ).toFixed(2)}%`)}
                      </span>
                    ) : (
                      <span style={{ color: "green", fontSize: "11px" }}>
                        {customerMarketingActiveExisting !== undefined &&
                          customerMarketingActiveExisting.length !== 0 &&
                          (customerMarketingActiveExisting[0]
                            .NET_SALES_TY_VS_LLY === "-999999"
                            ? "-"
                            : `LLY +${Number(
                                customerMarketingActiveExisting[0]
                                  .NET_SALES_TY_VS_LLY
                              ).toFixed(2)}%`)}
                      </span>
                    )}
                  </td>
                  <td>
                    {customerMarketingActiveExisting !== undefined &&
                      customerMarketingActiveExisting.length !== 0 &&
                      (customerMarketingActiveExisting[0].TRANS_COUNT_TY ===
                      "-999999"
                        ? "-"
                        : currencyFormat(
                            Number(
                              customerMarketingActiveExisting[0].TRANS_COUNT_TY
                            )
                          ))}
                    <br />
                    {customerMarketingActiveExisting !== undefined &&
                    customerMarketingActiveExisting.length !== 0 &&
                    Number(customerMarketingActiveExisting[0].TRANS_TY_VS_LY)
                      .toFixed(2)
                      .includes("-") ? (
                      <span style={{ color: "red", fontSize: "12px" }}>
                        {customerMarketingActiveExisting !== undefined &&
                          customerMarketingActiveExisting.length !== 0 &&
                          (customerMarketingActiveExisting[0].TRANS_TY_VS_LY ===
                          "-999999"
                            ? "-"
                            : `LY ${Number(
                                customerMarketingActiveExisting[0]
                                  .TRANS_TY_VS_LY
                              ).toFixed(2)}%`)}
                      </span>
                    ) : (
                      <span style={{ color: "green", fontSize: "12px" }}>
                        {customerMarketingActiveExisting !== undefined &&
                          customerMarketingActiveExisting.length !== 0 &&
                          (customerMarketingActiveExisting[0].TRANS_TY_VS_LY ===
                          "-999999"
                            ? "-"
                            : `LY +${Number(
                                customerMarketingActiveExisting[0]
                                  .TRANS_TY_VS_LY
                              ).toFixed(2)}%`)}
                      </span>
                    )}
                    <br />
                    {customerMarketingActiveExisting !== undefined &&
                    customerMarketingActiveExisting.length !== 0 &&
                    Number(customerMarketingActiveExisting[0].TRANS_TY_VS_LLY)
                      .toFixed(2)
                      .includes("-") ? (
                      <span style={{ color: "red", fontSize: "11px" }}>
                        {customerMarketingActiveExisting !== undefined &&
                          customerMarketingActiveExisting.length !== 0 &&
                          (customerMarketingActiveExisting[0]
                            .TRANS_TY_VS_LLY === "-999999"
                            ? "-"
                            : `LLY ${Number(
                                customerMarketingActiveExisting[0]
                                  .TRANS_TY_VS_LLY
                              ).toFixed(2)}%`)}
                      </span>
                    ) : (
                      <span style={{ color: "green", fontSize: "11px" }}>
                        {customerMarketingActiveExisting !== undefined &&
                          customerMarketingActiveExisting.length !== 0 &&
                          (customerMarketingActiveExisting[0]
                            .TRANS_TY_VS_LLY === "-999999"
                            ? "-"
                            : `LLY +${Number(
                                customerMarketingActiveExisting[0]
                                  .TRANS_TY_VS_LLY
                              ).toFixed(2)}%`)}
                      </span>
                    )}
                  </td>
                  <td>
                    {customerMarketingActiveExisting !== undefined &&
                      customerMarketingActiveExisting.length !== 0 &&
                      (customerMarketingActiveExisting[0].PM_TY === "-999999"
                        ? "-"
                        : "$" +
                          currencyFormat(
                            Number(customerMarketingActiveExisting[0].PM_TY)
                          ))}
                    <br />
                    {customerMarketingActiveExisting !== undefined &&
                    customerMarketingActiveExisting.length !== 0 &&
                    Number(customerMarketingActiveExisting[0].PM_TY_VS_LY)
                      .toFixed(2)
                      .includes("-") ? (
                      <span style={{ color: "red", fontSize: "12px" }}>
                        {customerMarketingActiveExisting !== undefined &&
                          customerMarketingActiveExisting.length !== 0 &&
                          (customerMarketingActiveExisting[0].PM_TY_VS_LY ===
                          "-999999"
                            ? "-"
                            : `LY ${Number(
                                customerMarketingActiveExisting[0].PM_TY_VS_LY
                              ).toFixed(2)}%`)}
                      </span>
                    ) : (
                      <span style={{ color: "green", fontSize: "12px" }}>
                        {customerMarketingActiveExisting !== undefined &&
                          customerMarketingActiveExisting.length !== 0 &&
                          (customerMarketingActiveExisting[0].PM_TY_VS_LY ===
                          "-999999"
                            ? "-"
                            : `LY +${Number(
                                customerMarketingActiveExisting[0].PM_TY_VS_LY
                              ).toFixed(2)}%`)}
                      </span>
                    )}
                    <br />
                    {customerMarketingActiveExisting !== undefined &&
                    customerMarketingActiveExisting.length !== 0 &&
                    Number(customerMarketingActiveExisting[0].PM_TY_VS_LLY)
                      .toFixed(2)
                      .includes("-") ? (
                      <span style={{ color: "red", fontSize: "11px" }}>
                        {customerMarketingActiveExisting !== undefined &&
                          customerMarketingActiveExisting.length !== 0 &&
                          (customerMarketingActiveExisting[0].PM_TY_VS_LLY ===
                          "-999999"
                            ? "-"
                            : `LLY ${Number(
                                customerMarketingActiveExisting[0].PM_TY_VS_LLY
                              ).toFixed(2)}%`)}
                      </span>
                    ) : (
                      <span style={{ color: "green", fontSize: "11px" }}>
                        {customerMarketingActiveExisting !== undefined &&
                          customerMarketingActiveExisting.length !== 0 &&
                          (customerMarketingActiveExisting[0].PM_TY_VS_LLY ===
                          "-999999"
                            ? "-"
                            : `LLY +${Number(
                                customerMarketingActiveExisting[0].PM_TY_VS_LLY
                              ).toFixed(2)}%`)}
                      </span>
                    )}
                  </td>
                  <td>
                    {customerMarketingActiveExisting !== undefined &&
                      customerMarketingActiveExisting.length !== 0 &&
                      (customerMarketingActiveExisting[0].AOV_TY === "-999999"
                        ? "-"
                        : "$" +
                          Number(
                            customerMarketingActiveExisting[0].AOV_TY
                          ).toFixed(2))}
                    <br />
                    {customerMarketingActiveExisting !== undefined &&
                    customerMarketingActiveExisting.length !== 0 &&
                    Number(customerMarketingActiveExisting[0].AOV_TY_VS_LY)
                      .toFixed(2)
                      .includes("-") ? (
                      <span style={{ color: "red", fontSize: "12px" }}>
                        {customerMarketingActiveExisting !== undefined &&
                          customerMarketingActiveExisting.length !== 0 &&
                          (customerMarketingActiveExisting[0].AOV_TY_VS_LY ===
                          "-999999"
                            ? "-"
                            : `LY ${Number(
                                customerMarketingActiveExisting[0].AOV_TY_VS_LY
                              ).toFixed(2)}%`)}
                      </span>
                    ) : (
                      <span style={{ color: "green", fontSize: "12px" }}>
                        {customerMarketingActiveExisting !== undefined &&
                          customerMarketingActiveExisting.length !== 0 &&
                          (customerMarketingActiveExisting[0].AOV_TY_VS_LY ===
                          "-999999"
                            ? "-"
                            : `LY +${Number(
                                customerMarketingActiveExisting[0].AOV_TY_VS_LY
                              ).toFixed(2)}%`)}
                      </span>
                    )}
                    <br />
                    {customerMarketingActiveExisting !== undefined &&
                    customerMarketingActiveExisting.length !== 0 &&
                    Number(customerMarketingActiveExisting[0].AOV_TY_VS_LLY)
                      .toFixed(2)
                      .includes("-") ? (
                      <span style={{ color: "red", fontSize: "11px" }}>
                        {customerMarketingActiveExisting !== undefined &&
                          customerMarketingActiveExisting.length !== 0 &&
                          (customerMarketingActiveExisting[0].AOV_TY_VS_LLY ===
                          "-999999"
                            ? "-"
                            : `LLY ${Number(
                                customerMarketingActiveExisting[0].AOV_TY_VS_LLY
                              ).toFixed(2)}%`)}
                      </span>
                    ) : (
                      <span style={{ color: "green", fontSize: "11px" }}>
                        {customerMarketingActiveExisting !== undefined &&
                          customerMarketingActiveExisting.length !== 0 &&
                          (customerMarketingActiveExisting[0].AOV_TY_VS_LLY ===
                          "-999999"
                            ? "-"
                            : `LLY +${Number(
                                customerMarketingActiveExisting[0].AOV_TY_VS_LLY
                              ).toFixed(2)}%`)}
                      </span>
                    )}
                  </td>
                  <td>
                    {customerMarketingActiveExisting !== undefined &&
                      customerMarketingActiveExisting.length !== 0 &&
                      (customerMarketingActiveExisting[0].UPT_TY === "-999999"
                        ? "-"
                        : Number(
                            customerMarketingActiveExisting[0].UPT_TY
                          ).toFixed(1))}
                    <br />
                    {customerMarketingActiveExisting !== undefined &&
                    customerMarketingActiveExisting.length !== 0 &&
                    Number(customerMarketingActiveExisting[0].UPT_TY_VS_LY)
                      .toFixed(2)
                      .includes("-") ? (
                      <span style={{ color: "red", fontSize: "12px" }}>
                        {customerMarketingActiveExisting !== undefined &&
                          customerMarketingActiveExisting.length !== 0 &&
                          (customerMarketingActiveExisting[0].UPT_TY_VS_LY ===
                          "-999999"
                            ? "-"
                            : `LY ${Number(
                                customerMarketingActiveExisting[0].UPT_TY_VS_LY
                              ).toFixed(2)}%`)}
                      </span>
                    ) : (
                      <span style={{ color: "green", fontSize: "12px" }}>
                        {customerMarketingActiveExisting !== undefined &&
                          customerMarketingActiveExisting.length !== 0 &&
                          (customerMarketingActiveExisting[0].UPT_TY_VS_LY ===
                          "-999999"
                            ? "-"
                            : `LY +${Number(
                                customerMarketingActiveExisting[0].UPT_TY_VS_LY
                              ).toFixed(2)}%`)}
                      </span>
                    )}
                    <br />
                    {customerMarketingActiveExisting !== undefined &&
                    customerMarketingActiveExisting.length !== 0 &&
                    Number(customerMarketingActiveExisting[0].UPT_TY_VS_LLY)
                      .toFixed(2)
                      .includes("-") ? (
                      <span style={{ color: "red", fontSize: "11px" }}>
                        {customerMarketingActiveExisting !== undefined &&
                          customerMarketingActiveExisting.length !== 0 &&
                          (customerMarketingActiveExisting[0].UPT_TY_VS_LLY ===
                          "-999999"
                            ? "-"
                            : `LLY ${Number(
                                customerMarketingActiveExisting[0].UPT_TY_VS_LLY
                              ).toFixed(2)}%`)}
                      </span>
                    ) : (
                      <span style={{ color: "green", fontSize: "11px" }}>
                        {customerMarketingActiveExisting !== undefined &&
                          customerMarketingActiveExisting.length !== 0 &&
                          (customerMarketingActiveExisting[0].UPT_TY_VS_LLY ===
                          "-999999"
                            ? "-"
                            : `LLY +${Number(
                                customerMarketingActiveExisting[0].UPT_TY_VS_LLY
                              ).toFixed(2)}%`)}
                      </span>
                    )}
                  </td>
                  <td>
                    {customerMarketingActiveExisting !== undefined &&
                      customerMarketingActiveExisting.length !== 0 &&
                      (customerMarketingActiveExisting[0].AUR_TY === "-999999"
                        ? "-"
                        : "$" +
                          Number(
                            customerMarketingActiveExisting[0].AUR_TY
                          ).toFixed(2))}
                    <br />
                    {customerMarketingActiveExisting !== undefined &&
                    customerMarketingActiveExisting.length !== 0 &&
                    Number(customerMarketingActiveExisting[0].AUR_TY_VS_LY)
                      .toFixed(2)
                      .includes("-") ? (
                      <span style={{ color: "red", fontSize: "12px" }}>
                        {customerMarketingActiveExisting !== undefined &&
                          customerMarketingActiveExisting.length !== 0 &&
                          (customerMarketingActiveExisting[0].AUR_TY_VS_LY ===
                          "-999999"
                            ? "-"
                            : `LY ${Number(
                                customerMarketingActiveExisting[0].AUR_TY_VS_LY
                              ).toFixed(2)}%`)}
                      </span>
                    ) : (
                      <span style={{ color: "green", fontSize: "12px" }}>
                        {customerMarketingActiveExisting !== undefined &&
                          customerMarketingActiveExisting.length !== 0 &&
                          (customerMarketingActiveExisting[0].AUR_TY_VS_LY ===
                          "-999999"
                            ? "-"
                            : `LY +${Number(
                                customerMarketingActiveExisting[0].AUR_TY_VS_LY
                              ).toFixed(2)}%`)}
                      </span>
                    )}
                    <br />
                    {customerMarketingActiveExisting !== undefined &&
                    customerMarketingActiveExisting.length !== 0 &&
                    Number(customerMarketingActiveExisting[0].AUR_TY_VS_LLY)
                      .toFixed(2)
                      .includes("-") ? (
                      <span style={{ color: "red", fontSize: "11px" }}>
                        {customerMarketingActiveExisting !== undefined &&
                          customerMarketingActiveExisting.length !== 0 &&
                          (customerMarketingActiveExisting[0].AUR_TY_VS_LLY ===
                          "-999999"
                            ? "-"
                            : `LLY ${Number(
                                customerMarketingActiveExisting[0].AUR_TY_VS_LLY
                              ).toFixed(2)}%`)}
                      </span>
                    ) : (
                      <span style={{ color: "green", fontSize: "11px" }}>
                        {customerMarketingActiveExisting !== undefined &&
                          customerMarketingActiveExisting.length !== 0 &&
                          (customerMarketingActiveExisting[0].AUR_TY_VS_LLY ===
                          "-999999"
                            ? "-"
                            : `LLY +${Number(
                                customerMarketingActiveExisting[0].AUR_TY_VS_LLY
                              ).toFixed(2)}%`)}
                      </span>
                    )}
                  </td>
                  <td>
                    {customerMarketingActiveExisting !== undefined &&
                      customerMarketingActiveExisting.length !== 0 &&
                      (customerMarketingActiveExisting[0].MARGIN_RATE_PER_TY ===
                      "-999999"
                        ? "-"
                        : Number(
                            customerMarketingActiveExisting[0]
                              .MARGIN_RATE_PER_TY
                          ).toFixed(2))}
                    <br />
                    {customerMarketingActiveExisting !== undefined &&
                    customerMarketingActiveExisting.length !== 0 &&
                    Number(
                      customerMarketingActiveExisting[0]
                        .MARGIN_RATE_PER_TY_VS_LY
                    )
                      .toFixed(2)
                      .includes("-") ? (
                      <span style={{ color: "red", fontSize: "12px" }}>
                        {customerMarketingActiveExisting !== undefined &&
                          customerMarketingActiveExisting.length !== 0 &&
                          (customerMarketingActiveExisting[0]
                            .MARGIN_RATE_PER_TY_VS_LY === "-999999"
                            ? "-"
                            : `LY ${Number(
                                customerMarketingActiveExisting[0]
                                  .MARGIN_RATE_PER_TY_VS_LY
                              ).toFixed(2)}%`)}
                      </span>
                    ) : (
                      <span style={{ color: "green", fontSize: "12px" }}>
                        {customerMarketingActiveExisting !== undefined &&
                          customerMarketingActiveExisting.length !== 0 &&
                          (customerMarketingActiveExisting[0]
                            .MARGIN_RATE_PER_TY_VS_LY === "-999999"
                            ? "-"
                            : `LY +${Number(
                                customerMarketingActiveExisting[0]
                                  .MARGIN_RATE_PER_TY_VS_LY
                              ).toFixed(2)}%`)}
                      </span>
                    )}
                    <br />
                    {customerMarketingActiveExisting !== undefined &&
                    customerMarketingActiveExisting.length !== 0 &&
                    Number(
                      customerMarketingActiveExisting[0]
                        .MARGIN_RATE_PER_TY_VS_LLY
                    )
                      .toFixed(2)
                      .includes("-") ? (
                      <span style={{ color: "red", fontSize: "11px" }}>
                        {customerMarketingActiveExisting !== undefined &&
                          customerMarketingActiveExisting.length !== 0 &&
                          (customerMarketingActiveExisting[0]
                            .MARGIN_RATE_PER_TY_VS_LLY === "-999999"
                            ? "-"
                            : `LLY ${Number(
                                customerMarketingActiveExisting[0]
                                  .MARGIN_RATE_PER_TY_VS_LLY
                              ).toFixed(2)}%`)}
                      </span>
                    ) : (
                      <span style={{ color: "green", fontSize: "11px" }}>
                        {customerMarketingActiveExisting !== undefined &&
                          customerMarketingActiveExisting.length !== 0 &&
                          (customerMarketingActiveExisting[0]
                            .MARGIN_RATE_PER_TY_VS_LLY === "-999999"
                            ? "-"
                            : `LLY +${Number(
                                customerMarketingActiveExisting[0]
                                  .MARGIN_RATE_PER_TY_VS_LLY
                              ).toFixed(2)}%`)}
                      </span>
                    )}
                  </td>
                  <td>
                    {customerMarketingActiveExisting !== undefined &&
                      customerMarketingActiveExisting.length !== 0 &&
                      (customerMarketingActiveExisting[0]
                        .NET_SALES_PER_CUST_TY === "-999999"
                        ? "-"
                        : "$" +
                          Number(
                            customerMarketingActiveExisting[0]
                              .NET_SALES_PER_CUST_TY
                          ).toFixed(2))}
                    <br />
                    {customerMarketingActiveExisting !== undefined &&
                    customerMarketingActiveExisting.length !== 0 &&
                    Number(
                      customerMarketingActiveExisting[0]
                        .NET_SALES_PER_CUST_TY_VS_LY
                    )
                      .toFixed(2)
                      .includes("-") ? (
                      <span style={{ color: "red", fontSize: "12px" }}>
                        {customerMarketingActiveExisting !== undefined &&
                          customerMarketingActiveExisting.length !== 0 &&
                          (customerMarketingActiveExisting[0]
                            .NET_SALES_PER_CUST_TY_VS_LY === "-999999"
                            ? "-"
                            : `LY ${Number(
                                customerMarketingActiveExisting[0]
                                  .NET_SALES_PER_CUST_TY_VS_LY
                              ).toFixed(2)}%`)}
                      </span>
                    ) : (
                      <span style={{ color: "green", fontSize: "12px" }}>
                        {customerMarketingActiveExisting !== undefined &&
                          customerMarketingActiveExisting.length !== 0 &&
                          (customerMarketingActiveExisting[0]
                            .NET_SALES_PER_CUST_TY_VS_LY === "-999999"
                            ? "-"
                            : `LY +${Number(
                                customerMarketingActiveExisting[0]
                                  .NET_SALES_PER_CUST_TY_VS_LY
                              ).toFixed(2)}%`)}
                      </span>
                    )}
                    <br />
                    {customerMarketingActiveExisting !== undefined &&
                    customerMarketingActiveExisting.length !== 0 &&
                    Number(
                      customerMarketingActiveExisting[0]
                        .NET_SALES_PER_CUST_TY_VS_LLY
                    )
                      .toFixed(2)
                      .includes("-") ? (
                      <span style={{ color: "red", fontSize: "11px" }}>
                        {customerMarketingActiveExisting !== undefined &&
                          customerMarketingActiveExisting.length !== 0 &&
                          (customerMarketingActiveExisting[0]
                            .NET_SALES_PER_CUST_TY_VS_LLY === "-999999"
                            ? "-"
                            : `LLY ${Number(
                                customerMarketingActiveExisting[0]
                                  .NET_SALES_PER_CUST_TY_VS_LLY
                              ).toFixed(2)}%`)}
                      </span>
                    ) : (
                      <span style={{ color: "green", fontSize: "11px" }}>
                        {customerMarketingActiveExisting !== undefined &&
                          customerMarketingActiveExisting.length !== 0 &&
                          (customerMarketingActiveExisting[0]
                            .NET_SALES_PER_CUST_TY_VS_LLY === "-999999"
                            ? "-"
                            : `LLY +${Number(
                                customerMarketingActiveExisting[0]
                                  .NET_SALES_PER_CUST_TY_VS_LLY
                              ).toFixed(2)}%`)}
                      </span>
                    )}
                  </td>
                  <td>
                    {customerMarketingActiveExisting !== undefined &&
                      customerMarketingActiveExisting.length !== 0 &&
                      (customerMarketingActiveExisting[0].AVG_TRAN_TY ===
                      "-999999"
                        ? "-"
                        : Number(
                            customerMarketingActiveExisting[0].AVG_TRAN_TY
                          ).toFixed(2))}
                    <br />
                    {customerMarketingActiveExisting !== undefined &&
                    customerMarketingActiveExisting.length !== 0 &&
                    Number(customerMarketingActiveExisting[0].AVG_TRAN_TY_VS_LY)
                      .toFixed(2)
                      .includes("-") ? (
                      <span style={{ color: "red", fontSize: "12px" }}>
                        {customerMarketingActiveExisting !== undefined &&
                          customerMarketingActiveExisting.length !== 0 &&
                          (customerMarketingActiveExisting[0]
                            .AVG_TRAN_TY_VS_LY === "-999999"
                            ? "-"
                            : `LY ${Number(
                                customerMarketingActiveExisting[0]
                                  .AVG_TRAN_TY_VS_LY
                              ).toFixed(2)}%`)}
                      </span>
                    ) : (
                      <span style={{ color: "green", fontSize: "12px" }}>
                        {customerMarketingActiveExisting !== undefined &&
                          customerMarketingActiveExisting.length !== 0 &&
                          (customerMarketingActiveExisting[0]
                            .AVG_TRAN_TY_VS_LY === "-999999"
                            ? "-"
                            : `LY +${Number(
                                customerMarketingActiveExisting[0]
                                  .AVG_TRAN_TY_VS_LY
                              ).toFixed(2)}%`)}
                      </span>
                    )}
                    <br />
                    {customerMarketingActiveExisting !== undefined &&
                    customerMarketingActiveExisting.length !== 0 &&
                    Number(
                      customerMarketingActiveExisting[0].AVG_TRAN_TY_VS_LLY
                    )
                      .toFixed(2)
                      .includes("-") ? (
                      <span style={{ color: "red", fontSize: "11px" }}>
                        {customerMarketingActiveExisting !== undefined &&
                          customerMarketingActiveExisting.length !== 0 &&
                          (customerMarketingActiveExisting[0]
                            .AVG_TRAN_TY_VS_LLY === "-999999"
                            ? "-"
                            : `LLY ${Number(
                                customerMarketingActiveExisting[0]
                                  .AVG_TRAN_TY_VS_LLY
                              ).toFixed(2)}%`)}
                      </span>
                    ) : (
                      <span style={{ color: "green", fontSize: "11px" }}>
                        {customerMarketingActiveExisting !== undefined &&
                          customerMarketingActiveExisting.length !== 0 &&
                          (customerMarketingActiveExisting[0]
                            .AVG_TRAN_TY_VS_LLY === "-999999"
                            ? "-"
                            : `LLY +${Number(
                                customerMarketingActiveExisting[0]
                                  .AVG_TRAN_TY_VS_LLY
                              ).toFixed(2)}%`)}
                      </span>
                    )}
                  </td>
                </>
              )}
            </tr>
            <tr>
              <td
                className="tableCol"
                id={
                  selectedMarketingCategoryId !== "NR"
                    ? "New_Customer"
                    : "NewCustomer"
                }
                onClick={() =>
                  selectedMarketingCategoryId !== "NR"
                    ? handleModalOpen("New Customers")
                    : ""
                }
              >
                {"New Customers"}{" "}
                {gettooltip(
                  "NewCustomersInfoIcon",
                  "NewCustomers",
                  "NewCustomers",
                  "Active in L12M but not active in L12M to L24M"
                )}
              </td>
              {loading.Active_L12m ? (
                <>
                  <LoaderForRow tdCount={10} />
                </>
              ) : (
                <>
                  <td>
                    {customerMarketingActiveData !== undefined &&
                      customerMarketingActiveData.length !== 0 &&
                      (customerMarketingActiveData[0].CUST_COUNT_TY ===
                      "-999999"
                        ? "-"
                        : currencyFormat(
                            Number(customerMarketingActiveData[0].CUST_COUNT_TY)
                          ))}
                    <br />
                    {customerMarketingActiveData !== undefined &&
                    customerMarketingActiveData.length !== 0 &&
                    Number(customerMarketingActiveData[0].CUST_TY_VS_LY)
                      .toFixed(2)
                      .includes("-") ? (
                      <span style={{ color: "red", fontSize: "12px" }}>
                        {customerMarketingActiveData !== undefined &&
                          customerMarketingActiveData.length !== 0 &&
                          (customerMarketingActiveData[0].CUST_TY_VS_LY ===
                          "-999999"
                            ? "-"
                            : `LY ${Number(
                                customerMarketingActiveData[0].CUST_TY_VS_LY
                              ).toFixed(2)}%`)}
                      </span>
                    ) : (
                      <span style={{ color: "green", fontSize: "12px" }}>
                        {customerMarketingActiveData !== undefined &&
                          customerMarketingActiveData.length !== 0 &&
                          (customerMarketingActiveData[0].CUST_TY_VS_LY ===
                          "-999999"
                            ? "-"
                            : `LY +${Number(
                                customerMarketingActiveData[0].CUST_TY_VS_LY
                              ).toFixed(2)}%`)}
                      </span>
                    )}
                    <br />
                    {customerMarketingActiveData !== undefined &&
                    customerMarketingActiveData.length !== 0 &&
                    Number(customerMarketingActiveData[0].CUST_TY_VS_LLY)
                      .toFixed(2)
                      .includes("-") ? (
                      <span style={{ color: "red", fontSize: "11px" }}>
                        {customerMarketingActiveData !== undefined &&
                          customerMarketingActiveData.length !== 0 &&
                          (customerMarketingActiveData[0].CUST_TY_VS_LLY ===
                          "-999999"
                            ? "-"
                            : `LLY ${Number(
                                customerMarketingActiveData[0].CUST_TY_VS_LLY
                              ).toFixed(2)}%`)}
                      </span>
                    ) : (
                      <span style={{ color: "green", fontSize: "11px" }}>
                        {customerMarketingActiveData !== undefined &&
                          customerMarketingActiveData.length !== 0 &&
                          (customerMarketingActiveData[0].CUST_TY_VS_LLY ===
                          "-999999"
                            ? "-"
                            : `LLY +${Number(
                                customerMarketingActiveData[0].CUST_TY_VS_LLY
                              ).toFixed(2)}%`)}
                      </span>
                    )}
                  </td>
                  <td>
                    {customerMarketingActiveData !== undefined &&
                      customerMarketingActiveData.length !== 0 &&
                      (customerMarketingActiveData[0].NET_SALES_TY === "-999999"
                        ? "-"
                        : "$" +
                          currencyFormat(
                            Number(customerMarketingActiveData[0].NET_SALES_TY)
                          ))}
                    <br />
                    {customerMarketingActiveData !== undefined &&
                    customerMarketingActiveData.length !== 0 &&
                    Number(customerMarketingActiveData[0].NET_SALES_TY_VS_LY)
                      .toFixed(2)
                      .includes("-") ? (
                      <span style={{ color: "red", fontSize: "12px" }}>
                        {customerMarketingActiveData !== undefined &&
                          customerMarketingActiveData.length !== 0 &&
                          (customerMarketingActiveData[0].NET_SALES_TY_VS_LY ===
                          "-999999"
                            ? "-"
                            : `LY ${Number(
                                customerMarketingActiveData[0]
                                  .NET_SALES_TY_VS_LY
                              ).toFixed(2)}%`)}
                      </span>
                    ) : (
                      <span style={{ color: "green", fontSize: "12px" }}>
                        {customerMarketingActiveData !== undefined &&
                          customerMarketingActiveData.length !== 0 &&
                          (customerMarketingActiveData[0].NET_SALES_TY_VS_LY ===
                          "-999999"
                            ? "-"
                            : `LY +${Number(
                                customerMarketingActiveData[0]
                                  .NET_SALES_TY_VS_LY
                              ).toFixed(2)}%`)}
                      </span>
                    )}
                    <br />
                    {customerMarketingActiveData !== undefined &&
                    customerMarketingActiveData.length !== 0 &&
                    Number(customerMarketingActiveData[0].NET_SALES_TY_VS_LLY)
                      .toFixed(2)
                      .includes("-") ? (
                      <span style={{ color: "red", fontSize: "11px" }}>
                        {customerMarketingActiveData !== undefined &&
                          customerMarketingActiveData.length !== 0 &&
                          (customerMarketingActiveData[0]
                            .NET_SALES_TY_VS_LLY === "-999999"
                            ? "-"
                            : `LLY ${Number(
                                customerMarketingActiveData[0]
                                  .NET_SALES_TY_VS_LLY
                              ).toFixed(2)}%`)}
                      </span>
                    ) : (
                      <span style={{ color: "green", fontSize: "11px" }}>
                        {customerMarketingActiveData !== undefined &&
                          customerMarketingActiveData.length !== 0 &&
                          (customerMarketingActiveData[0]
                            .NET_SALES_TY_VS_LLY === "-999999"
                            ? "-"
                            : `LLY +${Number(
                                customerMarketingActiveData[0]
                                  .NET_SALES_TY_VS_LLY
                              ).toFixed(2)}%`)}
                      </span>
                    )}
                  </td>
                  <td>
                    {customerMarketingActiveData !== undefined &&
                      customerMarketingActiveData.length !== 0 &&
                      (customerMarketingActiveData[0].TRANS_COUNT_TY ===
                      "-999999"
                        ? "-"
                        : currencyFormat(
                            Number(
                              customerMarketingActiveData[0].TRANS_COUNT_TY
                            )
                          ))}
                    <br />
                    {customerMarketingActiveData !== undefined &&
                    customerMarketingActiveData.length !== 0 &&
                    Number(customerMarketingActiveData[0].TRANS_TY_VS_LY)
                      .toFixed(2)
                      .includes("-") ? (
                      <span style={{ color: "red", fontSize: "12px" }}>
                        {customerMarketingActiveData !== undefined &&
                          customerMarketingActiveData.length !== 0 &&
                          (customerMarketingActiveData[0].TRANS_TY_VS_LY ===
                          "-999999"
                            ? "-"
                            : `LY ${Number(
                                customerMarketingActiveData[0].TRANS_TY_VS_LY
                              ).toFixed(2)}%`)}
                      </span>
                    ) : (
                      <span style={{ color: "green", fontSize: "12px" }}>
                        {customerMarketingActiveData !== undefined &&
                          customerMarketingActiveData.length !== 0 &&
                          (customerMarketingActiveData[0].TRANS_TY_VS_LY ===
                          "-999999"
                            ? "-"
                            : `LY +${Number(
                                customerMarketingActiveData[0].TRANS_TY_VS_LY
                              ).toFixed(2)}%`)}
                      </span>
                    )}
                    <br />
                    {customerMarketingActiveData !== undefined &&
                    customerMarketingActiveData.length !== 0 &&
                    Number(customerMarketingActiveData[0].TRANS_TY_VS_LLY)
                      .toFixed(2)
                      .includes("-") ? (
                      <span style={{ color: "red", fontSize: "11px" }}>
                        {customerMarketingActiveData !== undefined &&
                          customerMarketingActiveData.length !== 0 &&
                          (customerMarketingActiveData[0].TRANS_TY_VS_LLY ===
                          "-999999"
                            ? "-"
                            : `LLY ${Number(
                                customerMarketingActiveData[0].TRANS_TY_VS_LLY
                              ).toFixed(2)}`)}
                      </span>
                    ) : (
                      <span style={{ color: "green", fontSize: "11px" }}>
                        {customerMarketingActiveData !== undefined &&
                          customerMarketingActiveData.length !== 0 &&
                          (customerMarketingActiveData[0].TRANS_TY_VS_LLY ===
                          "-999999"
                            ? "-"
                            : `LLY +${Number(
                                customerMarketingActiveData[0].TRANS_TY_VS_LLY
                              ).toFixed(2)}`)}
                      </span>
                    )}
                  </td>
                  <td>
                    {customerMarketingActiveData !== undefined &&
                      customerMarketingActiveData.length !== 0 &&
                      (customerMarketingActiveData[0].PM_TY === "-999999"
                        ? "-"
                        : "$" +
                          currencyFormat(
                            Number(customerMarketingActiveData[0].PM_TY)
                          ))}
                    <br />
                    {customerMarketingActiveData !== undefined &&
                    customerMarketingActiveData.length !== 0 &&
                    Number(customerMarketingActiveData[0].PM_TY_VS_LY)
                      .toFixed(2)
                      .includes("-") ? (
                      <span style={{ color: "red", fontSize: "12px" }}>
                        {customerMarketingActiveData !== undefined &&
                          customerMarketingActiveData.length !== 0 &&
                          (customerMarketingActiveData[0].PM_TY_VS_LY ===
                          "-999999"
                            ? "-"
                            : `LY ${Number(
                                customerMarketingActiveData[0].PM_TY_VS_LY
                              ).toFixed(2)}%`)}
                      </span>
                    ) : (
                      <span style={{ color: "green", fontSize: "12px" }}>
                        {customerMarketingActiveData !== undefined &&
                          customerMarketingActiveData.length !== 0 &&
                          (customerMarketingActiveData[0].PM_TY_VS_LY ===
                          "-999999"
                            ? "-"
                            : `LY +${Number(
                                customerMarketingActiveData[0].PM_TY_VS_LY
                              ).toFixed(2)}%`)}
                      </span>
                    )}
                    <br />
                    {customerMarketingActiveData !== undefined &&
                    customerMarketingActiveData.length !== 0 &&
                    Number(customerMarketingActiveData[0].PM_TY_VS_LLY)
                      .toFixed(2)
                      .includes("-") ? (
                      <span style={{ color: "red", fontSize: "11px" }}>
                        {customerMarketingActiveData !== undefined &&
                          customerMarketingActiveData.length !== 0 &&
                          (customerMarketingActiveData[0].PM_TY_VS_LLY ===
                          "-999999"
                            ? "-"
                            : `LLY ${Number(
                                customerMarketingActiveData[0].PM_TY_VS_LLY
                              ).toFixed(2)}%`)}
                      </span>
                    ) : (
                      <span style={{ color: "green", fontSize: "11px" }}>
                        {customerMarketingActiveData !== undefined &&
                          customerMarketingActiveData.length !== 0 &&
                          (customerMarketingActiveData[0].PM_TY_VS_LLY ===
                          "-999999"
                            ? "-"
                            : `LLY +${Number(
                                customerMarketingActiveData[0].PM_TY_VS_LLY
                              ).toFixed(2)}%`)}
                      </span>
                    )}
                  </td>
                  <td>
                    {customerMarketingActiveData !== undefined &&
                      customerMarketingActiveData.length !== 0 &&
                      (customerMarketingActiveData[0].AOV_TY === "-999999"
                        ? "-"
                        : "$" +
                          Number(customerMarketingActiveData[0].AOV_TY).toFixed(
                            2
                          ))}
                    <br />
                    {customerMarketingActiveData !== undefined &&
                    customerMarketingActiveData.length !== 0 &&
                    Number(customerMarketingActiveData[0].AOV_TY_VS_LY)
                      .toFixed(2)
                      .includes("-") ? (
                      <span style={{ color: "red", fontSize: "12px" }}>
                        {customerMarketingActiveData !== undefined &&
                          customerMarketingActiveData.length !== 0 &&
                          (customerMarketingActiveData[0].AOV_TY_VS_LY ===
                          "-999999"
                            ? "-"
                            : `LY ${Number(
                                customerMarketingActiveData[0].AOV_TY_VS_LY
                              ).toFixed(2)}%`)}
                      </span>
                    ) : (
                      <span style={{ color: "green", fontSize: "12px" }}>
                        {customerMarketingActiveData !== undefined &&
                          customerMarketingActiveData.length !== 0 &&
                          (customerMarketingActiveData[0].AOV_TY_VS_LY ===
                          "-999999"
                            ? "-"
                            : `LY +${Number(
                                customerMarketingActiveData[0].AOV_TY_VS_LY
                              ).toFixed(2)}%`)}
                      </span>
                    )}
                    <br />
                    {customerMarketingActiveData !== undefined &&
                    customerMarketingActiveData.length !== 0 &&
                    Number(customerMarketingActiveData[0].AOV_TY_VS_LLY)
                      .toFixed(2)
                      .includes("-") ? (
                      <span style={{ color: "red", fontSize: "11px" }}>
                        {customerMarketingActiveData !== undefined &&
                          customerMarketingActiveData.length !== 0 &&
                          (customerMarketingActiveData[0].AOV_TY_VS_LLY ===
                          "-999999"
                            ? "-"
                            : `LLY ${Number(
                                customerMarketingActiveData[0].AOV_TY_VS_LLY
                              ).toFixed(2)}%`)}
                      </span>
                    ) : (
                      <span style={{ color: "green", fontSize: "11px" }}>
                        {customerMarketingActiveData !== undefined &&
                          customerMarketingActiveData.length !== 0 &&
                          (customerMarketingActiveData[0].AOV_TY_VS_LLY ===
                          "-999999"
                            ? "-"
                            : `LLY +${Number(
                                customerMarketingActiveData[0].AOV_TY_VS_LLY
                              ).toFixed(2)}%`)}
                      </span>
                    )}
                  </td>
                  <td>
                    {customerMarketingActiveData !== undefined &&
                      customerMarketingActiveData.length !== 0 &&
                      (customerMarketingActiveData[0].UPT_TY === "-999999"
                        ? "-"
                        : Number(customerMarketingActiveData[0].UPT_TY).toFixed(
                            1
                          ))}
                    <br />
                    {customerMarketingActiveData !== undefined &&
                    customerMarketingActiveData.length !== 0 &&
                    Number(customerMarketingActiveData[0].UPT_TY_VS_LY)
                      .toFixed(2)
                      .includes("-") ? (
                      <span style={{ color: "red", fontSize: "12px" }}>
                        {customerMarketingActiveData !== undefined &&
                          customerMarketingActiveData.length !== 0 &&
                          (customerMarketingActiveData[0].UPT_TY_VS_LY ===
                          "-999999"
                            ? "-"
                            : `LY ${Number(
                                customerMarketingActiveData[0].UPT_TY_VS_LY
                              ).toFixed(2)}%`)}
                      </span>
                    ) : (
                      <span style={{ color: "green", fontSize: "12px" }}>
                        {customerMarketingActiveData !== undefined &&
                          customerMarketingActiveData.length !== 0 &&
                          (customerMarketingActiveData[0].UPT_TY_VS_LY ===
                          "-999999"
                            ? "-"
                            : `LY +${Number(
                                customerMarketingActiveData[0].UPT_TY_VS_LY
                              ).toFixed(2)}%`)}
                      </span>
                    )}
                    <br />
                    {customerMarketingActiveData !== undefined &&
                    customerMarketingActiveData.length !== 0 &&
                    Number(customerMarketingActiveData[0].UPT_TY_VS_LLY)
                      .toFixed(2)
                      .includes("-") ? (
                      <span style={{ color: "red", fontSize: "11px" }}>
                        {customerMarketingActiveData !== undefined &&
                          customerMarketingActiveData.length !== 0 &&
                          (customerMarketingActiveData[0].UPT_TY_VS_LLY ===
                          "-999999"
                            ? "-"
                            : `LLY ${Number(
                                customerMarketingActiveData[0].UPT_TY_VS_LLY
                              ).toFixed(2)}%`)}
                      </span>
                    ) : (
                      <span style={{ color: "green", fontSize: "11px" }}>
                        {customerMarketingActiveData !== undefined &&
                          customerMarketingActiveData.length !== 0 &&
                          (customerMarketingActiveData[0].UPT_TY_VS_LLY ===
                          "-999999"
                            ? "-"
                            : `LLY +${Number(
                                customerMarketingActiveData[0].UPT_TY_VS_LLY
                              ).toFixed(2)}%`)}
                      </span>
                    )}
                  </td>
                  <td>
                    {customerMarketingActiveData !== undefined &&
                      customerMarketingActiveData.length !== 0 &&
                      (customerMarketingActiveData[0].AUR_TY === "-999999"
                        ? "-"
                        : "$" +
                          Number(customerMarketingActiveData[0].AUR_TY).toFixed(
                            2
                          ))}
                    <br />
                    {customerMarketingActiveData !== undefined &&
                    customerMarketingActiveData.length !== 0 &&
                    Number(customerMarketingActiveData[0].AUR_TY_VS_LY)
                      .toFixed(2)
                      .includes("-") ? (
                      <span style={{ color: "red", fontSize: "12px" }}>
                        {customerMarketingActiveData !== undefined &&
                          customerMarketingActiveData.length !== 0 &&
                          (customerMarketingActiveData[0].AUR_TY_VS_LY ===
                          "-999999"
                            ? "-"
                            : `LY ${Number(
                                customerMarketingActiveData[0].AUR_TY_VS_LY
                              ).toFixed(2)}%`)}
                      </span>
                    ) : (
                      <span style={{ color: "green", fontSize: "12px" }}>
                        {customerMarketingActiveData !== undefined &&
                          customerMarketingActiveData.length !== 0 &&
                          (customerMarketingActiveData[0].AUR_TY_VS_LY ===
                          "-999999"
                            ? "-"
                            : `LY +${Number(
                                customerMarketingActiveData[0].AUR_TY_VS_LY
                              ).toFixed(2)}%`)}
                      </span>
                    )}
                    <br />
                    {customerMarketingActiveData !== undefined &&
                    customerMarketingActiveData.length !== 0 &&
                    Number(customerMarketingActiveData[0].AUR_TY_VS_LLY)
                      .toFixed(2)
                      .includes("-") ? (
                      <span style={{ color: "red", fontSize: "11px" }}>
                        {customerMarketingActiveData !== undefined &&
                          customerMarketingActiveData.length !== 0 &&
                          (customerMarketingActiveData[0].AUR_TY_VS_LLY ===
                          "-999999"
                            ? "-"
                            : `LLY ${Number(
                                customerMarketingActiveData[0].AUR_TY_VS_LLY
                              ).toFixed(2)}%`)}
                      </span>
                    ) : (
                      <span style={{ color: "green", fontSize: "11px" }}>
                        {customerMarketingActiveData !== undefined &&
                          customerMarketingActiveData.length !== 0 &&
                          (customerMarketingActiveData[0].AUR_TY_VS_LLY ===
                          "-999999"
                            ? "-"
                            : `LLY +${Number(
                                customerMarketingActiveData[0].AUR_TY_VS_LLY
                              ).toFixed(2)}%`)}
                      </span>
                    )}
                  </td>
                  <td>
                    {customerMarketingActiveData !== undefined &&
                      customerMarketingActiveData.length !== 0 &&
                      (customerMarketingActiveData[0].MARGIN_RATE_PER_TY ===
                      "-999999"
                        ? "-"
                        : Number(
                            customerMarketingActiveData[0].MARGIN_RATE_PER_TY
                          ).toFixed(2))}
                    <br />
                    {customerMarketingActiveData !== undefined &&
                    customerMarketingActiveData.length !== 0 &&
                    Number(
                      customerMarketingActiveData[0].MARGIN_RATE_PER_TY_VS_LY
                    )
                      .toFixed(2)
                      .includes("-") ? (
                      <span style={{ color: "red", fontSize: "12px" }}>
                        {customerMarketingActiveData !== undefined &&
                          customerMarketingActiveData.length !== 0 &&
                          (customerMarketingActiveData[0]
                            .MARGIN_RATE_PER_TY_VS_LY === "-999999"
                            ? "-"
                            : `LY ${Number(
                                customerMarketingActiveData[0]
                                  .MARGIN_RATE_PER_TY_VS_LY
                              ).toFixed(2)}%`)}
                      </span>
                    ) : (
                      <span style={{ color: "green", fontSize: "12px" }}>
                        {customerMarketingActiveData !== undefined &&
                          customerMarketingActiveData.length !== 0 &&
                          (customerMarketingActiveData[0]
                            .MARGIN_RATE_PER_TY_VS_LY === "-999999"
                            ? "-"
                            : `LY +${Number(
                                customerMarketingActiveData[0]
                                  .MARGIN_RATE_PER_TY_VS_LY
                              ).toFixed(2)}%`)}
                      </span>
                    )}
                    <br />
                    {customerMarketingActiveData !== undefined &&
                    customerMarketingActiveData.length !== 0 &&
                    Number(
                      customerMarketingActiveData[0].MARGIN_RATE_PER_TY_VS_LLY
                    )
                      .toFixed(2)
                      .includes("-") ? (
                      <span style={{ color: "red", fontSize: "11px" }}>
                        {customerMarketingActiveData !== undefined &&
                          customerMarketingActiveData.length !== 0 &&
                          (customerMarketingActiveData[0]
                            .MARGIN_RATE_PER_TY_VS_LLY === "-999999"
                            ? "-"
                            : `LLY ${Number(
                                customerMarketingActiveData[0]
                                  .MARGIN_RATE_PER_TY_VS_LLY
                              ).toFixed(2)}%`)}
                      </span>
                    ) : (
                      <span style={{ color: "green", fontSize: "11px" }}>
                        {customerMarketingActiveData !== undefined &&
                          customerMarketingActiveData.length !== 0 &&
                          (customerMarketingActiveData[0]
                            .MARGIN_RATE_PER_TY_VS_LLY === "-999999"
                            ? "-"
                            : `LLY +${Number(
                                customerMarketingActiveData[0]
                                  .MARGIN_RATE_PER_TY_VS_LLY
                              ).toFixed(2)}%`)}
                      </span>
                    )}
                  </td>
                  <td>
                    {customerMarketingActiveData !== undefined &&
                      customerMarketingActiveData.length !== 0 &&
                      (customerMarketingActiveData[0].NET_SALES_PER_CUST_TY ===
                      "-999999"
                        ? "-"
                        : "$" +
                          Number(
                            customerMarketingActiveData[0].NET_SALES_PER_CUST_TY
                          ).toFixed(2))}
                    <br />
                    {customerMarketingActiveData !== undefined &&
                    customerMarketingActiveData.length !== 0 &&
                    Number(
                      customerMarketingActiveData[0].NET_SALES_PER_CUST_TY_VS_LY
                    )
                      .toFixed(2)
                      .includes("-") ? (
                      <span style={{ color: "red", fontSize: "12px" }}>
                        {customerMarketingActiveData !== undefined &&
                          customerMarketingActiveData.length !== 0 &&
                          (customerMarketingActiveData[0]
                            .NET_SALES_PER_CUST_TY_VS_LY === "-999999"
                            ? "-"
                            : `LY ${Number(
                                customerMarketingActiveData[0]
                                  .NET_SALES_PER_CUST_TY_VS_LY
                              ).toFixed(2)}%`)}
                      </span>
                    ) : (
                      <span style={{ color: "green", fontSize: "12px" }}>
                        {customerMarketingActiveData !== undefined &&
                          customerMarketingActiveData.length !== 0 &&
                          (customerMarketingActiveData[0]
                            .NET_SALES_PER_CUST_TY_VS_LY === "-999999"
                            ? "-"
                            : `LY +${Number(
                                customerMarketingActiveData[0]
                                  .NET_SALES_PER_CUST_TY_VS_LY
                              ).toFixed(2)}%`)}
                      </span>
                    )}
                    <br />
                    {customerMarketingActiveData !== undefined &&
                    customerMarketingActiveData.length !== 0 &&
                    Number(
                      customerMarketingActiveData[0]
                        .NET_SALES_PER_CUST_TY_VS_LLY
                    )
                      .toFixed(2)
                      .includes("-") ? (
                      <span style={{ color: "red", fontSize: "11px" }}>
                        {customerMarketingActiveData !== undefined &&
                          customerMarketingActiveData.length !== 0 &&
                          (customerMarketingActiveData[0]
                            .NET_SALES_PER_CUST_TY_VS_LLY === "-999999"
                            ? "-"
                            : `LLY ${Number(
                                customerMarketingActiveData[0]
                                  .NET_SALES_PER_CUST_TY_VS_LLY
                              ).toFixed(2)}%`)}
                      </span>
                    ) : (
                      <span style={{ color: "green", fontSize: "11px" }}>
                        {customerMarketingActiveData !== undefined &&
                          customerMarketingActiveData.length !== 0 &&
                          (customerMarketingActiveData[0]
                            .NET_SALES_PER_CUST_TY_VS_LLY === "-999999"
                            ? "-"
                            : `LLY +${Number(
                                customerMarketingActiveData[0]
                                  .NET_SALES_PER_CUST_TY_VS_LLY
                              ).toFixed(2)}%`)}
                      </span>
                    )}
                  </td>
                  <td>
                    {customerMarketingActiveData !== undefined &&
                      customerMarketingActiveData.length !== 0 &&
                      (customerMarketingActiveData[0].AVG_TRAN_TY === "-999999"
                        ? "-"
                        : Number(
                            customerMarketingActiveData[0].AVG_TRAN_TY
                          ).toFixed(2))}
                    <br />
                    {customerMarketingActiveData !== undefined &&
                    customerMarketingActiveData.length !== 0 &&
                    Number(customerMarketingActiveData[0].AVG_TRAN_TY_VS_LY)
                      .toFixed(2)
                      .includes("-") ? (
                      <span style={{ color: "red", fontSize: "12px" }}>
                        {customerMarketingActiveData !== undefined &&
                          customerMarketingActiveData.length !== 0 &&
                          (customerMarketingActiveData[0].AVG_TRAN_TY_VS_LY ===
                          "-999999"
                            ? "-"
                            : `LY ${Number(
                                customerMarketingActiveData[0].AVG_TRAN_TY_VS_LY
                              ).toFixed(2)}%`)}
                      </span>
                    ) : (
                      <span style={{ color: "green", fontSize: "12px" }}>
                        {customerMarketingActiveData !== undefined &&
                          customerMarketingActiveData.length !== 0 &&
                          (customerMarketingActiveData[0].AVG_TRAN_TY_VS_LY ===
                          "-999999"
                            ? "-"
                            : `LY +${Number(
                                customerMarketingActiveData[0].AVG_TRAN_TY_VS_LY
                              ).toFixed(2)}%`)}
                      </span>
                    )}
                    <br />
                    {customerMarketingActiveData !== undefined &&
                    customerMarketingActiveData.length !== 0 &&
                    Number(customerMarketingActiveData[0].AVG_TRAN_TY_VS_LLY)
                      .toFixed(2)
                      .includes("-") ? (
                      <span style={{ color: "red", fontSize: "11px" }}>
                        {customerMarketingActiveData !== undefined &&
                          customerMarketingActiveData.length !== 0 &&
                          (customerMarketingActiveData[0].AVG_TRAN_TY_VS_LLY ===
                          "-999999"
                            ? "-"
                            : `LLY ${Number(
                                customerMarketingActiveData[0]
                                  .AVG_TRAN_TY_VS_LLY
                              ).toFixed(2)}%`)}
                      </span>
                    ) : (
                      <span style={{ color: "green", fontSize: "11px" }}>
                        {customerMarketingActiveData !== undefined &&
                          customerMarketingActiveData.length !== 0 &&
                          (customerMarketingActiveData[0].AVG_TRAN_TY_VS_LLY ===
                          "-999999"
                            ? "-"
                            : `LLY +${Number(
                                customerMarketingActiveData[0]
                                  .AVG_TRAN_TY_VS_LLY
                              ).toFixed(2)}%`)}
                      </span>
                    )}
                  </td>
                </>
              )}
            </tr>
            <tr>
              <td
                className="tableCol"
                id={
                  selectedMarketingCategoryId !== "NR"
                    ? "AtRisk_69"
                    : "AtRisk69"
                }
                onClick={() =>
                  selectedMarketingCategoryId !== "NR"
                    ? handleModalOpen("At risk (6m-9m)")
                    : ""
                }
              >
                {"At risk (6m-9m)"}{" "}
                {gettooltip(
                  "AtRisk_6_9InfoIcon",
                  "AtRisk_6_9",
                  "AtRisk_6_9",
                  "Active in L9M but not active in L6M"
                )}
              </td>
              {loading.AtRisk_6m_9m ? (
                <>
                  <LoaderForRow tdCount={10} />
                </>
              ) : (
                <>
                  <td>
                    {customerMarketingDataSixMonths !== undefined &&
                      customerMarketingDataSixMonths.length !== 0 &&
                      (customerMarketingDataSixMonths[0].CUST_COUNT_TY ===
                      "-999999"
                        ? "-"
                        : currencyFormat(
                            Number(
                              customerMarketingDataSixMonths[0].CUST_COUNT_TY
                            )
                          ))}
                    <br />
                    {customerMarketingDataSixMonths !== undefined &&
                    customerMarketingDataSixMonths.length !== 0 &&
                    Number(customerMarketingDataSixMonths[0].CUST_TY_VS_LY)
                      .toFixed(2)
                      .includes("-") ? (
                      <span style={{ color: "green", fontSize: "12px" }}>
                        {customerMarketingDataSixMonths !== undefined &&
                          customerMarketingDataSixMonths.length !== 0 &&
                          (customerMarketingDataSixMonths[0].CUST_TY_VS_LY ===
                          "-999999"
                            ? "-"
                            : `LY ${Number(
                                customerMarketingDataSixMonths[0].CUST_TY_VS_LY
                              ).toFixed(2)}%`)}
                      </span>
                    ) : (
                      <span style={{ color: "red", fontSize: "12px" }}>
                        {customerMarketingDataSixMonths !== undefined &&
                          customerMarketingDataSixMonths.length !== 0 &&
                          (customerMarketingDataSixMonths[0].CUST_TY_VS_LY ===
                          "-999999"
                            ? "-"
                            : `LY +${Number(
                                customerMarketingDataSixMonths[0].CUST_TY_VS_LY
                              ).toFixed(2)}%`)}
                      </span>
                    )}
                    <br />
                    {customerMarketingDataSixMonths !== undefined &&
                    customerMarketingDataSixMonths.length !== 0 &&
                    Number(customerMarketingDataSixMonths[0].CUST_TY_VS_LLY)
                      .toFixed(2)
                      .includes("-") ? (
                      <span style={{ color: "green", fontSize: "11px" }}>
                        {customerMarketingDataSixMonths !== undefined &&
                          customerMarketingDataSixMonths.length !== 0 &&
                          (customerMarketingDataSixMonths[0].CUST_TY_VS_LLY ===
                          "-999999"
                            ? "-"
                            : `LLY ${Number(
                                customerMarketingDataSixMonths[0].CUST_TY_VS_LLY
                              ).toFixed(2)}%`)}
                      </span>
                    ) : (
                      <span style={{ color: "red", fontSize: "11px" }}>
                        {customerMarketingDataSixMonths !== undefined &&
                          customerMarketingDataSixMonths.length !== 0 &&
                          (customerMarketingDataSixMonths[0].CUST_TY_VS_LLY ===
                          "-999999"
                            ? "-"
                            : `LLY +${Number(
                                customerMarketingDataSixMonths[0].CUST_TY_VS_LLY
                              ).toFixed(2)}%`)}
                      </span>
                    )}
                  </td>
                  <td>
                    {customerMarketingDataSixMonths !== undefined &&
                      customerMarketingDataSixMonths.length !== 0 &&
                      (customerMarketingDataSixMonths[0].NET_SALES_TY ===
                      "-999999"
                        ? "-"
                        : "$" +
                          currencyFormat(
                            Number(
                              customerMarketingDataSixMonths[0].NET_SALES_TY
                            )
                          ))}
                    <br />
                    {customerMarketingDataSixMonths !== undefined &&
                    customerMarketingDataSixMonths.length !== 0 &&
                    Number(customerMarketingDataSixMonths[0].NET_SALES_TY_VS_LY)
                      .toFixed(2)
                      .includes("-") ? (
                      <span style={{ color: "green", fontSize: "12px" }}>
                        {customerMarketingDataSixMonths !== undefined &&
                          customerMarketingDataSixMonths.length !== 0 &&
                          (customerMarketingDataSixMonths[0]
                            .NET_SALES_TY_VS_LY === "-999999"
                            ? "-"
                            : `LY ${Number(
                                customerMarketingDataSixMonths[0]
                                  .NET_SALES_TY_VS_LY
                              ).toFixed(2)}%`)}
                      </span>
                    ) : (
                      <span style={{ color: "red", fontSize: "12px" }}>
                        {customerMarketingDataSixMonths !== undefined &&
                          customerMarketingDataSixMonths.length !== 0 &&
                          (customerMarketingDataSixMonths[0]
                            .NET_SALES_TY_VS_LY === "-999999"
                            ? "-"
                            : `LY +${Number(
                                customerMarketingDataSixMonths[0]
                                  .NET_SALES_TY_VS_LY
                              ).toFixed(2)}%`)}
                      </span>
                    )}
                    <br />
                    {customerMarketingDataSixMonths !== undefined &&
                    customerMarketingDataSixMonths.length !== 0 &&
                    Number(
                      customerMarketingDataSixMonths[0].NET_SALES_TY_VS_LLY
                    )
                      .toFixed(2)
                      .includes("-") ? (
                      <span style={{ color: "green", fontSize: "11px" }}>
                        {customerMarketingDataSixMonths !== undefined &&
                          customerMarketingDataSixMonths.length !== 0 &&
                          (customerMarketingDataSixMonths[0]
                            .NET_SALES_TY_VS_LLY === "-999999"
                            ? "-"
                            : `LLY ${Number(
                                customerMarketingDataSixMonths[0]
                                  .NET_SALES_TY_VS_LLY
                              ).toFixed(2)}%`)}
                      </span>
                    ) : (
                      <span style={{ color: "red", fontSize: "11px" }}>
                        {customerMarketingDataSixMonths !== undefined &&
                          customerMarketingDataSixMonths.length !== 0 &&
                          (customerMarketingDataSixMonths[0]
                            .NET_SALES_TY_VS_LLY === "-999999"
                            ? "-"
                            : `LLY +${Number(
                                customerMarketingDataSixMonths[0]
                                  .NET_SALES_TY_VS_LLY
                              ).toFixed(2)}%`)}
                      </span>
                    )}
                  </td>
                  <td>
                    {customerMarketingDataSixMonths !== undefined &&
                      customerMarketingDataSixMonths.length !== 0 &&
                      (customerMarketingDataSixMonths[0].TRANS_COUNT_TY ===
                      "-999999"
                        ? "-"
                        : currencyFormat(
                            Number(
                              customerMarketingDataSixMonths[0].TRANS_COUNT_TY
                            )
                          ))}
                    <br />
                    {customerMarketingDataSixMonths !== undefined &&
                    customerMarketingDataSixMonths.length !== 0 &&
                    Number(customerMarketingDataSixMonths[0].TRANS_TY_VS_LY)
                      .toFixed(2)
                      .includes("-") ? (
                      <span style={{ color: "green", fontSize: "12px" }}>
                        {customerMarketingDataSixMonths !== undefined &&
                          customerMarketingDataSixMonths.length !== 0 &&
                          (customerMarketingDataSixMonths[0].TRANS_TY_VS_LY ===
                          "-999999"
                            ? "-"
                            : `LY ${Number(
                                customerMarketingDataSixMonths[0].TRANS_TY_VS_LY
                              ).toFixed(2)}%`)}
                      </span>
                    ) : (
                      <span style={{ color: "red", fontSize: "12px" }}>
                        {customerMarketingDataSixMonths !== undefined &&
                          customerMarketingDataSixMonths.length !== 0 &&
                          (customerMarketingDataSixMonths[0].TRANS_TY_VS_LY ===
                          "-999999"
                            ? "-"
                            : `LY ${Number(
                                customerMarketingDataSixMonths[0].TRANS_TY_VS_LY
                              ).toFixed(2)}%`)}
                      </span>
                    )}
                    <br />
                    {customerMarketingDataSixMonths !== undefined &&
                    customerMarketingDataSixMonths.length !== 0 &&
                    Number(customerMarketingDataSixMonths[0].TRANS_TY_VS_LLY)
                      .toFixed(2)
                      .includes("-") ? (
                      <span style={{ color: "green", fontSize: "11px" }}>
                        {customerMarketingDataSixMonths !== undefined &&
                          customerMarketingDataSixMonths.length !== 0 &&
                          (customerMarketingDataSixMonths[0].TRANS_TY_VS_LLY ===
                          "-999999"
                            ? "-"
                            : `LLY ${Number(
                                customerMarketingDataSixMonths[0]
                                  .TRANS_TY_VS_LLY
                              ).toFixed(2)}%`)}
                      </span>
                    ) : (
                      <span style={{ color: "red", fontSize: "11px" }}>
                        {customerMarketingDataSixMonths !== undefined &&
                          customerMarketingDataSixMonths.length !== 0 &&
                          (customerMarketingDataSixMonths[0].TRANS_TY_VS_LLY ===
                          "-999999"
                            ? "-"
                            : `LLY +${Number(
                                customerMarketingDataSixMonths[0]
                                  .TRANS_TY_VS_LLY
                              ).toFixed(2)}%`)}
                      </span>
                    )}
                  </td>
                  <td>
                    {customerMarketingDataSixMonths !== undefined &&
                      customerMarketingDataSixMonths.length !== 0 &&
                      (customerMarketingDataSixMonths[0].PM_TY === "-999999"
                        ? "-"
                        : "$" +
                          currencyFormat(
                            Number(customerMarketingDataSixMonths[0].PM_TY)
                          ))}
                    <br />
                    {customerMarketingDataSixMonths !== undefined &&
                    customerMarketingDataSixMonths.length !== 0 &&
                    Number(customerMarketingDataSixMonths[0].PM_TY_VS_LY)
                      .toFixed(2)
                      .includes("-") ? (
                      <span style={{ color: "green", fontSize: "12px" }}>
                        {customerMarketingDataSixMonths !== undefined &&
                          customerMarketingDataSixMonths.length !== 0 &&
                          (customerMarketingDataSixMonths[0].PM_TY_VS_LY ===
                          "-999999"
                            ? "-"
                            : `LY ${Number(
                                customerMarketingDataSixMonths[0].PM_TY_VS_LY
                              ).toFixed(2)}%`)}
                      </span>
                    ) : (
                      <span style={{ color: "red", fontSize: "12px" }}>
                        {customerMarketingDataSixMonths !== undefined &&
                          customerMarketingDataSixMonths.length !== 0 &&
                          (customerMarketingDataSixMonths[0].PM_TY_VS_LY ===
                          "-999999"
                            ? "-"
                            : `LY +${Number(
                                customerMarketingDataSixMonths[0].PM_TY_VS_LY
                              ).toFixed(2)}%`)}
                      </span>
                    )}
                    <br />
                    {customerMarketingDataSixMonths !== undefined &&
                    customerMarketingDataSixMonths.length !== 0 &&
                    Number(customerMarketingDataSixMonths[0].PM_TY_VS_LLY)
                      .toFixed(2)
                      .includes("-") ? (
                      <span style={{ color: "green", fontSize: "11px" }}>
                        {customerMarketingDataSixMonths !== undefined &&
                          customerMarketingDataSixMonths.length !== 0 &&
                          (customerMarketingDataSixMonths[0].PM_TY_VS_LLY ===
                          "-999999"
                            ? "-"
                            : `LLY ${Number(
                                customerMarketingDataSixMonths[0].PM_TY_VS_LLY
                              ).toFixed(2)}%`)}
                      </span>
                    ) : (
                      <span style={{ color: "red", fontSize: "11px" }}>
                        {customerMarketingDataSixMonths !== undefined &&
                          customerMarketingDataSixMonths.length !== 0 &&
                          (customerMarketingDataSixMonths[0].PM_TY_VS_LLY ===
                          "-999999"
                            ? "-"
                            : `LLY +${Number(
                                customerMarketingDataSixMonths[0].PM_TY_VS_LLY
                              ).toFixed(2)}%`)}
                      </span>
                    )}
                  </td>
                  <td>
                    {customerMarketingDataSixMonths !== undefined &&
                      customerMarketingDataSixMonths.length !== 0 &&
                      (customerMarketingDataSixMonths[0].AOV_TY === "-999999"
                        ? "-"
                        : "$" +
                          Number(
                            customerMarketingDataSixMonths[0].AOV_TY
                          ).toFixed(2))}
                    <br />
                    {customerMarketingDataSixMonths !== undefined &&
                    customerMarketingDataSixMonths.length !== 0 &&
                    Number(customerMarketingDataSixMonths[0].AOV_TY_VS_LY)
                      .toFixed(2)
                      .includes("-") ? (
                      <span style={{ color: "green", fontSize: "12px" }}>
                        {customerMarketingDataSixMonths !== undefined &&
                          customerMarketingDataSixMonths.length !== 0 &&
                          (customerMarketingDataSixMonths[0].AOV_TY_VS_LY ===
                          "-999999"
                            ? "-"
                            : `LY ${Number(
                                customerMarketingDataSixMonths[0].AOV_TY_VS_LY
                              ).toFixed(2)}%`)}
                      </span>
                    ) : (
                      <span style={{ color: "red", fontSize: "12px" }}>
                        {customerMarketingDataSixMonths !== undefined &&
                          customerMarketingDataSixMonths.length !== 0 &&
                          (customerMarketingDataSixMonths[0].AOV_TY_VS_LY ===
                          "-999999"
                            ? "-"
                            : `LY +${Number(
                                customerMarketingDataSixMonths[0].AOV_TY_VS_LY
                              ).toFixed(2)}%`)}
                      </span>
                    )}
                    <br />
                    {customerMarketingDataSixMonths !== undefined &&
                    customerMarketingDataSixMonths.length !== 0 &&
                    Number(customerMarketingDataSixMonths[0].AOV_TY_VS_LLY)
                      .toFixed(2)
                      .includes("-") ? (
                      <span style={{ color: "green", fontSize: "11px" }}>
                        {customerMarketingDataSixMonths !== undefined &&
                          customerMarketingDataSixMonths.length !== 0 &&
                          (customerMarketingDataSixMonths[0].AOV_TY_VS_LLY ===
                          "-999999"
                            ? "-"
                            : `LLY ${Number(
                                customerMarketingDataSixMonths[0].AOV_TY_VS_LLY
                              ).toFixed(2)}%`)}
                      </span>
                    ) : (
                      <span style={{ color: "red", fontSize: "11px" }}>
                        {customerMarketingDataSixMonths !== undefined &&
                          customerMarketingDataSixMonths.length !== 0 &&
                          (customerMarketingDataSixMonths[0].AOV_TY_VS_LLY ===
                          "-999999"
                            ? "-"
                            : `LLY +${Number(
                                customerMarketingDataSixMonths[0].AOV_TY_VS_LLY
                              ).toFixed(2)}%`)}
                      </span>
                    )}
                  </td>
                  <td>
                    {customerMarketingDataSixMonths !== undefined &&
                      customerMarketingDataSixMonths.length !== 0 &&
                      (customerMarketingDataSixMonths[0].UPT_TY === "-999999"
                        ? "-"
                        : Number(
                            customerMarketingDataSixMonths[0].UPT_TY
                          ).toFixed(1))}
                    <br />
                    {customerMarketingDataSixMonths !== undefined &&
                    customerMarketingDataSixMonths.length !== 0 &&
                    Number(customerMarketingDataSixMonths[0].UPT_TY_VS_LY)
                      .toFixed(2)
                      .includes("-") ? (
                      <span style={{ color: "green", fontSize: "12px" }}>
                        {customerMarketingDataSixMonths !== undefined &&
                          customerMarketingDataSixMonths.length !== 0 &&
                          (customerMarketingDataSixMonths[0].UPT_TY_VS_LY ===
                          "-999999"
                            ? "-"
                            : `LY ${Number(
                                customerMarketingDataSixMonths[0].UPT_TY_VS_LY
                              ).toFixed(2)}%`)}
                      </span>
                    ) : (
                      <span style={{ color: "red", fontSize: "12px" }}>
                        {customerMarketingDataSixMonths !== undefined &&
                          customerMarketingDataSixMonths.length !== 0 &&
                          (customerMarketingDataSixMonths[0].UPT_TY_VS_LY ===
                          "-999999"
                            ? "-"
                            : `LY +${Number(
                                customerMarketingDataSixMonths[0].UPT_TY_VS_LY
                              ).toFixed(2)}%`)}
                      </span>
                    )}
                    <br />
                    {customerMarketingDataSixMonths !== undefined &&
                    customerMarketingDataSixMonths.length !== 0 &&
                    Number(customerMarketingDataSixMonths[0].UPT_TY_VS_LLY)
                      .toFixed(2)
                      .includes("-") ? (
                      <span style={{ color: "green", fontSize: "11px" }}>
                        {customerMarketingDataSixMonths !== undefined &&
                          customerMarketingDataSixMonths.length !== 0 &&
                          (customerMarketingDataSixMonths[0].UPT_TY_VS_LLY ===
                          "-999999"
                            ? "-"
                            : `LLY ${Number(
                                customerMarketingDataSixMonths[0].UPT_TY_VS_LLY
                              ).toFixed(2)}%`)}
                      </span>
                    ) : (
                      <span style={{ color: "red", fontSize: "11px" }}>
                        {customerMarketingDataSixMonths !== undefined &&
                          customerMarketingDataSixMonths.length !== 0 &&
                          (customerMarketingDataSixMonths[0].UPT_TY_VS_LLY ===
                          "-999999"
                            ? "-"
                            : `LLY +${Number(
                                customerMarketingDataSixMonths[0].UPT_TY_VS_LLY
                              ).toFixed(2)}%`)}
                      </span>
                    )}
                  </td>
                  <td>
                    {customerMarketingDataSixMonths !== undefined &&
                      customerMarketingDataSixMonths.length !== 0 &&
                      (customerMarketingDataSixMonths[0].AUR_TY === "-999999"
                        ? "-"
                        : "$" +
                          Number(
                            customerMarketingDataSixMonths[0].AUR_TY
                          ).toFixed(2))}
                    <br />
                    {customerMarketingDataSixMonths !== undefined &&
                    customerMarketingDataSixMonths.length !== 0 &&
                    Number(customerMarketingDataSixMonths[0].AUR_TY_VS_LY)
                      .toFixed(2)
                      .includes("-") ? (
                      <span style={{ color: "green", fontSize: "12px" }}>
                        {customerMarketingDataSixMonths !== undefined &&
                          customerMarketingDataSixMonths.length !== 0 &&
                          (customerMarketingDataSixMonths[0].AUR_TY_VS_LY ===
                          "-999999"
                            ? "-"
                            : `LY ${Number(
                                customerMarketingDataSixMonths[0].AUR_TY_VS_LY
                              ).toFixed(2)}%`)}
                      </span>
                    ) : (
                      <span style={{ color: "red", fontSize: "12px" }}>
                        {customerMarketingDataSixMonths !== undefined &&
                          customerMarketingDataSixMonths.length !== 0 &&
                          (customerMarketingDataSixMonths[0].AUR_TY_VS_LY ===
                          "-999999"
                            ? "-"
                            : `LY +${Number(
                                customerMarketingDataSixMonths[0].AUR_TY_VS_LY
                              ).toFixed(2)}%`)}
                      </span>
                    )}
                    <br />
                    {customerMarketingDataSixMonths !== undefined &&
                    customerMarketingDataSixMonths.length !== 0 &&
                    Number(customerMarketingDataSixMonths[0].AUR_TY_VS_LLY)
                      .toFixed(2)
                      .includes("-") ? (
                      <span style={{ color: "green", fontSize: "11px" }}>
                        {customerMarketingDataSixMonths !== undefined &&
                          customerMarketingDataSixMonths.length !== 0 &&
                          (customerMarketingDataSixMonths[0].AUR_TY_VS_LLY ===
                          "-999999"
                            ? "-"
                            : `LLY ${Number(
                                customerMarketingDataSixMonths[0].AUR_TY_VS_LLY
                              ).toFixed(2)}%`)}
                      </span>
                    ) : (
                      <span style={{ color: "red", fontSize: "11px" }}>
                        {customerMarketingDataSixMonths !== undefined &&
                          customerMarketingDataSixMonths.length !== 0 &&
                          (customerMarketingDataSixMonths[0].AUR_TY_VS_LLY ===
                          "-999999"
                            ? "-"
                            : `LLY +${Number(
                                customerMarketingDataSixMonths[0].AUR_TY_VS_LLY
                              ).toFixed(2)}%`)}
                      </span>
                    )}
                  </td>
                  <td>
                    {customerMarketingDataSixMonths !== undefined &&
                      customerMarketingDataSixMonths.length !== 0 &&
                      (customerMarketingDataSixMonths[0].MARGIN_RATE_PER_TY ===
                      "-999999"
                        ? "-"
                        : Number(
                            customerMarketingDataSixMonths[0].MARGIN_RATE_PER_TY
                          ).toFixed(2))}
                    <br />
                    {customerMarketingDataSixMonths !== undefined &&
                    customerMarketingDataSixMonths.length !== 0 &&
                    Number(
                      customerMarketingDataSixMonths[0].MARGIN_RATE_PER_TY_VS_LY
                    )
                      .toFixed(2)
                      .includes("-") ? (
                      <span style={{ color: "green", fontSize: "12px" }}>
                        {customerMarketingDataSixMonths !== undefined &&
                          customerMarketingDataSixMonths.length !== 0 &&
                          (customerMarketingDataSixMonths[0]
                            .MARGIN_RATE_PER_TY_VS_LY === "-999999"
                            ? "-"
                            : `LY ${Number(
                                customerMarketingDataSixMonths[0]
                                  .MARGIN_RATE_PER_TY_VS_LY
                              ).toFixed(2)}%`)}
                      </span>
                    ) : (
                      <span style={{ color: "red", fontSize: "12px" }}>
                        {customerMarketingDataSixMonths !== undefined &&
                          customerMarketingDataSixMonths.length !== 0 &&
                          (customerMarketingDataSixMonths[0]
                            .MARGIN_RATE_PER_TY_VS_LY === "-999999"
                            ? "-"
                            : `LY +${Number(
                                customerMarketingDataSixMonths[0]
                                  .MARGIN_RATE_PER_TY_VS_LY
                              ).toFixed(2)}%`)}
                      </span>
                    )}
                    <br />
                    {customerMarketingDataSixMonths !== undefined &&
                    customerMarketingDataSixMonths.length !== 0 &&
                    Number(
                      customerMarketingDataSixMonths[0]
                        .MARGIN_RATE_PER_TY_VS_LLY
                    )
                      .toFixed(2)
                      .includes("-") ? (
                      <span style={{ color: "green", fontSize: "11px" }}>
                        {customerMarketingDataSixMonths !== undefined &&
                          customerMarketingDataSixMonths.length !== 0 &&
                          (customerMarketingDataSixMonths[0]
                            .MARGIN_RATE_PER_TY_VS_LLY === "-999999"
                            ? "-"
                            : `LLY ${Number(
                                customerMarketingDataSixMonths[0]
                                  .MARGIN_RATE_PER_TY_VS_LLY
                              ).toFixed(2)}%`)}
                      </span>
                    ) : (
                      <span style={{ color: "red", fontSize: "11px" }}>
                        {customerMarketingDataSixMonths !== undefined &&
                          customerMarketingDataSixMonths.length !== 0 &&
                          (customerMarketingDataSixMonths[0]
                            .MARGIN_RATE_PER_TY_VS_LLY === "-999999"
                            ? "-"
                            : `LLY +${Number(
                                customerMarketingDataSixMonths[0]
                                  .MARGIN_RATE_PER_TY_VS_LLY
                              ).toFixed(2)}%`)}
                      </span>
                    )}
                  </td>
                  <td>
                    {customerMarketingDataSixMonths !== undefined &&
                      customerMarketingDataSixMonths.length !== 0 &&
                      (customerMarketingDataSixMonths[0]
                        .NET_SALES_PER_CUST_TY === "-999999"
                        ? "-"
                        : "$" +
                          Number(
                            customerMarketingDataSixMonths[0]
                              .NET_SALES_PER_CUST_TY
                          ).toFixed(2))}
                    <br />
                    {customerMarketingDataSixMonths !== undefined &&
                    customerMarketingDataSixMonths.length !== 0 &&
                    Number(
                      customerMarketingDataSixMonths[0]
                        .NET_SALES_PER_CUST_TY_VS_LY
                    )
                      .toFixed(2)
                      .includes("-") ? (
                      <span style={{ color: "green", fontSize: "12px" }}>
                        {customerMarketingDataSixMonths !== undefined &&
                          customerMarketingDataSixMonths.length !== 0 &&
                          (customerMarketingDataSixMonths[0]
                            .NET_SALES_PER_CUST_TY_VS_LY === "-999999"
                            ? "-"
                            : `LY ${Number(
                                customerMarketingDataSixMonths[0]
                                  .NET_SALES_PER_CUST_TY_VS_LY
                              ).toFixed(2)}%`)}
                      </span>
                    ) : (
                      <span style={{ color: "red", fontSize: "12px" }}>
                        {customerMarketingDataSixMonths !== undefined &&
                          customerMarketingDataSixMonths.length !== 0 &&
                          (customerMarketingDataSixMonths[0]
                            .NET_SALES_PER_CUST_TY_VS_LY === "-999999"
                            ? "-"
                            : `LY +${Number(
                                customerMarketingDataSixMonths[0]
                                  .NET_SALES_PER_CUST_TY_VS_LY
                              ).toFixed(2)}%`)}
                      </span>
                    )}
                    <br />
                    {customerMarketingDataSixMonths !== undefined &&
                    customerMarketingDataSixMonths.length !== 0 &&
                    Number(
                      customerMarketingDataSixMonths[0]
                        .NET_SALES_PER_CUST_TY_VS_LLY
                    )
                      .toFixed(2)
                      .includes("-") ? (
                      <span style={{ color: "green", fontSize: "11px" }}>
                        {customerMarketingDataSixMonths !== undefined &&
                          customerMarketingDataSixMonths.length !== 0 &&
                          (customerMarketingDataSixMonths[0]
                            .NET_SALES_PER_CUST_TY_VS_LLY === "-999999"
                            ? "-"
                            : `LLY ${Number(
                                customerMarketingDataSixMonths[0]
                                  .NET_SALES_PER_CUST_TY_VS_LLY
                              ).toFixed(2)}%`)}
                      </span>
                    ) : (
                      <span style={{ color: "red", fontSize: "11px" }}>
                        {customerMarketingDataSixMonths !== undefined &&
                          customerMarketingDataSixMonths.length !== 0 &&
                          (customerMarketingDataSixMonths[0]
                            .NET_SALES_PER_CUST_TY_VS_LLY === "-999999"
                            ? "-"
                            : `LLY +${Number(
                                customerMarketingDataSixMonths[0]
                                  .NET_SALES_PER_CUST_TY_VS_LLY
                              ).toFixed(2)}%`)}
                      </span>
                    )}
                  </td>
                  <td>
                    {customerMarketingDataSixMonths !== undefined &&
                      customerMarketingDataSixMonths.length !== 0 &&
                      (customerMarketingDataSixMonths[0].AVG_TRAN_TY ===
                      "-999999"
                        ? "-"
                        : Number(
                            customerMarketingDataSixMonths[0].AVG_TRAN_TY
                          ).toFixed(2))}
                    <br />
                    {customerMarketingDataSixMonths !== undefined &&
                    customerMarketingDataSixMonths.length !== 0 &&
                    Number(customerMarketingDataSixMonths[0].AVG_TRAN_TY_VS_LY)
                      .toFixed(2)
                      .includes("-") ? (
                      <span style={{ color: "green", fontSize: "12px" }}>
                        {customerMarketingDataSixMonths !== undefined &&
                          customerMarketingDataSixMonths.length !== 0 &&
                          (customerMarketingDataSixMonths[0]
                            .AVG_TRAN_TY_VS_LY === "-999999"
                            ? "-"
                            : `LY ${Number(
                                customerMarketingDataSixMonths[0]
                                  .AVG_TRAN_TY_VS_LY
                              ).toFixed(2)}%`)}
                      </span>
                    ) : (
                      <span style={{ color: "red", fontSize: "12px" }}>
                        {customerMarketingDataSixMonths !== undefined &&
                          customerMarketingDataSixMonths.length !== 0 &&
                          (customerMarketingDataSixMonths[0]
                            .AVG_TRAN_TY_VS_LY === "-999999"
                            ? "-"
                            : `LY +${Number(
                                customerMarketingDataSixMonths[0]
                                  .AVG_TRAN_TY_VS_LY
                              ).toFixed(2)}%`)}
                      </span>
                    )}
                    <br />
                    {customerMarketingDataSixMonths !== undefined &&
                    customerMarketingDataSixMonths.length !== 0 &&
                    Number(customerMarketingDataSixMonths[0].AVG_TRAN_TY_VS_LLY)
                      .toFixed(2)
                      .includes("-") ? (
                      <span style={{ color: "green", fontSize: "11px" }}>
                        {customerMarketingDataSixMonths !== undefined &&
                          customerMarketingDataSixMonths.length !== 0 &&
                          (customerMarketingDataSixMonths[0]
                            .AVG_TRAN_TY_VS_LLY === "-999999"
                            ? "-"
                            : `LLY ${Number(
                                customerMarketingDataSixMonths[0]
                                  .AVG_TRAN_TY_VS_LLY
                              ).toFixed(2)}%`)}
                      </span>
                    ) : (
                      <span style={{ color: "red", fontSize: "11px" }}>
                        {customerMarketingDataSixMonths !== undefined &&
                          customerMarketingDataSixMonths.length !== 0 &&
                          (customerMarketingDataSixMonths[0]
                            .AVG_TRAN_TY_VS_LLY === "-999999"
                            ? "-"
                            : `LLY +${Number(
                                customerMarketingDataSixMonths[0]
                                  .AVG_TRAN_TY_VS_LLY
                              ).toFixed(2)}%`)}
                      </span>
                    )}
                  </td>
                </>
              )}
            </tr>
            <tr>
              <td
                className="tableCol"
                id={
                  selectedMarketingCategoryId !== "NR"
                    ? "AtRisk_9_12"
                    : "AtRisk9_12"
                }
                onClick={() =>
                  selectedMarketingCategoryId !== "NR"
                    ? handleModalOpen("At risk (9m-12m)")
                    : ""
                }
              >
                {"At risk (9m-12m)"}{" "}
                {gettooltip(
                  "AtRisk_9_12InfoIcon",
                  "AtRisk_9_12",
                  "AtRisk_9_12",
                  "Active in L12M but not active in L9M"
                )}
              </td>
              {loading.AtRisk_9m_12m ? (
                <>
                  <LoaderForRow tdCount={10} />
                </>
              ) : (
                <>
                  <td>
                    {customerMarketingDataNineMonths !== undefined &&
                      customerMarketingDataNineMonths.length !== 0 &&
                      (customerMarketingDataNineMonths[0].CUST_COUNT_TY ===
                      "-999999"
                        ? "-"
                        : currencyFormat(
                            Number(
                              customerMarketingDataNineMonths[0].CUST_COUNT_TY
                            )
                          ))}
                    <br />
                    {customerMarketingDataNineMonths !== undefined &&
                    customerMarketingDataNineMonths.length !== 0 &&
                    Number(customerMarketingDataNineMonths[0].CUST_TY_VS_LY)
                      .toFixed(2)
                      .includes("-") ? (
                      <span style={{ color: "green", fontSize: "12px" }}>
                        {customerMarketingDataNineMonths !== undefined &&
                          customerMarketingDataNineMonths.length !== 0 &&
                          (customerMarketingDataNineMonths[0].CUST_TY_VS_LY ===
                          "-999999"
                            ? "-"
                            : `LY ${Number(
                                customerMarketingDataNineMonths[0].CUST_TY_VS_LY
                              ).toFixed(2)}%`)}
                      </span>
                    ) : (
                      <span style={{ color: "red", fontSize: "12px" }}>
                        {customerMarketingDataNineMonths !== undefined &&
                          customerMarketingDataNineMonths.length !== 0 &&
                          (customerMarketingDataNineMonths[0].CUST_TY_VS_LY ===
                          "-999999"
                            ? "-"
                            : `LY +${Number(
                                customerMarketingDataNineMonths[0].CUST_TY_VS_LY
                              ).toFixed(2)}%`)}
                      </span>
                    )}
                    <br />
                    {customerMarketingDataNineMonths !== undefined &&
                    customerMarketingDataNineMonths.length !== 0 &&
                    Number(customerMarketingDataNineMonths[0].CUST_TY_VS_LLY)
                      .toFixed(2)
                      .includes("-") ? (
                      <span style={{ color: "green", fontSize: "11px" }}>
                        {customerMarketingDataNineMonths !== undefined &&
                          customerMarketingDataNineMonths.length !== 0 &&
                          (customerMarketingDataNineMonths[0].CUST_TY_VS_LLY ===
                          "-999999"
                            ? "-"
                            : `LLY ${Number(
                                customerMarketingDataNineMonths[0]
                                  .CUST_TY_VS_LLY
                              ).toFixed(2)}%`)}
                      </span>
                    ) : (
                      <span style={{ color: "red", fontSize: "11px" }}>
                        {customerMarketingDataNineMonths !== undefined &&
                          customerMarketingDataNineMonths.length !== 0 &&
                          (customerMarketingDataNineMonths[0].CUST_TY_VS_LLY ===
                          "-999999"
                            ? "-"
                            : `LLY +${Number(
                                customerMarketingDataNineMonths[0]
                                  .CUST_TY_VS_LLY
                              ).toFixed(2)}%`)}
                      </span>
                    )}
                  </td>
                  <td>
                    {customerMarketingDataNineMonths !== undefined &&
                      customerMarketingDataNineMonths.length !== 0 &&
                      (customerMarketingDataNineMonths[0].NET_SALES_TY ===
                      "-999999"
                        ? "-"
                        : "$" +
                          currencyFormat(
                            Number(
                              customerMarketingDataNineMonths[0].NET_SALES_TY
                            )
                          ))}
                    <br />
                    {customerMarketingDataNineMonths !== undefined &&
                    customerMarketingDataNineMonths.length !== 0 &&
                    Number(
                      customerMarketingDataNineMonths[0].NET_SALES_TY_VS_LY
                    )
                      .toFixed(2)
                      .includes("-") ? (
                      <span style={{ color: "green", fontSize: "12px" }}>
                        {customerMarketingDataNineMonths !== undefined &&
                          customerMarketingDataNineMonths.length !== 0 &&
                          (customerMarketingDataNineMonths[0]
                            .NET_SALES_TY_VS_LY === "-999999"
                            ? "-"
                            : `LY ${Number(
                                customerMarketingDataNineMonths[0]
                                  .NET_SALES_TY_VS_LY
                              ).toFixed(2)}%`)}
                      </span>
                    ) : (
                      <span style={{ color: "red", fontSize: "12px" }}>
                        {customerMarketingDataNineMonths !== undefined &&
                          customerMarketingDataNineMonths.length !== 0 &&
                          (customerMarketingDataNineMonths[0]
                            .NET_SALES_TY_VS_LY === "-999999"
                            ? "-"
                            : `LY +${Number(
                                customerMarketingDataNineMonths[0]
                                  .NET_SALES_TY_VS_LY
                              ).toFixed(2)}%`)}
                      </span>
                    )}
                    <br />
                    {customerMarketingDataNineMonths !== undefined &&
                    customerMarketingDataNineMonths.length !== 0 &&
                    Number(
                      customerMarketingDataNineMonths[0].NET_SALES_TY_VS_LLY
                    )
                      .toFixed(2)
                      .includes("-") ? (
                      <span style={{ color: "green", fontSize: "11px" }}>
                        {customerMarketingDataNineMonths !== undefined &&
                          customerMarketingDataNineMonths.length !== 0 &&
                          (customerMarketingDataNineMonths[0]
                            .NET_SALES_TY_VS_LLY === "-999999"
                            ? "-"
                            : `LLY ${Number(
                                customerMarketingDataNineMonths[0]
                                  .NET_SALES_TY_VS_LLY
                              ).toFixed(2)}%`)}
                      </span>
                    ) : (
                      <span style={{ color: "red", fontSize: "11px" }}>
                        {customerMarketingDataNineMonths !== undefined &&
                          customerMarketingDataNineMonths.length !== 0 &&
                          (customerMarketingDataNineMonths[0]
                            .NET_SALES_TY_VS_LLY === "-999999"
                            ? "-"
                            : `LLY +${Number(
                                customerMarketingDataNineMonths[0]
                                  .NET_SALES_TY_VS_LLY
                              ).toFixed(2)}%`)}
                      </span>
                    )}
                  </td>
                  <td>
                    {customerMarketingDataNineMonths !== undefined &&
                      customerMarketingDataNineMonths.length !== 0 &&
                      (customerMarketingDataNineMonths[0].TRANS_COUNT_TY ===
                      "-999999"
                        ? "-"
                        : currencyFormat(
                            Number(
                              customerMarketingDataNineMonths[0].TRANS_COUNT_TY
                            )
                          ))}
                    <br />
                    {customerMarketingDataNineMonths !== undefined &&
                    customerMarketingDataNineMonths.length !== 0 &&
                    Number(customerMarketingDataNineMonths[0].TRANS_TY_VS_LY)
                      .toFixed(2)
                      .includes("-") ? (
                      <span style={{ color: "green", fontSize: "12px" }}>
                        {customerMarketingDataNineMonths !== undefined &&
                          customerMarketingDataNineMonths.length !== 0 &&
                          (customerMarketingDataNineMonths[0].TRANS_TY_VS_LY ===
                          "-999999"
                            ? "-"
                            : `LY ${Number(
                                customerMarketingDataNineMonths[0]
                                  .TRANS_TY_VS_LY
                              ).toFixed(2)}%`)}
                      </span>
                    ) : (
                      <span style={{ color: "red", fontSize: "12px" }}>
                        {customerMarketingDataNineMonths !== undefined &&
                          customerMarketingDataNineMonths.length !== 0 &&
                          (customerMarketingDataNineMonths[0].TRANS_TY_VS_LY ===
                          "-999999"
                            ? "-"
                            : `LY +${Number(
                                customerMarketingDataNineMonths[0]
                                  .TRANS_TY_VS_LY
                              ).toFixed(2)}%`)}
                      </span>
                    )}
                    <br />
                    {customerMarketingDataNineMonths !== undefined &&
                    customerMarketingDataNineMonths.length !== 0 &&
                    Number(customerMarketingDataNineMonths[0].TRANS_TY_VS_LLY)
                      .toFixed(2)
                      .includes("-") ? (
                      <span style={{ color: "green", fontSize: "11px" }}>
                        {customerMarketingDataNineMonths !== undefined &&
                          customerMarketingDataNineMonths.length !== 0 &&
                          (customerMarketingDataNineMonths[0]
                            .TRANS_TY_VS_LLY === "-999999"
                            ? "-"
                            : `LLY ${Number(
                                customerMarketingDataNineMonths[0]
                                  .TRANS_TY_VS_LLY
                              ).toFixed(2)}%`)}
                      </span>
                    ) : (
                      <span style={{ color: "red", fontSize: "11px" }}>
                        {customerMarketingDataNineMonths !== undefined &&
                          customerMarketingDataNineMonths.length !== 0 &&
                          (customerMarketingDataNineMonths[0]
                            .TRANS_TY_VS_LLY === "-999999"
                            ? "-"
                            : `LLY +${Number(
                                customerMarketingDataNineMonths[0]
                                  .TRANS_TY_VS_LLY
                              ).toFixed(2)}%`)}
                      </span>
                    )}
                  </td>
                  <td>
                    {customerMarketingDataNineMonths !== undefined &&
                      customerMarketingDataNineMonths.length !== 0 &&
                      (customerMarketingDataNineMonths[0].PM_TY === "-999999"
                        ? "-"
                        : "$" +
                          currencyFormat(
                            Number(customerMarketingDataNineMonths[0].PM_TY)
                          ))}
                    <br />
                    {customerMarketingDataNineMonths !== undefined &&
                    customerMarketingDataNineMonths.length !== 0 &&
                    Number(customerMarketingDataNineMonths[0].PM_TY_VS_LY)
                      .toFixed(2)
                      .includes("-") ? (
                      <span style={{ color: "green", fontSize: "12px" }}>
                        {customerMarketingDataNineMonths !== undefined &&
                          customerMarketingDataNineMonths.length !== 0 &&
                          (customerMarketingDataNineMonths[0].PM_TY_VS_LY ===
                          "-999999"
                            ? "-"
                            : `LY ${Number(
                                customerMarketingDataNineMonths[0].PM_TY_VS_LY
                              ).toFixed(2)}%`)}
                      </span>
                    ) : (
                      <span style={{ color: "red", fontSize: "12px" }}>
                        {customerMarketingDataNineMonths !== undefined &&
                          customerMarketingDataNineMonths.length !== 0 &&
                          (customerMarketingDataNineMonths[0].PM_TY_VS_LY ===
                          "-999999"
                            ? "-"
                            : `LY +${Number(
                                customerMarketingDataNineMonths[0].PM_TY_VS_LY
                              ).toFixed(2)}%`)}
                      </span>
                    )}
                    <br />
                    {customerMarketingDataNineMonths !== undefined &&
                    customerMarketingDataNineMonths.length !== 0 &&
                    Number(customerMarketingDataNineMonths[0].PM_TY_VS_LLY)
                      .toFixed(2)
                      .includes("-") ? (
                      <span style={{ color: "green", fontSize: "11px" }}>
                        {customerMarketingDataNineMonths !== undefined &&
                          customerMarketingDataNineMonths.length !== 0 &&
                          (customerMarketingDataNineMonths[0].PM_TY_VS_LLY ===
                          "-999999"
                            ? "-"
                            : `LLY ${Number(
                                customerMarketingDataNineMonths[0].PM_TY_VS_LLY
                              ).toFixed(2)}%`)}
                      </span>
                    ) : (
                      <span style={{ color: "red", fontSize: "11px" }}>
                        {customerMarketingDataNineMonths !== undefined &&
                          customerMarketingDataNineMonths.length !== 0 &&
                          (customerMarketingDataNineMonths[0].PM_TY_VS_LLY ===
                          "-999999"
                            ? "-"
                            : `LLY +${Number(
                                customerMarketingDataNineMonths[0].PM_TY_VS_LLY
                              ).toFixed(2)}%`)}
                      </span>
                    )}
                  </td>
                  <td>
                    {customerMarketingDataNineMonths !== undefined &&
                      customerMarketingDataNineMonths.length !== 0 &&
                      (customerMarketingDataNineMonths[0].AOV_TY === "-999999"
                        ? "-"
                        : "$" +
                          Number(
                            customerMarketingDataNineMonths[0].AOV_TY
                          ).toFixed(2))}
                    <br />
                    {customerMarketingDataNineMonths !== undefined &&
                    customerMarketingDataNineMonths.length !== 0 &&
                    Number(customerMarketingDataNineMonths[0].AOV_TY_VS_LY)
                      .toFixed(2)
                      .includes("-") ? (
                      <span style={{ color: "green", fontSize: "12px" }}>
                        {customerMarketingDataNineMonths !== undefined &&
                          customerMarketingDataNineMonths.length !== 0 &&
                          (customerMarketingDataNineMonths[0].AOV_TY_VS_LY ===
                          "-999999"
                            ? "-"
                            : `LY ${Number(
                                customerMarketingDataNineMonths[0].AOV_TY_VS_LY
                              ).toFixed(2)}%`)}
                      </span>
                    ) : (
                      <span style={{ color: "red", fontSize: "12px" }}>
                        {customerMarketingDataNineMonths !== undefined &&
                          customerMarketingDataNineMonths.length !== 0 &&
                          (customerMarketingDataNineMonths[0].AOV_TY_VS_LY ===
                          "-999999"
                            ? "-"
                            : `LY +${Number(
                                customerMarketingDataNineMonths[0].AOV_TY_VS_LY
                              ).toFixed(2)}%`)}
                      </span>
                    )}
                    <br />
                    {customerMarketingDataNineMonths !== undefined &&
                    customerMarketingDataNineMonths.length !== 0 &&
                    Number(customerMarketingDataNineMonths[0].AOV_TY_VS_LLY)
                      .toFixed(2)
                      .includes("-") ? (
                      <span style={{ color: "green", fontSize: "11px" }}>
                        {customerMarketingDataNineMonths !== undefined &&
                          customerMarketingDataNineMonths.length !== 0 &&
                          (customerMarketingDataNineMonths[0].AOV_TY_VS_LLY ===
                          "-999999"
                            ? "-"
                            : `LLY ${Number(
                                customerMarketingDataNineMonths[0].AOV_TY_VS_LLY
                              ).toFixed(2)}%`)}
                      </span>
                    ) : (
                      <span style={{ color: "red", fontSize: "11px" }}>
                        {customerMarketingDataNineMonths !== undefined &&
                          customerMarketingDataNineMonths.length !== 0 &&
                          (customerMarketingDataNineMonths[0].AOV_TY_VS_LLY ===
                          "-999999"
                            ? "-"
                            : `LLY +${Number(
                                customerMarketingDataNineMonths[0].AOV_TY_VS_LLY
                              ).toFixed(2)}%`)}
                      </span>
                    )}
                  </td>
                  <td>
                    {customerMarketingDataNineMonths !== undefined &&
                      customerMarketingDataNineMonths.length !== 0 &&
                      (customerMarketingDataNineMonths[0].UPT_TY === "-999999"
                        ? "-"
                        : Number(
                            customerMarketingDataNineMonths[0].UPT_TY
                          ).toFixed(1))}
                    <br />
                    {customerMarketingDataNineMonths !== undefined &&
                    customerMarketingDataNineMonths.length !== 0 &&
                    Number(customerMarketingDataNineMonths[0].UPT_TY_VS_LY)
                      .toFixed(2)
                      .includes("-") ? (
                      <span style={{ color: "green", fontSize: "12px" }}>
                        {customerMarketingDataNineMonths !== undefined &&
                          customerMarketingDataNineMonths.length !== 0 &&
                          (customerMarketingDataNineMonths[0].UPT_TY_VS_LY ===
                          "-999999"
                            ? "-"
                            : `LY ${Number(
                                customerMarketingDataNineMonths[0].UPT_TY_VS_LY
                              ).toFixed(2)}%`)}
                      </span>
                    ) : (
                      <span style={{ color: "red", fontSize: "12px" }}>
                        {customerMarketingDataNineMonths !== undefined &&
                          customerMarketingDataNineMonths.length !== 0 &&
                          (customerMarketingDataNineMonths[0].UPT_TY_VS_LY ===
                          "-999999"
                            ? "-"
                            : `LY +${Number(
                                customerMarketingDataNineMonths[0].UPT_TY_VS_LY
                              ).toFixed(2)}%`)}
                      </span>
                    )}
                    <br />
                    {customerMarketingDataNineMonths !== undefined &&
                    customerMarketingDataNineMonths.length !== 0 &&
                    Number(customerMarketingDataNineMonths[0].UPT_TY_VS_LLY)
                      .toFixed(2)
                      .includes("-") ? (
                      <span style={{ color: "green", fontSize: "11px" }}>
                        {customerMarketingDataNineMonths !== undefined &&
                          customerMarketingDataNineMonths.length !== 0 &&
                          (customerMarketingDataNineMonths[0].UPT_TY_VS_LLY ===
                          "-999999"
                            ? "-"
                            : `LLY ${Number(
                                customerMarketingDataNineMonths[0].UPT_TY_VS_LLY
                              ).toFixed(2)}%`)}
                      </span>
                    ) : (
                      <span style={{ color: "red", fontSize: "11px" }}>
                        {customerMarketingDataNineMonths !== undefined &&
                          customerMarketingDataNineMonths.length !== 0 &&
                          (customerMarketingDataNineMonths[0].UPT_TY_VS_LLY ===
                          "-999999"
                            ? "-"
                            : `LLY +${Number(
                                customerMarketingDataNineMonths[0].UPT_TY_VS_LLY
                              ).toFixed(2)}%`)}
                      </span>
                    )}
                  </td>
                  <td>
                    {customerMarketingDataNineMonths !== undefined &&
                      customerMarketingDataNineMonths.length !== 0 &&
                      (customerMarketingDataNineMonths[0].AUR_TY === "-999999"
                        ? "-"
                        : "$" +
                          Number(
                            customerMarketingDataNineMonths[0].AUR_TY
                          ).toFixed(2))}
                    <br />
                    {customerMarketingDataNineMonths !== undefined &&
                    customerMarketingDataNineMonths.length !== 0 &&
                    Number(customerMarketingDataNineMonths[0].AUR_TY_VS_LY)
                      .toFixed(2)
                      .includes("-") ? (
                      <span style={{ color: "green", fontSize: "12px" }}>
                        {customerMarketingDataNineMonths !== undefined &&
                          customerMarketingDataNineMonths.length !== 0 &&
                          (customerMarketingDataNineMonths[0].AUR_TY_VS_LY ===
                          "-999999"
                            ? "-"
                            : `LY ${Number(
                                customerMarketingDataNineMonths[0].AUR_TY_VS_LY
                              ).toFixed(2)}%`)}
                      </span>
                    ) : (
                      <span style={{ color: "red", fontSize: "12px" }}>
                        {customerMarketingDataNineMonths !== undefined &&
                          customerMarketingDataNineMonths.length !== 0 &&
                          (customerMarketingDataNineMonths[0].AUR_TY_VS_LY ===
                          "-999999"
                            ? "-"
                            : `LY +${Number(
                                customerMarketingDataNineMonths[0].AUR_TY_VS_LY
                              ).toFixed(2)}%`)}
                      </span>
                    )}
                    <br />
                    {customerMarketingDataNineMonths !== undefined &&
                    customerMarketingDataNineMonths.length !== 0 &&
                    Number(customerMarketingDataNineMonths[0].AUR_TY_VS_LLY)
                      .toFixed(2)
                      .includes("-") ? (
                      <span style={{ color: "green", fontSize: "11px" }}>
                        {customerMarketingDataNineMonths !== undefined &&
                          customerMarketingDataNineMonths.length !== 0 &&
                          (customerMarketingDataNineMonths[0].AUR_TY_VS_LLY ===
                          "-999999"
                            ? "-"
                            : `LLY ${Number(
                                customerMarketingDataNineMonths[0].AUR_TY_VS_LLY
                              ).toFixed(2)}%`)}
                      </span>
                    ) : (
                      <span style={{ color: "red", fontSize: "11px" }}>
                        {customerMarketingDataNineMonths !== undefined &&
                          customerMarketingDataNineMonths.length !== 0 &&
                          (customerMarketingDataNineMonths[0].AUR_TY_VS_LLY ===
                          "-999999"
                            ? "-"
                            : `LLY +${Number(
                                customerMarketingDataNineMonths[0].AUR_TY_VS_LLY
                              ).toFixed(2)}%`)}
                      </span>
                    )}
                  </td>
                  <td>
                    {customerMarketingDataNineMonths !== undefined &&
                      customerMarketingDataNineMonths.length !== 0 &&
                      (customerMarketingDataNineMonths[0].MARGIN_RATE_PER_TY ===
                      "-999999"
                        ? "-"
                        : Number(
                            customerMarketingDataNineMonths[0]
                              .MARGIN_RATE_PER_TY
                          ).toFixed(2))}
                    <br />
                    {customerMarketingDataNineMonths !== undefined &&
                    customerMarketingDataNineMonths.length !== 0 &&
                    Number(
                      customerMarketingDataNineMonths[0]
                        .MARGIN_RATE_PER_TY_VS_LY
                    )
                      .toFixed(2)
                      .includes("-") ? (
                      <span style={{ color: "green", fontSize: "12px" }}>
                        {customerMarketingDataNineMonths !== undefined &&
                          customerMarketingDataNineMonths.length !== 0 &&
                          (customerMarketingDataNineMonths[0]
                            .MARGIN_RATE_PER_TY_VS_LY === "-999999"
                            ? "-"
                            : `LY ${Number(
                                customerMarketingDataNineMonths[0]
                                  .MARGIN_RATE_PER_TY_VS_LY
                              ).toFixed(2)}%`)}
                      </span>
                    ) : (
                      <span style={{ color: "red", fontSize: "12px" }}>
                        {customerMarketingDataNineMonths !== undefined &&
                          customerMarketingDataNineMonths.length !== 0 &&
                          (customerMarketingDataNineMonths[0]
                            .MARGIN_RATE_PER_TY_VS_LY === "-999999"
                            ? "-"
                            : `LY +${Number(
                                customerMarketingDataNineMonths[0]
                                  .MARGIN_RATE_PER_TY_VS_LY
                              ).toFixed(2)}%`)}
                      </span>
                    )}
                    <br />
                    {customerMarketingDataNineMonths !== undefined &&
                    customerMarketingDataNineMonths.length !== 0 &&
                    Number(
                      customerMarketingDataNineMonths[0]
                        .MARGIN_RATE_PER_TY_VS_LLY
                    )
                      .toFixed(2)
                      .includes("-") ? (
                      <span style={{ color: "green", fontSize: "11px" }}>
                        {customerMarketingDataNineMonths !== undefined &&
                          customerMarketingDataNineMonths.length !== 0 &&
                          (customerMarketingDataNineMonths[0]
                            .MARGIN_RATE_PER_TY_VS_LLY === "-999999"
                            ? "-"
                            : `LLY ${Number(
                                customerMarketingDataNineMonths[0]
                                  .MARGIN_RATE_PER_TY_VS_LLY
                              ).toFixed(2)}%`)}
                      </span>
                    ) : (
                      <span style={{ color: "red", fontSize: "11px" }}>
                        {customerMarketingDataNineMonths !== undefined &&
                          customerMarketingDataNineMonths.length !== 0 &&
                          (customerMarketingDataNineMonths[0]
                            .MARGIN_RATE_PER_TY_VS_LLY === "-999999"
                            ? "-"
                            : `LLY +${Number(
                                customerMarketingDataNineMonths[0]
                                  .MARGIN_RATE_PER_TY_VS_LLY
                              ).toFixed(2)}%`)}
                      </span>
                    )}
                  </td>
                  <td>
                    {customerMarketingDataNineMonths !== undefined &&
                      customerMarketingDataNineMonths.length !== 0 &&
                      (customerMarketingDataNineMonths[0]
                        .NET_SALES_PER_CUST_TY === "-999999"
                        ? "-"
                        : "$" +
                          Number(
                            customerMarketingDataNineMonths[0]
                              .NET_SALES_PER_CUST_TY
                          ).toFixed(2))}
                    <br />
                    {customerMarketingDataNineMonths !== undefined &&
                    customerMarketingDataNineMonths.length !== 0 &&
                    Number(
                      customerMarketingDataNineMonths[0]
                        .NET_SALES_PER_CUST_TY_VS_LY
                    )
                      .toFixed(2)
                      .includes("-") ? (
                      <span style={{ color: "green", fontSize: "12px" }}>
                        {customerMarketingDataNineMonths !== undefined &&
                          customerMarketingDataNineMonths.length !== 0 &&
                          (customerMarketingDataNineMonths[0]
                            .NET_SALES_PER_CUST_TY_VS_LY === "-999999"
                            ? "-"
                            : `LY ${Number(
                                customerMarketingDataNineMonths[0]
                                  .NET_SALES_PER_CUST_TY_VS_LY
                              ).toFixed(2)}%`)}
                      </span>
                    ) : (
                      <span style={{ color: "red", fontSize: "12px" }}>
                        {customerMarketingDataNineMonths !== undefined &&
                          customerMarketingDataNineMonths.length !== 0 &&
                          (customerMarketingDataNineMonths[0]
                            .NET_SALES_PER_CUST_TY_VS_LY === "-999999"
                            ? "-"
                            : `LY +${Number(
                                customerMarketingDataNineMonths[0]
                                  .NET_SALES_PER_CUST_TY_VS_LY
                              ).toFixed(2)}%`)}
                      </span>
                    )}
                    <br />
                    {customerMarketingDataNineMonths !== undefined &&
                    customerMarketingDataNineMonths.length !== 0 &&
                    Number(
                      customerMarketingDataNineMonths[0]
                        .NET_SALES_PER_CUST_TY_VS_LLY
                    )
                      .toFixed(2)
                      .includes("-") ? (
                      <span style={{ color: "green", fontSize: "11px" }}>
                        {customerMarketingDataNineMonths !== undefined &&
                          customerMarketingDataNineMonths.length !== 0 &&
                          (customerMarketingDataNineMonths[0]
                            .NET_SALES_PER_CUST_TY_VS_LLY === "-999999"
                            ? "-"
                            : `LLY ${Number(
                                customerMarketingDataNineMonths[0]
                                  .NET_SALES_PER_CUST_TY_VS_LLY
                              ).toFixed(2)}%`)}
                      </span>
                    ) : (
                      <span style={{ color: "red", fontSize: "11px" }}>
                        {customerMarketingDataNineMonths !== undefined &&
                          customerMarketingDataNineMonths.length !== 0 &&
                          (customerMarketingDataNineMonths[0]
                            .NET_SALES_PER_CUST_TY_VS_LLY === "-999999"
                            ? "-"
                            : `LLY +${Number(
                                customerMarketingDataNineMonths[0]
                                  .NET_SALES_PER_CUST_TY_VS_LLY
                              ).toFixed(2)}%`)}
                      </span>
                    )}
                  </td>
                  <td>
                    {customerMarketingDataNineMonths !== undefined &&
                      customerMarketingDataNineMonths.length !== 0 &&
                      (customerMarketingDataNineMonths[0].AVG_TRAN_TY ===
                      "-999999"
                        ? "-"
                        : Number(
                            customerMarketingDataNineMonths[0].AVG_TRAN_TY
                          ).toFixed(2))}
                    <br />
                    {customerMarketingDataNineMonths !== undefined &&
                    customerMarketingDataNineMonths.length !== 0 &&
                    Number(customerMarketingDataNineMonths[0].AVG_TRAN_TY_VS_LY)
                      .toFixed(2)
                      .includes("-") ? (
                      <span style={{ color: "green", fontSize: "12px" }}>
                        {customerMarketingDataNineMonths !== undefined &&
                          customerMarketingDataNineMonths.length !== 0 &&
                          (customerMarketingDataNineMonths[0]
                            .AVG_TRAN_TY_VS_LY === "-999999"
                            ? "-"
                            : `LY ${Number(
                                customerMarketingDataNineMonths[0]
                                  .AVG_TRAN_TY_VS_LY
                              ).toFixed(2)}%`)}
                      </span>
                    ) : (
                      <span style={{ color: "red", fontSize: "12px" }}>
                        {customerMarketingDataNineMonths !== undefined &&
                          customerMarketingDataNineMonths.length !== 0 &&
                          (customerMarketingDataNineMonths[0]
                            .AVG_TRAN_TY_VS_LY === "-999999"
                            ? "-"
                            : `LY +${Number(
                                customerMarketingDataNineMonths[0]
                                  .AVG_TRAN_TY_VS_LY
                              ).toFixed(2)}%`)}
                      </span>
                    )}
                    <br />
                    {customerMarketingDataNineMonths !== undefined &&
                    customerMarketingDataNineMonths.length !== 0 &&
                    Number(
                      customerMarketingDataNineMonths[0].AVG_TRAN_TY_VS_LLY
                    )
                      .toFixed(2)
                      .includes("-") ? (
                      <span style={{ color: "green", fontSize: "11px" }}>
                        {customerMarketingDataNineMonths !== undefined &&
                          customerMarketingDataNineMonths.length !== 0 &&
                          (customerMarketingDataNineMonths[0]
                            .AVG_TRAN_TY_VS_LLY === "-999999"
                            ? "-"
                            : `LLY ${Number(
                                customerMarketingDataNineMonths[0]
                                  .AVG_TRAN_TY_VS_LLY
                              ).toFixed(2)}%`)}
                      </span>
                    ) : (
                      <span style={{ color: "red", fontSize: "11px" }}>
                        {customerMarketingDataNineMonths !== undefined &&
                          customerMarketingDataNineMonths.length !== 0 &&
                          (customerMarketingDataNineMonths[0]
                            .AVG_TRAN_TY_VS_LLY === "-999999"
                            ? "-"
                            : `LLY +${Number(
                                customerMarketingDataNineMonths[0]
                                  .AVG_TRAN_TY_VS_LLY
                              ).toFixed(2)}%`)}
                      </span>
                    )}
                  </td>
                </>
              )}
            </tr>
            <tr>
              <td className="tableTotalCol">
                <b>{"Sub Total"}</b>
              </td>
              {loading.first_half_total ? (
                <>
                  <LoaderForRow tdCount={10} />
                </>
              ) : (
                <>
                  <th>
                    {customerMarketingFirst_Four_Total_Data &&
                      customerMarketingFirst_Four_Total_Data !== undefined &&
                      customerMarketingFirst_Four_Total_Data.length !== 0 &&
                      (customerMarketingFirst_Four_Total_Data[0]
                        .CUST_COUNT_TY === "-999999"
                        ? "-"
                        : currencyFormat(
                            Number(
                              customerMarketingFirst_Four_Total_Data[0]
                                .CUST_COUNT_TY
                            )
                          ))}
                    <br />
                    {customerMarketingFirst_Four_Total_Data !== undefined &&
                    customerMarketingFirst_Four_Total_Data.length !== 0 &&
                    Number(
                      customerMarketingFirst_Four_Total_Data[0].CUST_TY_VS_LY
                    )
                      .toFixed(2)
                      .includes("-") ? (
                      <span style={{ color: "red", fontSize: "12px" }}>
                        {customerMarketingFirst_Four_Total_Data !== undefined &&
                          customerMarketingFirst_Four_Total_Data.length !== 0 &&
                          (customerMarketingFirst_Four_Total_Data[0]
                            .CUST_TY_VS_LY === "-999999"
                            ? "-"
                            : `LY ${Number(
                                customerMarketingFirst_Four_Total_Data[0]
                                  .CUST_TY_VS_LY
                              ).toFixed(2)}%`)}
                      </span>
                    ) : (
                      <span style={{ color: "green", fontSize: "12px" }}>
                        {customerMarketingFirst_Four_Total_Data !== undefined &&
                          customerMarketingFirst_Four_Total_Data.length !== 0 &&
                          (customerMarketingFirst_Four_Total_Data[0]
                            .CUST_TY_VS_LY === "-999999"
                            ? "-"
                            : `LY +${Number(
                                customerMarketingFirst_Four_Total_Data[0]
                                  .CUST_TY_VS_LY
                              ).toFixed(2)}%`)}
                      </span>
                    )}
                    <br />
                    {customerMarketingFirst_Four_Total_Data !== undefined &&
                    customerMarketingFirst_Four_Total_Data.length !== 0 &&
                    Number(
                      customerMarketingFirst_Four_Total_Data[0].CUST_TY_VS_LLY
                    )
                      .toFixed(2)
                      .includes("-") ? (
                      <span style={{ color: "red", fontSize: "11px" }}>
                        {customerMarketingFirst_Four_Total_Data !== undefined &&
                          customerMarketingFirst_Four_Total_Data.length !== 0 &&
                          (customerMarketingFirst_Four_Total_Data[0]
                            .CUST_TY_VS_LLY === "-999999"
                            ? "-"
                            : `LLY ${Number(
                                customerMarketingFirst_Four_Total_Data[0]
                                  .CUST_TY_VS_LLY
                              ).toFixed(2)}%`)}
                      </span>
                    ) : (
                      <span style={{ color: "green", fontSize: "11px" }}>
                        {customerMarketingFirst_Four_Total_Data !== undefined &&
                          customerMarketingFirst_Four_Total_Data.length !== 0 &&
                          (customerMarketingFirst_Four_Total_Data[0]
                            .CUST_TY_VS_LLY === "-999999"
                            ? "-"
                            : `LLY +${Number(
                                customerMarketingFirst_Four_Total_Data[0]
                                  .CUST_TY_VS_LLY
                              ).toFixed(2)}%`)}
                      </span>
                    )}
                  </th>
                  <th>
                    {customerMarketingFirst_Four_Total_Data &&
                      customerMarketingFirst_Four_Total_Data !== undefined &&
                      customerMarketingFirst_Four_Total_Data.length !== 0 &&
                      (customerMarketingFirst_Four_Total_Data[0]
                        .NET_SALES_TY === "-999999"
                        ? "-"
                        : "$" +
                          currencyFormat(
                            Number(
                              customerMarketingFirst_Four_Total_Data[0]
                                .NET_SALES_TY
                            )
                          ))}
                    <br />
                    {customerMarketingFirst_Four_Total_Data !== undefined &&
                    customerMarketingFirst_Four_Total_Data.length !== 0 &&
                    Number(
                      customerMarketingFirst_Four_Total_Data[0]
                        .NET_SALES_TY_VS_LY
                    )
                      .toFixed(2)
                      .includes("-") ? (
                      <span style={{ color: "red", fontSize: "12px" }}>
                        {customerMarketingFirst_Four_Total_Data !== undefined &&
                          customerMarketingFirst_Four_Total_Data.length !== 0 &&
                          (customerMarketingFirst_Four_Total_Data[0]
                            .NET_SALES_TY_VS_LY === "-999999"
                            ? "-"
                            : `LY ${Number(
                                customerMarketingFirst_Four_Total_Data[0]
                                  .NET_SALES_TY_VS_LY
                              ).toFixed(2)}%`)}
                      </span>
                    ) : (
                      <span style={{ color: "green", fontSize: "12px" }}>
                        {customerMarketingFirst_Four_Total_Data !== undefined &&
                          customerMarketingFirst_Four_Total_Data.length !== 0 &&
                          (customerMarketingFirst_Four_Total_Data[0]
                            .NET_SALES_TY_VS_LY === "-999999"
                            ? "-"
                            : `LY +${Number(
                                customerMarketingFirst_Four_Total_Data[0]
                                  .NET_SALES_TY_VS_LY
                              ).toFixed(2)}%`)}
                      </span>
                    )}
                    <br />
                    {customerMarketingFirst_Four_Total_Data !== undefined &&
                    customerMarketingFirst_Four_Total_Data.length !== 0 &&
                    Number(
                      customerMarketingFirst_Four_Total_Data[0]
                        .NET_SALES_TY_VS_LLY
                    )
                      .toFixed(2)
                      .includes("-") ? (
                      <span style={{ color: "red", fontSize: "11px" }}>
                        {customerMarketingFirst_Four_Total_Data !== undefined &&
                          customerMarketingFirst_Four_Total_Data.length !== 0 &&
                          (customerMarketingFirst_Four_Total_Data[0]
                            .NET_SALES_TY_VS_LLY === "-999999"
                            ? "-"
                            : `LLY ${Number(
                                customerMarketingFirst_Four_Total_Data[0]
                                  .NET_SALES_TY_VS_LLY
                              ).toFixed(2)}%`)}
                      </span>
                    ) : (
                      <span style={{ color: "green", fontSize: "11px" }}>
                        {customerMarketingFirst_Four_Total_Data !== undefined &&
                          customerMarketingFirst_Four_Total_Data.length !== 0 &&
                          (customerMarketingFirst_Four_Total_Data[0]
                            .NET_SALES_TY_VS_LLY === "-999999"
                            ? "-"
                            : `LLY +${Number(
                                customerMarketingFirst_Four_Total_Data[0]
                                  .NET_SALES_TY_VS_LLY
                              ).toFixed(2)}%`)}
                      </span>
                    )}
                  </th>
                  <th>
                    {customerMarketingFirst_Four_Total_Data &&
                      customerMarketingFirst_Four_Total_Data !== undefined &&
                      customerMarketingFirst_Four_Total_Data.length !== 0 &&
                      (customerMarketingFirst_Four_Total_Data[0]
                        .TRANS_COUNT_TY === "-999999"
                        ? "-"
                        : currencyFormat(
                            Number(
                              customerMarketingFirst_Four_Total_Data[0]
                                .TRANS_COUNT_TY
                            )
                          ))}
                    <br />
                    {customerMarketingFirst_Four_Total_Data !== undefined &&
                    customerMarketingFirst_Four_Total_Data.length !== 0 &&
                    Number(
                      customerMarketingFirst_Four_Total_Data[0].TRANS_TY_VS_LY
                    )
                      .toFixed(2)
                      .includes("-") ? (
                      <span style={{ color: "red", fontSize: "12px" }}>
                        {customerMarketingFirst_Four_Total_Data !== undefined &&
                          customerMarketingFirst_Four_Total_Data.length !== 0 &&
                          (customerMarketingFirst_Four_Total_Data[0]
                            .TRANS_TY_VS_LY === "-999999"
                            ? "-"
                            : `LY ${Number(
                                customerMarketingFirst_Four_Total_Data[0]
                                  .TRANS_TY_VS_LY
                              ).toFixed(2)}%`)}
                      </span>
                    ) : (
                      <span style={{ color: "green", fontSize: "12px" }}>
                        {customerMarketingFirst_Four_Total_Data !== undefined &&
                          customerMarketingFirst_Four_Total_Data.length !== 0 &&
                          (customerMarketingFirst_Four_Total_Data[0]
                            .TRANS_TY_VS_LY === "-999999"
                            ? "-"
                            : `LY +${Number(
                                customerMarketingFirst_Four_Total_Data[0]
                                  .TRANS_TY_VS_LY
                              ).toFixed(2)}%`)}
                      </span>
                    )}
                    <br />
                    {customerMarketingFirst_Four_Total_Data !== undefined &&
                    customerMarketingFirst_Four_Total_Data.length !== 0 &&
                    Number(
                      customerMarketingFirst_Four_Total_Data[0].TRANS_TY_VS_LLY
                    )
                      .toFixed(2)
                      .includes("-") ? (
                      <span style={{ color: "red", fontSize: "11px" }}>
                        {customerMarketingFirst_Four_Total_Data !== undefined &&
                          customerMarketingFirst_Four_Total_Data.length !== 0 &&
                          (customerMarketingFirst_Four_Total_Data[0]
                            .TRANS_TY_VS_LLY === "-999999"
                            ? "-"
                            : `LLY ${Number(
                                customerMarketingFirst_Four_Total_Data[0]
                                  .TRANS_TY_VS_LLY
                              ).toFixed(2)}%`)}
                      </span>
                    ) : (
                      <span style={{ color: "green", fontSize: "11px" }}>
                        {customerMarketingFirst_Four_Total_Data !== undefined &&
                          customerMarketingFirst_Four_Total_Data.length !== 0 &&
                          (customerMarketingFirst_Four_Total_Data[0]
                            .TRANS_TY_VS_LLY === "-999999"
                            ? "-"
                            : `LLY +${Number(
                                customerMarketingFirst_Four_Total_Data[0]
                                  .TRANS_TY_VS_LLY
                              ).toFixed(2)}%`)}
                      </span>
                    )}
                  </th>
                  <th>
                    {customerMarketingFirst_Four_Total_Data &&
                      customerMarketingFirst_Four_Total_Data !== undefined &&
                      customerMarketingFirst_Four_Total_Data.length !== 0 &&
                      (customerMarketingFirst_Four_Total_Data[0].PM_TY ===
                      "-999999"
                        ? "-"
                        : "$" +
                          currencyFormat(
                            Number(
                              customerMarketingFirst_Four_Total_Data[0].PM_TY
                            )
                          ))}
                    <br />
                    {customerMarketingFirst_Four_Total_Data !== undefined &&
                    customerMarketingFirst_Four_Total_Data.length !== 0 &&
                    Number(
                      customerMarketingFirst_Four_Total_Data[0].PM_TY_VS_LY
                    )
                      .toFixed(2)
                      .includes("-") ? (
                      <span style={{ color: "red", fontSize: "12px" }}>
                        {customerMarketingFirst_Four_Total_Data !== undefined &&
                          customerMarketingFirst_Four_Total_Data.length !== 0 &&
                          (customerMarketingFirst_Four_Total_Data[0]
                            .PM_TY_VS_LY === "-999999"
                            ? "-"
                            : `LY ${Number(
                                customerMarketingFirst_Four_Total_Data[0]
                                  .PM_TY_VS_LY
                              ).toFixed(2)}%`)}
                      </span>
                    ) : (
                      <span style={{ color: "green", fontSize: "12px" }}>
                        {customerMarketingFirst_Four_Total_Data !== undefined &&
                          customerMarketingFirst_Four_Total_Data.length !== 0 &&
                          (customerMarketingFirst_Four_Total_Data[0]
                            .PM_TY_VS_LY === "-999999"
                            ? "-"
                            : `LY +${Number(
                                customerMarketingFirst_Four_Total_Data[0]
                                  .PM_TY_VS_LY
                              ).toFixed(2)}%`)}
                      </span>
                    )}
                    <br />
                    {customerMarketingFirst_Four_Total_Data !== undefined &&
                    customerMarketingFirst_Four_Total_Data.length !== 0 &&
                    Number(
                      customerMarketingFirst_Four_Total_Data[0].PM_TY_VS_LLY
                    )
                      .toFixed(2)
                      .includes("-") ? (
                      <span style={{ color: "red", fontSize: "11px" }}>
                        {customerMarketingFirst_Four_Total_Data !== undefined &&
                          customerMarketingFirst_Four_Total_Data.length !== 0 &&
                          (customerMarketingFirst_Four_Total_Data[0]
                            .PM_TY_VS_LLY === "-999999"
                            ? "-"
                            : `LLY ${Number(
                                customerMarketingFirst_Four_Total_Data[0]
                                  .PM_TY_VS_LLY
                              ).toFixed(2)}%`)}
                      </span>
                    ) : (
                      <span style={{ color: "green", fontSize: "11px" }}>
                        {customerMarketingFirst_Four_Total_Data !== undefined &&
                          customerMarketingFirst_Four_Total_Data.length !== 0 &&
                          (customerMarketingFirst_Four_Total_Data[0]
                            .PM_TY_VS_LLY === "-999999"
                            ? "-"
                            : `LLY +${Number(
                                customerMarketingFirst_Four_Total_Data[0]
                                  .PM_TY_VS_LLY
                              ).toFixed(2)}%`)}
                      </span>
                    )}
                  </th>
                  <th>
                    {customerMarketingFirst_Four_Total_Data &&
                      customerMarketingFirst_Four_Total_Data !== undefined &&
                      customerMarketingFirst_Four_Total_Data.length !== 0 &&
                      (customerMarketingFirst_Four_Total_Data[0].AOV_TY ===
                      "-999999"
                        ? "-"
                        : "$" +
                          Number(
                            customerMarketingFirst_Four_Total_Data[0].AOV_TY
                          ).toFixed(2))}
                    <br />
                    {customerMarketingFirst_Four_Total_Data !== undefined &&
                    customerMarketingFirst_Four_Total_Data.length !== 0 &&
                    Number(
                      customerMarketingFirst_Four_Total_Data[0].AOV_TY_VS_LY
                    )
                      .toFixed(2)
                      .includes("-") ? (
                      <span style={{ color: "red", fontSize: "12px" }}>
                        {customerMarketingFirst_Four_Total_Data !== undefined &&
                          customerMarketingFirst_Four_Total_Data.length !== 0 &&
                          (customerMarketingFirst_Four_Total_Data[0]
                            .AOV_TY_VS_LY === "-999999"
                            ? "-"
                            : `LY ${Number(
                                customerMarketingFirst_Four_Total_Data[0]
                                  .AOV_TY_VS_LY
                              ).toFixed(2)}%`)}
                      </span>
                    ) : (
                      <span style={{ color: "green", fontSize: "12px" }}>
                        {customerMarketingFirst_Four_Total_Data !== undefined &&
                          customerMarketingFirst_Four_Total_Data.length !== 0 &&
                          (customerMarketingFirst_Four_Total_Data[0]
                            .AOV_TY_VS_LY === "-999999"
                            ? "-"
                            : `LY +${Number(
                                customerMarketingFirst_Four_Total_Data[0]
                                  .AOV_TY_VS_LY
                              ).toFixed(2)}%`)}
                      </span>
                    )}
                    <br />
                    {customerMarketingFirst_Four_Total_Data !== undefined &&
                    customerMarketingFirst_Four_Total_Data.length !== 0 &&
                    Number(
                      customerMarketingFirst_Four_Total_Data[0].AOV_TY_VS_LLY
                    )
                      .toFixed(2)
                      .includes("-") ? (
                      <span style={{ color: "red", fontSize: "11px" }}>
                        {customerMarketingFirst_Four_Total_Data !== undefined &&
                          customerMarketingFirst_Four_Total_Data.length !== 0 &&
                          (customerMarketingFirst_Four_Total_Data[0]
                            .AOV_TY_VS_LLY === "-999999"
                            ? "-"
                            : `LLY ${Number(
                                customerMarketingFirst_Four_Total_Data[0]
                                  .AOV_TY_VS_LLY
                              ).toFixed(2)}%`)}
                      </span>
                    ) : (
                      <span style={{ color: "green", fontSize: "11px" }}>
                        {customerMarketingFirst_Four_Total_Data !== undefined &&
                          customerMarketingFirst_Four_Total_Data.length !== 0 &&
                          (customerMarketingFirst_Four_Total_Data[0]
                            .AOV_TY_VS_LLY === "-999999"
                            ? "-"
                            : `LLY +${Number(
                                customerMarketingFirst_Four_Total_Data[0]
                                  .AOV_TY_VS_LLY
                              ).toFixed(2)}%`)}
                      </span>
                    )}
                  </th>
                  <th>
                    {customerMarketingFirst_Four_Total_Data &&
                      customerMarketingFirst_Four_Total_Data !== undefined &&
                      customerMarketingFirst_Four_Total_Data.length !== 0 &&
                      (customerMarketingFirst_Four_Total_Data[0].UPT_TY ===
                      "-999999"
                        ? "-"
                        : Number(
                            customerMarketingFirst_Four_Total_Data[0].UPT_TY
                          ).toFixed(1))}
                    <br />
                    {customerMarketingFirst_Four_Total_Data !== undefined &&
                    customerMarketingFirst_Four_Total_Data.length !== 0 &&
                    Number(
                      customerMarketingFirst_Four_Total_Data[0].UPT_TY_VS_LY
                    )
                      .toFixed(2)
                      .includes("-") ? (
                      <span style={{ color: "red", fontSize: "12px" }}>
                        {customerMarketingFirst_Four_Total_Data !== undefined &&
                          customerMarketingFirst_Four_Total_Data.length !== 0 &&
                          (customerMarketingFirst_Four_Total_Data[0]
                            .UPT_TY_VS_LY === "-999999"
                            ? "-"
                            : `LY ${Number(
                                customerMarketingFirst_Four_Total_Data[0]
                                  .UPT_TY_VS_LY
                              ).toFixed(2)}%`)}
                      </span>
                    ) : (
                      <span style={{ color: "green", fontSize: "12px" }}>
                        {customerMarketingFirst_Four_Total_Data !== undefined &&
                          customerMarketingFirst_Four_Total_Data.length !== 0 &&
                          (customerMarketingFirst_Four_Total_Data[0]
                            .UPT_TY_VS_LY === "-999999"
                            ? "-"
                            : `LY +${Number(
                                customerMarketingFirst_Four_Total_Data[0]
                                  .UPT_TY_VS_LY
                              ).toFixed(2)}%`)}
                      </span>
                    )}
                    <br />
                    {customerMarketingFirst_Four_Total_Data !== undefined &&
                    customerMarketingFirst_Four_Total_Data.length !== 0 &&
                    Number(
                      customerMarketingFirst_Four_Total_Data[0].UPT_TY_VS_LLY
                    )
                      .toFixed(2)
                      .includes("-") ? (
                      <span style={{ color: "red", fontSize: "11px" }}>
                        {customerMarketingFirst_Four_Total_Data !== undefined &&
                          customerMarketingFirst_Four_Total_Data.length !== 0 &&
                          (customerMarketingFirst_Four_Total_Data[0]
                            .UPT_TY_VS_LLY === "-999999"
                            ? "-"
                            : `LLY ${Number(
                                customerMarketingFirst_Four_Total_Data[0]
                                  .UPT_TY_VS_LLY
                              ).toFixed(2)}%`)}
                      </span>
                    ) : (
                      <span style={{ color: "green", fontSize: "11px" }}>
                        {customerMarketingFirst_Four_Total_Data !== undefined &&
                          customerMarketingFirst_Four_Total_Data.length !== 0 &&
                          (customerMarketingFirst_Four_Total_Data[0]
                            .UPT_TY_VS_LLY === "-999999"
                            ? "-"
                            : `LLY +${Number(
                                customerMarketingFirst_Four_Total_Data[0]
                                  .UPT_TY_VS_LLY
                              ).toFixed(2)}%`)}
                      </span>
                    )}
                  </th>
                  <th>
                    {customerMarketingFirst_Four_Total_Data &&
                      customerMarketingFirst_Four_Total_Data !== undefined &&
                      customerMarketingFirst_Four_Total_Data.length !== 0 &&
                      (customerMarketingFirst_Four_Total_Data[0].AUR_TY ===
                      "-999999"
                        ? "-"
                        : "$" +
                          Number(
                            customerMarketingFirst_Four_Total_Data[0].AUR_TY
                          ).toFixed(2))}
                    <br />
                    {customerMarketingFirst_Four_Total_Data !== undefined &&
                    customerMarketingFirst_Four_Total_Data.length !== 0 &&
                    Number(
                      customerMarketingFirst_Four_Total_Data[0].AUR_TY_VS_LY
                    )
                      .toFixed(2)
                      .includes("-") ? (
                      <span style={{ color: "red", fontSize: "12px" }}>
                        {customerMarketingFirst_Four_Total_Data !== undefined &&
                          customerMarketingFirst_Four_Total_Data.length !== 0 &&
                          (customerMarketingFirst_Four_Total_Data[0]
                            .AUR_TY_VS_LY === "-999999"
                            ? "-"
                            : `LY ${Number(
                                customerMarketingFirst_Four_Total_Data[0]
                                  .AUR_TY_VS_LY
                              ).toFixed(2)}%`)}
                      </span>
                    ) : (
                      <span style={{ color: "green", fontSize: "12px" }}>
                        {customerMarketingFirst_Four_Total_Data !== undefined &&
                          customerMarketingFirst_Four_Total_Data.length !== 0 &&
                          (customerMarketingFirst_Four_Total_Data[0]
                            .AUR_TY_VS_LY === "-999999"
                            ? "-"
                            : `LY +${Number(
                                customerMarketingFirst_Four_Total_Data[0]
                                  .AUR_TY_VS_LY
                              ).toFixed(2)}%`)}
                      </span>
                    )}
                    <br />
                    {customerMarketingFirst_Four_Total_Data !== undefined &&
                    customerMarketingFirst_Four_Total_Data.length !== 0 &&
                    Number(
                      customerMarketingFirst_Four_Total_Data[0].AUR_TY_VS_LLY
                    )
                      .toFixed(2)
                      .includes("-") ? (
                      <span style={{ color: "red", fontSize: "11px" }}>
                        {customerMarketingFirst_Four_Total_Data !== undefined &&
                          customerMarketingFirst_Four_Total_Data.length !== 0 &&
                          (customerMarketingFirst_Four_Total_Data[0]
                            .AUR_TY_VS_LLY === "-999999"
                            ? "-"
                            : `LLY ${Number(
                                customerMarketingFirst_Four_Total_Data[0]
                                  .AUR_TY_VS_LLY
                              ).toFixed(2)}%`)}
                      </span>
                    ) : (
                      <span style={{ color: "green", fontSize: "11px" }}>
                        {customerMarketingFirst_Four_Total_Data !== undefined &&
                          customerMarketingFirst_Four_Total_Data.length !== 0 &&
                          (customerMarketingFirst_Four_Total_Data[0]
                            .AUR_TY_VS_LLY === "-999999"
                            ? "-"
                            : `LLY +${Number(
                                customerMarketingFirst_Four_Total_Data[0]
                                  .AUR_TY_VS_LLY
                              ).toFixed(2)}%`)}
                      </span>
                    )}
                  </th>
                  <th>
                    {customerMarketingFirst_Four_Total_Data &&
                      customerMarketingFirst_Four_Total_Data !== undefined &&
                      customerMarketingFirst_Four_Total_Data.length !== 0 &&
                      (customerMarketingFirst_Four_Total_Data[0]
                        .MARGIN_RATE_PER_TY === "-999999"
                        ? "-"
                        : Number(
                            customerMarketingFirst_Four_Total_Data[0]
                              .MARGIN_RATE_PER_TY
                          ).toFixed(2))}
                    <br />
                    {customerMarketingFirst_Four_Total_Data !== undefined &&
                    customerMarketingFirst_Four_Total_Data.length !== 0 &&
                    Number(
                      customerMarketingFirst_Four_Total_Data[0]
                        .MARGIN_RATE_PER_TY_VS_LY
                    )
                      .toFixed(2)
                      .includes("-") ? (
                      <span style={{ color: "red", fontSize: "12px" }}>
                        {customerMarketingFirst_Four_Total_Data !== undefined &&
                          customerMarketingFirst_Four_Total_Data.length !== 0 &&
                          (customerMarketingFirst_Four_Total_Data[0]
                            .MARGIN_RATE_PER_TY_VS_LY === "-999999"
                            ? "-"
                            : `LY ${Number(
                                customerMarketingFirst_Four_Total_Data[0]
                                  .MARGIN_RATE_PER_TY_VS_LY
                              ).toFixed(2)}%`)}
                      </span>
                    ) : (
                      <span style={{ color: "green", fontSize: "12px" }}>
                        {customerMarketingFirst_Four_Total_Data !== undefined &&
                          customerMarketingFirst_Four_Total_Data.length !== 0 &&
                          (customerMarketingFirst_Four_Total_Data[0]
                            .MARGIN_RATE_PER_TY_VS_LY === "-999999"
                            ? "-"
                            : `LY +${Number(
                                customerMarketingFirst_Four_Total_Data[0]
                                  .MARGIN_RATE_PER_TY_VS_LY
                              ).toFixed(2)}%`)}
                      </span>
                    )}
                    <br />
                    {customerMarketingFirst_Four_Total_Data !== undefined &&
                    customerMarketingFirst_Four_Total_Data.length !== 0 &&
                    Number(
                      customerMarketingFirst_Four_Total_Data[0]
                        .MARGIN_RATE_PER_TY_VS_LLY
                    )
                      .toFixed(2)
                      .includes("-") ? (
                      <span style={{ color: "red", fontSize: "11px" }}>
                        {customerMarketingFirst_Four_Total_Data !== undefined &&
                          customerMarketingFirst_Four_Total_Data.length !== 0 &&
                          (customerMarketingFirst_Four_Total_Data[0]
                            .MARGIN_RATE_PER_TY_VS_LLY === "-999999"
                            ? "-"
                            : `LLY ${Number(
                                customerMarketingFirst_Four_Total_Data[0]
                                  .MARGIN_RATE_PER_TY_VS_LLY
                              ).toFixed(2)}%`)}
                      </span>
                    ) : (
                      <span style={{ color: "green", fontSize: "11px" }}>
                        {customerMarketingFirst_Four_Total_Data !== undefined &&
                          customerMarketingFirst_Four_Total_Data.length !== 0 &&
                          (customerMarketingFirst_Four_Total_Data[0]
                            .MARGIN_RATE_PER_TY_VS_LLY === "-999999"
                            ? "-"
                            : `LLY +${Number(
                                customerMarketingFirst_Four_Total_Data[0]
                                  .MARGIN_RATE_PER_TY_VS_LLY
                              ).toFixed(2)}%`)}
                      </span>
                    )}
                  </th>
                  <th>
                    {customerMarketingFirst_Four_Total_Data &&
                      customerMarketingFirst_Four_Total_Data !== undefined &&
                      customerMarketingFirst_Four_Total_Data.length !== 0 &&
                      (customerMarketingFirst_Four_Total_Data[0]
                        .NET_SALES_PER_CUST_TY === "-999999"
                        ? "-"
                        : "$" +
                          Number(
                            customerMarketingFirst_Four_Total_Data[0]
                              .NET_SALES_PER_CUST_TY
                          ).toFixed(2))}
                    <br />
                    {customerMarketingFirst_Four_Total_Data !== undefined &&
                    customerMarketingFirst_Four_Total_Data.length !== 0 &&
                    Number(
                      customerMarketingFirst_Four_Total_Data[0]
                        .NET_SALES_PER_CUST_TY_VS_LY
                    )
                      .toFixed(2)
                      .includes("-") ? (
                      <span style={{ color: "red", fontSize: "12px" }}>
                        {customerMarketingFirst_Four_Total_Data !== undefined &&
                          customerMarketingFirst_Four_Total_Data.length !== 0 &&
                          (customerMarketingFirst_Four_Total_Data[0]
                            .NET_SALES_PER_CUST_TY_VS_LY === "-999999"
                            ? "-"
                            : `LY ${Number(
                                customerMarketingFirst_Four_Total_Data[0]
                                  .NET_SALES_PER_CUST_TY_VS_LY
                              ).toFixed(2)}%`)}
                      </span>
                    ) : (
                      <span style={{ color: "green", fontSize: "12px" }}>
                        {customerMarketingFirst_Four_Total_Data !== undefined &&
                          customerMarketingFirst_Four_Total_Data.length !== 0 &&
                          (customerMarketingFirst_Four_Total_Data[0]
                            .NET_SALES_PER_CUST_TY_VS_LY === "-999999"
                            ? "-"
                            : `LY +${Number(
                                customerMarketingFirst_Four_Total_Data[0]
                                  .NET_SALES_PER_CUST_TY_VS_LY
                              ).toFixed(2)}%`)}
                      </span>
                    )}
                    <br />
                    {customerMarketingFirst_Four_Total_Data !== undefined &&
                    customerMarketingFirst_Four_Total_Data.length !== 0 &&
                    Number(
                      customerMarketingFirst_Four_Total_Data[0]
                        .NET_SALES_PER_CUST_TY_VS_LLY
                    )
                      .toFixed(2)
                      .includes("-") ? (
                      <span style={{ color: "red", fontSize: "11px" }}>
                        {customerMarketingFirst_Four_Total_Data !== undefined &&
                          customerMarketingFirst_Four_Total_Data.length !== 0 &&
                          (customerMarketingFirst_Four_Total_Data[0]
                            .NET_SALES_PER_CUST_TY_VS_LLY === "-999999"
                            ? "-"
                            : `LLY ${Number(
                                customerMarketingFirst_Four_Total_Data[0]
                                  .NET_SALES_PER_CUST_TY_VS_LLY
                              ).toFixed(2)}%`)}
                      </span>
                    ) : (
                      <span style={{ color: "green", fontSize: "11px" }}>
                        {customerMarketingFirst_Four_Total_Data !== undefined &&
                          customerMarketingFirst_Four_Total_Data.length !== 0 &&
                          (customerMarketingFirst_Four_Total_Data[0]
                            .NET_SALES_PER_CUST_TY_VS_LLY === "-999999"
                            ? "-"
                            : `LLY +${Number(
                                customerMarketingFirst_Four_Total_Data[0]
                                  .NET_SALES_PER_CUST_TY_VS_LLY
                              ).toFixed(2)}%`)}
                      </span>
                    )}
                  </th>
                  <th>
                    {customerMarketingFirst_Four_Total_Data &&
                      customerMarketingFirst_Four_Total_Data !== undefined &&
                      customerMarketingFirst_Four_Total_Data.length !== 0 &&
                      (customerMarketingFirst_Four_Total_Data[0].AVG_TRAN_TY ===
                      "-999999"
                        ? "-"
                        : Number(
                            customerMarketingFirst_Four_Total_Data[0]
                              .AVG_TRAN_TY
                          ).toFixed(2))}
                    <br />
                    {customerMarketingFirst_Four_Total_Data !== undefined &&
                    customerMarketingFirst_Four_Total_Data.length !== 0 &&
                    Number(
                      customerMarketingFirst_Four_Total_Data[0]
                        .AVG_TRAN_TY_VS_LY
                    )
                      .toFixed(2)
                      .includes("-") ? (
                      <span style={{ color: "red", fontSize: "12px" }}>
                        {customerMarketingFirst_Four_Total_Data !== undefined &&
                          customerMarketingFirst_Four_Total_Data.length !== 0 &&
                          (customerMarketingFirst_Four_Total_Data[0]
                            .AVG_TRAN_TY_VS_LY === "-999999"
                            ? "-"
                            : `LY ${Number(
                                customerMarketingFirst_Four_Total_Data[0]
                                  .AVG_TRAN_TY_VS_LY
                              ).toFixed(2)}%`)}
                      </span>
                    ) : (
                      <span style={{ color: "green", fontSize: "12px" }}>
                        {customerMarketingFirst_Four_Total_Data !== undefined &&
                          customerMarketingFirst_Four_Total_Data.length !== 0 &&
                          (customerMarketingFirst_Four_Total_Data[0]
                            .AVG_TRAN_TY_VS_LY === "-999999"
                            ? "-"
                            : `LY +${Number(
                                customerMarketingFirst_Four_Total_Data[0]
                                  .AVG_TRAN_TY_VS_LY
                              ).toFixed(2)}%`)}
                      </span>
                    )}
                    <br />
                    {customerMarketingFirst_Four_Total_Data !== undefined &&
                    customerMarketingFirst_Four_Total_Data.length !== 0 &&
                    Number(
                      customerMarketingFirst_Four_Total_Data[0]
                        .AVG_TRAN_TY_VS_LLY
                    )
                      .toFixed(2)
                      .includes("-") ? (
                      <span style={{ color: "red", fontSize: "11px" }}>
                        {customerMarketingFirst_Four_Total_Data !== undefined &&
                          customerMarketingFirst_Four_Total_Data.length !== 0 &&
                          (customerMarketingFirst_Four_Total_Data[0]
                            .AVG_TRAN_TY_VS_LLY === "-999999"
                            ? "-"
                            : `LLY ${Number(
                                customerMarketingFirst_Four_Total_Data[0]
                                  .AVG_TRAN_TY_VS_LLY
                              ).toFixed(2)}%`)}
                      </span>
                    ) : (
                      <span style={{ color: "green", fontSize: "11px" }}>
                        {customerMarketingFirst_Four_Total_Data !== undefined &&
                          customerMarketingFirst_Four_Total_Data.length !== 0 &&
                          (customerMarketingFirst_Four_Total_Data[0]
                            .AVG_TRAN_TY_VS_LLY === "-999999"
                            ? "-"
                            : `LLY +${Number(
                                customerMarketingFirst_Four_Total_Data[0]
                                  .AVG_TRAN_TY_VS_LLY
                              ).toFixed(2)}%`)}
                      </span>
                    )}
                  </th>
                </>
              )}
            </tr>
            <tr>
              <td
                className="tableCol"
                id={
                  selectedMarketingCategoryId !== "NR"
                    ? "Inactive_12_18"
                    : "Inactive12_18"
                }
                onClick={() =>
                  selectedMarketingCategoryId !== "NR"
                    ? handleModalOpen("Inactive (12m-18m)")
                    : ""
                }
              >
                {"Inactive (12m-18m)"}{" "}
                {gettooltip(
                  "InActive_12_18InfoIcon",
                  "InActive_12_18",
                  "InActive_12_18",
                  "Active in L12M-L18M but not active in L12M"
                )}
              </td>
              {loading.Inactive_12m_18m ? (
                <>
                  <LoaderForRow tdCount={10} />
                </>
              ) : (
                <>
                  <td>
                    {customerMarketingInActive_12_18_Data !== undefined &&
                      customerMarketingInActive_12_18_Data.length !== 0 &&
                      (customerMarketingInActive_12_18_Data[0].CUST_COUNT_TY ===
                      "-999999"
                        ? "-"
                        : currencyFormat(
                            Number(
                              customerMarketingInActive_12_18_Data[0]
                                .CUST_COUNT_TY
                            )
                          ))}
                    <br />
                    {customerMarketingInActive_12_18_Data !== undefined &&
                    customerMarketingInActive_12_18_Data.length !== 0 &&
                    Number(
                      customerMarketingInActive_12_18_Data[0].CUST_TY_VS_LY
                    )
                      .toFixed(2)
                      .includes("-") ? (
                      <span style={{ color: "green", fontSize: "12px" }}>
                        {customerMarketingInActive_12_18_Data !== undefined &&
                          customerMarketingInActive_12_18_Data.length !== 0 &&
                          (customerMarketingInActive_12_18_Data[0]
                            .CUST_TY_VS_LY === "-999999"
                            ? "-"
                            : `LY ${Number(
                                customerMarketingInActive_12_18_Data[0]
                                  .CUST_TY_VS_LY
                              ).toFixed(2)}%`)}
                      </span>
                    ) : (
                      <span style={{ color: "red", fontSize: "12px" }}>
                        {customerMarketingInActive_12_18_Data !== undefined &&
                          customerMarketingInActive_12_18_Data.length !== 0 &&
                          (customerMarketingInActive_12_18_Data[0]
                            .CUST_TY_VS_LY === "-999999"
                            ? "-"
                            : `LY +${Number(
                                customerMarketingInActive_12_18_Data[0]
                                  .CUST_TY_VS_LY
                              ).toFixed(2)}%`)}
                      </span>
                    )}
                    <br />
                    {customerMarketingInActive_12_18_Data !== undefined &&
                    customerMarketingInActive_12_18_Data.length !== 0 &&
                    Number(
                      customerMarketingInActive_12_18_Data[0].CUST_TY_VS_LLY
                    )
                      .toFixed(2)
                      .includes("-") ? (
                      <span style={{ color: "green", fontSize: "11px" }}>
                        {customerMarketingInActive_12_18_Data !== undefined &&
                          customerMarketingInActive_12_18_Data.length !== 0 &&
                          (customerMarketingInActive_12_18_Data[0]
                            .CUST_TY_VS_LLY === "-999999"
                            ? "-"
                            : `LLY ${Number(
                                customerMarketingInActive_12_18_Data[0]
                                  .CUST_TY_VS_LLY
                              ).toFixed(2)}%`)}
                      </span>
                    ) : (
                      <span style={{ color: "red", fontSize: "11px" }}>
                        {customerMarketingInActive_12_18_Data !== undefined &&
                          customerMarketingInActive_12_18_Data.length !== 0 &&
                          (customerMarketingInActive_12_18_Data[0]
                            .CUST_TY_VS_LLY === "-999999"
                            ? "-"
                            : `LLY +${Number(
                                customerMarketingInActive_12_18_Data[0]
                                  .CUST_TY_VS_LLY
                              ).toFixed(2)}%`)}
                      </span>
                    )}
                  </td>
                  <td>
                    <br />
                    {customerMarketingInActive_12_18_Data !== undefined &&
                      customerMarketingInActive_12_18_Data.length !== 0 &&
                      "NA"}
                  </td>
                  <td>
                    <br />
                    {customerMarketingInActive_12_18_Data !== undefined &&
                      customerMarketingInActive_12_18_Data.length !== 0 &&
                      "NA"}
                  </td>
                  <td>
                    <br />
                    {customerMarketingInActive_12_18_Data !== undefined &&
                      customerMarketingInActive_12_18_Data.length !== 0 &&
                      "NA"}
                  </td>
                  <td>
                    <br />
                    {customerMarketingInActive_12_18_Data !== undefined &&
                      customerMarketingInActive_12_18_Data.length !== 0 &&
                      "NA"}
                  </td>
                  <td>
                    <br />
                    {customerMarketingInActive_12_18_Data !== undefined &&
                      customerMarketingInActive_12_18_Data.length !== 0 &&
                      "NA"}
                  </td>
                  <td>
                    <br />
                    {customerMarketingInActive_12_18_Data !== undefined &&
                      customerMarketingInActive_12_18_Data.length !== 0 &&
                      "NA"}
                  </td>
                  <td>
                    <br />
                    {customerMarketingInActive_12_18_Data !== undefined &&
                      customerMarketingInActive_12_18_Data.length !== 0 &&
                      "NA"}
                  </td>
                  <td>
                    <br />
                    {customerMarketingInActive_12_18_Data !== undefined &&
                      customerMarketingInActive_12_18_Data.length !== 0 &&
                      "NA"}
                  </td>
                  <td>
                    <br />
                    {customerMarketingInActive_12_18_Data !== undefined &&
                      customerMarketingInActive_12_18_Data.length !== 0 &&
                      "NA"}
                  </td>
                </>
              )}
            </tr>
            <tr>
              <td
                className="tableCol"
                id={
                  selectedMarketingCategoryId !== "NR"
                    ? "Inactive_18_24"
                    : "Inactive18_24"
                }
                onClick={() =>
                  selectedMarketingCategoryId !== "NR"
                    ? handleModalOpen("Inactive (18m-24m)")
                    : ""
                }
              >
                {"Inactive (18m-24m)"}{" "}
                {gettooltip(
                  "InActive_18_24InfoIcon",
                  "InActive_18_24",
                  "InActive_18_24",
                  "Active in L18M-L24M but not active in L18M"
                )}
              </td>
              {loading.Inactive_18m_24m ? (
                <>
                  <LoaderForRow tdCount={10} />
                </>
              ) : (
                <>
                  <td>
                    {customerMarketingInActive_18_24_Data !== undefined &&
                      customerMarketingInActive_18_24_Data.length !== 0 &&
                      (customerMarketingInActive_18_24_Data[0].CUST_COUNT_TY ===
                      "-999999"
                        ? "-"
                        : currencyFormat(
                            Number(
                              customerMarketingInActive_18_24_Data[0]
                                .CUST_COUNT_TY
                            )
                          ))}
                    <br />
                    {customerMarketingInActive_18_24_Data !== undefined &&
                    customerMarketingInActive_18_24_Data.length !== 0 &&
                    Number(
                      customerMarketingInActive_18_24_Data[0].CUST_TY_VS_LY
                    )
                      .toFixed(2)
                      .includes("-") ? (
                      <span style={{ color: "green", fontSize: "12px" }}>
                        {customerMarketingInActive_18_24_Data !== undefined &&
                          customerMarketingInActive_18_24_Data.length !== 0 &&
                          (customerMarketingInActive_18_24_Data[0]
                            .CUST_TY_VS_LY === "-999999"
                            ? "-"
                            : `LY ${Number(
                                customerMarketingInActive_18_24_Data[0]
                                  .CUST_TY_VS_LY
                              ).toFixed(2)}%`)}
                      </span>
                    ) : (
                      <span style={{ color: "red", fontSize: "12px" }}>
                        {customerMarketingInActive_18_24_Data !== undefined &&
                          customerMarketingInActive_18_24_Data.length !== 0 &&
                          (customerMarketingInActive_18_24_Data[0]
                            .CUST_TY_VS_LY === "-999999"
                            ? "-"
                            : `LY +${Number(
                                customerMarketingInActive_18_24_Data[0]
                                  .CUST_TY_VS_LY
                              ).toFixed(2)}%`)}
                      </span>
                    )}
                    <br />
                    {customerMarketingInActive_18_24_Data !== undefined &&
                    customerMarketingInActive_18_24_Data.length !== 0 &&
                    Number(
                      customerMarketingInActive_18_24_Data[0].CUST_TY_VS_LLY
                    )
                      .toFixed(2)
                      .includes("-") ? (
                      <span style={{ color: "green", fontSize: "11px" }}>
                        {customerMarketingInActive_18_24_Data !== undefined &&
                          customerMarketingInActive_18_24_Data.length !== 0 &&
                          (customerMarketingInActive_18_24_Data[0]
                            .CUST_TY_VS_LLY === "-999999"
                            ? "-"
                            : `LLY ${Number(
                                customerMarketingInActive_18_24_Data[0]
                                  .CUST_TY_VS_LLY
                              ).toFixed(2)}%`)}
                      </span>
                    ) : (
                      <span style={{ color: "red", fontSize: "11px" }}>
                        {customerMarketingInActive_18_24_Data !== undefined &&
                          customerMarketingInActive_18_24_Data.length !== 0 &&
                          (customerMarketingInActive_18_24_Data[0]
                            .CUST_TY_VS_LLY === "-999999"
                            ? "-"
                            : `LLY +${Number(
                                customerMarketingInActive_18_24_Data[0]
                                  .CUST_TY_VS_LLY
                              ).toFixed(2)}%`)}
                      </span>
                    )}
                  </td>
                  <td>
                    <br />
                    {customerMarketingInActive_18_24_Data !== undefined &&
                      customerMarketingInActive_18_24_Data.length !== 0 &&
                      "NA"}
                  </td>
                  <td>
                    <br />
                    {customerMarketingInActive_18_24_Data !== undefined &&
                      customerMarketingInActive_18_24_Data.length !== 0 &&
                      "NA"}
                  </td>
                  <td>
                    <br />
                    {customerMarketingInActive_18_24_Data !== undefined &&
                      customerMarketingInActive_18_24_Data.length !== 0 &&
                      "NA"}
                  </td>
                  <td>
                    <br />
                    {customerMarketingInActive_18_24_Data !== undefined &&
                      customerMarketingInActive_18_24_Data.length !== 0 &&
                      "NA"}
                  </td>
                  <td>
                    <br />
                    {customerMarketingInActive_18_24_Data !== undefined &&
                      customerMarketingInActive_18_24_Data.length !== 0 &&
                      "NA"}
                  </td>
                  <td>
                    <br />
                    {customerMarketingInActive_18_24_Data !== undefined &&
                      customerMarketingInActive_18_24_Data.length !== 0 &&
                      "NA"}
                  </td>
                  <td>
                    <br />{" "}
                    {customerMarketingInActive_18_24_Data !== undefined &&
                      customerMarketingInActive_18_24_Data.length !== 0 &&
                      "NA"}
                  </td>
                  <td>
                    <br />{" "}
                    {customerMarketingInActive_18_24_Data !== undefined &&
                      customerMarketingInActive_18_24_Data.length !== 0 &&
                      "NA"}
                  </td>
                  <td>
                    <br />
                    {customerMarketingInActive_18_24_Data !== undefined &&
                      customerMarketingInActive_18_24_Data.length !== 0 &&
                      "NA"}
                  </td>
                </>
              )}
            </tr>
            <tr>
              <td className="tableTotalCol">
                <b>{"Sub Total"}</b>
              </td>
              {loading.second_half_total ? (
                <>
                  <LoaderForRow tdCount={10} />
                </>
              ) : (
                <>
                  <th>
                    {customerMarketingSecond_half_total_Data !== undefined &&
                      customerMarketingSecond_half_total_Data.length !== 0 &&
                      (customerMarketingSecond_half_total_Data[0]
                        .CUST_COUNT_TY === "-999999"
                        ? "-"
                        : currencyFormat(
                            Number(
                              customerMarketingSecond_half_total_Data[0]
                                .CUST_COUNT_TY
                            )
                          ))}
                    <br />
                    {customerMarketingSecond_half_total_Data !== undefined &&
                    customerMarketingSecond_half_total_Data.length !== 0 &&
                    Number(
                      customerMarketingSecond_half_total_Data[0].CUST_TY_VS_LY
                    )
                      .toFixed(2)
                      .includes("-") ? (
                      <span style={{ color: "green", fontSize: "12px" }}>
                        {customerMarketingSecond_half_total_Data !==
                          undefined &&
                          customerMarketingSecond_half_total_Data.length !==
                            0 &&
                          (customerMarketingSecond_half_total_Data[0]
                            .CUST_TY_VS_LY === "-999999"
                            ? "-"
                            : `LY ${Number(
                                customerMarketingSecond_half_total_Data[0]
                                  .CUST_TY_VS_LY
                              ).toFixed(2)}%`)}
                      </span>
                    ) : (
                      <span style={{ color: "red", fontSize: "12px" }}>
                        {customerMarketingSecond_half_total_Data !==
                          undefined &&
                          customerMarketingSecond_half_total_Data.length !==
                            0 &&
                          (customerMarketingSecond_half_total_Data[0]
                            .CUST_TY_VS_LY === "-999999"
                            ? "-"
                            : `LY +${Number(
                                customerMarketingSecond_half_total_Data[0]
                                  .CUST_TY_VS_LY
                              ).toFixed(2)}%`)}
                      </span>
                    )}
                    <br />
                    {customerMarketingSecond_half_total_Data !== undefined &&
                    customerMarketingSecond_half_total_Data.length !== 0 &&
                    Number(
                      customerMarketingSecond_half_total_Data[0].CUST_TY_VS_LLY
                    )
                      .toFixed(2)
                      .includes("-") ? (
                      <span style={{ color: "green", fontSize: "11px" }}>
                        {customerMarketingSecond_half_total_Data !==
                          undefined &&
                          customerMarketingSecond_half_total_Data.length !==
                            0 &&
                          (customerMarketingSecond_half_total_Data[0]
                            .CUST_TY_VS_LLY === "-999999"
                            ? "-"
                            : `LLY ${Number(
                                customerMarketingSecond_half_total_Data[0]
                                  .CUST_TY_VS_LLY
                              ).toFixed(2)}%`)}
                      </span>
                    ) : (
                      <span style={{ color: "red", fontSize: "11px" }}>
                        {customerMarketingSecond_half_total_Data !==
                          undefined &&
                          customerMarketingSecond_half_total_Data.length !==
                            0 &&
                          (customerMarketingSecond_half_total_Data[0]
                            .CUST_TY_VS_LLY === "-999999"
                            ? "-"
                            : `LLY +${Number(
                                customerMarketingSecond_half_total_Data[0]
                                  .CUST_TY_VS_LLY
                              ).toFixed(2)}%`)}
                      </span>
                    )}
                  </th>
                  <th></th>
                  <th></th>
                  <th></th>
                  <th></th>
                  <th></th>
                  <th></th>
                  <th></th>
                  <th></th>
                  <th></th>
                </>
              )}
            </tr>
            <tr>
              <td className="tableTotalColumn">
                <b>{"Total"}</b>{" "}
                {gettooltip(
                  "TotalInfoIcon",
                  "Total",
                  "Total",
                  "Active Customers + Inactive Customers"
                )}
              </td>
              {loading.total ? (
                <>
                  <LoaderForRow tdCount={10} />
                </>
              ) : (
                <>
                  <th>
                    {marketingTotal !== undefined &&
                      marketingTotal.length !== 0 &&
                      (marketingTotal[0].CUST_COUNT_TY === "-999999"
                        ? "-"
                        : currencyFormat(
                            Number(marketingTotal[0].CUST_COUNT_TY)
                          ))}
                    <br />
                    {marketingTotal !== undefined &&
                    marketingTotal.length !== 0 &&
                    Number(marketingTotal[0].CUST_TY_VS_LY)
                      .toFixed(2)
                      .includes("-") ? (
                      <span style={{ color: "red", fontSize: "12px" }}>
                        {marketingTotal !== undefined &&
                          marketingTotal.length !== 0 &&
                          (marketingTotal[0].CUST_TY_VS_LY === "-999999"
                            ? "-"
                            : `LY ${Number(
                                marketingTotal[0].CUST_TY_VS_LY
                              ).toFixed(2)}%`)}
                      </span>
                    ) : (
                      <span style={{ color: "green", fontSize: "12px" }}>
                        {marketingTotal !== undefined &&
                          marketingTotal.length !== 0 &&
                          (marketingTotal[0].CUST_TY_VS_LY === "-999999"
                            ? "-"
                            : `LY +${Number(
                                marketingTotal[0].CUST_TY_VS_LY
                              ).toFixed(2)}%`)}
                      </span>
                    )}
                    <br />
                    {marketingTotal !== undefined &&
                    marketingTotal.length !== 0 &&
                    Number(marketingTotal[0].CUST_TY_VS_LLY)
                      .toFixed(2)
                      .includes("-") ? (
                      <span style={{ color: "red", fontSize: "11px" }}>
                        {marketingTotal !== undefined &&
                          marketingTotal.length !== 0 &&
                          (marketingTotal[0].CUST_TY_VS_LLY === "-999999"
                            ? "-"
                            : `LLY ${Number(
                                marketingTotal[0].CUST_TY_VS_LLY
                              ).toFixed(2)}%`)}
                      </span>
                    ) : (
                      <span style={{ color: "green", fontSize: "11px" }}>
                        {marketingTotal !== undefined &&
                          marketingTotal.length !== 0 &&
                          (marketingTotal[0].CUST_TY_VS_LLY === "-999999"
                            ? "-"
                            : `LLY +${Number(
                                marketingTotal[0].CUST_TY_VS_LLY
                              ).toFixed(2)}%`)}
                      </span>
                    )}
                  </th>
                  <th>
                    {marketingTotal !== undefined &&
                      marketingTotal.length !== 0 &&
                      (marketingTotal[0].NET_SALES_TY === "-999999"
                        ? "-"
                        : "$" +
                          currencyFormat(
                            Number(marketingTotal[0].NET_SALES_TY)
                          ))}
                    <br />
                    {marketingTotal !== undefined &&
                    marketingTotal.length !== 0 &&
                    Number(marketingTotal[0].NET_SALES_TY_VS_LY)
                      .toFixed(2)
                      .includes("-") ? (
                      <span style={{ color: "red", fontSize: "12px" }}>
                        {marketingTotal !== undefined &&
                          marketingTotal.length !== 0 &&
                          (marketingTotal[0].NET_SALES_TY_VS_LY === "-999999"
                            ? "-"
                            : `LY ${Number(
                                marketingTotal[0].NET_SALES_TY_VS_LY
                              ).toFixed(2)}%`)}
                      </span>
                    ) : (
                      <span style={{ color: "green", fontSize: "12px" }}>
                        {marketingTotal !== undefined &&
                          marketingTotal.length !== 0 &&
                          (marketingTotal[0].NET_SALES_TY_VS_LY === "-999999"
                            ? "-"
                            : `LY +${Number(
                                marketingTotal[0].NET_SALES_TY_VS_LY
                              ).toFixed(2)}%`)}
                      </span>
                    )}
                    <br />
                    {marketingTotal !== undefined &&
                    marketingTotal.length !== 0 &&
                    Number(marketingTotal[0].NET_SALES_TY_VS_LLY)
                      .toFixed(2)
                      .includes("-") ? (
                      <span style={{ color: "red", fontSize: "11px" }}>
                        {marketingTotal !== undefined &&
                          marketingTotal.length !== 0 &&
                          (marketingTotal[0].NET_SALES_TY_VS_LLY === "-999999"
                            ? "-"
                            : `LLY ${Number(
                                marketingTotal[0].NET_SALES_TY_VS_LLY
                              ).toFixed(2)}%`)}
                      </span>
                    ) : (
                      <span style={{ color: "green", fontSize: "11px" }}>
                        {marketingTotal !== undefined &&
                          marketingTotal.length !== 0 &&
                          (marketingTotal[0].NET_SALES_TY_VS_LLY === "-999999"
                            ? "-"
                            : `LLY +${Number(
                                marketingTotal[0].NET_SALES_TY_VS_LLY
                              ).toFixed(2)}%`)}
                      </span>
                    )}
                  </th>
                  <th>
                    {marketingTotal !== undefined &&
                      marketingTotal.length !== 0 &&
                      (marketingTotal[0].TRANS_COUNT_TY === "-999999"
                        ? "-"
                        : currencyFormat(
                            Number(marketingTotal[0].TRANS_COUNT_TY)
                          ))}
                    <br />
                    {marketingTotal !== undefined &&
                    marketingTotal.length !== 0 &&
                    Number(marketingTotal[0].TRANS_TY_VS_LY)
                      .toFixed(2)
                      .includes("-") ? (
                      <span style={{ color: "red", fontSize: "12px" }}>
                        {marketingTotal !== undefined &&
                          marketingTotal.length !== 0 &&
                          (marketingTotal[0].TRANS_TY_VS_LY === "-999999"
                            ? "-"
                            : `LY ${Number(
                                marketingTotal[0].TRANS_TY_VS_LY
                              ).toFixed(2)}%`)}
                      </span>
                    ) : (
                      <span style={{ color: "green", fontSize: "12px" }}>
                        {marketingTotal !== undefined &&
                          marketingTotal.length !== 0 &&
                          (marketingTotal[0].TRANS_TY_VS_LY === "-999999"
                            ? "-"
                            : `LY +${Number(
                                marketingTotal[0].TRANS_TY_VS_LY
                              ).toFixed(2)}%`)}
                      </span>
                    )}
                    <br />
                    {marketingTotal !== undefined &&
                    marketingTotal.length !== 0 &&
                    Number(marketingTotal[0].TRANS_TY_VS_LLY)
                      .toFixed(2)
                      .includes("-") ? (
                      <span style={{ color: "red", fontSize: "11px" }}>
                        {marketingTotal !== undefined &&
                          marketingTotal.length !== 0 &&
                          (marketingTotal[0].TRANS_TY_VS_LLY === "-999999"
                            ? "-"
                            : `LLY ${Number(
                                marketingTotal[0].TRANS_TY_VS_LLY
                              ).toFixed(2)}%`)}
                      </span>
                    ) : (
                      <span style={{ color: "green", fontSize: "11px" }}>
                        {marketingTotal !== undefined &&
                          marketingTotal.length !== 0 &&
                          (marketingTotal[0].TRANS_TY_VS_LLY === "-999999"
                            ? "-"
                            : `LLY +${Number(
                                marketingTotal[0].TRANS_TY_VS_LLY
                              ).toFixed(2)}%`)}
                      </span>
                    )}
                  </th>
                  <th>
                    {marketingTotal !== undefined &&
                      marketingTotal.length !== 0 &&
                      (marketingTotal[0].PM_TY === "-999999"
                        ? "-"
                        : "$" +
                          currencyFormat(Number(marketingTotal[0].PM_TY)))}
                    <br />
                    {marketingTotal !== undefined &&
                    marketingTotal.length !== 0 &&
                    Number(marketingTotal[0].PM_TY_VS_LY)
                      .toFixed(2)
                      .includes("-") ? (
                      <span style={{ color: "red", fontSize: "12px" }}>
                        {marketingTotal !== undefined &&
                          marketingTotal.length !== 0 &&
                          (marketingTotal[0].PM_TY_VS_LY === "-999999"
                            ? "-"
                            : `LY ${Number(
                                marketingTotal[0].PM_TY_VS_LY
                              ).toFixed(2)}%`)}
                      </span>
                    ) : (
                      <span style={{ color: "green", fontSize: "12px" }}>
                        {marketingTotal !== undefined &&
                          marketingTotal.length !== 0 &&
                          (marketingTotal[0].PM_TY_VS_LY === "-999999"
                            ? "-"
                            : `LY +${Number(
                                marketingTotal[0].PM_TY_VS_LY
                              ).toFixed(2)}%`)}
                      </span>
                    )}
                    <br />
                    {marketingTotal !== undefined &&
                    marketingTotal.length !== 0 &&
                    Number(marketingTotal[0].PM_TY_VS_LLY)
                      .toFixed(2)
                      .includes("-") ? (
                      <span style={{ color: "red", fontSize: "11px" }}>
                        {marketingTotal !== undefined &&
                          marketingTotal.length !== 0 &&
                          (marketingTotal[0].PM_TY_VS_LLY === "-999999"
                            ? "-"
                            : `LLY ${Number(
                                marketingTotal[0].PM_TY_VS_LLY
                              ).toFixed(2)}%`)}
                      </span>
                    ) : (
                      <span style={{ color: "green", fontSize: "11px" }}>
                        {marketingTotal !== undefined &&
                          marketingTotal.length !== 0 &&
                          (marketingTotal[0].PM_TY_VS_LLY === "-999999"
                            ? "-"
                            : `LLY +${Number(
                                marketingTotal[0].PM_TY_VS_LLY
                              ).toFixed(2)}%`)}
                      </span>
                    )}
                  </th>
                  <th>
                    {marketingTotal !== undefined &&
                      marketingTotal.length !== 0 &&
                      (marketingTotal[0].AOV_TY === "-999999"
                        ? "-"
                        : "$" + Number(marketingTotal[0].AOV_TY).toFixed(2))}
                    <br />
                    {marketingTotal !== undefined &&
                    marketingTotal.length !== 0 &&
                    Number(marketingTotal[0].AOV_TY_VS_LY)
                      .toFixed(2)
                      .includes("-") ? (
                      <span style={{ color: "red", fontSize: "12px" }}>
                        {marketingTotal !== undefined &&
                          marketingTotal.length !== 0 &&
                          (marketingTotal[0].AOV_TY_VS_LY === "-999999"
                            ? "-"
                            : `LY ${Number(
                                marketingTotal[0].AOV_TY_VS_LY
                              ).toFixed(2)}%`)}
                      </span>
                    ) : (
                      <span style={{ color: "green", fontSize: "12px" }}>
                        {marketingTotal !== undefined &&
                          marketingTotal.length !== 0 &&
                          (marketingTotal[0].AOV_TY_VS_LY === "-999999"
                            ? "-"
                            : `LY +${Number(
                                marketingTotal[0].AOV_TY_VS_LY
                              ).toFixed(2)}%`)}
                      </span>
                    )}
                    <br />
                    {marketingTotal !== undefined &&
                    marketingTotal.length !== 0 &&
                    Number(marketingTotal[0].AOV_TY_VS_LLY)
                      .toFixed(2)
                      .includes("-") ? (
                      <span style={{ color: "red", fontSize: "11px" }}>
                        {marketingTotal !== undefined &&
                          marketingTotal.length !== 0 &&
                          (marketingTotal[0].AOV_TY_VS_LLY === "-999999"
                            ? "-"
                            : `LLY ${Number(
                                marketingTotal[0].AOV_TY_VS_LLY
                              ).toFixed(2)}%`)}
                      </span>
                    ) : (
                      <span style={{ color: "green", fontSize: "11px" }}>
                        {marketingTotal !== undefined &&
                          marketingTotal.length !== 0 &&
                          (marketingTotal[0].AOV_TY_VS_LLY === "-999999"
                            ? "-"
                            : `LLY +${Number(
                                marketingTotal[0].AOV_TY_VS_LLY
                              ).toFixed(2)}%`)}
                      </span>
                    )}
                  </th>
                  <th>
                    {marketingTotal !== undefined &&
                      marketingTotal.length !== 0 &&
                      (marketingTotal[0].UPT_TY === "-999999"
                        ? "-"
                        : Number(marketingTotal[0].UPT_TY).toFixed(1))}
                    <br />
                    {marketingTotal !== undefined &&
                    marketingTotal.length !== 0 &&
                    Number(marketingTotal[0].UPT_TY_VS_LY)
                      .toFixed(2)
                      .includes("-") ? (
                      <span style={{ color: "red", fontSize: "12px" }}>
                        {marketingTotal !== undefined &&
                          marketingTotal.length !== 0 &&
                          (marketingTotal[0].UPT_TY_VS_LY === "-999999"
                            ? "-"
                            : `LY ${Number(
                                marketingTotal[0].UPT_TY_VS_LY
                              ).toFixed(2)}%`)}
                      </span>
                    ) : (
                      <span style={{ color: "green", fontSize: "12px" }}>
                        {marketingTotal !== undefined &&
                          marketingTotal.length !== 0 &&
                          (marketingTotal[0].UPT_TY_VS_LY === "-999999"
                            ? "-"
                            : `LY +${Number(
                                marketingTotal[0].UPT_TY_VS_LY
                              ).toFixed(2)}%`)}
                      </span>
                    )}
                    <br />
                    {marketingTotal !== undefined &&
                    marketingTotal.length !== 0 &&
                    Number(marketingTotal[0].UPT_TY_VS_LLY)
                      .toFixed(2)
                      .includes("-") ? (
                      <span style={{ color: "red", fontSize: "11px" }}>
                        {marketingTotal !== undefined &&
                          marketingTotal.length !== 0 &&
                          (marketingTotal[0].UPT_TY_VS_LLY === "-999999"
                            ? "-"
                            : `LLY ${Number(
                                marketingTotal[0].UPT_TY_VS_LLY
                              ).toFixed(2)}%`)}
                      </span>
                    ) : (
                      <span style={{ color: "green", fontSize: "11px" }}>
                        {marketingTotal !== undefined &&
                          marketingTotal.length !== 0 &&
                          (marketingTotal[0].UPT_TY_VS_LLY === "-999999"
                            ? "-"
                            : `LLY +${Number(
                                marketingTotal[0].UPT_TY_VS_LLY
                              ).toFixed(2)}%`)}
                      </span>
                    )}
                  </th>
                  <th>
                    {marketingTotal !== undefined &&
                      marketingTotal.length !== 0 &&
                      (marketingTotal[0].AUR_TY === "-999999"
                        ? "-"
                        : "$" + Number(marketingTotal[0].AUR_TY).toFixed(2))}
                    <br />
                    {marketingTotal !== undefined &&
                    marketingTotal.length !== 0 &&
                    Number(marketingTotal[0].AUR_TY_VS_LY)
                      .toFixed(2)
                      .includes("-") ? (
                      <span style={{ color: "red", fontSize: "12px" }}>
                        {marketingTotal !== undefined &&
                          marketingTotal.length !== 0 &&
                          (marketingTotal[0].AUR_TY_VS_LY === "-999999"
                            ? "-"
                            : `LY ${Number(
                                marketingTotal[0].AUR_TY_VS_LY
                              ).toFixed(2)}%`)}
                      </span>
                    ) : (
                      <span style={{ color: "green", fontSize: "12px" }}>
                        {marketingTotal !== undefined &&
                          marketingTotal.length !== 0 &&
                          (marketingTotal[0].AUR_TY_VS_LY === "-999999"
                            ? "-"
                            : `LY +${Number(
                                marketingTotal[0].AUR_TY_VS_LY
                              ).toFixed(2)}%`)}
                      </span>
                    )}
                    <br />
                    {marketingTotal !== undefined &&
                    marketingTotal.length !== 0 &&
                    Number(marketingTotal[0].AUR_TY_VS_LLY)
                      .toFixed(2)
                      .includes("-") ? (
                      <span style={{ color: "red", fontSize: "11px" }}>
                        {marketingTotal !== undefined &&
                          marketingTotal.length !== 0 &&
                          (marketingTotal[0].AUR_TY_VS_LLY === "-999999"
                            ? "-"
                            : `LLY ${Number(
                                marketingTotal[0].AUR_TY_VS_LLY
                              ).toFixed(2)}%`)}
                      </span>
                    ) : (
                      <span style={{ color: "green", fontSize: "11px" }}>
                        {marketingTotal !== undefined &&
                          marketingTotal.length !== 0 &&
                          (marketingTotal[0].AUR_TY_VS_LLY === "-999999"
                            ? "-"
                            : `LLY +${Number(
                                marketingTotal[0].AUR_TY_VS_LLY
                              ).toFixed(2)}%`)}
                      </span>
                    )}
                  </th>
                  <th>
                    {marketingTotal !== undefined &&
                      marketingTotal.length !== 0 &&
                      (marketingTotal[0].MARGIN_RATE_PER_TY === "-999999"
                        ? "-"
                        : Number(marketingTotal[0].MARGIN_RATE_PER_TY).toFixed(
                            2
                          ))}
                    <br />
                    {marketingTotal !== undefined &&
                    marketingTotal.length !== 0 &&
                    Number(marketingTotal[0].MARGIN_RATE_PER_TY_VS_LY)
                      .toFixed(2)
                      .includes("-") ? (
                      <span style={{ color: "red", fontSize: "12px" }}>
                        {marketingTotal !== undefined &&
                          marketingTotal.length !== 0 &&
                          (marketingTotal[0].MARGIN_RATE_PER_TY_VS_LY ===
                          "-999999"
                            ? "-"
                            : `LY ${Number(
                                marketingTotal[0].MARGIN_RATE_PER_TY_VS_LY
                              ).toFixed(2)}%`)}
                      </span>
                    ) : (
                      <span style={{ color: "green", fontSize: "12px" }}>
                        {marketingTotal !== undefined &&
                          marketingTotal.length !== 0 &&
                          (marketingTotal[0].MARGIN_RATE_PER_TY_VS_LY ===
                          "-999999"
                            ? "-"
                            : `LY +${Number(
                                marketingTotal[0].MARGIN_RATE_PER_TY_VS_LY
                              ).toFixed(2)}%`)}
                      </span>
                    )}
                    <br />
                    {marketingTotal !== undefined &&
                    marketingTotal.length !== 0 &&
                    Number(marketingTotal[0].MARGIN_RATE_PER_TY_VS_LLY)
                      .toFixed(2)
                      .includes("-") ? (
                      <span style={{ color: "red", fontSize: "11px" }}>
                        {marketingTotal !== undefined &&
                          marketingTotal.length !== 0 &&
                          (marketingTotal[0].MARGIN_RATE_PER_TY_VS_LLY ===
                          "-999999"
                            ? "-"
                            : `LLY ${Number(
                                marketingTotal[0].MARGIN_RATE_PER_TY_VS_LLY
                              ).toFixed(2)}%`)}
                      </span>
                    ) : (
                      <span style={{ color: "green", fontSize: "11px" }}>
                        {marketingTotal !== undefined &&
                          marketingTotal.length !== 0 &&
                          (marketingTotal[0].MARGIN_RATE_PER_TY_VS_LLY ===
                          "-999999"
                            ? "-"
                            : `LLY +${Number(
                                marketingTotal[0].MARGIN_RATE_PER_TY_VS_LLY
                              ).toFixed(2)}%`)}
                      </span>
                    )}
                  </th>
                  <th>
                    {marketingTotal !== undefined &&
                      marketingTotal.length !== 0 &&
                      (marketingTotal[0].NET_SALES_PER_CUST_TY === "-999999"
                        ? "-"
                        : "$" +
                          Number(
                            marketingTotal[0].NET_SALES_PER_CUST_TY
                          ).toFixed(2))}
                    <br />
                    {marketingTotal !== undefined &&
                    marketingTotal.length !== 0 &&
                    Number(marketingTotal[0].NET_SALES_PER_CUST_TY_VS_LY)
                      .toFixed(2)
                      .includes("-") ? (
                      <span style={{ color: "red", fontSize: "12px" }}>
                        {marketingTotal !== undefined &&
                          marketingTotal.length !== 0 &&
                          (marketingTotal[0].NET_SALES_PER_CUST_TY_VS_LY ===
                          "-999999"
                            ? "-"
                            : `LY ${Number(
                                marketingTotal[0].NET_SALES_PER_CUST_TY_VS_LY
                              ).toFixed(2)}%`)}
                      </span>
                    ) : (
                      <span style={{ color: "green", fontSize: "12px" }}>
                        {marketingTotal !== undefined &&
                          marketingTotal.length !== 0 &&
                          (marketingTotal[0].NET_SALES_PER_CUST_TY_VS_LY ===
                          "-999999"
                            ? "-"
                            : `LY +${Number(
                                marketingTotal[0].NET_SALES_PER_CUST_TY_VS_LY
                              ).toFixed(2)}%`)}
                      </span>
                    )}
                    <br />
                    {marketingTotal !== undefined &&
                    marketingTotal.length !== 0 &&
                    Number(marketingTotal[0].NET_SALES_PER_CUST_TY_VS_LLY)
                      .toFixed(2)
                      .includes("-") ? (
                      <span style={{ color: "red", fontSize: "11px" }}>
                        {marketingTotal !== undefined &&
                          marketingTotal.length !== 0 &&
                          (marketingTotal[0].NET_SALES_PER_CUST_TY_VS_LLY ===
                          "-999999"
                            ? "-"
                            : `LLY ${Number(
                                marketingTotal[0].NET_SALES_PER_CUST_TY_VS_LLY
                              ).toFixed(2)}%`)}
                      </span>
                    ) : (
                      <span style={{ color: "green", fontSize: "11px" }}>
                        {marketingTotal !== undefined &&
                          marketingTotal.length !== 0 &&
                          (marketingTotal[0].NET_SALES_PER_CUST_TY_VS_LLY ===
                          "-999999"
                            ? "-"
                            : `LLY +${Number(
                                marketingTotal[0].NET_SALES_PER_CUST_TY_VS_LLY
                              ).toFixed(2)}%`)}
                      </span>
                    )}
                  </th>
                  <th>
                    {marketingTotal !== undefined &&
                      marketingTotal.length !== 0 &&
                      (marketingTotal[0].AVG_TRAN_TY === "-999999"
                        ? "-"
                        : Number(marketingTotal[0].AVG_TRAN_TY).toFixed(2))}
                    <br />
                    {marketingTotal !== undefined &&
                    marketingTotal.length !== 0 &&
                    Number(marketingTotal[0].AVG_TRAN_TY_VS_LY)
                      .toFixed(2)
                      .includes("-") ? (
                      <span style={{ color: "red", fontSize: "12px" }}>
                        {marketingTotal !== undefined &&
                          marketingTotal.length !== 0 &&
                          (marketingTotal[0].AVG_TRAN_TY_VS_LY === "-999999"
                            ? "-"
                            : `LY ${Number(
                                marketingTotal[0].AVG_TRAN_TY_VS_LY
                              ).toFixed(2)}%`)}
                      </span>
                    ) : (
                      <span style={{ color: "green", fontSize: "12px" }}>
                        {marketingTotal !== undefined &&
                          marketingTotal.length !== 0 &&
                          (marketingTotal[0].AVG_TRAN_TY_VS_LY === "-999999"
                            ? "-"
                            : `LY +${Number(
                                marketingTotal[0].AVG_TRAN_TY_VS_LY
                              ).toFixed(2)}%`)}
                      </span>
                    )}
                    <br />
                    {marketingTotal !== undefined &&
                    marketingTotal.length !== 0 &&
                    Number(marketingTotal[0].AVG_TRAN_TY_VS_LLY)
                      .toFixed(2)
                      .includes("-") ? (
                      <span style={{ color: "red", fontSize: "11px" }}>
                        {marketingTotal !== undefined &&
                          marketingTotal.length !== 0 &&
                          (marketingTotal[0].AVG_TRAN_TY_VS_LLY === "-999999"
                            ? "-"
                            : `LLY ${Number(
                                marketingTotal[0].AVG_TRAN_TY_VS_LLY
                              ).toFixed(2)}%`)}
                      </span>
                    ) : (
                      <span style={{ color: "green", fontSize: "11px" }}>
                        {marketingTotal !== undefined &&
                          marketingTotal.length !== 0 &&
                          (marketingTotal[0].AVG_TRAN_TY_VS_LLY === "-999999"
                            ? "-"
                            : `LLY +${Number(
                                marketingTotal[0].AVG_TRAN_TY_VS_LLY
                              ).toFixed(2)}%`)}
                      </span>
                    )}
                  </th>
                </>
              )}
            </tr>
          </tbody>
        </Table>
      </div>
    </div>
  );
}

export default MarketingHome;
