import React, { useState, useEffect, useCallback } from "react";
import { useSelector, useDispatch } from "react-redux";
import { Dropdown, Form, Placeholder } from "react-bootstrap";
import axios from "axios";
import DatePicker from "react-datetime";
import moment from "moment";
import "../HomePage/HomePage.css";
import MarketingHome from "./MarketingHome";
import calender from "../../assests/images/calender.svg";
import { handleMarketingBannerChange } from "../../Redux/Actions/BannerChangeActions";
import { handleMarketingCategoryChange } from "../../Redux/Actions/CategoryChangeActions";
import { handleMarketingDateChange } from "../../Redux/Actions/DateChangeActions";
import { getDateFormat, getDateMinusTwoYear } from "../Utils";
import { gettooltip } from "../Utils";
import { UTCtoEST } from "../Utils";
import NotificationMessage from "../NotificationMessage/NotificationMessage";
import NoAccess from "../NoAccess/NoAccess";

const MarketingBanners = [
  { value: "All Banner", id: "0" },
  { value: "BBBY US", id: "1" },
  { value: "BBBY CA", id: "2" },
  { value: "buy buy Baby", id: "3" },
  { value: "Harmon", id: "5" },
];

function MarketingContainer() {
  const [selectedMarketingBanner, setSelectedMarketingBanner] = useState(
    MarketingBanners[0]
  );
  const dispatch = useDispatch();

  const [chkBox, isChkBox] = useState({
    isDm: true,
    isEm: false,
    isSms: false,
    isNotReachable: false,
  });
  const [refreshTime, setRefreshTime] = useState("");

  const refreshDate =
    refreshTime.length > 0 && UTCtoEST(refreshTime[0].end_time * 1000);

  const [loading, setloader] = useState({
    AtRisk_6m_9m: false,
    AtRisk_9m_12m: false,
    Active_Existing: false,
    Active_L12m: false,
    Inactive_12m_18m: false,
    Inactive_18m_24m: false,
    UnIdentifed_Customers: false,
    first_half_total: false,
    second_half_total: false,
    total: false,
    Inactive_24mp: false,
    record_dates: false,
    refreshTime: false,
  });
  const selectedMarketingCategoryId = useSelector(
    (store) => store.MarketingCategory.id
  );
  if (selectedMarketingCategoryId === "DM") {
    chkBox.isDm = true;
  }
  const selectedMarketingDate = useSelector(
    (store) => store.MarketingDate.value
  );
  const selectedMarketingBannerId = useSelector(
    (store) => store.MarketingBanner.id
  );
  const [defaultDate, setDefaultDate] = useState(moment().subtract(2, "days"));
  const [customerMarketingActiveExisting, setCustomerMarketingActiveExisting] =
    useState();
  const [customerMarketingActiveData, setCustomerMarketingActiveData] =
    useState();
  const [customerMarketingDataSixMonths, setCustomerMarketingDataSixMonths] =
    useState();
  const [customerMarketingDataNineMonths, setCustomerMarketingDataNineMonths] =
    useState();
  const [
    customerMarketingFirst_Four_Total_Data,
    setCustomerMarketingFirst_Four_Total_Data,
  ] = useState();
  const [
    customerMarketingInActive_12_18_Data,
    setCustomerMarketingInActive_12_18_Data,
  ] = useState();
  const [
    customerMarketingInActive_18_24_Data,
    setCustomerMarketingInActive_18_24_Data,
  ] = useState();
  const [
    customerMarketingSecond_half_total_Data,
    setCustomerMarketingSecond_half_total_Data,
  ] = useState();
  const [marketingTotal, setMarketingTotal] = useState();
  const [periodStartDate, setPeriodStartDate] = useState("");
  const [periodEndDate, setPeriodEndDate] = useState("");

  const handleMarketingBanner = useCallback(
    (event) => {
      setSelectedMarketingBanner((prevsValue) => ({
        ...prevsValue,
        value: event.target.innerText,
        id: event.target.id,
      }));
      dispatch(
        handleMarketingBannerChange({
          value: event.target.innerText,
          id: event.target.id,
        })
      );
    },
    [selectedMarketingBannerId]
  );

  const onChangeCheck = useCallback(
    (e) => {
      if (e.target.value === "DM") {
        isChkBox(() => ({
          isDm: !chkBox.isDm,
          isEm: false,
          isSms: false,
          isNotReachable: false,
        }));
        if (e.target.checked) {
          dispatch(
            handleMarketingCategoryChange({
              value: "DM",
              id: "DM",
            })
          );
        } else {
          dispatch(
            handleMarketingCategoryChange({
              value: chkBox.isEm
                ? "EM"
                : chkBox.isSms
                ? "SMS"
                : chkBox.isNotReachable
                ? "NR"
                : "DM",
              id: chkBox.isEm
                ? "EM"
                : chkBox.isSms
                ? "SMS"
                : chkBox.isNotReachable
                ? "NR"
                : "DM",
            })
          );
        }
      } else if (e.target.value === "EM") {
        isChkBox(() => ({
          isEm: !chkBox.isEm,
          isDm: false,
          isSms: false,
          isNotReachable: false,
        }));
        if (e.target.checked) {
          dispatch(
            handleMarketingCategoryChange({
              value: "EM",
              id: "EM",
            })
          );
        } else {
          dispatch(
            handleMarketingCategoryChange({
              value: chkBox.isDm
                ? "DM"
                : chkBox.isSms
                ? "SMS"
                : chkBox.isNotReachable
                ? "NR"
                : "DM",
              id: chkBox.isDm
                ? "DM"
                : chkBox.isSms
                ? "SMS"
                : chkBox.isNotReachable
                ? "NR"
                : "DM",
            })
          );
        }
      } else if (e.target.value === "SMS") {
        isChkBox(() => ({
          isSms: !chkBox.isSms,
          isEm: false,
          isDm: false,
          isNotReachable: false,
        }));
        if (e.target.checked) {
          dispatch(
            handleMarketingCategoryChange({
              value: "SMS",
              id: "SMS",
            })
          );
        } else {
          dispatch(
            handleMarketingCategoryChange({
              value: chkBox.isDm
                ? "DM"
                : chkBox.isEm
                ? "EM"
                : chkBox.isNotReachable
                ? "NR"
                : "DM",
              id: chkBox.isDm
                ? "DM"
                : chkBox.isEm
                ? "EM"
                : chkBox.isNotReachable
                ? "NR"
                : "DM",
            })
          );
        }
      } else if (e.target.value === "NR") {
        isChkBox(() => ({
          isNotReachable: !chkBox.isNotReachable,
          isSms: false,
          isEm: false,
          isDm: false,
        }));
        if (e.target.checked) {
          dispatch(
            handleMarketingCategoryChange({
              value: "NR",
              id: "NR",
            })
          );
        } else {
          dispatch(
            handleMarketingCategoryChange({
              value: chkBox.isDm
                ? "DM"
                : chkBox.isEm
                ? "EM"
                : chkBox.isSms
                ? "SMS"
                : "DM",
              id: chkBox.isDm
                ? "DM"
                : chkBox.isEm
                ? "EM"
                : chkBox.isSms
                ? "SMS"
                : "DM",
            })
          );
        }
      }
    },
    [selectedMarketingCategoryId]
  );

  const handleMarketingDate = (dateSelected) => {
    if (moment(dateSelected, "MM/DD/YYYY", true).isValid()) {
      setDefaultDate();
      setPeriodStartDate(getDateMinusTwoYear(dateSelected));
      setPeriodEndDate(moment(dateSelected));
      dispatch(handleMarketingDateChange(dateSelected.format("YYYY-MM-DD")));
    } else {
      setDefaultDate(moment().subtract(2, "days"));
    }
  };

  /* let customDatess =
    programRecordAvailableDates &&
    programRecordAvailableDates.map((item) => {
      return item["TRANS_DATE"];
    }); */
  // const disableCustomDt = (current) => {
  //   return defaultDate && defaultDate.includes(current.format("YYYY-MM-DD"));
  // };
  const disableFutureDt = (current) => {
    return current.isBefore(defaultDate);
  };

  useEffect(() => {
    setPeriodStartDate(getDateMinusTwoYear(defaultDate));
    setPeriodEndDate(moment(defaultDate));
  }, []);

  useEffect(() => {
    const fetchCustomerMarketingDataActiveExisting = async () => {
      try {
        setloader((currValue) => ({
          ...currValue,
          Active_Existing: true,
        }));
        let url =
          process.env.REACT_APP_API_ENDPOINT +
          process.env.REACT_APP_CUSTOMER_MARKETING_Active_Existing +
          "concept=" +
          selectedMarketingBannerId +
          "&date=" +
          selectedMarketingDate +
          "&marketingType=" +
          selectedMarketingCategoryId;
        await axios({ url }).then((res) => {
          setCustomerMarketingActiveExisting(res.data);
          setloader((currValue) => ({
            ...currValue,
            Active_Existing: false,
          }));
        });
      } catch (err) {
        console.log("err-fetchCustomerMarketingDataActiveExisting", err);
        setloader((currValue) => ({
          ...currValue,
          Active_Existing: false,
        }));
      }
    };

    const fetchCustomerMarketingDataActive = async () => {
      try {
        setloader((currValue) => ({
          ...currValue,
          Active_L12m: true,
        }));
        let url =
          process.env.REACT_APP_API_ENDPOINT +
          process.env.REACT_APP_CUSTOMER_MARKETING_Active +
          "concept=" +
          selectedMarketingBannerId +
          "&date=" +
          selectedMarketingDate +
          "&marketingType=" +
          selectedMarketingCategoryId;
        await axios({ url }).then((res) => {
          setCustomerMarketingActiveData(res.data);
          setloader((currValue) => ({
            ...currValue,
            Active_L12m: false,
          }));
        });
      } catch (err) {
        console.log("err-fetchCustomerMarketingDataActive", err);
        setloader((currValue) => ({
          ...currValue,
          Active_L12m: false,
        }));
      }
    };

    const fetchMarketingCustomerDataSixMonths = async () => {
      try {
        setloader((currValue) => ({
          ...currValue,
          AtRisk_6m_9m: true,
        }));
        let url =
          process.env.REACT_APP_API_ENDPOINT +
          process.env.REACT_APP_CUSTOMER_MARKETING_6m_9m +
          "concept=" +
          selectedMarketingBannerId +
          "&date=" +
          selectedMarketingDate +
          "&marketingType=" +
          selectedMarketingCategoryId +
          "&customerType=" +
          "ALL";
        await axios({ url }).then((res) => {
          setloader((currValue) => ({
            ...currValue,
            AtRisk_6m_9m: false,
          }));
          setCustomerMarketingDataSixMonths(res.data);
        });
      } catch (err) {
        console.log("err-fetchMarketingCustomerDataSixMonths", err);
        setloader((currValue) => ({
          ...currValue,
          AtRisk_6m_9m: false,
        }));
      }
    };

    const fetchMarketingCustomerDataNineMonths = async () => {
      try {
        setloader((currValue) => ({
          ...currValue,
          AtRisk_9m_12m: true,
        }));
        let url =
          process.env.REACT_APP_API_ENDPOINT +
          process.env.REACT_APP_CUSTOMER_MARKETING_9m_12m +
          "concept=" +
          selectedMarketingBannerId +
          "&date=" +
          selectedMarketingDate +
          "&customerType=" +
          "ALL&marketingType=" +
          selectedMarketingCategoryId;
        await axios({ url }).then((res) => {
          setCustomerMarketingDataNineMonths(res.data);
          setloader((currValue) => ({
            ...currValue,
            AtRisk_9m_12m: false,
          }));
        });
      } catch (err) {
        console.log("err-fetchcustomerMarketingDataNineMonths", err);
        setloader((currValue) => ({
          ...currValue,
          AtRisk_9m_12m: false,
        }));
      }
    };

    const fetchMarketingfirstFourTotal = async () => {
      try {
        setloader((currValue) => ({
          ...currValue,
          first_half_total: true,
        }));
        let url =
          process.env.REACT_APP_API_ENDPOINT +
          process.env.REACT_APP_CUSTOMER_MARKETING_First_Four_Total +
          "concept=" +
          selectedMarketingBannerId +
          "&date=" +
          selectedMarketingDate +
          "&customerType=" +
          "ALL&marketingType=" +
          selectedMarketingCategoryId;
        await axios({ url }).then((res) => {
          setCustomerMarketingFirst_Four_Total_Data(res.data);
          setloader((currValue) => ({
            ...currValue,
            first_half_total: false,
          }));
        });
      } catch (err) {
        console.log("err-fetchMarketingfirstFourTotal", err);
        setloader((currValue) => ({
          ...currValue,
          first_half_total: false,
        }));
      }
    };

    const fetchMarketingCustomerDataInActive_12_18 = async () => {
      try {
        setloader((currValue) => ({
          ...currValue,
          Inactive_12m_18m: true,
        }));
        let url =
          process.env.REACT_APP_API_ENDPOINT +
          process.env.REACT_APP_CUSTOMER_MARKETING_InActive_12_18 +
          "concept=" +
          selectedMarketingBannerId +
          "&date=" +
          selectedMarketingDate +
          "&marketingType=" +
          selectedMarketingCategoryId;
        await axios({ url }).then((res) => {
          setCustomerMarketingInActive_12_18_Data(res.data);
          setloader((currValue) => ({
            ...currValue,
            Inactive_12m_18m: false,
          }));
        });
      } catch (err) {
        console.log("err-fetchMarketingCustomerDataInActive_12_18", err);
        setloader((currValue) => ({
          ...currValue,
          Inactive_12m_18m: false,
        }));
      }
    };

    const fetchMarketingCustomerDataInActive_18_24 = async () => {
      try {
        setloader((currValue) => ({
          ...currValue,
          Inactive_18m_24m: true,
        }));
        let url =
          process.env.REACT_APP_API_ENDPOINT +
          process.env.REACT_APP_CUSTOMER_MARKETING_InActive_18_24 +
          "concept=" +
          selectedMarketingBannerId +
          "&date=" +
          selectedMarketingDate +
          "&marketingType=" +
          selectedMarketingCategoryId;
        await axios({ url }).then((res) => {
          setCustomerMarketingInActive_18_24_Data(res.data);
          setloader((currValue) => ({
            ...currValue,
            Inactive_18m_24m: false,
          }));
        });
      } catch (err) {
        console.log("err-fetchMarketingCustomerDataInActive_18_24", err);
        setloader((currValue) => ({
          ...currValue,
          Inactive_18m_24m: false,
        }));
      }
    };

    const fetchMarketingTotalsecondHalf = async () => {
      try {
        setloader((currValue) => ({
          ...currValue,
          second_half_total: true,
        }));
        let url =
          process.env.REACT_APP_API_ENDPOINT +
          process.env.REACT_APP_CUSTOMER_MARKETING_Second_half_total +
          "concept=" +
          selectedMarketingBannerId +
          "&date=" +
          selectedMarketingDate +
          "&marketingType=" +
          selectedMarketingCategoryId +
          "&customerType=ALL";
        await axios({ url }).then((res) => {
          setCustomerMarketingSecond_half_total_Data(res.data);
          setloader((currValue) => ({
            ...currValue,
            second_half_total: false,
          }));
        });
      } catch (err) {
        console.log("err-fetchMarketingTotalsecondHalf", err);
        setloader((currValue) => ({
          ...currValue,
          second_half_total: false,
        }));
      }
    };

    const fetchcustomerMarketingTotal = async () => {
      try {
        setloader((currValue) => ({
          ...currValue,
          total: true,
        }));
        let url =
          process.env.REACT_APP_API_ENDPOINT +
          process.env.REACT_APP_CUSTOMER_MARKETING_total +
          "concept=" +
          selectedMarketingBannerId +
          "&date=" +
          selectedMarketingDate +
          "&marketingType=" +
          selectedMarketingCategoryId +
          "&customerType=ALL";
        await axios({ url }).then((res) => {
          setMarketingTotal(res.data);
          setloader((currValue) => ({
            ...currValue,
            total: false,
          }));
        });
      } catch (err) {
        console.log("err-fetchcustomerMarketingTotal", err);
        setloader((currValue) => ({
          ...currValue,
          total: false,
        }));
      }
    };
    if (localStorage.getItem("isMARKETING") === "Y") {
      fetchCustomerMarketingDataActiveExisting();
      fetchCustomerMarketingDataActive();
      fetchMarketingCustomerDataSixMonths();
      fetchMarketingCustomerDataNineMonths();
      fetchMarketingfirstFourTotal();
      fetchMarketingCustomerDataInActive_12_18();
      fetchMarketingCustomerDataInActive_18_24();
      fetchMarketingTotalsecondHalf();
      fetchcustomerMarketingTotal();
    }
  }, [
    selectedMarketingBannerId,
    selectedMarketingDate,
    selectedMarketingCategoryId,
  ]);

  useEffect(() => {
    const getLastRefreshTime = async () => {
      try {
        setloader((currValue) => ({
          ...currValue,
          refreshTime: true,
        }));
        let url =
          process.env.REACT_APP_API_ENDPOINT +
          process.env.REACT_APP_REFRESH_TIME +
          "dagId=MARKETING";
        await axios({ url }).then((res) => {
          setloader((currValue) => ({
            ...currValue,
            refreshTime: false,
          }));
          setRefreshTime(res.data);
        });
      } catch (err) {
        setloader((currValue) => ({
          ...currValue,
          refreshTime: true,
        }));
        console.log("err-getLastRefreshTime", err);
      }
    };
    getLastRefreshTime();
  }, []);
  return localStorage.getItem("isMARKETING") === "Y" ? (
    <div>
      {refreshTime.length > 0 && <NotificationMessage message={refreshDate} />}
      <div className="mt-1 d-flex align-items-center headings">
        <div className="d-flex justify-content-start p-3">
          <span className="progselectupText">Concept</span>
        </div>
        <div className="d-flex justify-content-start p-3">
          <span className="progselectupText">Type</span>
        </div>
      </div>
      <div className="mt-3 d-flex align-items-center">
        <div className="d-flex justify-content-start p-3">
          <Dropdown className="d-inline">
            <Dropdown.Toggle>{selectedMarketingBanner.value}</Dropdown.Toggle>
            <Dropdown.Menu
              className="dropdown-menu-ext"
              onClick={(e) => handleMarketingBanner(e)}
            >
              {MarketingBanners.map((data) => {
                return (
                  <Dropdown.Item
                    key={data.id}
                    className="dropdown-item-ext"
                    id={data.id}
                  >
                    {data.value}
                  </Dropdown.Item>
                );
              })}
            </Dropdown.Menu>
          </Dropdown>
        </div>
        <div className="d-flex justify-content-start p-3">
          <label className="chkBox-label">
            <input
              type="checkbox"
              checked={chkBox.isDm}
              onChange={onChangeCheck}
              value="DM"
              id="DM"
              className="chkBox"
            />{" "}
            Direct Mail
          </label>
        </div>
        <div className="d-flex justify-content-start p-3">
          <label className="chkBox-label">
            <input
              type="checkbox"
              checked={chkBox.isEm}
              onChange={onChangeCheck}
              value="EM"
              id="EM"
              className="chkBox"
            />{" "}
            Email
          </label>
        </div>
        <div className="d-flex justify-content-start p-3">
          <label className="chkBox-label">
            <input
              type="checkbox"
              checked={chkBox.isSms}
              onChange={onChangeCheck}
              value="SMS"
              id="SMS"
              className="chkBox"
            />{" "}
            SMS
          </label>
        </div>
        <div className="d-flex justify-content-start p-3">
          <label className="chkBox-label">
            <input
              type="checkbox"
              checked={chkBox.isNotReachable}
              onChange={onChangeCheck}
              value="NR"
              id="NR"
              className="chkBox"
            />{" "}
            Not Reachable
          </label>
          <span style={{ width: "20px", marginTop: "-1.7%" }}>
            {" "}
            {gettooltip(
              "NotReachableInfoIcon",
              "NotReachable",
              "NotReachable",
              "Customer shopped, but can not be contacted through",
              " Direct Email, Email and SMS"
            )}
          </span>
        </div>
        {loading.record_dates ? (
          <Placeholder.Button xs={1} />
        ) : (
          <div className="d-flex justify-content-start p-3">
            <label
              className="d-flex datepicker"
              onClick={(e) => e.preventDefault()}
            >
              <DatePicker
                timeFormat={false}
                value={
                  defaultDate
                    ? defaultDate
                    : moment(selectedMarketingDate).format("MM/DD/YYYY")
                }
                isValidDate={disableFutureDt}
                onChange={(date) => handleMarketingDate(date)}
                closeOnSelect
                inputProps={{ readOnly: true }}
              />
              <img src={calender} className="date-picker-icon" />
            </label>
          </div>
        )}
        <div
          className="d-flex justify-content-start p-3"
          style={{ marginLeft: "-6rem" }}
        >
          {!loading.record_dates && periodStartDate !== "" ? (
            <div>
              <span>{`(${getDateFormat(periodStartDate)} - ${getDateFormat(
                periodEndDate
              )})`}</span>
            </div>
          ) : (
            ""
          )}
        </div>
      </div>
      <MarketingHome
        loading={loading}
        customerMarketingActiveExisting={customerMarketingActiveExisting}
        customerMarketingActiveData={customerMarketingActiveData}
        customerMarketingDataSixMonths={customerMarketingDataSixMonths}
        customerMarketingDataNineMonths={customerMarketingDataNineMonths}
        customerMarketingFirst_Four_Total_Data={
          customerMarketingFirst_Four_Total_Data
        }
        customerMarketingInActive_12_18_Data={
          customerMarketingInActive_12_18_Data
        }
        customerMarketingInActive_18_24_Data={
          customerMarketingInActive_18_24_Data
        }
        customerMarketingSecond_half_total_Data={
          customerMarketingSecond_half_total_Data
        }
        marketingTotal={marketingTotal}
        selectedMarketingCategoryId={selectedMarketingCategoryId}
        selectedMarketingBannerId={selectedMarketingBannerId}
        selectedMarketingDate={selectedMarketingDate}
        periodStartDate={periodStartDate}
        periodEndDate={periodEndDate}
      />
    </div>
  ) : (
    <NoAccess tabName="Marketing" />
  );
}

export default MarketingContainer;
