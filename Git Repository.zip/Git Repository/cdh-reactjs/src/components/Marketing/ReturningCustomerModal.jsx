import React, { useEffect, useState } from "react";
import { Modal, Table } from "react-bootstrap";
import ReactTooltip from "react-tooltip";
import { FiInfo } from "react-icons/fi";
import "../Marketing/Marketing.css";
import axios from "axios";
import { decimalCurrencyFormat } from "../ScoreCard/Marketing";
import { currencyFormat } from "../CdhHome/CdhHome";
import LoaderForRow from "../LoaderForTable/LoaderForRow";
import { getDateFormat } from "../Utils";
import { gettooltip } from "../Utils";

function ReturningCustomerModal({
  modalFlag,
  handleModalClose,
  selectedMarketingCategoryId,
  modalHeaderText,
  selectedMarketingBannerId,
  selectedMarketingDate,
  loadingHome,
  periodStartDate,
  periodEndDate,
}) {
  const typeText =
    selectedMarketingCategoryId === "DM"
      ? "Direct Mail"
      : selectedMarketingCategoryId === "EM"
      ? "Email"
      : selectedMarketingCategoryId === "SMS"
      ? "SMS"
      : "";

  const [loading, setloader] = useState({
    modalData: false,
    modalTotal: false,
  });

  const [customerMarketingActiveExisting, setCustomerMarketingActiveExisting] =
    useState();
  const [customerMarketingTotal, setCustomerMarketingTotal] = useState();

  const dimensionType =
    modalHeaderText === "Returning Customers"
      ? "RC"
      : modalHeaderText === "New Customers"
      ? "NC"
      : modalHeaderText === "At risk (6m-9m)"
      ? "AR_6M_9M"
      : modalHeaderText === "At risk (9m-12m)"
      ? "AR_9M_12M"
      : modalHeaderText === "Inactive (12m-18m)"
      ? "INA_12M_18M"
      : modalHeaderText === "Inactive (18m-24m)"
      ? "INA_18M_24M"
      : "";

  useEffect(() => {
    const fetchCustomerMarketingModalDataActiveExisting = async () => {
      try {
        setCustomerMarketingActiveExisting();
        setloader(() => ({
          modalData: true,
        }));
        let url =
          process.env.REACT_APP_API_ENDPOINT +
          process.env.REACT_APP_CUSTOMER_MARKETING_MODAL_Active_Existing +
          "concept=" +
          selectedMarketingBannerId +
          "&date=" +
          selectedMarketingDate +
          "&dimensiontype=" +
          dimensionType;
        if (modalFlag) {
          await axios({ url }).then((res) => {
            res.data !== undefined &&
              res.data.length !== 0 &&
              setCustomerMarketingActiveExisting(res.data);
            setloader(() => ({
              modalData: false,
            }));
          });
        } else {
          setloader(() => ({
            modalData: false,
          }));
        }
      } catch (err) {
        console.log("err-fetchCustomerMarketingModalData", err);
        setloader(() => ({
          modalData: false,
        }));
      }
    };

    const fetchCustomerMarketingModalTotal = async () => {
      try {
        setCustomerMarketingTotal();
        setloader(() => ({
          modalTotal: true,
        }));
        let url =
          process.env.REACT_APP_API_ENDPOINT +
          process.env.REACT_APP_CUSTOMER_MARKETING_MODAL_Total +
          "concept=" +
          selectedMarketingBannerId +
          "&date=" +
          selectedMarketingDate +
          "&dimensiontype=" +
          dimensionType;
        if (modalFlag) {
          await axios({ url }).then((res) => {
            res.data !== undefined &&
              res.data.length !== 0 &&
              setCustomerMarketingTotal(res.data);
            setloader(() => ({
              modalTotal: false,
            }));
          });
        } else {
          setloader(() => ({
            modalTotal: false,
          }));
        }
      } catch (err) {
        console.log("err-fetchCustomerMarketingModalTotal", err);
        setloader(() => ({
          modalTotal: false,
        }));
      }
    };

    if (selectedMarketingCategoryId === "SMS") {
      fetchCustomerMarketingModalDataActiveExisting();
      fetchCustomerMarketingModalTotal();
    } else {
      setCustomerMarketingActiveExisting();
      setCustomerMarketingTotal();
    }
  }, [modalFlag, dimensionType]);

  return (
    <>
      <Modal show={modalFlag} fullscreen={true} onHide={handleModalClose}>
        <Modal.Header closeButton>
          <Modal.Title>
            {modalHeaderText}{" "}
            <span>
              <FiInfo className="TypeInfoIcon" data-tip data-for="Type" />
              <ReactTooltip
                className="tooltip_css"
                id="Type"
                place="top"
                effect="float"
                backgroundColor="#595959"
              >
                Customer contacted through {typeText}
              </ReactTooltip>
            </span>
          </Modal.Title>
        </Modal.Header>
        <div className="HeaderText">
          Customer contacted through {typeText}
          <div className="DatePeriod">
            {!loadingHome.record_dates && periodStartDate !== "" ? (
              <div>
                {modalHeaderText !== "Inactive (12m-18m)" &&
                modalHeaderText !== "Inactive (18m-24m)" ? (
                  <span>{`Transaction Period (${getDateFormat(
                    periodStartDate
                  )} - ${getDateFormat(periodEndDate)})`}</span>
                ) : (
                  <span>{`(${getDateFormat(periodStartDate)} - ${getDateFormat(
                    periodEndDate
                  )})`}</span>
                )}
              </div>
            ) : (
              ""
            )}
          </div>
        </div>
        <Modal.Body>
          <div className="p-3" style={{ marginBottom: "50px" }}>
            <Table striped bordered hover size="sm">
              <thead>
                <tr>
                  <th>Contacted Month</th>
                  <th>
                    Customers{" "}
                    <span>
                      <FiInfo
                        className="CustomersInfoIcon"
                        data-tip
                        data-for="Customers"
                      />
                      <ReactTooltip
                        className="tooltip_css"
                        id="Customers"
                        place="top"
                        effect="float"
                        backgroundColor="#595959"
                      >
                        Count of customers contacted through {typeText} in the
                        specified month
                      </ReactTooltip>
                    </span>
                  </th>
                  <th>
                    Net Sales{" "}
                    {modalHeaderText !== "Inactive (12m-18m)" &&
                      modalHeaderText !== "Inactive (18m-24m)" &&
                      gettooltip(
                        "NetSalesInfoIcon",
                        "NetSales",
                        "NetSales",
                        "Net Sales for one year for contacted customers"
                      )}
                  </th>
                  <th>
                    Transactions{" "}
                    {modalHeaderText !== "Inactive (12m-18m)" &&
                      modalHeaderText !== "Inactive (18m-24m)" &&
                      gettooltip(
                        "TransactionsInfoIcon",
                        "Transactions",
                        "Transactions",
                        "Transactions for one year for contacted customers"
                      )}
                  </th>
                  <th>
                    Product Margin{" "}
                    {modalHeaderText !== "Inactive (12m-18m)" &&
                      modalHeaderText !== "Inactive (18m-24m)" &&
                      gettooltip(
                        "ProductMarginInfoIcon",
                        "ProductMargin",
                        "ProductMargin",
                        "Product Margin for one year for contacted customers"
                      )}
                  </th>
                  <th>AOV</th>
                  <th>UPT</th>
                  <th>AUR</th>
                  <th>
                    Margin Rate <br /> %
                  </th>
                  <th>
                    Net Sales per <br /> Customer
                  </th>
                  <th>
                    Transactions per <br /> Customer
                  </th>
                </tr>
              </thead>
              <tbody>
                {loading.modalData || loading.modalTotal ? (
                  <tr>
                    <LoaderForRow height={"400px"} tdCount={11} />
                  </tr>
                ) : customerMarketingActiveExisting !== undefined &&
                  customerMarketingActiveExisting.length !== 0 ? (
                  customerMarketingActiveExisting.map((data) => {
                    return (
                      <tr className="align-middle">
                        <td>{data.MONTH_NAME + " " + data.YEAR_ID}</td>
                        <td>
                          {data.CUST_COUNT_TY !== undefined &&
                          data.CUST_COUNT_TY.length !== 0 &&
                          data.CUST_COUNT_TY !== "-999999"
                            ? currencyFormat(data.CUST_COUNT_TY)
                            : "-"}
                        </td>
                        <td>
                          {data.NET_SALES_TY !== undefined &&
                          data.NET_SALES_TY.length !== 0 &&
                          data.NET_SALES_TY !== "-999999" &&
                          modalHeaderText !== "Inactive (12m-18m)" &&
                          modalHeaderText !== "Inactive (18m-24m)"
                            ? currencyFormat(data.NET_SALES_TY)
                            : "-"}
                        </td>
                        <td>
                          {data.TRANS_COUNT_TY !== undefined &&
                          data.TRANS_COUNT_TY.length !== 0 &&
                          data.TRANS_COUNT_TY !== "-999999" &&
                          modalHeaderText !== "Inactive (12m-18m)" &&
                          modalHeaderText !== "Inactive (18m-24m)"
                            ? currencyFormat(data.TRANS_COUNT_TY)
                            : "-"}
                        </td>
                        <td>
                          {data.PM_TY !== undefined &&
                          data.PM_TY.length !== 0 &&
                          data.PM_TY !== "-999999" &&
                          modalHeaderText !== "Inactive (12m-18m)" &&
                          modalHeaderText !== "Inactive (18m-24m)"
                            ? currencyFormat(data.PM_TY)
                            : "-"}
                        </td>
                        <td>
                          {data.AOV_TY !== undefined &&
                          data.AOV_TY.length !== 0 &&
                          data.AOV_TY !== "-999999" &&
                          modalHeaderText !== "Inactive (12m-18m)" &&
                          modalHeaderText !== "Inactive (18m-24m)"
                            ? decimalCurrencyFormat(data.AOV_TY)
                            : "-"}
                        </td>
                        <td>
                          {data.UPT_TY !== undefined &&
                          data.UPT_TY.length !== 0 &&
                          data.UPT_TY !== "-999999" &&
                          modalHeaderText !== "Inactive (12m-18m)" &&
                          modalHeaderText !== "Inactive (18m-24m)"
                            ? decimalCurrencyFormat(data.UPT_TY)
                            : "-"}
                        </td>
                        <td>
                          {data.AUR_TY !== undefined &&
                          data.AUR_TY.length !== 0 &&
                          data.AUR_TY !== "-999999" &&
                          modalHeaderText !== "Inactive (12m-18m)" &&
                          modalHeaderText !== "Inactive (18m-24m)"
                            ? decimalCurrencyFormat(data.AUR_TY)
                            : "-"}
                        </td>
                        <td>
                          {data.MARGIN_RATE_PER_TY !== undefined &&
                          data.MARGIN_RATE_PER_TY.length !== 0 &&
                          data.MARGIN_RATE_PER_TY !== "-999999" &&
                          modalHeaderText !== "Inactive (12m-18m)" &&
                          modalHeaderText !== "Inactive (18m-24m)"
                            ? decimalCurrencyFormat(data.MARGIN_RATE_PER_TY)
                            : "-"}
                        </td>
                        <td>
                          {data.NET_SALES_PER_CUST_TY !== undefined &&
                          data.NET_SALES_PER_CUST_TY.length !== 0 &&
                          data.NET_SALES_PER_CUST_TY !== "-999999" &&
                          modalHeaderText !== "Inactive (12m-18m)" &&
                          modalHeaderText !== "Inactive (18m-24m)"
                            ? decimalCurrencyFormat(data.NET_SALES_PER_CUST_TY)
                            : "-"}
                        </td>
                        <td>
                          {data.AVG_TRAN_TY !== undefined &&
                          data.AVG_TRAN_TY.length !== 0 &&
                          data.AVG_TRAN_TY !== "-999999" &&
                          modalHeaderText !== "Inactive (12m-18m)" &&
                          modalHeaderText !== "Inactive (18m-24m)"
                            ? decimalCurrencyFormat(data.AVG_TRAN_TY)
                            : "-"}
                        </td>
                      </tr>
                    );
                  })
                ) : (
                  <tr>
                    <td
                      align="center"
                      colSpan="11"
                      style={{ fontWeight: "500" }}
                    >
                      DATA NOT AVAILABLE
                    </td>
                  </tr>
                )}
                {customerMarketingTotal !== undefined &&
                customerMarketingTotal.length !== 0 &&
                customerMarketingActiveExisting !== undefined &&
                customerMarketingActiveExisting.length !== 0
                  ? customerMarketingTotal.map((data) => {
                      return (
                        <tr style={{ fontWeight: "500" }}>
                          <td>Total</td>
                          <td>
                            {data.CUST_COUNT_TY !== undefined &&
                            data.CUST_COUNT_TY.length !== 0 &&
                            data.CUST_COUNT_TY !== "-999999"
                              ? currencyFormat(data.CUST_COUNT_TY)
                              : "-"}
                          </td>
                          <td>
                            {data.NET_SALES_TY !== undefined &&
                            data.NET_SALES_TY.length !== 0 &&
                            data.NET_SALES_TY !== "-999999" &&
                            modalHeaderText !== "Inactive (12m-18m)" &&
                            modalHeaderText !== "Inactive (18m-24m)"
                              ? currencyFormat(data.NET_SALES_TY)
                              : "-"}
                          </td>
                          <td>
                            {data.TRANS_COUNT_TY !== undefined &&
                            data.TRANS_COUNT_TY.length !== 0 &&
                            data.TRANS_COUNT_TY !== "-999999" &&
                            modalHeaderText !== "Inactive (12m-18m)" &&
                            modalHeaderText !== "Inactive (18m-24m)"
                              ? currencyFormat(data.TRANS_COUNT_TY)
                              : "-"}
                          </td>
                          <td>
                            {data.PM_TY !== undefined &&
                            data.PM_TY.length !== 0 &&
                            data.PM_TY !== "-999999" &&
                            modalHeaderText !== "Inactive (12m-18m)" &&
                            modalHeaderText !== "Inactive (18m-24m)"
                              ? currencyFormat(data.PM_TY)
                              : "-"}
                          </td>
                          <td>
                            {data.AOV_TY !== undefined &&
                            data.AOV_TY.length !== 0 &&
                            data.AOV_TY !== "-999999" &&
                            modalHeaderText !== "Inactive (12m-18m)" &&
                            modalHeaderText !== "Inactive (18m-24m)"
                              ? decimalCurrencyFormat(data.AOV_TY)
                              : "-"}
                          </td>
                          <td>
                            {data.UPT_TY !== undefined &&
                            data.UPT_TY.length !== 0 &&
                            data.UPT_TY !== "-999999" &&
                            modalHeaderText !== "Inactive (12m-18m)" &&
                            modalHeaderText !== "Inactive (18m-24m)"
                              ? decimalCurrencyFormat(data.UPT_TY)
                              : "-"}
                          </td>
                          <td>
                            {data.AUR_TY !== undefined &&
                            data.AUR_TY.length !== 0 &&
                            data.AUR_TY !== "-999999" &&
                            modalHeaderText !== "Inactive (12m-18m)" &&
                            modalHeaderText !== "Inactive (18m-24m)"
                              ? decimalCurrencyFormat(data.AUR_TY)
                              : "-"}
                          </td>
                          <td>
                            {data.MARGIN_RATE_PER_TY !== undefined &&
                            data.MARGIN_RATE_PER_TY.length !== 0 &&
                            data.MARGIN_RATE_PER_TY !== "-999999" &&
                            modalHeaderText !== "Inactive (12m-18m)" &&
                            modalHeaderText !== "Inactive (18m-24m)"
                              ? decimalCurrencyFormat(data.MARGIN_RATE_PER_TY)
                              : "-"}
                          </td>
                          <td>
                            {data.NET_SALES_PER_CUST_TY !== undefined &&
                            data.NET_SALES_PER_CUST_TY.length !== 0 &&
                            data.NET_SALES_PER_CUST_TY !== "-999999" &&
                            modalHeaderText !== "Inactive (12m-18m)" &&
                            modalHeaderText !== "Inactive (18m-24m)"
                              ? decimalCurrencyFormat(
                                  data.NET_SALES_PER_CUST_TY
                                )
                              : "-"}
                          </td>
                          <td>
                            {data.AVG_TRAN_TY !== undefined &&
                            data.AVG_TRAN_TY.length !== 0 &&
                            data.AVG_TRAN_TY !== "-999999" &&
                            modalHeaderText !== "Inactive (12m-18m)" &&
                            modalHeaderText !== "Inactive (18m-24m)"
                              ? decimalCurrencyFormat(data.AVG_TRAN_TY)
                              : "-"}
                          </td>
                        </tr>
                      );
                    })
                  : ""}
              </tbody>
            </Table>
          </div>
        </Modal.Body>
      </Modal>
    </>
  );
}

export default ReturningCustomerModal;
