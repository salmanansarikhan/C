import React, { useState, useEffect, useCallback, useRef } from "react";
import { useSelector, useDispatch } from "react-redux";
import { Dropdown, Form, Placeholder } from "react-bootstrap";
import DatePicker from "react-datetime";
import moment from "moment";
import axios from "axios";
import CdhHome from "../CdhHome/CdhHome";
// import Footer from "../Footer/Footer";
// import Header from "../Header/Header";
import "./HomePage.css";
import "react-datetime/css/react-datetime.css";
import { handleDateChange } from "../../Redux/Actions/DateChangeActions";
import { handleBannerChange } from "../../Redux/Actions/BannerChangeActions";
import { handleCategoryChange } from "../../Redux/Actions/CategoryChangeActions";
import calender from "../../assests/images/calender.svg";
import { getDateFormat, getDateMinusTwoYear } from "../Utils";
import { UTCtoEST, accessRights } from "../Utils";
import NotificationMessage from "../NotificationMessage/NotificationMessage";
import NoAccess from "../NoAccess/NoAccess";
import Spinner from "react-bootstrap/Spinner";

const Banners = [
  { value: "All Banner", id: "0" },
  { value: "BBBY US", id: "1" },
  { value: "BBBY CA", id: "2" },
  { value: "buy buy Baby", id: "3" },
  { value: "Harmon", id: "5" },
];
const Category = [
  { value: "All Customers", id: "ALL" },
  { value: "Beyond+", id: "BPLUS" },
  { value: "Credit Card", id: "CC" },
  { value: "Beyond+ & Credit Card", id: "BC" },
  { value: "App", id: "APP" },
];
const CustomerStatus = [
  { value: "Returning Customers", id: "Stable_Exist" },
  { value: "New Customers", id: "Stable_New_L12m" },
  { value: "At risk (6m-9m)", id: "Atrisk_6m_9m" },
  { value: "At risk (9m-12m)", id: "Atrisk_9m-12m" },
  { value: "Inactive (13m-18m)", id: "Inactive_13m_18m" },
  { value: "Inactive (18m-24m)", id: "Inactive_18m_24m" },
];

function HomePage() {
  const dispatch = useDispatch();
  let dateObjforMax = new Date();
  dateObjforMax.setUTCDate(dateObjforMax.getUTCDate() - 2);
  let Maxday = dateObjforMax.getUTCDate();
  let Maxyear = dateObjforMax.getUTCFullYear();
  let Maxmonth = dateObjforMax.getUTCMonth() + 1; //months from 1-12
  let MaxDayforPicker =
    Maxyear +
    "-" +
    (Maxmonth < 10 ? `0${Maxmonth}` : Maxmonth) +
    "-" +
    (Maxday < 10 ? `0${Maxday}` : Maxday);
  const [selectedBanner, setSelectedBanner] = useState(Banners[0]);
  const [customerDataSixMonths, setCustomerDataSixMonths] = useState();
  const [customerDataNineMonths, setCustomerDataNineMonths] = useState();
  const [customerActiveData, setCustomerActiveData] = useState();
  const [customerActiveExisting, setCustomerActiveExisting] = useState();
  const [customerInActive_12_18_Data, setCustomerInActive_12_18_Data] =
    useState();
  const [customerInActive_18_24_Data, setCustomerInActive_18_24_Data] =
    useState();
  const [firsthalftotalData, setFirst_half_total_Data] = useState();
  const [secondhalftotalData, setSecond_half_total_Data] = useState();
  const [customerDataInactive, setCustomerDataInactive] = useState();
  const [customerTotal, setTotal] = useState();
  const [firstFourTotalData, setFirst_Four_Total_Data] = useState();
  const [customerInActive_24plus_Data, setCustomerInActive_24plus_Data] =
    useState();
  const [recordAvailableDates, setRecordAvailableDates] = useState();
  const [refreshTime, setRefreshTime] = useState("");
  const [accessRightsData, setaccessRightsData] = useState("");
  const refreshDate =
    refreshTime.length > 0 && UTCtoEST(refreshTime[0].end_time * 1000);

  const [loading, setloader] = useState({
    AtRisk_6m_9m: false,
    AtRisk_9m_12m: false,
    Active_Existing: false,
    Active_L12m: false,
    Inactive_12m_18m: false,
    Inactive_18m_24m: false,
    UnIdentifed_Customers: false,
    first_half_total: false,
    second_half_total: false,
    total: false,
    first_Four_Total: false,
    Inactive_24mp: false,
    record_dates: false,
    refreshTime: false,
    access: false,
  });
  const [chkBox, isChkBox] = useState({
    isAllCust: true,
    isBPlus: false,
    isCc: false,
    isBcc: false,
    isApp: false,
    isWPlus: false,
  });
  const [disableBplus, isdisableBplus] = useState(false);
  const [disableWplus, isdisableWplus] = useState(false);

  const selectedBannerId = useSelector((store) => store.Banner.id);
  const selectedCategoryId = useSelector((store) => store.Category.id);
  const selectedDate = useSelector((store) => store.Date.value);

  const [defaultDate, setDefaultDate] = useState(moment().subtract(2, "days"));

  const [periodStartDate, setPeriodStartDate] = useState("");
  const [periodEndDate, setPeriodEndDate] = useState("");

  if (selectedCategoryId === "ALL") {
    chkBox.isAllCust = true;
  }

  const handleBanner = useCallback(
    (event) => {
      setSelectedBanner((prevsValue) => ({
        ...prevsValue,
        value: event.target.innerText,
        id: event.target.id,
      }));
      dispatch(
        handleBannerChange({
          value: event.target.innerText,
          id: event.target.id,
        })
      );
      if (event.target.id === "3" || event.target.id === "5") {
        isdisableBplus(true);
      } else {
        isdisableBplus(false);
      }
    },
    [selectedBannerId]
  );

  const handleDate = (dateSelected) => {
    setPeriodStartDate(getDateMinusTwoYear(dateSelected));
    setPeriodEndDate(moment(dateSelected));
    if (moment(dateSelected, "MM/DD/YYYY", true).isValid()) {
      setDefaultDate();
      dispatch(handleDateChange(dateSelected.format("YYYY-MM-DD")));
    } else {
      setDefaultDate(moment().subtract(2, "days"));
    }
  };

  const onChangeCheck = useCallback(
    (e) => {
      if (e.target.value === "ALL") {
        isChkBox(() => ({
          isAllCust: true,
          isBPlus: false,
          isCc: false,
          isApp: false,
          isWPlus: false,
        }));

        dispatch(
          handleCategoryChange({
            value: e.target.id,
            id: e.target.value,
          })
        );
      } else if (e.target.value === "BPLUS") {
        isChkBox((value) => ({
          ...value,
          isAllCust: false,
          isBPlus: !chkBox.isBPlus,
          isWPlus: false,
        }));
        if (e.target.checked) {
          setSelectedBanner({ value: "BBBY US", id: "1" });
          dispatch(
            handleCategoryChange({
              value:
                chkBox.isCc && chkBox.isApp
                  ? "BCA"
                  : chkBox.isCc
                  ? "BC"
                  : chkBox.isApp
                  ? "BA"
                  : e.target.id,
              id:
                chkBox.isCc && chkBox.isApp
                  ? "BCA"
                  : chkBox.isCc
                  ? "BC"
                  : chkBox.isApp
                  ? "BA"
                  : e.target.value,
            })
          );
          dispatch(handleBannerChange({ value: "BBBY US", id: "1" }));
        } else {
          setSelectedBanner({ value: "BBBY US", id: "1" });

          dispatch(
            handleCategoryChange({
              value:
                chkBox.isCc && chkBox.isApp
                  ? "CA"
                  : chkBox.isCc
                  ? "CC"
                  : chkBox.isApp
                  ? "APP"
                  : "ALL",
              id:
                chkBox.isCc && chkBox.isApp
                  ? "CA"
                  : chkBox.isCc
                  ? "CC"
                  : chkBox.isApp
                  ? "APP"
                  : "ALL",
            })
          );
          dispatch(handleBannerChange({ value: "BBBY US", id: "1" }));
        }
      } else if (e.target.value === "CC") {
        isChkBox((value) => ({
          ...value,
          isAllCust: false,
          isCc: !chkBox.isCc,
        }));
        if (e.target.checked) {
          !chkBox.isWPlus && setSelectedBanner({ value: "BBBY US", id: "1" });
          dispatch(
            handleCategoryChange({
              value:
                chkBox.isBPlus && chkBox.isApp
                  ? "BCA"
                  : chkBox.isWPlus && chkBox.isApp
                  ? "WCA"
                  : chkBox.isApp
                  ? "CA"
                  : chkBox.isBPlus
                  ? "BC"
                  : chkBox.isWPlus
                  ? "WC"
                  : e.target.id,
              id:
                chkBox.isBPlus && chkBox.isApp
                  ? "BCA"
                  : chkBox.isWPlus && chkBox.isApp
                  ? "WCA"
                  : chkBox.isApp
                  ? "CA"
                  : chkBox.isBPlus
                  ? "BC"
                  : chkBox.isWPlus
                  ? "WC"
                  : e.target.value,
            })
          );
          !chkBox.isWPlus &&
            dispatch(handleBannerChange({ value: "BBBY US", id: "1" }));
        } else {
          !chkBox.isWPlus && setSelectedBanner({ value: "BBBY US", id: "1" });

          dispatch(
            handleCategoryChange({
              value:
                chkBox.isBPlus && chkBox.isApp
                  ? "BA"
                  : chkBox.isWPlus && chkBox.isApp
                  ? "WA"
                  : chkBox.isBPlus
                  ? "BPLUS"
                  : chkBox.isWPlus
                  ? "WPLUS"
                  : chkBox.isApp
                  ? "APP"
                  : "ALL",
              id:
                chkBox.isBPlus && chkBox.isApp
                  ? "BA"
                  : chkBox.isWPlus && chkBox.isApp
                  ? "WA"
                  : chkBox.isBPlus
                  ? "BPLUS"
                  : chkBox.isWPlus
                  ? "WPLUS"
                  : chkBox.isApp
                  ? "APP"
                  : "ALL",
            })
          );
          !chkBox.isWPlus &&
            dispatch(handleBannerChange({ value: "BBBY US", id: "1" }));
        }
      } else if (e.target.value === "APP") {
        isChkBox((value) => ({
          ...value,
          isAllCust: false,
          isApp: !chkBox.isApp,
        }));
        if (e.target.checked) {
          dispatch(
            handleCategoryChange({
              value:
                chkBox.isBPlus && chkBox.isCc
                  ? "BCA"
                  : chkBox.isWPlus && chkBox.isCc
                  ? "WCA"
                  : chkBox.isCc
                  ? "CA"
                  : chkBox.isBPlus
                  ? "BA"
                  : chkBox.isWPlus
                  ? "WA"
                  : e.target.id,
              id:
                chkBox.isBPlus && chkBox.isCc
                  ? "BCA"
                  : chkBox.isWPlus && chkBox.isCc
                  ? "WCA"
                  : chkBox.isCc
                  ? "CA"
                  : chkBox.isBPlus
                  ? "BA"
                  : chkBox.isWPlus
                  ? "WA"
                  : e.target.value,
            })
          );
        } else {
          dispatch(
            handleCategoryChange({
              value:
                chkBox.isBPlus && chkBox.isCc
                  ? "BC"
                  : chkBox.isWPlus && chkBox.isCc
                  ? "WC"
                  : chkBox.isBPlus
                  ? "BPLUS"
                  : chkBox.isWPlus
                  ? "WPLUS"
                  : chkBox.isCc
                  ? "CC"
                  : "ALL",
              id:
                chkBox.isBPlus && chkBox.isCc
                  ? "BC"
                  : chkBox.isWPlus && chkBox.isCc
                  ? "WC"
                  : chkBox.isBPlus
                  ? "BPLUS"
                  : chkBox.isWPlus
                  ? "WPLUS"
                  : chkBox.isCc
                  ? "CC"
                  : "ALL",
            })
          );
        }
      } else if (e.target.value === "WPLUS") {
        isChkBox((value) => ({
          ...value,
          isAllCust: false,
          isWPlus: !chkBox.isWPlus,
          isBPlus: false,
        }));
        if (e.target.checked) {
          dispatch(
            handleCategoryChange({
              value:
                chkBox.isCc && chkBox.isApp
                  ? "WCA"
                  : chkBox.isCc
                  ? "WC"
                  : chkBox.isApp
                  ? "WA"
                  : e.target.id,
              id:
                chkBox.isCc && chkBox.isApp
                  ? "WCA"
                  : chkBox.isCc
                  ? "WC"
                  : chkBox.isApp
                  ? "WA"
                  : e.target.value,
            })
          );
        } else {
          dispatch(
            handleCategoryChange({
              value:
                chkBox.isCc && chkBox.isApp
                  ? "CA"
                  : chkBox.isCc
                  ? "CC"
                  : chkBox.isApp
                  ? "APP"
                  : "ALL",
              id:
                chkBox.isCc && chkBox.isApp
                  ? "CA"
                  : chkBox.isCc
                  ? "CC"
                  : chkBox.isApp
                  ? "APP"
                  : "ALL",
            })
          );
        }
      }
      if (selectedCategoryId === "BCA") {
        setSelectedBanner({ value: "BBBY US", id: "1" });
        dispatch(handleBannerChange({ value: "BBBY US", id: "1" }));
      }
    },
    [selectedCategoryId]
  );

  useEffect(() => {
    const getLastRefreshTime = async () => {
      try {
        setloader((currValue) => ({
          ...currValue,
          refreshTime: true,
        }));
        let url =
          process.env.REACT_APP_API_ENDPOINT +
          process.env.REACT_APP_REFRESH_TIME +
          "dagId=OVERALL_HEALTH";
        await axios({ url }).then((res) => {
          setloader((currValue) => ({
            ...currValue,
            refreshTime: false,
          }));
          setRefreshTime(res.data);
        });
      } catch (err) {
        setloader((currValue) => ({
          ...currValue,
          refreshTime: true,
        }));
        console.log("err-getLastRefreshTime", err);
      }
    };
    const fetchAccessManagement = async () => {
      try {
        setloader((currValue) => ({
          ...currValue,
          access: true,
        }));
        let url =
          process.env.REACT_APP_API_ENDPOINT +
          process.env.REACT_APP_ACCESS_MANAGEMENT +
          "userId=" +
          localStorage.getItem("userId").toUpperCase();
        await axios({ url }).then((res) => {
          setloader((currValue) => ({
            ...currValue,
            access: false,
          }));
          setaccessRightsData(res.data);
          accessRights(res.data);
        });
      } catch (err) {
        setloader((currValue) => ({
          ...currValue,
          access: true,
        }));
        console.log("err-fetchAccessManagement", err);
      }
    };
    //if (localStorage.getItem("userId")) fetchAccessManagement();
    getLastRefreshTime();
  }, []);

  useEffect(() => {
    setPeriodStartDate(getDateMinusTwoYear(defaultDate));
    setPeriodEndDate(moment(defaultDate));
  }, []);

  useEffect(() => {
    const getRecordAvailableDates = async () => {
      try {
        setloader((currValue) => ({
          ...currValue,
          record_dates: true,
        }));
        let url =
          process.env.REACT_APP_API_ENDPOINT +
          process.env.REACT_APP_RECORD_AVAILABLE_DATES +
          "concept=" +
          selectedBannerId +
          "&customerType=" +
          selectedCategoryId +
          "&channelType=" +
          "ALL";
        await axios({ url }).then((res) => {
          setloader((currValue) => ({
            ...currValue,
            record_dates: false,
          }));
          setRecordAvailableDates(res.data);
        });
      } catch (err) {
        console.log("err-getRecordAvailableDates", err);
        setloader((currValue) => ({
          ...currValue,
          record_dates: false,
        }));
      }
    };

    getRecordAvailableDates();
  }, [selectedBannerId, selectedCategoryId]);

  useEffect(() => {
    if (selectedBannerId === "3" || selectedBannerId === "5") {
      isdisableBplus(true);
    } else {
      isdisableBplus(false);
    }
    const fetchCustomerDataSixMonths = async () => {
      try {
        setloader((currValue) => ({
          ...currValue,
          AtRisk_6m_9m: true,
        }));
        let url =
          process.env.REACT_APP_API_ENDPOINT +
          process.env.REACT_APP_CUSTOMER_6m_9m +
          "concept=" +
          selectedBannerId +
          "&date=" +
          selectedDate +
          "&customerType=" +
          selectedCategoryId +
          "&channelType=" +
          "ALL";
        await axios({ url }).then((res) => {
          setloader((currValue) => ({
            ...currValue,
            AtRisk_6m_9m: false,
          }));
          setCustomerDataSixMonths(res.data);
        });
      } catch (err) {
        console.log("err-fetchCustomerDataSixMonths", err);
        setloader((currValue) => ({
          ...currValue,
          AtRisk_6m_9m: false,
        }));
      }
    };
    const fetchCustomerDataNineMonths = async () => {
      try {
        setloader((currValue) => ({
          ...currValue,
          AtRisk_9m_12m: true,
        }));
        let url =
          process.env.REACT_APP_API_ENDPOINT +
          process.env.REACT_APP_CUSTOMER_9m_12m +
          "concept=" +
          selectedBannerId +
          "&date=" +
          selectedDate +
          "&customerType=" +
          selectedCategoryId +
          "&channelType=" +
          "ALL";
        await axios({ url }).then((res) => {
          setCustomerDataNineMonths(res.data);
          setloader((currValue) => ({
            ...currValue,
            AtRisk_9m_12m: false,
          }));
        });
      } catch (err) {
        console.log("err-fetchCustomerDataNineMonths", err);
        setloader((currValue) => ({
          ...currValue,
          AtRisk_9m_12m: false,
        }));
      }
    };
    const fetchCustomerDataActive = async () => {
      try {
        setloader((currValue) => ({
          ...currValue,
          Active_L12m: true,
        }));
        let url =
          process.env.REACT_APP_API_ENDPOINT +
          process.env.REACT_APP_CUSTOMER_Active +
          "concept=" +
          selectedBannerId +
          "&date=" +
          selectedDate +
          "&customerType=" +
          selectedCategoryId +
          "&channelType=" +
          "ALL";
        await axios({ url }).then((res) => {
          setCustomerActiveData(res.data);
          setloader((currValue) => ({
            ...currValue,
            Active_L12m: false,
          }));
        });
      } catch (err) {
        console.log("err-fetchCustomerDataActive", err);
        setloader((currValue) => ({
          ...currValue,
          Active_L12m: false,
        }));
      }
    };
    const fetchCustomerDataActiveExisting = async () => {
      try {
        setloader((currValue) => ({
          ...currValue,
          Active_Existing: true,
        }));
        let url =
          process.env.REACT_APP_API_ENDPOINT +
          process.env.REACT_APP_CUSTOMER_Active_Existing +
          "concept=" +
          selectedBannerId +
          "&date=" +
          selectedDate +
          "&customerType=" +
          selectedCategoryId +
          "&channelType=" +
          "ALL";
        await axios({ url }).then((res) => {
          setCustomerActiveExisting(res.data);
          setloader((currValue) => ({
            ...currValue,
            Active_Existing: false,
          }));
        });
      } catch (err) {
        console.log("err-fetchCustomerDataActiveExisting", err);
        setloader((currValue) => ({
          ...currValue,
          Active_Existing: false,
        }));
      }
    };
    const fetchCustomerDataInActive_12_18 = async () => {
      try {
        setloader((currValue) => ({
          ...currValue,
          Inactive_12m_18m: true,
        }));
        let url =
          process.env.REACT_APP_API_ENDPOINT +
          process.env.REACT_APP_CUSTOMER_InActive_12_18 +
          "concept=" +
          selectedBannerId +
          "&date=" +
          selectedDate +
          "&customerType=" +
          selectedCategoryId +
          "&channelType=" +
          "ALL";
        await axios({ url }).then((res) => {
          setCustomerInActive_12_18_Data(res.data);
          setloader((currValue) => ({
            ...currValue,
            Inactive_12m_18m: false,
          }));
        });
      } catch (err) {
        console.log("err-fetchCustomerDataInActive_12_18", err);
        setloader((currValue) => ({
          ...currValue,
          Inactive_12m_18m: false,
        }));
      }
    };
    const fetchCustomerDataInActive_18_24 = async () => {
      try {
        setloader((currValue) => ({
          ...currValue,
          Inactive_18m_24m: true,
        }));
        let url =
          process.env.REACT_APP_API_ENDPOINT +
          process.env.REACT_APP_CUSTOMER_InActive_18_24 +
          "concept=" +
          selectedBannerId +
          "&date=" +
          selectedDate +
          "&customerType=" +
          selectedCategoryId +
          "&channelType=" +
          "ALL";
        await axios({ url }).then((res) => {
          setCustomerInActive_18_24_Data(res.data);
          setloader((currValue) => ({
            ...currValue,
            Inactive_18m_24m: false,
          }));
        });
      } catch (err) {
        console.log("err-fetchCustomerDataInActive_18_24", err);
        setloader((currValue) => ({
          ...currValue,
          Inactive_18m_24m: false,
        }));
      }
    };
    const fetchTotalfirstHalf = async () => {
      try {
        setloader((currValue) => ({
          ...currValue,
          first_half_total: true,
        }));
        let url =
          process.env.REACT_APP_API_ENDPOINT +
          process.env.REACT_APP_CUSTOMER_First_half_total +
          "concept=" +
          selectedBannerId +
          "&date=" +
          selectedDate +
          "&customerType=" +
          selectedCategoryId +
          "&channelType=" +
          "ALL";
        await axios({ url }).then((res) => {
          setFirst_half_total_Data(res.data);
          setloader((currValue) => ({
            ...currValue,
            first_half_total: false,
          }));
        });
      } catch (err) {
        console.log("err-fetchTotalfirstHalf", err);
        setloader((currValue) => ({
          ...currValue,
          first_half_total: false,
        }));
      }
    };
    const fetchTotalsecondHalf = async () => {
      try {
        setloader((currValue) => ({
          ...currValue,
          second_half_total: true,
        }));
        let url =
          process.env.REACT_APP_API_ENDPOINT +
          process.env.REACT_APP_CUSTOMER_Second_half_total +
          "concept=" +
          selectedBannerId +
          "&date=" +
          selectedDate +
          "&customerType=" +
          selectedCategoryId +
          "&channelType=" +
          "ALL";
        await axios({ url }).then((res) => {
          setSecond_half_total_Data(res.data);
          setloader((currValue) => ({
            ...currValue,
            second_half_total: false,
          }));
        });
      } catch (err) {
        console.log("err-fetchTotalsecondHalf", err);
        setloader((currValue) => ({
          ...currValue,
          second_half_total: false,
        }));
      }
    };
    const fetchCustomerDataInActive = async () => {
      try {
        setloader((currValue) => ({
          ...currValue,
          UnIdentifed_Customers: true,
        }));
        let url =
          process.env.REACT_APP_API_ENDPOINT +
          process.env.REACT_APP_CUSTOMER_Unidentified +
          "concept=" +
          selectedBannerId +
          "&date=" +
          selectedDate +
          "&customerType=" +
          selectedCategoryId +
          "&channelType=" +
          "ALL";
        await axios({ url }).then((res) => {
          setCustomerDataInactive(res.data);
          setloader((currValue) => ({
            ...currValue,
            UnIdentifed_Customers: false,
          }));
        });
      } catch (err) {
        console.log("err-fetchCustomerDataInActive", err);
        setloader((currValue) => ({
          ...currValue,
          UnIdentifed_Customers: false,
        }));
      }
    };
    const fetchCustomerTotal = async () => {
      try {
        setloader((currValue) => ({
          ...currValue,
          total: true,
        }));
        let url =
          process.env.REACT_APP_API_ENDPOINT +
          process.env.REACT_APP_CUSTOMER_total +
          "concept=" +
          selectedBannerId +
          "&date=" +
          selectedDate +
          "&customerType=" +
          selectedCategoryId +
          "&channelType=" +
          "ALL";
        await axios({ url }).then((res) => {
          setTotal(res.data);
          setloader((currValue) => ({
            ...currValue,
            total: false,
          }));
        });
      } catch (err) {
        console.log("err-fetchCustomerTotal", err);
        setloader((currValue) => ({
          ...currValue,
          total: false,
        }));
      }
    };
    const fetchfirstFourTotal = async () => {
      try {
        setloader((currValue) => ({
          ...currValue,
          first_four_total: true,
        }));
        let url =
          process.env.REACT_APP_API_ENDPOINT +
          process.env.REACT_APP_CUSTOMER_First_Four_Total +
          "concept=" +
          selectedBannerId +
          "&date=" +
          selectedDate +
          "&customerType=" +
          selectedCategoryId +
          "&channelType=" +
          "ALL";
        await axios({ url }).then((res) => {
          setFirst_Four_Total_Data(res.data);
          setloader((currValue) => ({
            ...currValue,
            first_four_total: false,
          }));
        });
      } catch (err) {
        console.log("err-fetchfirstFourTotal", err);
        setloader((currValue) => ({
          ...currValue,
          first_four_total: false,
        }));
      }
    };
    const fetchCustomerDataInActive_24p = async () => {
      try {
        setloader((currValue) => ({
          ...currValue,
          Inactive_24mp: true,
        }));
        let url =
          process.env.REACT_APP_API_ENDPOINT +
          process.env.REACT_APP_CUSTOMER_24_Plus +
          "concept=" +
          selectedBannerId +
          "&date=" +
          selectedDate +
          "&customerType=" +
          selectedCategoryId +
          "&channelType=" +
          "ALL";
        await axios({ url }).then((res) => {
          setCustomerInActive_24plus_Data(res.data);
          setloader((currValue) => ({
            ...currValue,
            Inactive_24mp: false,
          }));
        });
      } catch (err) {
        console.log("err-fetchCustomerDataInActive_24p", err);
        setloader((currValue) => ({
          ...currValue,
          Inactive_24mp: false,
        }));
      }
    };
    if (
      localStorage.getItem("isOVERALL_HEALTH") === "Y" ||
      localStorage.getItem("isOVERALL_HEALTH") === null
    ) {
      fetchCustomerDataActive();
      fetchCustomerDataActiveExisting();
      fetchCustomerDataSixMonths();
      fetchCustomerDataNineMonths();
      fetchCustomerDataInActive_12_18();
      fetchCustomerDataInActive_18_24();
      fetchTotalfirstHalf();
      fetchTotalsecondHalf();
      fetchCustomerDataInActive();
      fetchCustomerTotal();
      fetchfirstFourTotal();
      fetchCustomerDataInActive_24p();
    }
  }, [selectedDate, selectedBannerId, selectedCategoryId]);

  let customDatess =
    recordAvailableDates &&
    recordAvailableDates.map((item) => {
      return item["TRANS_DATE"];
    });
  const maxDay = moment().subtract(2, "days");
  const disableCustomDt = (current) => {
    return (
      customDatess &&
      customDatess.includes(current.format("YYYY-MM-DD")) && // getRecordAvailableDates
      current.isBefore(maxDay) // &&
      // !current.isBefore(moment("2022-02-28").toDate())
    );
  };
  return localStorage.getItem("isOVERALL_HEALTH") === "Y" ? (
    <div>
      {/* <Header /> */}
      {refreshTime.length > 0 && <NotificationMessage message={refreshDate} />}
      <div className="mt-1 d-flex align-items-center headings">
        <div className="d-flex justify-content-start p-3">
          <span className="progselectupText">Concept</span>
        </div>
        <div className="d-flex justify-content-start p-3">
          <span className="progselectupText">Type</span>
        </div>
      </div>
      <div className="mt-3 d-flex align-items-center">
        <div className="d-flex justify-content-start p-3">
          <Dropdown className="d-inline">
            <Dropdown.Toggle>{selectedBanner.value}</Dropdown.Toggle>
            <Dropdown.Menu
              className="dropdown-menu-ext"
              onClick={(e) => handleBanner(e)}
            >
              {selectedCategoryId === "BPLUS" ||
              selectedCategoryId === "BC" ||
              selectedCategoryId === "BCA"
                ? Banners.filter((banner) => {
                    return banner.id === "1";
                  }).map((banner) => {
                    return (
                      <Dropdown.Item
                        key={banner.id}
                        className="dropdown-item-ext"
                        id={banner.id}
                      >
                        {banner.value}
                      </Dropdown.Item>
                    );
                  })
                : Banners.map((data) => {
                    return (
                      <Dropdown.Item
                        key={data.id}
                        className="dropdown-item-ext"
                        id={data.id}
                      >
                        {data.value}
                      </Dropdown.Item>
                    );
                  })}
            </Dropdown.Menu>
          </Dropdown>
        </div>
        <div className="d-flex justify-content-start p-3">
          <label className="chkBox-label">
            <input
              type="checkbox"
              checked={chkBox.isAllCust}
              onChange={onChangeCheck}
              value="ALL"
              id="All Customers"
              className="chkBox"
            />{" "}
            All Customers
          </label>
        </div>
        <div className="d-flex justify-content-start p-3">
          <label className="chkBox-label">
            <input
              type="checkbox"
              checked={chkBox.isBPlus}
              onChange={onChangeCheck}
              value="BPLUS"
              id="Beyond+"
              className="chkBox"
              disabled={disableBplus}
            />{" "}
            Beyond+
          </label>
        </div>
        <div className="d-flex justify-content-start p-3">
          <label className="chkBox-label">
            <input
              type="checkbox"
              checked={chkBox.isWPlus}
              onChange={onChangeCheck}
              value="WPLUS"
              id="Welcome+"
              className="chkBox"
              disabled={disableWplus}
            />{" "}
            Welcome+
          </label>
        </div>
        <div className="d-flex justify-content-start p-3">
          <label className="chkBox-label">
            <input
              type="checkbox"
              checked={chkBox.isCc}
              onChange={onChangeCheck}
              value="CC"
              id="Credit Card"
              className="chkBox"
            />{" "}
            Credit Card
          </label>
        </div>
        <div className="d-flex justify-content-start p-3">
          <label className="chkBox-label">
            <input
              type="checkbox"
              checked={chkBox.isApp}
              onChange={onChangeCheck}
              value="APP"
              id="APP"
              className="chkBox"
            />{" "}
            APP
          </label>
        </div>
        {/* <div className="d-flex justify-content-start p-3">
            <Form.Group controlId="duedate">
              <Form.Control
                type="date"
                name="datePicker"
                placeholder="select a Date"
                value={selectedDate}
                onChange={(e) => handleDate(e.target.value)}
                max={MaxDayforPicker}
              />
            </Form.Group>
          </div> */}
        {loading.record_dates ? (
          <Placeholder.Button xs={1} />
        ) : (
          <div className="d-flex justify-content-start p-3">
            <label
              className="d-flex datepicker"
              onClick={(e) => e.preventDefault()}
            >
              <DatePicker
                timeFormat={false}
                value={
                  defaultDate
                    ? defaultDate
                    : moment(selectedDate).format("MM/DD/YYYY")
                }
                isValidDate={disableCustomDt}
                onChange={(date) => handleDate(date)}
                closeOnSelect
                inputProps={{ readOnly: true }}
              />
              <img src={calender} className="date-picker-icon" />
            </label>
          </div>
        )}
        <div
          className="d-flex justify-content-start p-3"
          style={{ marginLeft: "-6rem" }}
        >
          {!loading.record_dates && periodStartDate !== "" ? (
            <div>
              <span>{`(${getDateFormat(periodStartDate)} - ${getDateFormat(
                periodEndDate
              )})`}</span>
            </div>
          ) : (
            ""
          )}
        </div>
      </div>

      {selectedCategoryId === "ALL" || "BPLUS" || "CC" || "BC" || "APP" ? (
        <CdhHome
          customerDataSixMonths={customerDataSixMonths}
          customerDataNineMonths={customerDataNineMonths}
          customerActiveData={customerActiveData}
          customerActiveExisting={customerActiveExisting}
          customerInActive_12_18_Data={customerInActive_12_18_Data}
          customerInActive_18_24_Data={customerInActive_18_24_Data}
          firsthalftotalData={firsthalftotalData}
          secondhalftotalData={secondhalftotalData}
          loading={loading}
          selectedCategoryId={selectedCategoryId}
          customerUnidentifiedData={customerDataInactive}
          customerTotal={customerTotal}
          firstFourTotalData={firstFourTotalData}
          customerInActive_24plus_Data={customerInActive_24plus_Data}
          selectedBannerId={selectedBannerId}
          selectedDate={selectedDate}
          periodStartDate={periodStartDate}
          periodEndDate={periodEndDate}
        />
      ) : (
        ""
      )}
      {/* <Footer /> */}
    </div>
  ) : localStorage.getItem("isOVERALL_HEALTH") !== null && (
      <>
        {/* <Header /> */}
        <NoAccess tabName="Overall health" />
        {/* <Footer /> */}
      </>
    ) ? (
    <>
      {/* <Header /> */}
      <NoAccess tabName="Overall health" />
      {/* <Footer /> */}
    </>
  ) : (
    <div style={{ height: "100vh" }} className="spinner">
      {loading.access && <Spinner animation="border" variant="primary" />}
      {accessRightsData.length === "" && <NoAccess tabName="Overall health" />}:
    </div>
  );
}

export default HomePage;
