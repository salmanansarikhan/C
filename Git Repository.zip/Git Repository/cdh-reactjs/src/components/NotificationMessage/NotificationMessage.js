import React, { useState } from "react";
import Alert from "react-bootstrap/Alert";
import { getDateFormatFromDB } from "../Utils";
import './NotificationMessage.css'
  
const NotificationMessage = ({message, maxDate}) => {
    const [show, setShow] = useState(true);
    const currentTabname = localStorage?.getItem("currentTabName");
    const maxDateValue = maxDate ? getDateFormatFromDB(maxDate[0].MAX_DATE): '';
    if (show) {
      return (
        <Alert variant="info" onClose={() => setShow(false)} dismissible>
          {currentTabname === 'feedback' ? <div className="refreshtext">{maxDateValue ? `Data last refreshed at ${message} | Data availablity till ${maxDateValue}` : `Data last refreshed at ${message}`}</div> :
          <div className="refreshtext">{`Data last refreshed at ${message}`}</div>}
        </Alert>
      );
    }
    else{
      return <></>
    }
};
  
export default NotificationMessage;