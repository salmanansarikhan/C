import moment from "moment";
import dateFormat from "dateformat";
import ReactTooltip from "react-tooltip";
import { FiInfo } from "react-icons/fi";

export const getDateFormatFromDB = (value) => {
  const dateReplace = value.replaceAll("-", "/");
  let date = dateFormat(dateReplace, "mm/dd/yyyy");
  return date;
};

export const getDateFormat = (value) => {
  let date = moment(new Date(value)).format("MM/DD/YYYY");
  return date;
};

export const getDateMinusTwoYear = (value) => {
  let date = moment(value).subtract(1, "years");
  return date;
};

export const gettooltip = (clsName, datafor, id, text, text2 = "") => {
  return (
    <span>
      <FiInfo className={clsName} data-tip data-for={datafor} />
      <ReactTooltip
        className="tooltip_css "
        id={id}
        place="top"
        effect="float"
        backgroundColor="#595959"
      >
        {text}
        <br />
        {text2}
      </ReactTooltip>
    </span>
  );
};

export const UTCtoEST = (time) => {
  let ESTdate = new Date(parseInt(time));
  let usaTime = ESTdate.toLocaleString("en-US", { timeZone: "UTC" });
  //
  // let dateToMilliseconds = ESTdate.getTime();
  // let subtractedDays = dateToMilliseconds + (-86400000*2);
  // let newDate = new Date(subtractedDays);
  // let substractedUsaTime = newDate.toLocaleString('en-US', { timeZone: 'UTC' })
  // return [usaTime, substractedUsaTime] ;
  return usaTime;
};

export const  DateCompare = (DateA, DateB) => {
  var a = new Date(DateA + "T00:00:00");
  var b = new Date(DateB + "T00:00:00");

  // let msDateA = Date.UTC(a.getFullYear(), a.getMonth() + 1, a.getDate());
  // let msDateB = Date.UTC(b.getFullYear(), b.getMonth() + 1, b.getDate());

  let msDateA = parseInt(
    a.getFullYear().toString() +
      ("0" + (a.getMonth() + 1)).slice(-2) +
      ("0" + a.getDate()).slice(-2)
  );
  let msDateB = parseInt(
    b.getFullYear().toString() +
      ("0" + (b.getMonth() + 1)).slice(-2) +
      ("0" + b.getDate()).slice(-2)
  );

  if (msDateA < msDateB) return -1;
  // less than
  else if (msDateA == msDateB) return 0;
  // equal
  else if (msDateA > msDateB) return 1;
  // greater than
  else return null; // error
}

export const accessRights = (data) => {
  localStorage.setItem("isOVERALL_HEALTH", data && data[0].OVERALL_HEALTH);
  localStorage.setItem("isADMIN", data && data[0].ADMIN);
  localStorage.setItem("isCHANNEL", data && data[0].CHANNEL);
  localStorage.setItem("isCUSTOMER_FEEDBACK", data && data[0].CUSTOMER_FEEDBACK);
  localStorage.setItem("isDECILES", data && data[0].DECILES);
  localStorage.setItem("isFUNNEL", data && data[0].FUNNEL);
  localStorage.setItem("isLOYALTY", data && data[0].LOYALTY);
  localStorage.setItem("isMARKETING", data && data[0].MARKETING);
  localStorage.setItem("isPROGRAM", data && data[0].PROGRAM);
  localStorage.setItem("isSCORECARD", data && data[0].SCORECARD);
  localStorage.setItem("isSTORES", data && data[0].STORES);
  localStorage.setItem("isSUPER_ADMIN", data && data[0].SUPER_ADMIN);
}

export const currencyFormat = (value) => {
  return parseFloat(value)
    .toFixed(0)
    .replace(/(\d)(?=(\d{3})+(?!\d))/g, "$1,");
};
export const decimalCurrencyFormat = (value) => {
  return parseFloat(value)
    .toFixed(2)
    .replace(/(\d)(?=(\d{3})+(?!\d))/g, "$1,");
};