import React, { useState, useEffect, useCallback } from "react";
import { useSelector, useDispatch } from "react-redux";
import { Dropdown, Placeholder } from "react-bootstrap";
import axios from "axios";
import "../Store/StoreContainer.css";
import { handleStoreBannerChange } from "../../Redux/Actions/BannerChangeActions";
import { handleStoreCategoryChange } from "../../Redux/Actions/CategoryChangeActions";
import { handleStorePeriodChange } from "../../Redux/Actions/StorePeriodChangeActions";
import StoreHome from "./StoreHome";
import NotificationMessage from "../NotificationMessage/NotificationMessage";
import NoAccess from "../NoAccess/NoAccess";

import { getDateFormatFromDB, UTCtoEST } from "../Utils";

const StoreBanners = [
  { value: "All Banner", id: "1,2,3,5" },
  { value: "BBBY US", id: "1" },
  { value: "BBBY CA", id: "2" },
  { value: "buy buy Baby", id: "3" },
  { value: "Harmon", id: "5" },
];

const StoreCategory = [
  { value: "Stores with more than (custom) sign ups", id: "1" },
  { value: "Stores with 0 loyalty", id: "2" },
];

const StorePeriods = [
  { value: "Yesterday", id: "0" },
  { value: "WTD", id: "1" },
  { value: "MTD", id: "2" },
  { value: "QTD", id: "3" },
  { value: "YTD ", id: "4" },
];

function StoreContainer() {
  const dispatch = useDispatch();

  const [allStorePeriods, setAllStorePeriods] = useState([]);

  const [selectedStoreBanner, setSelectedStoreBanner] = useState(
    StoreBanners[0]
  );
  const [selectedStoreCategory, setSelectedStoreCategory] = useState(
    StoreCategory[0]
  );

  const [selectedStorePeriod, setSelectedStorePeriod] = useState(
    StorePeriods[0]
  );
  const [periodStartDateLY, setPeriodStartDateLY] = useState("");
  const [periodEndDateLY, setPeriodEndDateLY] = useState("");
  const [periodStartDateTY, setPeriodStartDateTY] = useState("");
  const [periodEndDateTY, setPeriodEndDateTY] = useState("");
  const [correctDateRange, setCorrectDateRange] = useState(false);
  const [storeSignUp, setStoreSignUp] = useState(1);
  const [allStoreData, setAllStoreData] = useState("");
  const [refreshTime, setRefreshTime] = useState("");

  const refreshDate =
    refreshTime.length > 0 && UTCtoEST(refreshTime[0].end_time * 1000);

  const selectedStorePeriodId = useSelector((store) => store.StorePeriod.id);

  const selectedStorePeriodValue = useSelector(
    (store) => store.StorePeriod.value
  );
  const selectedStoreBannerId = useSelector((store) => store.StoreBanner.id);

  const selectedStoreCategoryId = useSelector(
    (store) => store.StoreCategory.id
  );

  const [loading, setloader] = useState({
    periodData: false,
    storeData: false,
  });

  const handleStoreBanner = useCallback(
    (event) => {
      setSelectedStoreBanner((prevsValue) => ({
        ...prevsValue,
        value: event.target.innerText,
        id: event.target.id,
      }));
      dispatch(
        handleStoreBannerChange({
          value: event.target.innerText,
          id: event.target.id,
        })
      );
      setCorrectDateRange(true);
    },
    [selectedStoreBannerId]
  );

  const handleStorePeriod = useCallback((event) => {
    setSelectedStorePeriod((prevsValue) => ({
      ...prevsValue,
      value: event.target.innerText,
      id: event.target.id,
    }));
    dispatch(
      handleStorePeriodChange({
        value: event.target.innerText,
        id: event.target.id,
      })
    );
  }, []);

  const handleStoreCategory = useCallback((event) => {
    setSelectedStoreCategory((prevsValue) => ({
      ...prevsValue,
      value: event.target.innerText,
      id: event.target.id,
    }));
    dispatch(
      handleStoreCategoryChange({
        value: event.target.innerText,
        id: event.target.id,
      })
    );
    setCorrectDateRange(true);
  }, []);

  const handleChange = (event) => {
    setStoreSignUp(event.target.value);
  };

  useEffect(() => {
    const getLastRefreshTime = async () => {
      try {
        setloader((currValue) => ({
          ...currValue,
          refreshTime: true,
        }));
        let url =
          process.env.REACT_APP_API_ENDPOINT +
          process.env.REACT_APP_REFRESH_TIME +
          "dagId=STORES";
        await axios({ url }).then((res) => {
          setloader((currValue) => ({
            ...currValue,
            refreshTime: false,
          }));
          setRefreshTime(res.data);
        });
      } catch (err) {
        setloader((currValue) => ({
          ...currValue,
          refreshTime: true,
        }));
        console.log("err-getLastRefreshTime", err);
      }
    };
    getLastRefreshTime();
  }, []);

  useEffect(() => {
    setStoreSignUp(1);
  }, [selectedStoreCategoryId]);

  useEffect(() => {
    const getStorePeriods = async () => {
      try {
        setloader((currValue) => ({
          ...currValue,
          periodData: true,
        }));
        let url =
          process.env.REACT_APP_API_ENDPOINT +
          process.env.REACT_APP_LOYALTY_PERIODS;
        await axios({ url }).then((res) => {
          setloader((currValue) => ({
            ...currValue,
            periodData: false,
          }));
          setAllStorePeriods(res.data);
          if (
            selectedStorePeriodId === "0" &&
            allStorePeriods[0] !== undefined &&
            allStorePeriods[0] !== null
          ) {
            setPeriodStartDateTY(allStorePeriods[0].TY_YESTERDAY);
            setPeriodEndDateTY(allStorePeriods[0].TY_YESTERDAY);
            setPeriodStartDateLY(allStorePeriods[0].LY_YESTERDAY);
            setPeriodEndDateLY(allStorePeriods[0].LY_YESTERDAY);
            setCorrectDateRange(true);
          }
        });
      } catch (err) {
        setloader((currValue) => ({
          ...currValue,
          periodData: true,
        }));
        console.log("err-getStorePeriods", err);
      }
    };
    getStorePeriods();
  }, []);

  useEffect(() => {
    const assignDates = () => {
      if (selectedStorePeriodId === "0") {
        setPeriodStartDateTY(allStorePeriods[0].TY_YESTERDAY);
        setPeriodEndDateTY(allStorePeriods[0].TY_YESTERDAY);
        setPeriodStartDateLY(allStorePeriods[0].LY_YESTERDAY);
        setPeriodEndDateLY(allStorePeriods[0].LY_YESTERDAY);
        setCorrectDateRange(true);
      } else if (selectedStorePeriodId === "1") {
        setPeriodStartDateTY(allStorePeriods[0].TY_WTD_START_DATE);
        setPeriodEndDateTY(allStorePeriods[0].TY_WTD_END_DATE);
        setPeriodStartDateLY(allStorePeriods[0].LY_WTD_START_DATE);
        setPeriodEndDateLY(allStorePeriods[0].LY_WTD_END_DATE);
        setCorrectDateRange(true);
      } else if (selectedStorePeriodId === "2") {
        setPeriodStartDateTY(allStorePeriods[0].TY_MTD_START_DATE);
        setPeriodEndDateTY(allStorePeriods[0].TY_MTD_END_DATE);
        setPeriodStartDateLY(allStorePeriods[0].LY_MTD_START_DATE);
        setPeriodEndDateLY(allStorePeriods[0].LY_MTD_END_DATE);
        setCorrectDateRange(true);
      } else if (selectedStorePeriodId === "3") {
        setPeriodStartDateTY(allStorePeriods[0].TY_QTD_START_DATE);
        setPeriodEndDateTY(allStorePeriods[0].TY_QTD_END_DATE);
        setPeriodStartDateLY(allStorePeriods[0].LY_QTD_START_DATE);
        setPeriodEndDateLY(allStorePeriods[0].LY_QTD_END_DATE);
        setCorrectDateRange(true);
      } else if (selectedStorePeriodId === "4") {
        setPeriodStartDateTY(allStorePeriods[0].TY_YTD_START_DATE);
        setPeriodEndDateTY(allStorePeriods[0].TY_YTD_END_DATE);
        setPeriodStartDateLY(allStorePeriods[0].LY_YTD_START_DATE);
        setPeriodEndDateLY(allStorePeriods[0].LY_YTD_END_DATE);
        setCorrectDateRange(true);
      }
    };
    allStorePeriods[0] !== undefined &&
      allStorePeriods[0] !== null &&
      correctDateRange === false &&
      assignDates();
  }, [
    allStorePeriods,
    selectedStorePeriodId,
    selectedStoreBannerId,
    selectedStoreCategoryId,
    periodEndDateLY,
    periodEndDateTY,
    periodStartDateLY,
    periodStartDateTY,
    //correctDateRange,
  ]);

  useEffect(() => {
    const getStorePeriods = async () => {
      try {
        setloader((currValue) => ({
          ...currValue,
          storeData: true,
        }));
        let url =
          process.env.REACT_APP_API_ENDPOINT +
          process.env.REACT_APP_STORE_DATA +
          "&startDate=" +
          periodStartDateTY +
          "&endDate=" +
          periodEndDateTY +
          "&concept=" +
          selectedStoreBannerId +
          "&signupCount=" +
          storeSignUp;
        if (correctDateRange) {
          await axios({ url }).then((res) => {
            setloader((currValue) => ({
              ...currValue,
              storeData: false,
            }));
            setAllStoreData(
              res.data.sort((a, b) => {
                return Number(a.STORE) - Number(b.STORE);
              })
            );
          });
          setCorrectDateRange(false);
        }
      } catch (err) {
        setloader((currValue) => ({
          ...currValue,
          storeData: true,
        }));
        console.log("err-getStorePeriods", err);
      }
    };
    const getStoreZeroPeriods = async () => {
      try {
        setloader((currValue) => ({
          ...currValue,
          storeData: true,
        }));
        let url =
          process.env.REACT_APP_API_ENDPOINT +
          process.env.REACT_APP_STORE_DATA +
          "&startDate=" +
          periodStartDateTY +
          "&endDate=" +
          periodEndDateTY +
          "&concept=" +
          selectedStoreBannerId +
          "&signupCount=0";
        if (correctDateRange) {
          await axios({ url }).then((res) => {
            setloader((currValue) => ({
              ...currValue,
              storeData: false,
            }));
            setAllStoreData(
              res.data.sort((a, b) => {
                return Number(a.STORE) - Number(b.STORE);
              })
            );
          });
          setCorrectDateRange(false);
        }
      } catch (err) {
        setloader((currValue) => ({
          ...currValue,
          storeData: true,
        }));
        console.log("err-getStorePeriods", err);
      }
    };
    if (
      localStorage.getItem("isSTORES") === "Y" &&
      selectedStorePeriodId &&
      periodEndDateLY !== "" &&
      selectedStoreCategoryId === "1"
    ) {
      getStorePeriods();
    } else if (
      localStorage.getItem("isSTORES") === "Y" &&
      selectedStorePeriodId &&
      periodEndDateLY !== "" &&
      selectedStoreCategoryId === "2"
    ) {
      getStoreZeroPeriods();
    }
  }, [
    selectedStorePeriodId,
    selectedStoreBannerId,
    selectedStoreCategoryId,
    storeSignUp,
    periodStartDateTY,
    periodEndDateTY,
    periodEndDateLY,
    periodStartDateLY,
  ]);

  return localStorage.getItem("isSTORES") === "Y" ? (
    <>
      <div>
        {refreshTime.length > 0 && (
          <NotificationMessage message={refreshDate} />
        )}
        <div className="mt-1 d-flex align-items-center headings">
          <div className="d-flex justify-content-start p-3">
            <span className="storeselectupText">Concept</span>
          </div>
          <div className="d-flex justify-content-start p-3">
            <span className="storeselectupText" style={{ paddingLeft: "0px" }}>
              Type
            </span>
          </div>
          {/* <div className="d-flex justify-content-start p-3">
          <span className="storeselectupText" >
            Period
          </span>
        </div> */}
        </div>
        <div className="mt-3 d-flex align-items-center">
          <div className="d-flex justify-content-start p-3">
            <Dropdown className="d-inline">
              <Dropdown.Toggle>{selectedStoreBanner.value}</Dropdown.Toggle>
              <Dropdown.Menu
                className="dropdown-menu-ext"
                onClick={(e) => handleStoreBanner(e)}
              >
                {StoreBanners.map((data) => {
                  return (
                    <Dropdown.Item
                      key={data.id}
                      className="dropdown-item-ext"
                      id={data.id}
                    >
                      {data.value}
                    </Dropdown.Item>
                  );
                })}
              </Dropdown.Menu>
            </Dropdown>
          </div>
          <div className="d-flex justify-content-start p-3">
            <Dropdown className="d-inline">
              <Dropdown.Toggle>{selectedStoreCategory.value}</Dropdown.Toggle>
              <Dropdown.Menu
                className="dropdown-menu-ext"
                onClick={(e) => handleStoreCategory(e)}
              >
                {StoreCategory.map((data) => {
                  return (
                    <Dropdown.Item
                      key={data.id}
                      className="dropdown-item-ext"
                      id={data.id}
                    >
                      {data.value}
                    </Dropdown.Item>
                  );
                })}
              </Dropdown.Menu>
            </Dropdown>
          </div>
          {selectedStoreCategoryId === "1" && (
            <div className="d-flex justify-content-start p-3">
              <label className="d-flex justify-content-start">
                <input
                  id="typeinp"
                  type="range"
                  min="0"
                  max="500"
                  value={storeSignUp}
                  onChange={handleChange}
                  step="1"
                  className="inputSlider"
                />
                {storeSignUp}
              </label>
            </div>
          )}
          <div className="d-flex justify-content-start p-3">
            <Dropdown className="d-inline">
              <Dropdown.Toggle>{selectedStorePeriod.value}</Dropdown.Toggle>
              <Dropdown.Menu
                className="dropdown-menu-ext"
                onClick={(e) => handleStorePeriod(e)}
              >
                {StorePeriods.map((data) => {
                  return (
                    <Dropdown.Item
                      key={data.id}
                      className="dropdown-item-ext"
                      id={data.id}
                    >
                      {data.value}
                    </Dropdown.Item>
                  );
                })}
              </Dropdown.Menu>
            </Dropdown>
          </div>
          <div>
            {periodEndDateLY !== "" ? (
              <div>
                <span>{`(${getDateFormatFromDB(
                  periodStartDateTY
                )} - ${getDateFormatFromDB(periodEndDateTY)}`}</span>
                <span className="vsStyling"> vs </span>
                <span>{`${getDateFormatFromDB(
                  periodStartDateLY
                )} - ${getDateFormatFromDB(periodEndDateLY)})`}</span>
              </div>
            ) : (
              <div>
                <span>{`( - `}</span>
                <span className="vsStyling"> vs </span>
                <span>{` - )`}</span>
              </div>
            )}
          </div>
        </div>
        <div>
          <StoreHome loading={loading} allStoreData={allStoreData} />
        </div>
      </div>
    </>
  ) : (
    <NoAccess tabName="Stores" />
  );
}

export default StoreContainer;
