import React from "react";
import { Table } from "react-bootstrap";
import LoaderForRow from "../LoaderForTable/LoaderForRow";
import { currencyFormat } from "../CdhHome/CdhHome";
import { decimalCurrencyFormat } from "../ScoreCard/Marketing";
import "../Store/StoreContainer.css";
import { gettooltip } from "../Utils";

function StoreHome({ loading, allStoreData }) {
  return (
    <div>
      <div className="p-3" style={{ marginBottom: "50px" }}>
        <Table style={{ textAlign: "center" }} striped bordered hover size="sm">
          <thead className="text">
            <tr>
              {/* <th></th> */}
              <th>Store</th>
              <th>District</th>
              <th>Region</th>
              <th>Welcome Sign Ups</th>
              <th>Welcome+ Sign Ups</th>
              <th>Credit Card Sign Ups</th>
              <th>
                % Of Transactions with Loyalty{" "}
                {gettooltip(
                  "TransactionsLoyaltyInfoIcon",
                  "TransactionsLoyalty",
                  "TransactionsLoyalty",
                  "Number of loyalty transaction for store divided by",
                  "number of total transaction for store"
                )}
              </th>
              <th>Store Traffic</th>
              <th>Store Rating</th>
            </tr>
          </thead>
          <tbody>
            {loading.storeData || loading.storeData ? (
              <tr>
                <LoaderForRow height={"700px"} tdCount={9} />
              </tr>
            ) : allStoreData !== undefined && allStoreData.length !== 0 ? (
              allStoreData.map((data) => {
                return (
                  <tr className="align-middle">
                    <td>
                      {data.STORE !== undefined &&
                      data.STORE.length !== 0 &&
                      data.STORE !== "-999999"
                        ? data.STORE
                        : "-"}
                    </td>
                    <td>
                      {data.DISTRICT !== undefined &&
                      data.DISTRICT.length !== 0 &&
                      data.DISTRICT !== "-999999"
                        ? data.DISTRICT
                        : "-"}
                    </td>
                    <td>
                      {data.REGION !== undefined &&
                      data.REGION.length !== 0 &&
                      data.REGION !== "-999999"
                        ? data.REGION
                        : "-"}
                    </td>
                    <td>
                      {data.Welcome_Sign_Ups !== undefined &&
                      data.Welcome_Sign_Ups.length !== 0 &&
                      data.Welcome_Sign_Ups !== "-999999"
                        ? currencyFormat(data.Welcome_Sign_Ups)
                        : "-"}
                    </td>
                    <td>
                      {data.Welcome_Plus_Sign_Ups !== undefined &&
                      data.Welcome_Plus_Sign_Ups.length !== 0 &&
                      data.Welcome_Plus_Sign_Ups !== "-999999"
                        ? currencyFormat(data.Welcome_Plus_Sign_Ups)
                        : "-"}
                    </td>
                    <td>
                      {data.Credit_Card_Sign_Ups !== undefined &&
                      data.Credit_Card_Sign_Ups.length !== 0 &&
                      data.Credit_Card_Sign_Ups !== "-999999"
                        ? currencyFormat(data.Credit_Card_Sign_Ups)
                        : "-"}
                    </td>
                    <td>
                      {data.Transactions_Loyalty !== undefined &&
                      data.Transactions_Loyalty.length !== 0 &&
                      data.Transactions_Loyalty !== "-999999"
                        ? `${decimalCurrencyFormat(data.Transactions_Loyalty)}%`
                        : "-"}
                    </td>
                    <td>
                      {data.Store_Traffic !== undefined &&
                      data.Store_Traffic.length !== 0 &&
                      data.Store_Traffic !== "-999999"
                        ? currencyFormat(data.Store_Traffic)
                        : "-"}
                    </td>
                    <td>
                      {data.Store_Rating !== undefined &&
                      data.Store_Rating.length !== 0 &&
                      data.Store_Rating !== "-999999"
                        ? currencyFormat(data.Store_Rating)
                        : "-"}
                    </td>
                  </tr>
                );
              })
            ) : (
              <tr>
                <td align="center" colSpan="9" style={{ fontWeight: "500" }}>
                  DATA NOT AVAILABLE
                </td>
              </tr>
            )}
          </tbody>
        </Table>
      </div>
    </div>
  );
}

export default StoreHome;
