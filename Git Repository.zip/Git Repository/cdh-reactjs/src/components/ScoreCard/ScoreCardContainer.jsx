import React, { useState, useEffect, useCallback } from "react";
import { useSelector, useDispatch } from "react-redux";
import { useHistory } from "react-router-dom";
import {
  Dropdown,
  Form,
  Placeholder,
  PlaceholderButton,
} from "react-bootstrap";
import axios from "axios";
import Marketing from "./Marketing";
import StoreDigital from "./StoreDigital";
import Inventory from "./Inventory";
import "../ScoreCard/ScoreCard.css";
import { handleScoreCardBannerChange } from "../../Redux/Actions/BannerChangeActions";
import {
  handleScoreCardPeriodChange,
  handleScoreCardYearChange,
} from "../../Redux/Actions/ScoreCardPeriodChangeActions";
import { UTCtoEST } from "../Utils";
import NotificationMessage from "../NotificationMessage/NotificationMessage";
import NoAccess from "../NoAccess/NoAccess";

const ScoreCardBanners = [
  { value: "All Banner", id: "0" },
  { value: "BBBY US", id: "1" },
  { value: "BBBY CA", id: "2" },
  { value: "buy buy Baby", id: "3" },
  { value: "Harmon", id: "5" },
];

function ScoreCardContainer() {
  const dispatch = useDispatch();
  let history = useHistory();

  const [selectedScoreCardBanner, setSelectedScoreCardBanner] = useState(
    ScoreCardBanners[0]
  );
  const [scoreCardDates, setScoreCardDates] = useState();
  const [scoreCardYear, setScoreCardYear] = useState();
  const [selectedScoreCardYear, setSelectedScoreCardYear] = useState();
  const [selectedScoreCardPeriod, setSelectedScoreCardPeriod] = useState(
    scoreCardDates !== undefined ? scoreCardDates[0] : ""
  );
  const [tabView, setTabview] = useState({
    marketingView: true,
    storeView: false,
    inventoryView: false,
  });
  const [scoreCardAppShoppers, setScoreCardAppShoppers] = useState();
  const [scoreCardTotalActiveCustomers, setScoreCardTotalActiveCustomers] =
    useState();
  const [scoreCardReActiveCustomers, setScoreCardReActiveCustomers] =
    useState();
  const [scoreCardEngageCustomers, setScoreCardEngageCustomers] = useState();
  const [scoreCardPlcc, setScoreCardPlcc] = useState();
  const [scoreCardBopisSdd, setScoreCardBopisSdd] = useState();
  const [scoreCardOmni, setScoreCardOmni] = useState();
  const [scoreCardBnpl, setScoreCardBnpl] = useState();
  const [scoreCardBPlus, setScoreCardBPlus] = useState();
  const [scoreCardClv, setScoreCardClv] = useState();
  const [scoreCardCrr, setScoreCardCrr] = useState();
  const [scoreCardGsc, setScoreCardGsc] = useState();
  const [scoreCardCac, setScoreCardCac] = useState();
  const [scoreCardOnv, setScoreCardOnv] = useState();
  const [scoreCardCar, setScoreCardCar] = useState();
  const [scoreCardOncr, setScoreCardOncr] = useState();
  const [scoreCardSt, setScoreCardSt] = useState();
  const [scoreCardStsp, setScoreCardStsp] = useState();
  const [scoreCardStcr, setScoreCardStcr] = useState();
  const [scoreCardAov, setScoreCardAov] = useState();
  const [scoreCardAbr, setScoreCardAbr] = useState();
  const [scoreCardOBplus, setScoreCardOBplus] = useState();
  const [scoreCardSBplus, setScoreCardSBplus] = useState();
  const [scoreCardSts, setScoreCardSts] = useState();
  const [scoreCardOnsp, setScoreCardOnsp] = useState();
  const [scoreCardStcs, setScoreCardStcs] = useState();
  const [scoreCardOncs, setScoreCardOncs] = useState();
  const [scoreCardStsr, setScoreCardStsr] = useState();
  const [scoreCardOnsr, setScoreCardOnsr] = useState();
  const [scoreCardItrn, setScoreCardItrn] = useState();
  const [scoreCardAsku, setScoreCardAsku] = useState();
  const [scoreCardOnStore, setScoreCardOnStore] = useState();
  const [scoreCardInStore, setScoreCardInStore] = useState();
  const [scoreCardAppLogin, setScoreCardAppLogin] = useState();
  const [scoreCardMarketingEarners, setScoreCardMarketingEarners] = useState();
  const [scoreCardMarketingRedeemers, setScoreCardMarketingRedeemers] =
    useState();
  const [scoreCardNBinStore, setScoreCardNBinStore] = useState();
  const [scoreCardFiscalDates, setScoreCardFiscalDates] = useState();
  const [scoreCardOnnb, setScoreCardOnnb] = useState();

  const [scoreCardStoreWelcome, setScoreCardStoreWelcome] = useState();
  const [scoreCardStoreWelcomePlus, setScoreCardStoreWelcomePlus] = useState();
  const [scoreCardOnlineWelcome, setScoreCardOnlineWelcome] = useState();
  const [scoreCardOnlineWelcomePlus, setScoreCardOnlineWelcomePlus] =
    useState();

  const selectedScoreCardBannerId = useSelector(
    (store) => store.ScoreCardBanner.id
  );
  const selectedScoreCardPeriodId = useSelector(
    (store) => store.ScoreCardPeriod.id
  );
  const selectedScoreCardPeriodValue = useSelector(
    (store) => store.ScoreCardPeriod.value
  );
  const selectedScoreCardYearId = useSelector(
    (store) => store.ScoreCardYear.id
  );

  const [refreshTime, setRefreshTime] = useState("");

  const refreshDate =
    refreshTime.length > 0 && UTCtoEST(refreshTime[0].end_time * 1000);

  const [loading, setloader] = useState({
    app_Shoppers: false,
    active_customers: false,
    reActive_customers: false,
    engage_customers: false,
    plcc: false,
    bopis_sdd: false,
    omni: false,
    bplus: false,
    clv: false,
    crr: false,
    gsc: false,
    cac: false,
    onv: false,
    car: false,
    oncr: false,
    st: false,
    stsp: false,
    stcr: false,
    aov: false,
    abr: false,
    obplus: false,
    sbplus: false,
    sts: false,
    onsp: false,
    oncs: false,
    stcs: false,
    stsr: false,
    onsr: false,
    itrn: false,
    asku: false,
    onroas: false,
    inroas: false,
    yeardd: false,
    datedd: false,
    app_Logins: false,
    earners: false,
    redeemers: false,
    nbinstore: false,
    fiscaldates: false,
    onnb: false,
    storeWelcome: false,
    storeWelcomePlus: false,
    onlineWelcome: false,
    onlineWelcomePlus: false,
    refreshTime: false,
  });

  const handleFunnelClick = () => {
    history.push(`/cdh/funnel`);
  };

  const handleScoreCardBanner = useCallback(
    (event) => {
      setSelectedScoreCardBanner((prevsValue) => ({
        ...prevsValue,
        value: event.target.innerText,
        id: event.target.id,
      }));
      dispatch(
        handleScoreCardBannerChange({
          value: event.target.innerText,
          id: event.target.id,
        })
      );
    },
    [selectedScoreCardBannerId]
  );

  const handleScoreCardYear = useCallback(
    (event) => {
      setSelectedScoreCardYear((prevsValue) => ({
        ...prevsValue,
        value: event.target.innerText,
        id: event.target.id,
      }));
      dispatch(
        handleScoreCardYearChange({
          value: event.target.innerText,
          id: event.target.id,
        })
      );
      dispatch(
        handleScoreCardPeriodChange({
          value: "",
          id: "",
        })
      );
      setSelectedScoreCardPeriod("");
      setloader((currValue) => ({
        ...currValue,
        app_Shoppers: true,
        active_customers: true,
        reActive_customers: true,
        engage_customers: true,
        plcc: true,
        bopis_sdd: true,
        omni: true,
        bplus: true,
        clv: true,
      }));
    },
    [selectedScoreCardYearId]
  );

  const handleScoreCardPeriod = useCallback(
    (event) => {
      setSelectedScoreCardPeriod((prevsValue) => ({
        ...prevsValue,
        value: event.target.innerText,
        id: event.target.id,
      }));
      dispatch(
        handleScoreCardPeriodChange({
          value: event.target.innerText,
          id: event.target.id,
        })
      );
    },
    [selectedScoreCardPeriodId]
  );

  const buttonClick = (tab) => {
    if (tab === "1") {
      setTabview(() => ({
        marketingView: true,
        storeView: false,
        inventoryView: false,
      }));
    } else if (tab === "2") {
      setTabview(() => ({
        marketingView: false,
        storeView: true,
        inventoryView: false,
      }));
    } else if (tab === "3") {
      setTabview(() => ({
        marketingView: false,
        storeView: false,
        inventoryView: true,
      }));
    }
  };

  useEffect(() => {
    const getLastRefreshTime = async () => {
      try {
        setloader((currValue) => ({
          ...currValue,
          refreshTime: true,
        }));
        let url =
          process.env.REACT_APP_API_ENDPOINT +
          process.env.REACT_APP_REFRESH_TIME +
          "dagId=SCORECARD";
        await axios({ url }).then((res) => {
          setloader((currValue) => ({
            ...currValue,
            refreshTime: false,
          }));
          setRefreshTime(res.data);
        });
      } catch (err) {
        setloader((currValue) => ({
          ...currValue,
          refreshTime: true,
        }));
        console.log("err-getLastRefreshTime", err);
      }
    };
    getLastRefreshTime();
  }, []);

  useEffect(() => {
    const getScoreCardYear = async () => {
      try {
        setloader((currValue) => ({
          ...currValue,
          yeardd: true,
        }));
        let url =
          process.env.REACT_APP_API_ENDPOINT +
          process.env.REACT_APP_GET_SCORECARD_YEAR;
        await axios({ url }).then((res) => {
          setloader((currValue) => ({
            ...currValue,
            yeardd: false,
          }));
          setScoreCardYear(
            res.data.sort((a, b) => {
              return Number(b.YEAR) - Number(a.YEAR);
            })
          );
          dispatch(
            handleScoreCardYearChange({
              value: res.data[0].YEAR,
              id: res.data[0].YEAR,
            })
          );
        });
      } catch (err) {
        setloader((currValue) => ({
          ...currValue,
          yeardd: true,
        }));
        console.log("err-getScoreCardYear", err);
      }
    };
    getScoreCardYear();
  }, []);

  useEffect(() => {
    const getScoreCardDates = async () => {
      try {
        setloader((currValue) => ({
          ...currValue,
          datedd: true,
        }));
        let url =
          process.env.REACT_APP_API_ENDPOINT +
          process.env.REACT_APP_GET_SCORECARD_DATES +
          "year=" +
          selectedScoreCardYearId;
        await axios({ url }).then((res) => {
          setloader((currValue) => ({
            ...currValue,
            datedd: false,
          }));
          setScoreCardDates(res.data);
          const index = res.data.findIndex((element) => {
            if (element.LAST_COMPL_FISCAL_PERIOD_IND.includes("Y")) {
              return true;
            }
          });
          if (index === -1) {
            const indexe = res.data.findIndex((element) => {
              const date = new Date();
              date.setMonth(date.getMonth() - 1);
              if (
                element.MONTH.includes(
                  date.toLocaleString("default", { month: "long" })
                )
              ) {
                return true;
              }
            });
            dispatch(
              handleScoreCardPeriodChange({
                value: res.data[indexe].MONTH,
                id: res.data[indexe].PERIOD_ID,
              })
            );
          } else {
            dispatch(
              handleScoreCardPeriodChange({
                value: res.data[index].MONTH,
                id: res.data[index].PERIOD_ID,
              })
            );
          }
        });
      } catch (err) {
        setloader((currValue) => ({
          ...currValue,
          datedd: true,
        }));
        console.log("err-getScoreCardDates", err);
      }
    };
    if (selectedScoreCardYearId) {
      getScoreCardDates();
    }
  }, [selectedScoreCardYearId]);

  useEffect(() => {
    const getScoreCardFiscalDates = async () => {
      try {
        setloader((currValue) => ({
          ...currValue,
          fiscaldates: true,
        }));
        let url =
          process.env.REACT_APP_API_ENDPOINT +
          process.env.REACT_APP_GET_SCORECARD_FISCAL_DATES +
          "year=" +
          selectedScoreCardYearId +
          "&periodId=" +
          selectedScoreCardPeriodId;
        await axios({ url }).then((res) => {
          setloader((currValue) => ({
            ...currValue,
            fiscaldates: false,
          }));
          setScoreCardFiscalDates(res.data);
        });
      } catch (err) {
        setloader((currValue) => ({
          ...currValue,
          fiscaldates: true,
        }));
        console.log("err-getScoreCardFiscalDates", err);
      }
    };
    if (selectedScoreCardYearId && selectedScoreCardPeriodId) {
      getScoreCardFiscalDates();
    }
  }, [selectedScoreCardYearId, selectedScoreCardPeriodId]);

  useEffect(() => {
    const fetchScoreCardAppShoppers = async () => {
      try {
        setloader((currValue) => ({
          ...currValue,
          app_Shoppers: true,
        }));
        let url =
          process.env.REACT_APP_API_ENDPOINT +
          process.env.REACT_APP_SCORECARD +
          "concept=" +
          selectedScoreCardBannerId +
          "&periodId=" +
          selectedScoreCardPeriodId +
          "&customerType=" +
          "ALL" +
          "&metric=" +
          "APP_SHOPPERS";
        await axios({ url }).then((res) => {
          setloader((currValue) => ({
            ...currValue,
            app_Shoppers: false,
          }));
          setScoreCardAppShoppers(res.data);
        });
      } catch (err) {
        setloader((currValue) => ({
          ...currValue,
          app_Shoppers: true,
        }));
        console.log("err-fetchScoreCardAppShoppers", err);
      }
    };
    const fetchScoreCardTotalActiveCustomers = async () => {
      try {
        setloader((currValue) => ({
          ...currValue,
          active_customers: true,
        }));
        let url =
          process.env.REACT_APP_API_ENDPOINT +
          process.env.REACT_APP_SCORECARD +
          "concept=" +
          selectedScoreCardBannerId +
          "&periodId=" +
          selectedScoreCardPeriodId +
          "&customerType=" +
          "ALL" +
          "&metric=" +
          "ACTIVE_CUSTOMER";
        await axios({ url }).then((res) => {
          setloader((currValue) => ({
            ...currValue,
            active_customers: false,
          }));
          setScoreCardTotalActiveCustomers(res.data);
        });
      } catch (err) {
        setloader((currValue) => ({
          ...currValue,
          active_customers: true,
        }));
        console.log("err-fetchScoreCardTotalActiveCustomers", err);
      }
    };
    const fetchScoreCardReActiveCustomers = async () => {
      try {
        setloader((currValue) => ({
          ...currValue,
          reActive_customers: true,
        }));
        let url =
          process.env.REACT_APP_API_ENDPOINT +
          process.env.REACT_APP_SCORECARD +
          "concept=" +
          selectedScoreCardBannerId +
          "&periodId=" +
          selectedScoreCardPeriodId +
          "&customerType=" +
          "ALL" +
          "&metric=" +
          "NEW_REACTIVE_CUSTOMER";
        await axios({ url }).then((res) => {
          setloader((currValue) => ({
            ...currValue,
            reActive_customers: false,
          }));
          setScoreCardReActiveCustomers(res.data);
        });
      } catch (err) {
        setloader((currValue) => ({
          ...currValue,
          reActive_customers: true,
        }));
        console.log("err-fetchScoreCardReActiveCustomers", err);
      }
    };
    const fetchScoreCardActiveEngageCustomers = async () => {
      try {
        setloader((currValue) => ({
          ...currValue,
          engage_customers: true,
        }));
        let url =
          process.env.REACT_APP_API_ENDPOINT +
          process.env.REACT_APP_SCORECARD +
          "concept=" +
          selectedScoreCardBannerId +
          "&periodId=" +
          selectedScoreCardPeriodId +
          "&customerType=" +
          "ALL" +
          "&metric=" +
          "ACTIVE_ENGAGE_CUSTOMER";
        await axios({ url }).then((res) => {
          setloader((currValue) => ({
            ...currValue,
            engage_customers: false,
          }));
          setScoreCardEngageCustomers(res.data);
        });
      } catch (err) {
        setloader((currValue) => ({
          ...currValue,
          engage_customers: true,
        }));
        console.log("err-fetchScoreCardActiveEngageCustomers", err);
      }
    };
    const fetchScoreCardPLCC = async () => {
      try {
        setloader((currValue) => ({
          ...currValue,
          plcc: true,
        }));
        let url =
          process.env.REACT_APP_API_ENDPOINT +
          process.env.REACT_APP_SCORECARD +
          "concept=" +
          selectedScoreCardBannerId +
          "&periodId=" +
          selectedScoreCardPeriodId +
          "&customerType=" +
          "ALL" +
          "&metric=" +
          "PLCC";
        await axios({ url }).then((res) => {
          setloader((currValue) => ({
            ...currValue,
            plcc: false,
          }));
          setScoreCardPlcc(res.data);
        });
      } catch (err) {
        setloader((currValue) => ({
          ...currValue,
          plcc: true,
        }));
        console.log("err-fetchScoreCardPLCC", err);
      }
    };
    const fetchScoreCardBopisSdd = async () => {
      try {
        setloader((currValue) => ({
          ...currValue,
          bopis_sdd: true,
        }));
        let url =
          process.env.REACT_APP_API_ENDPOINT +
          process.env.REACT_APP_SCORECARD +
          "concept=" +
          selectedScoreCardBannerId +
          "&periodId=" +
          selectedScoreCardPeriodId +
          "&customerType=" +
          "ALL" +
          "&metric=" +
          "BOPIS_SDD";
        await axios({ url }).then((res) => {
          setloader((currValue) => ({
            ...currValue,
            bopis_sdd: false,
          }));
          setScoreCardBopisSdd(res.data);
        });
      } catch (err) {
        setloader((currValue) => ({
          ...currValue,
          bopis_sdd: true,
        }));
        console.log("err-fetchScoreCardBopisSdd", err);
      }
    };
    const fetchScoreCardOmni = async () => {
      try {
        setloader((currValue) => ({
          ...currValue,
          omni: true,
        }));
        let url =
          process.env.REACT_APP_API_ENDPOINT +
          process.env.REACT_APP_SCORECARD_PERCENTILE +
          "concept=" +
          selectedScoreCardBannerId +
          "&periodId=" +
          selectedScoreCardPeriodId +
          "&customerType=" +
          "ALL" +
          "&metric=" +
          "OMNI";
        await axios({ url }).then((res) => {
          setloader((currValue) => ({
            ...currValue,
            omni: false,
          }));
          setScoreCardOmni(res.data);
        });
      } catch (err) {
        setloader((currValue) => ({
          ...currValue,
          omni: true,
        }));
        console.log("err-fetchScoreCardOmni", err);
      }
    };
    const fetchScoreCardBNPL = async () => {
      try {
        setloader((currValue) => ({
          ...currValue,
          bnpl: true,
        }));
        let url =
          process.env.REACT_APP_API_ENDPOINT +
          process.env.REACT_APP_SCORECARD +
          "concept=" +
          selectedScoreCardBannerId +
          "&periodId=" +
          selectedScoreCardPeriodId +
          "&customerType=" +
          "ALL" +
          "&metric=" +
          "BNPL";
        await axios({ url }).then((res) => {
          setloader((currValue) => ({
            ...currValue,
            bnpl: false,
          }));
          setScoreCardBnpl(res.data);
        });
      } catch (err) {
        setloader((currValue) => ({
          ...currValue,
          bnpl: true,
        }));
        console.log("err-fetchScoreCardBNPL", err);
      }
    };
    const fetchScoreCardBPlus = async () => {
      try {
        setloader((currValue) => ({
          ...currValue,
          bplus: true,
        }));
        let url =
          process.env.REACT_APP_API_ENDPOINT +
          process.env.REACT_APP_SCORECARD +
          "concept=" +
          selectedScoreCardBannerId +
          "&periodId=" +
          selectedScoreCardPeriodId +
          "&customerType=" +
          "ALL" +
          "&metric=" +
          "BPLUS";
        await axios({ url }).then((res) => {
          setloader((currValue) => ({
            ...currValue,
            bplus: false,
          }));
          setScoreCardBPlus(res.data);
        });
      } catch (err) {
        setloader((currValue) => ({
          ...currValue,
          bplus: true,
        }));
        console.log("err-fetchScoreCardBPlus", err);
      }
    };
    const fetchScoreCardMarketingEarners = async () => {
      try {
        setloader((currValue) => ({
          ...currValue,
          earners: true,
        }));
        let url =
          process.env.REACT_APP_API_ENDPOINT +
          process.env.REACT_APP_SCORECARD +
          "concept=" +
          selectedScoreCardBannerId +
          "&periodId=" +
          selectedScoreCardPeriodId +
          "&customerType=" +
          "ALL" +
          "&metric=" +
          "Earners";
        await axios({ url }).then((res) => {
          setloader((currValue) => ({
            ...currValue,
            earners: false,
          }));
          setScoreCardMarketingEarners(res.data);
        });
      } catch (err) {
        setloader((currValue) => ({
          ...currValue,
          earners: true,
        }));
        console.log("err-fetchScoreCardMarketingEarners", err);
      }
    };
    const fetchScoreCardMarketingRedeemers = async () => {
      try {
        setloader((currValue) => ({
          ...currValue,
          redeemers: true,
        }));
        let url =
          process.env.REACT_APP_API_ENDPOINT +
          process.env.REACT_APP_SCORECARD +
          "concept=" +
          selectedScoreCardBannerId +
          "&periodId=" +
          selectedScoreCardPeriodId +
          "&customerType=" +
          "ALL" +
          "&metric=" +
          "Redeemers";
        await axios({ url }).then((res) => {
          setloader((currValue) => ({
            ...currValue,
            redeemers: false,
          }));
          setScoreCardMarketingRedeemers(res.data);
        });
      } catch (err) {
        setloader((currValue) => ({
          ...currValue,
          redeemers: true,
        }));
        console.log("err-fetchScoreCardMarketingRedeemers", err);
      }
    };
    const fetchScoreCardNBinStore = async () => {
      try {
        setloader((currValue) => ({
          ...currValue,
          nbinstore: true,
        }));
        let url =
          process.env.REACT_APP_API_ENDPOINT +
          process.env.REACT_APP_SCORECARD_PERCENTILE +
          "concept=" +
          selectedScoreCardBannerId +
          "&periodId=" +
          selectedScoreCardPeriodId +
          "&customerType=" +
          "ALL" +
          "&metric=" +
          "STNB";
        await axios({ url }).then((res) => {
          setloader((currValue) => ({
            ...currValue,
            nbinstore: false,
          }));
          setScoreCardNBinStore(res.data);
        });
      } catch (err) {
        setloader((currValue) => ({
          ...currValue,
          nbinstore: true,
        }));
        console.log("err-fetchScoreCardNBinStore", err);
      }
    };
    const fetchScoreCardClv = async () => {
      try {
        setloader((currValue) => ({
          ...currValue,
          clv: true,
        }));
        let url =
          process.env.REACT_APP_API_ENDPOINT +
          process.env.REACT_APP_SCORECARD +
          "concept=" +
          selectedScoreCardBannerId +
          "&periodId=" +
          selectedScoreCardPeriodId +
          "&customerType=" +
          "ALL" +
          "&metric=" +
          "CLV";
        await axios({ url }).then((res) => {
          setloader((currValue) => ({
            ...currValue,
            clv: false,
          }));
          setScoreCardClv(res.data);
        });
      } catch (err) {
        setloader((currValue) => ({
          ...currValue,
          clv: true,
        }));
        console.log("err-fetchScoreCardClv", err);
      }
    };
    const fetchScoreCardCrr = async () => {
      try {
        setloader((currValue) => ({
          ...currValue,
          crr: true,
        }));
        let url =
          process.env.REACT_APP_API_ENDPOINT +
          process.env.REACT_APP_SCORECARD_PERCENTILE +
          "concept=" +
          selectedScoreCardBannerId +
          "&periodId=" +
          selectedScoreCardPeriodId +
          "&customerType=" +
          "ALL" +
          "&metric=" +
          "CRR";
        await axios({ url }).then((res) => {
          setloader((currValue) => ({
            ...currValue,
            crr: false,
          }));
          setScoreCardCrr(res.data);
        });
      } catch (err) {
        setloader((currValue) => ({
          ...currValue,
          clv: true,
        }));
        console.log("err-fetchScoreCardCRR", err);
      }
    };
    const fetchScoreCardGsc = async () => {
      try {
        setloader((currValue) => ({
          ...currValue,
          gsc: true,
        }));
        let url =
          process.env.REACT_APP_API_ENDPOINT +
          process.env.REACT_APP_SCORECARD +
          "concept=" +
          selectedScoreCardBannerId +
          "&periodId=" +
          selectedScoreCardPeriodId +
          "&customerType=" +
          "ALL" +
          "&metric=" +
          "GSC";
        await axios({ url }).then((res) => {
          setloader((currValue) => ({
            ...currValue,
            gsc: false,
          }));
          setScoreCardGsc(res.data);
        });
      } catch (err) {
        setloader((currValue) => ({
          ...currValue,
          gsc: true,
        }));
        console.log("err-fetchScoreCardGsc", err);
      }
    };
    const fetchScoreCardCac = async () => {
      try {
        setloader((currValue) => ({
          ...currValue,
          cac: true,
        }));
        let url =
          process.env.REACT_APP_API_ENDPOINT +
          process.env.REACT_APP_SCORECARD +
          "concept=" +
          selectedScoreCardBannerId +
          "&periodId=" +
          selectedScoreCardPeriodId +
          "&customerType=" +
          "ALL" +
          "&metric=" +
          "CAC";
        await axios({ url }).then((res) => {
          setloader((currValue) => ({
            ...currValue,
            cac: false,
          }));
          setScoreCardCac(res.data);
        });
      } catch (err) {
        setloader((currValue) => ({
          ...currValue,
          cac: true,
        }));
        console.log("err-fetchScoreCardCac", err);
      }
    };
    const fetchScoreCardOnv = async () => {
      try {
        setloader((currValue) => ({
          ...currValue,
          onv: true,
        }));
        let url =
          process.env.REACT_APP_API_ENDPOINT +
          process.env.REACT_APP_SCORECARD +
          "concept=" +
          selectedScoreCardBannerId +
          "&periodId=" +
          selectedScoreCardPeriodId +
          "&customerType=" +
          "ALL" +
          "&metric=" +
          "ONV";
        await axios({ url }).then((res) => {
          setloader((currValue) => ({
            ...currValue,
            onv: false,
          }));
          setScoreCardOnv(res.data);
        });
      } catch (err) {
        setloader((currValue) => ({
          ...currValue,
          onv: true,
        }));
        console.log("err-fetchScoreCardOnv", err);
      }
    };
    const fetchScoreCardCar = async () => {
      try {
        setloader((currValue) => ({
          ...currValue,
          car: true,
        }));
        let url =
          process.env.REACT_APP_API_ENDPOINT +
          process.env.REACT_APP_SCORECARD_PERCENTILE +
          "concept=" +
          selectedScoreCardBannerId +
          "&periodId=" +
          selectedScoreCardPeriodId +
          "&customerType=" +
          "ALL" +
          "&metric=" +
          "CAR";
        await axios({ url }).then((res) => {
          setloader((currValue) => ({
            ...currValue,
            car: false,
          }));
          setScoreCardCar(res.data);
        });
      } catch (err) {
        setloader((currValue) => ({
          ...currValue,
          car: true,
        }));
        console.log("err-fetchScoreCardCar", err);
      }
    };
    const fetchScoreCardOncr = async () => {
      try {
        setloader((currValue) => ({
          ...currValue,
          oncr: true,
        }));
        let url =
          process.env.REACT_APP_API_ENDPOINT +
          process.env.REACT_APP_SCORECARD_PERCENTILE +
          "concept=" +
          selectedScoreCardBannerId +
          "&periodId=" +
          selectedScoreCardPeriodId +
          "&customerType=" +
          "ALL" +
          "&metric=" +
          "ONCR";
        await axios({ url }).then((res) => {
          setloader((currValue) => ({
            ...currValue,
            oncr: false,
          }));
          setScoreCardOncr(res.data);
        });
      } catch (err) {
        setloader((currValue) => ({
          ...currValue,
          oncr: true,
        }));
        console.log("err-fetchScoreCardOncr", err);
      }
    };
    const fetchScoreCardSt = async () => {
      try {
        setloader((currValue) => ({
          ...currValue,
          st: true,
        }));
        let url =
          process.env.REACT_APP_API_ENDPOINT +
          process.env.REACT_APP_SCORECARD +
          "concept=" +
          selectedScoreCardBannerId +
          "&periodId=" +
          selectedScoreCardPeriodId +
          "&customerType=" +
          "ALL" +
          "&metric=" +
          "ST";
        await axios({ url }).then((res) => {
          setloader((currValue) => ({
            ...currValue,
            st: false,
          }));
          setScoreCardSt(res.data);
        });
      } catch (err) {
        setloader((currValue) => ({
          ...currValue,
          st: true,
        }));
        console.log("err-fetchScoreCardSt", err);
      }
    };
    const fetchScoreCardStsp = async () => {
      try {
        setloader((currValue) => ({
          ...currValue,
          stsp: true,
        }));
        let url =
          process.env.REACT_APP_API_ENDPOINT +
          process.env.REACT_APP_SCORECARD_PERCENTILE +
          "concept=" +
          selectedScoreCardBannerId +
          "&periodId=" +
          selectedScoreCardPeriodId +
          "&customerType=" +
          "ALL" +
          "&metric=" +
          "STSP";
        await axios({ url }).then((res) => {
          setloader((currValue) => ({
            ...currValue,
            stsp: false,
          }));
          setScoreCardStsp(res.data);
        });
      } catch (err) {
        setloader((currValue) => ({
          ...currValue,
          stsp: true,
        }));
        console.log("err-fetchScoreCardStsp", err);
      }
    };
    const fetchScoreCardStcr = async () => {
      try {
        setloader((currValue) => ({
          ...currValue,
          stcr: true,
        }));
        let url =
          process.env.REACT_APP_API_ENDPOINT +
          process.env.REACT_APP_SCORECARD_PERCENTILE +
          "concept=" +
          selectedScoreCardBannerId +
          "&periodId=" +
          selectedScoreCardPeriodId +
          "&customerType=" +
          "ALL" +
          "&metric=" +
          "STCR";
        await axios({ url }).then((res) => {
          setloader((currValue) => ({
            ...currValue,
            stcr: false,
          }));
          setScoreCardStcr(res.data);
        });
      } catch (err) {
        setloader((currValue) => ({
          ...currValue,
          stcr: true,
        }));
        console.log("err-fetchScoreCardStcr", err);
      }
    };
    const fetchScoreCardAov = async () => {
      try {
        setloader((currValue) => ({
          ...currValue,
          aov: true,
        }));
        let url =
          process.env.REACT_APP_API_ENDPOINT +
          process.env.REACT_APP_SCORECARD +
          "concept=" +
          selectedScoreCardBannerId +
          "&periodId=" +
          selectedScoreCardPeriodId +
          "&customerType=" +
          "ALL" +
          "&metric=" +
          "AOV";
        await axios({ url }).then((res) => {
          setloader((currValue) => ({
            ...currValue,
            aov: false,
          }));
          setScoreCardAov(res.data);
        });
      } catch (err) {
        setloader((currValue) => ({
          ...currValue,
          aov: true,
        }));
        console.log("err-fetchScoreCardAov", err);
      }
    };
    const fetchScoreCardAbr = async () => {
      try {
        setloader((currValue) => ({
          ...currValue,
          abr: true,
        }));
        let url =
          process.env.REACT_APP_API_ENDPOINT +
          process.env.REACT_APP_SCORECARD_PERCENTILE +
          "concept=" +
          selectedScoreCardBannerId +
          "&periodId=" +
          selectedScoreCardPeriodId +
          "&customerType=" +
          "ALL" +
          "&metric=" +
          "ABR";
        await axios({ url }).then((res) => {
          setloader((currValue) => ({
            ...currValue,
            abr: false,
          }));
          setScoreCardAbr(res.data);
        });
      } catch (err) {
        setloader((currValue) => ({
          ...currValue,
          abr: true,
        }));
        console.log("err-fetchScoreCardAbr", err);
      }
    };
    const fetchScoreCardObplus = async () => {
      try {
        setloader((currValue) => ({
          ...currValue,
          obplus: true,
        }));
        let url =
          process.env.REACT_APP_API_ENDPOINT +
          process.env.REACT_APP_SCORECARD +
          "concept=" +
          selectedScoreCardBannerId +
          "&periodId=" +
          selectedScoreCardPeriodId +
          "&customerType=" +
          "ALL" +
          "&metric=" +
          "OBPLUS_SIGNUP";
        await axios({ url }).then((res) => {
          setloader((currValue) => ({
            ...currValue,
            obplus: false,
          }));
          setScoreCardOBplus(res.data);
        });
      } catch (err) {
        setloader((currValue) => ({
          ...currValue,
          obplus: true,
        }));
        console.log("err-fetchScoreCardObplus", err);
      }
    };
    const fetchScoreCardSbplus = async () => {
      try {
        setloader((currValue) => ({
          ...currValue,
          sbplus: true,
        }));
        let url =
          process.env.REACT_APP_API_ENDPOINT +
          process.env.REACT_APP_SCORECARD +
          "concept=" +
          selectedScoreCardBannerId +
          "&periodId=" +
          selectedScoreCardPeriodId +
          "&customerType=" +
          "ALL" +
          "&metric=" +
          "SBPLUS_SIGNUP";
        await axios({ url }).then((res) => {
          setloader((currValue) => ({
            ...currValue,
            sbplus: false,
          }));
          setScoreCardSBplus(res.data);
        });
      } catch (err) {
        setloader((currValue) => ({
          ...currValue,
          sbplus: true,
        }));
        console.log("err-fetchScoreCardSbplus", err);
      }
    };
    const fetchScoreCardSts = async () => {
      try {
        setloader((currValue) => ({
          ...currValue,
          sts: true,
        }));
        let url =
          process.env.REACT_APP_API_ENDPOINT +
          process.env.REACT_APP_SCORECARD +
          "concept=" +
          selectedScoreCardBannerId +
          "&periodId=" +
          selectedScoreCardPeriodId +
          "&customerType=" +
          "ALL" +
          "&metric=" +
          "STS";
        await axios({ url }).then((res) => {
          setloader((currValue) => ({
            ...currValue,
            sts: false,
          }));
          setScoreCardSts(res.data);
        });
      } catch (err) {
        setloader((currValue) => ({
          ...currValue,
          sts: true,
        }));
        console.log("err-fetchScoreCardSts", err);
      }
    };
    const fetchScoreCardOnsp = async () => {
      try {
        setloader((currValue) => ({
          ...currValue,
          onsp: true,
        }));
        let url =
          process.env.REACT_APP_API_ENDPOINT +
          process.env.REACT_APP_SCORECARD_PERCENTILE +
          "concept=" +
          selectedScoreCardBannerId +
          "&periodId=" +
          selectedScoreCardPeriodId +
          "&customerType=" +
          "ALL" +
          "&metric=" +
          "ONSP";
        await axios({ url }).then((res) => {
          setloader((currValue) => ({
            ...currValue,
            onsp: false,
          }));
          setScoreCardOnsp(res.data);
        });
      } catch (err) {
        setloader((currValue) => ({
          ...currValue,
          onsp: true,
        }));
        console.log("err-fetchScoreCardOnsp", err);
      }
    };
    const fetchScoreCardStcs = async () => {
      try {
        setloader((currValue) => ({
          ...currValue,
          stcs: true,
        }));
        let url =
          process.env.REACT_APP_API_ENDPOINT +
          process.env.REACT_APP_SCORECARD +
          "concept=" +
          selectedScoreCardBannerId +
          "&periodId=" +
          selectedScoreCardPeriodId +
          "&customerType=" +
          "ALL" +
          "&metric=" +
          "STCS";
        await axios({ url }).then((res) => {
          setloader((currValue) => ({
            ...currValue,
            stcs: false,
          }));
          setScoreCardStcs(res.data);
        });
      } catch (err) {
        setloader((currValue) => ({
          ...currValue,
          stcs: true,
        }));
        console.log("err-fetchScoreCardStcs", err);
      }
    };
    const fetchScoreCardOncs = async () => {
      try {
        setloader((currValue) => ({
          ...currValue,
          oncs: true,
        }));
        let url =
          process.env.REACT_APP_API_ENDPOINT +
          process.env.REACT_APP_SCORECARD +
          "concept=" +
          selectedScoreCardBannerId +
          "&periodId=" +
          selectedScoreCardPeriodId +
          "&customerType=" +
          "ALL" +
          "&metric=" +
          "ONCS";
        await axios({ url }).then((res) => {
          setloader((currValue) => ({
            ...currValue,
            oncs: false,
          }));
          setScoreCardOncs(res.data);
        });
      } catch (err) {
        setloader((currValue) => ({
          ...currValue,
          oncs: true,
        }));
        console.log("err-fetchScoreCardOncs", err);
      }
    };
    const fetchScoreCardStsr = async () => {
      try {
        setloader((currValue) => ({
          ...currValue,
          stsr: true,
        }));
        let url =
          process.env.REACT_APP_API_ENDPOINT +
          process.env.REACT_APP_SCORECARD_PERCENTILE +
          "concept=" +
          selectedScoreCardBannerId +
          "&periodId=" +
          selectedScoreCardPeriodId +
          "&customerType=" +
          "ALL" +
          "&metric=" +
          "STSR";
        await axios({ url }).then((res) => {
          setloader((currValue) => ({
            ...currValue,
            stsr: false,
          }));
          setScoreCardStsr(res.data);
        });
      } catch (err) {
        setloader((currValue) => ({
          ...currValue,
          stsr: true,
        }));
        console.log("err-fetchScoreCardStsr", err);
      }
    };
    const fetchScoreCardOnsr = async () => {
      try {
        setloader((currValue) => ({
          ...currValue,
          onsr: true,
        }));
        let url =
          process.env.REACT_APP_API_ENDPOINT +
          process.env.REACT_APP_SCORECARD_PERCENTILE +
          "concept=" +
          selectedScoreCardBannerId +
          "&periodId=" +
          selectedScoreCardPeriodId +
          "&customerType=" +
          "ALL" +
          "&metric=" +
          "ONSR";
        await axios({ url }).then((res) => {
          setloader((currValue) => ({
            ...currValue,
            onsr: false,
          }));
          setScoreCardOnsr(res.data);
        });
      } catch (err) {
        setloader((currValue) => ({
          ...currValue,
          onsr: true,
        }));
        console.log("err-fetchScoreCardOnsr", err);
      }
    };
    const fetchScoreCardItrn = async () => {
      try {
        setloader((currValue) => ({
          ...currValue,
          itrn: true,
        }));
        let url =
          process.env.REACT_APP_API_ENDPOINT +
          process.env.REACT_APP_SCORECARD +
          "concept=" +
          selectedScoreCardBannerId +
          "&periodId=" +
          selectedScoreCardPeriodId +
          "&customerType=" +
          "ALL" +
          "&metric=" +
          "ITRN";
        await axios({ url }).then((res) => {
          setloader((currValue) => ({
            ...currValue,
            itrn: false,
          }));
          setScoreCardItrn(res.data);
        });
      } catch (err) {
        setloader((currValue) => ({
          ...currValue,
          itrn: true,
        }));
        console.log("err-fetchScoreCardItrn", err);
      }
    };
    const fetchScoreCardAsku = async () => {
      try {
        setloader((currValue) => ({
          ...currValue,
          asku: true,
        }));
        let url =
          process.env.REACT_APP_API_ENDPOINT +
          process.env.REACT_APP_SCORECARD_PERCENTILE +
          "concept=" +
          selectedScoreCardBannerId +
          "&periodId=" +
          selectedScoreCardPeriodId +
          "&customerType=" +
          "ALL" +
          "&metric=" +
          "ASKU";
        await axios({ url }).then((res) => {
          setloader((currValue) => ({
            ...currValue,
            asku: false,
          }));
          setScoreCardAsku(res.data);
        });
      } catch (err) {
        setloader((currValue) => ({
          ...currValue,
          asku: true,
        }));
        console.log("err-fetchScoreCardAsku", err);
      }
    };
    const fetchScoreCardOnStore = async () => {
      try {
        setloader((currValue) => ({
          ...currValue,
          onroas: true,
        }));
        let url =
          process.env.REACT_APP_API_ENDPOINT +
          process.env.REACT_APP_SCORECARD_PERCENTILE +
          "concept=" +
          selectedScoreCardBannerId +
          "&periodId=" +
          selectedScoreCardPeriodId +
          "&customerType=" +
          "ALL" +
          "&metric=" +
          "ON_ROAS";
        await axios({ url }).then((res) => {
          setloader((currValue) => ({
            ...currValue,
            onroas: false,
          }));
          setScoreCardOnStore(res.data);
        });
      } catch (err) {
        setloader((currValue) => ({
          ...currValue,
          onroas: true,
        }));
        console.log("err-fetchScoreCardOnStore", err);
      }
    };
    const fetchScoreCardInStore = async () => {
      try {
        setloader((currValue) => ({
          ...currValue,
          inroas: true,
        }));
        let url =
          process.env.REACT_APP_API_ENDPOINT +
          process.env.REACT_APP_SCORECARD_PERCENTILE +
          "concept=" +
          selectedScoreCardBannerId +
          "&periodId=" +
          selectedScoreCardPeriodId +
          "&customerType=" +
          "ALL" +
          "&metric=" +
          "ST_ROAS";
        await axios({ url }).then((res) => {
          setloader((currValue) => ({
            ...currValue,
            inroas: false,
          }));
          setScoreCardInStore(res.data);
        });
      } catch (err) {
        setloader((currValue) => ({
          ...currValue,
          inroas: true,
        }));
        console.log("err-fetchScoreCardInStore", err);
      }
    };
    const fetchScoreCardAppLogin = async () => {
      try {
        setloader((currValue) => ({
          ...currValue,
          app_Logins: true,
        }));
        let url =
          process.env.REACT_APP_API_ENDPOINT +
          process.env.REACT_APP_SCORECARD +
          "concept=" +
          selectedScoreCardBannerId +
          "&periodId=" +
          selectedScoreCardPeriodId +
          "&customerType=" +
          "ALL" +
          "&metric=" +
          "APP_LOGINS";
        await axios({ url }).then((res) => {
          setloader((currValue) => ({
            ...currValue,
            app_Logins: false,
          }));
          setScoreCardAppLogin(res.data);
        });
      } catch (err) {
        setloader((currValue) => ({
          ...currValue,
          app_Logins: true,
        }));
        console.log("err-fetchScoreCardAppLogin", err);
      }
    };
    const fetchScoreCardOnnb = async () => {
      try {
        setloader((currValue) => ({
          ...currValue,
          onnb: true,
        }));
        let url =
          process.env.REACT_APP_API_ENDPOINT +
          process.env.REACT_APP_SCORECARD_PERCENTILE +
          "concept=" +
          selectedScoreCardBannerId +
          "&periodId=" +
          selectedScoreCardPeriodId +
          "&customerType=" +
          "ALL" +
          "&metric=" +
          "ONNB";
        await axios({ url }).then((res) => {
          setloader((currValue) => ({
            ...currValue,
            onnb: false,
          }));
          setScoreCardOnnb(res.data);
        });
      } catch (err) {
        setloader((currValue) => ({
          ...currValue,
          onnb: true,
        }));
        console.log("err-fetchScoreCardOnnb", err);
      }
    };
    const fetchScoreCardStoreWelcome = async () => {
      try {
        setloader((currValue) => ({
          ...currValue,
          storeWelcome: true,
        }));
        let url =
          process.env.REACT_APP_API_ENDPOINT +
          process.env.REACT_APP_SCORECARD +
          "concept=" +
          selectedScoreCardBannerId +
          "&periodId=" +
          selectedScoreCardPeriodId +
          "&customerType=" +
          "ALL" +
          "&metric=" +
          "WSS";
        await axios({ url }).then((res) => {
          setloader((currValue) => ({
            ...currValue,
            storeWelcome: false,
          }));
          setScoreCardStoreWelcome(res.data);
        });
      } catch (err) {
        setloader((currValue) => ({
          ...currValue,
          storeWelcome: true,
        }));
        console.log("err-fetchScoreCardStoreWelcome", err);
      }
    };
    const fetchScoreCardStoreWelcomePlus = async () => {
      try {
        setloader((currValue) => ({
          ...currValue,
          storeWelcomePlus: true,
        }));
        let url =
          process.env.REACT_APP_API_ENDPOINT +
          process.env.REACT_APP_SCORECARD +
          "concept=" +
          selectedScoreCardBannerId +
          "&periodId=" +
          selectedScoreCardPeriodId +
          "&customerType=" +
          "ALL" +
          "&metric=" +
          "WPS";
        await axios({ url }).then((res) => {
          setloader((currValue) => ({
            ...currValue,
            storeWelcomePlus: false,
          }));
          setScoreCardStoreWelcomePlus(res.data);
        });
      } catch (err) {
        setloader((currValue) => ({
          ...currValue,
          storeWelcomePlus: true,
        }));
        console.log("err-fetchScoreCardStoreWelcomePlus", err);
      }
    };
    const fetchScoreCardOnlineWelcome = async () => {
      try {
        setloader((currValue) => ({
          ...currValue,
          onlineWelcome: true,
        }));
        let url =
          process.env.REACT_APP_API_ENDPOINT +
          process.env.REACT_APP_SCORECARD +
          "concept=" +
          selectedScoreCardBannerId +
          "&periodId=" +
          selectedScoreCardPeriodId +
          "&customerType=" +
          "ALL" +
          "&metric=" +
          "WSO";
        await axios({ url }).then((res) => {
          setloader((currValue) => ({
            ...currValue,
            onlineWelcome: false,
          }));
          setScoreCardOnlineWelcome(res.data);
        });
      } catch (err) {
        setloader((currValue) => ({
          ...currValue,
          onlineWelcome: true,
        }));
        console.log("err-fetchScoreCardOnlineWelcome", err);
      }
    };
    const fetchScoreCardOnlineWelcomePlus = async () => {
      try {
        setloader((currValue) => ({
          ...currValue,
          onlineWelcomePlus: true,
        }));
        let url =
          process.env.REACT_APP_API_ENDPOINT +
          process.env.REACT_APP_SCORECARD +
          "concept=" +
          selectedScoreCardBannerId +
          "&periodId=" +
          selectedScoreCardPeriodId +
          "&customerType=" +
          "ALL" +
          "&metric=" +
          "WPO";
        await axios({ url }).then((res) => {
          setloader((currValue) => ({
            ...currValue,
            onlineWelcomePlus: false,
          }));
          setScoreCardOnlineWelcomePlus(res.data);
        });
      } catch (err) {
        setloader((currValue) => ({
          ...currValue,
          onlineWelcomePlus: true,
        }));
        console.log("err-fetchScoreCardOnlineWelcomePlus", err);
      }
    };
    if (
      localStorage.getItem("isSCORECARD") === "Y" &&
      selectedScoreCardPeriodId
    ) {
      fetchScoreCardAppShoppers();
      fetchScoreCardTotalActiveCustomers();
      fetchScoreCardReActiveCustomers();
      fetchScoreCardActiveEngageCustomers();
      fetchScoreCardPLCC();
      fetchScoreCardBopisSdd();
      fetchScoreCardOmni();
      fetchScoreCardBNPL();
      fetchScoreCardBPlus();
      fetchScoreCardClv();
      fetchScoreCardCrr();
      fetchScoreCardGsc();
      fetchScoreCardCac();
      fetchScoreCardOnv();
      fetchScoreCardCar();
      fetchScoreCardOncr();
      fetchScoreCardSt();
      fetchScoreCardStsp();
      fetchScoreCardStcr();
      fetchScoreCardAov();
      fetchScoreCardAbr();
      fetchScoreCardObplus();
      fetchScoreCardSbplus();
      fetchScoreCardSts();
      fetchScoreCardOnsp();
      fetchScoreCardStcs();
      fetchScoreCardOncs();
      fetchScoreCardStsr();
      fetchScoreCardOnsr();
      fetchScoreCardItrn();
      fetchScoreCardAsku();
      fetchScoreCardOnStore();
      fetchScoreCardInStore();
      fetchScoreCardAppLogin();
      fetchScoreCardMarketingEarners();
      fetchScoreCardMarketingRedeemers();
      fetchScoreCardNBinStore();
      fetchScoreCardOnnb();
      fetchScoreCardStoreWelcome();
      fetchScoreCardStoreWelcomePlus();
      fetchScoreCardOnlineWelcome();
      fetchScoreCardOnlineWelcomePlus();
    }
  }, [
    selectedScoreCardBannerId,
    selectedScoreCardPeriodId,
    selectedScoreCardYearId,
  ]);

  return localStorage.getItem("isSCORECARD") === "Y" ? (
    <div>
      {refreshTime.length > 0 && <NotificationMessage message={refreshDate} />}
      <div className="funnelLink" onClick={handleFunnelClick}>
        <span>Funnel</span>
      </div>
      <div className="mt-1 d-flex align-items-center headings">
        <div className="d-flex justify-content-start p-3">
          <span className="progselectupText">Concept</span>
        </div>
        <div className="d-flex justify-content-start p-3">
          <span className="progselectupText">Year</span>
        </div>
        <div className="d-flex justify-content-start p-3">
          <span className="progselectupText">Period</span>
        </div>
      </div>
      <div className="mt-3 d-flex align-items-center">
        <div className="d-flex justify-content-start p-3">
          <Dropdown className="d-inline">
            <Dropdown.Toggle>{selectedScoreCardBanner.value}</Dropdown.Toggle>
            <Dropdown.Menu
              className="dropdown-menu-ext"
              onClick={(e) => handleScoreCardBanner(e)}
            >
              {ScoreCardBanners.map((data) => {
                return (
                  <Dropdown.Item
                    key={data.id}
                    className="dropdown-item-ext"
                    id={data.id}
                  >
                    {data.value}
                  </Dropdown.Item>
                );
              })}
            </Dropdown.Menu>
          </Dropdown>
        </div>
        {loading.yeardd ? (
          <Placeholder.Button xs={1} />
        ) : (
          <div className="d-flex justify-content-start p-3">
            <Dropdown className="d-inline">
              <Dropdown.Toggle>
                {selectedScoreCardYearId ? selectedScoreCardYearId : "Select"}
              </Dropdown.Toggle>
              <Dropdown.Menu
                className="dropdown-menu-ext"
                onClick={(e) => handleScoreCardYear(e)}
              >
                {scoreCardYear &&
                  scoreCardYear.map((data) => {
                    return (
                      <Dropdown.Item
                        key={data.YEAR}
                        className="dropdown-item-ext"
                        id={data.YEAR}
                      >
                        {data.YEAR}
                      </Dropdown.Item>
                    );
                  })}
              </Dropdown.Menu>
            </Dropdown>
          </div>
        )}
        {loading.datedd ? (
          <Placeholder.Button xs={1} />
        ) : (
          <div className="d-flex justify-content-start p-3">
            <Dropdown className="d-inline">
              <Dropdown.Toggle>
                {selectedScoreCardPeriodValue
                  ? selectedScoreCardPeriodValue
                  : `Select`}
              </Dropdown.Toggle>
              <Dropdown.Menu
                className="dropdown-menu-ext"
                onClick={(e) => handleScoreCardPeriod(e)}
              >
                {scoreCardDates &&
                  scoreCardDates.map((data) => {
                    return (
                      <Dropdown.Item
                        key={data.PERIOD_ID}
                        className="dropdown-item-ext"
                        id={data.PERIOD_ID}
                      >
                        {data.MONTH}
                      </Dropdown.Item>
                    );
                  })}
              </Dropdown.Menu>
            </Dropdown>
          </div>
        )}
      </div>
      <div className="row HeaderContainer">
        {/* <div className="col-3 col-sm-3 SubHeader"></div> */}
        <div className="col-2 col-sm-1 SubHeader justify-content-center">
          <p
            className={
              tabView.marketingView ? "Header-Active HeaderTab " : "HeaderTab"
            }
            onClick={() => buttonClick("1")}
          >
            Marketing
          </p>
        </div>
        <div className="col-2 col-sm-2 SubHeader justify-content-center">
          <p
            className={
              tabView.storeView ? "Header-Active HeaderTab " : "HeaderTab"
            }
            onClick={() => buttonClick("2")}
          >
            Store and Digital <br /> Experience
          </p>
        </div>
        <div className="col-2 col-sm-2 SubHeader justify-content-left">
          <p
            className={
              tabView.inventoryView ? "Header-Active HeaderTab " : "HeaderTab"
            }
            onClick={() => buttonClick("3")}
          >
            Planning and <br /> Inventory
          </p>
        </div>
      </div>
      <div>
        {tabView.marketingView ? (
          <Marketing
            scoreCardAppShoppers={scoreCardAppShoppers}
            scoreCardTotalActiveCustomers={scoreCardTotalActiveCustomers}
            scoreCardReActiveCustomers={scoreCardReActiveCustomers}
            scoreCardEngageCustomers={scoreCardEngageCustomers}
            scoreCardPlcc={scoreCardPlcc}
            scoreCardBopisSdd={scoreCardBopisSdd}
            scoreCardOmni={scoreCardOmni}
            scoreCardBnpl={scoreCardBnpl}
            scoreCardBPlus={scoreCardBPlus}
            scoreCardClv={scoreCardClv}
            scoreCardCrr={scoreCardCrr}
            scoreCardGsc={scoreCardGsc}
            scoreCardCac={scoreCardCac}
            scoreCardOnRoas={scoreCardOnStore}
            scoreCardInRoas={scoreCardInStore}
            scoreCardAppLogin={scoreCardAppLogin}
            loading={loading}
            scoreCardMarketingEarners={scoreCardMarketingEarners}
            scoreCardMarketingRedeemers={scoreCardMarketingRedeemers}
            scoreCardFiscalDates={scoreCardFiscalDates}
          />
        ) : tabView.storeView ? (
          <StoreDigital
            scoreCardOnv={scoreCardOnv}
            loading={loading}
            scoreCardCar={scoreCardCar}
            scoreCardOncr={scoreCardOncr}
            scoreCardSt={scoreCardSt}
            scoreCardStsp={scoreCardStsp}
            scoreCardStcr={scoreCardStcr}
            scoreCardAov={scoreCardAov}
            scoreCardAbr={scoreCardAbr}
            scoreCardOBplus={scoreCardOBplus}
            scoreCardSBplus={scoreCardSBplus}
            scoreCardSts={scoreCardSts}
            scoreCardOnsp={scoreCardOnsp}
            scoreCardStcs={scoreCardStcs}
            scoreCardOncs={scoreCardOncs}
            selectedScoreCardBannerId={selectedScoreCardBannerId}
            scoreCardFiscalDates={scoreCardFiscalDates}
            scoreCardStoreWelcome={scoreCardStoreWelcome}
            scoreCardStoreWelcomePlus={scoreCardStoreWelcomePlus}
            scoreCardOnlineWelcome={scoreCardOnlineWelcome}
            scoreCardOnlineWelcomePlus={scoreCardOnlineWelcomePlus}
          />
        ) : (
          <Inventory
            loading={loading}
            scoreCardStsr={scoreCardStsr}
            scoreCardOnsr={scoreCardOnsr}
            scoreCardItrn={scoreCardItrn}
            scoreCardAsku={scoreCardAsku}
            scoreCardNBinStore={scoreCardNBinStore}
            scoreCardFiscalDates={scoreCardFiscalDates}
            scoreCardOnnb={scoreCardOnnb}
          />
        )}
      </div>
    </div>
  ) : (
    <NoAccess tabName="Scorecard" />
  );
}

export default ScoreCardContainer;
