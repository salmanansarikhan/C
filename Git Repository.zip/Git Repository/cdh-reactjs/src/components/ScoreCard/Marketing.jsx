import { React, useState } from "react";
import { useSelector } from "react-redux";
import "../ScoreCard/ScoreCard.css";
import { Table } from "react-bootstrap";
import LoaderForRow from "../LoaderForTable/LoaderForRow";
import { gettooltip, getDateFormatFromDB } from "../Utils";
export const currencyFormat = (value) => {
  return parseFloat(value)
    .toFixed(0)
    .replace(/(\d)(?=(\d{3})+(?!\d))/g, "$1,");
};
export const decimalCurrencyFormat = (value) => {
  return parseFloat(value)
    .toFixed(2)
    .replace(/(\d)(?=(\d{3})+(?!\d))/g, "$1,");
};
function Marketing({
  loading,
  scoreCardAppShoppers,
  scoreCardTotalActiveCustomers,
  scoreCardReActiveCustomers,
  scoreCardEngageCustomers,
  scoreCardPlcc,
  scoreCardBopisSdd,
  scoreCardOmni,
  scoreCardBnpl,
  scoreCardBPlus,
  scoreCardClv,
  scoreCardCrr,
  scoreCardGsc,
  scoreCardCac,
  scoreCardOnRoas,
  scoreCardInRoas,
  scoreCardAppLogin,
  scoreCardMarketingEarners,
  scoreCardMarketingRedeemers,
  scoreCardFiscalDates,
}) {
  const selectedScoreCardPeriodValue = useSelector(
    (store) => store.ScoreCardPeriod.value
  );
  return (
    <div className="">
      <div className="p-3" style={{ marginBottom: "50px" }}>
        <Table striped bordered hover size="sm">
          <thead className="text">
            <tr>
              <th rowSpan="2"></th>
              <th rowSpan="2">Metrics</th>
              <th colSpan="5">
                Selected Fiscal Month{" ("}
                {scoreCardFiscalDates !== undefined &&
                scoreCardFiscalDates.length !== 0 &&
                scoreCardFiscalDates[0].SFM_START_DATE !== "-999999"
                  ? getDateFormatFromDB(scoreCardFiscalDates[0].SFM_START_DATE)
                  : ""}
                {" - "}
                {scoreCardFiscalDates !== undefined &&
                scoreCardFiscalDates.length !== 0 &&
                scoreCardFiscalDates[0].SFM_END_DATE !== "-999999"
                  ? getDateFormatFromDB(scoreCardFiscalDates[0].SFM_END_DATE)
                  : ""}
                {")"}
              </th>
              <th colSpan="5">
                YTD{" ("}
                {scoreCardFiscalDates !== undefined &&
                scoreCardFiscalDates.length !== 0 &&
                scoreCardFiscalDates[0].YTD_START_DATE !== "-999999"
                  ? getDateFormatFromDB(scoreCardFiscalDates[0].YTD_START_DATE)
                  : ""}
                {" - "}
                {scoreCardFiscalDates !== undefined &&
                scoreCardFiscalDates.length !== 0 &&
                scoreCardFiscalDates[0].YTD_END_DATE !== "-999999"
                  ? getDateFormatFromDB(scoreCardFiscalDates[0].YTD_END_DATE)
                  : ""}
                {")"}
              </th>
            </tr>
            <tr>
              <th>
                Goal/Forecast{" "}
                {gettooltip(
                  "GoalForecastInfoIcon",
                  "GoalForecast",
                  "GoalForecast",
                  "Goals provided are tentative and will be revisited later in discussion with business"
                )}
              </th>
              <th>Actual(TY)</th>
              <th>Actual(LY)</th>
              <th>Variance(YoY)</th>
              <th>Variance (vs.Forecast)</th>
              <th>
                Goal/Forecast{" "}
                {gettooltip(
                  "GoalForecastInfoIcon",
                  "GoalForecast",
                  "GoalForecast",
                  "Goals provided are tentative and will be revisited later in discussion with business"
                )}
              </th>
              <th>Actual(TY)</th>
              <th>Actual(LY)</th>
              <th>Variance(YoY)</th>
              <th>Variance (vs.Forecast)</th>
            </tr>
          </thead>
          <tbody className="text">
            <tr className="align-middle">
              {" "}
              <th rowSpan="4">
                {"4 Key Customer"} <br /> {"KPIs"}
              </th>
              <th>
                Customer Lifetime Value <br />
                (Per Active Customer){" "}
                {gettooltip(
                  "CustLifetimeValueInfoIcon",
                  "CustLifetime",
                  "CustLifetime",
                  "Per customer 3-year product margin for active customer base"
                )}
              </th>
              {loading.clv ? (
                <>
                  <LoaderForRow tdCount={10} />
                </>
              ) : (
                <>
                  <td>
                    {scoreCardClv !== undefined &&
                      scoreCardClv.length !== 0 &&
                      (scoreCardClv[0].GOAL_FORCAST_LM === "-999999"
                        ? "-"
                        : decimalCurrencyFormat(
                            Number(scoreCardClv[0].GOAL_FORCAST_LM)
                          ))}
                  </td>{" "}
                  <td>
                    {scoreCardClv !== undefined &&
                      scoreCardClv.length !== 0 &&
                      (scoreCardClv[0].CUST_CNT_LM_TY === "-999999"
                        ? "-"
                        : decimalCurrencyFormat(
                            Number(scoreCardClv[0].CUST_CNT_LM_TY)
                          ))}
                  </td>{" "}
                  <td>
                    {scoreCardClv !== undefined &&
                      scoreCardClv.length !== 0 &&
                      (scoreCardClv[0].CUST_CNT_LM_LY === "-999999"
                        ? "-"
                        : decimalCurrencyFormat(
                            Number(scoreCardClv[0].CUST_CNT_LM_LY)
                          ))}
                  </td>{" "}
                  <td>
                    {scoreCardClv !== undefined &&
                    scoreCardClv.length !== 0 &&
                    Number(scoreCardClv[0].CUST_CNT_LM_TY_VS_LY)
                      .toFixed(2)
                      .includes("-") ? (
                      <span style={{ color: "red" }}>
                        {scoreCardClv !== undefined &&
                          scoreCardClv.length !== 0 &&
                          (scoreCardClv[0].CUST_CNT_LM_TY_VS_LY === "-999999"
                            ? "-"
                            : `${decimalCurrencyFormat(
                                Number(scoreCardClv[0].CUST_CNT_LM_TY_VS_LY)
                              )}%`)}
                      </span>
                    ) : (
                      <span style={{ color: "green" }}>
                        {scoreCardClv !== undefined &&
                          scoreCardClv.length !== 0 &&
                          (scoreCardClv[0].CUST_CNT_LM_TY_VS_LY === "-999999"
                            ? "-"
                            : `${decimalCurrencyFormat(
                                Number(scoreCardClv[0].CUST_CNT_LM_TY_VS_LY)
                              )}%`)}
                      </span>
                    )}
                  </td>{" "}
                  <td>
                    {scoreCardClv !== undefined &&
                    scoreCardClv.length !== 0 &&
                    Number(scoreCardClv[0].VARIANCE_FORCAST_LM)
                      .toFixed(2)
                      .includes("-") ? (
                      <span style={{ color: "red" }}>
                        {scoreCardClv !== undefined &&
                          scoreCardClv.length !== 0 &&
                          (scoreCardClv[0].VARIANCE_FORCAST_LM === "-999999"
                            ? "-"
                            : `${decimalCurrencyFormat(
                                Number(scoreCardClv[0].VARIANCE_FORCAST_LM)
                              )}%`)}
                      </span>
                    ) : (
                      <span style={{ color: "green" }}>
                        {scoreCardClv !== undefined &&
                          scoreCardClv.length !== 0 &&
                          (scoreCardClv[0].VARIANCE_FORCAST_LM === "-999999"
                            ? "-"
                            : `${decimalCurrencyFormat(
                                Number(scoreCardClv[0].VARIANCE_FORCAST_LM)
                              )}%`)}
                      </span>
                    )}
                  </td>{" "}
                  <td>
                    {scoreCardClv !== undefined &&
                      scoreCardClv.length !== 0 &&
                      (scoreCardClv[0].GOAL_FORCAST_YTD === "-999999"
                        ? "-"
                        : decimalCurrencyFormat(
                            Number(scoreCardClv[0].GOAL_FORCAST_YTD)
                          ))}
                  </td>{" "}
                  <td>
                    {scoreCardClv !== undefined &&
                      scoreCardClv.length !== 0 &&
                      (scoreCardClv[0].CUST_CNT_YTD_TY === "-999999"
                        ? "-"
                        : decimalCurrencyFormat(
                            Number(scoreCardClv[0].CUST_CNT_YTD_TY)
                          ))}
                  </td>{" "}
                  <td>
                    {scoreCardClv !== undefined &&
                      scoreCardClv.length !== 0 &&
                      (scoreCardClv[0].CUST_CNT_YTD_LY === "-999999"
                        ? "-"
                        : decimalCurrencyFormat(
                            Number(scoreCardClv[0].CUST_CNT_YTD_LY)
                          ))}
                  </td>{" "}
                  <td>
                    {scoreCardClv !== undefined &&
                    scoreCardClv.length !== 0 &&
                    Number(scoreCardClv[0].CUST_CNT_YTD_TY_VS_LY)
                      .toFixed(2)
                      .includes("-") ? (
                      <span style={{ color: "red" }}>
                        {scoreCardClv !== undefined &&
                          scoreCardClv.length !== 0 &&
                          (scoreCardClv[0].CUST_CNT_YTD_TY_VS_LY === "-999999"
                            ? "-"
                            : `${decimalCurrencyFormat(
                                Number(scoreCardClv[0].CUST_CNT_YTD_TY_VS_LY)
                              )}%`)}
                      </span>
                    ) : (
                      <span style={{ color: "green" }}>
                        {scoreCardClv !== undefined &&
                          scoreCardClv.length !== 0 &&
                          (scoreCardClv[0].CUST_CNT_YTD_TY_VS_LY === "-999999"
                            ? "-"
                            : `${decimalCurrencyFormat(
                                Number(scoreCardClv[0].CUST_CNT_YTD_TY_VS_LY)
                              )}%`)}
                      </span>
                    )}
                  </td>{" "}
                  <td>
                    {scoreCardClv !== undefined &&
                    scoreCardClv.length !== 0 &&
                    Number(scoreCardClv[0].VARIANCE_FORCAST_YTD)
                      .toFixed(2)
                      .includes("-") ? (
                      <span style={{ color: "red" }}>
                        {scoreCardClv !== undefined &&
                          scoreCardClv.length !== 0 &&
                          (scoreCardClv[0].VARIANCE_FORCAST_YTD === "-999999"
                            ? "-"
                            : `${decimalCurrencyFormat(
                                Number(scoreCardClv[0].VARIANCE_FORCAST_YTD)
                              )}%`)}
                      </span>
                    ) : (
                      <span style={{ color: "green" }}>
                        {scoreCardClv !== undefined &&
                          scoreCardClv.length !== 0 &&
                          (scoreCardClv[0].VARIANCE_FORCAST_YTD === "-999999"
                            ? "-"
                            : `${decimalCurrencyFormat(
                                Number(scoreCardClv[0].VARIANCE_FORCAST_YTD)
                              )}%`)}
                      </span>
                    )}
                  </td>{" "}
                </>
              )}
            </tr>
            <tr>
              {" "}
              <th>
                CAC (Customer Acquisition Cost){" "}
                {gettooltip(
                  "CustomerAcquisitionCostInfoIcon",
                  "CustomerAcquisitionCost",
                  "CustomerAcquisitionCost",
                  "Marketing spend in $ for the period  /",
                  "Total number of New & Reactivated customers in that period"
                )}
              </th>
              {loading.cac ? (
                <>
                  <LoaderForRow tdCount={10} />
                </>
              ) : (
                <>
                  <td>
                    {scoreCardCac !== undefined &&
                      scoreCardCac.length !== 0 &&
                      (scoreCardCac[0].GOAL_FORCAST_LM === "-999999"
                        ? "-"
                        : decimalCurrencyFormat(
                            Number(scoreCardCac[0].GOAL_FORCAST_LM)
                          ))}
                  </td>{" "}
                  <td>
                    {scoreCardCac !== undefined &&
                      scoreCardCac.length !== 0 &&
                      (scoreCardCac[0].CUST_CNT_LM_TY === "-999999"
                        ? "-"
                        : decimalCurrencyFormat(
                            Number(scoreCardCac[0].CUST_CNT_LM_TY)
                          ))}
                  </td>{" "}
                  <td>
                    {scoreCardCac !== undefined &&
                      scoreCardCac.length !== 0 &&
                      (scoreCardCac[0].CUST_CNT_LM_LY === "-999999"
                        ? "-"
                        : decimalCurrencyFormat(
                            Number(scoreCardCac[0].CUST_CNT_LM_LY)
                          ))}
                  </td>{" "}
                  <td>
                    {scoreCardCac !== undefined &&
                    scoreCardCac.length !== 0 &&
                    Number(scoreCardCac[0].CUST_CNT_LM_TY_VS_LY)
                      .toFixed(2)
                      .includes("-") ? (
                      <span style={{ color: "green" }}>
                        {scoreCardCac !== undefined &&
                          scoreCardCac.length !== 0 &&
                          (scoreCardCac[0].CUST_CNT_LM_TY_VS_LY === "-999999"
                            ? "-"
                            : `${decimalCurrencyFormat(
                                Number(scoreCardCac[0].CUST_CNT_LM_TY_VS_LY)
                              )}%`)}
                      </span>
                    ) : (
                      <span style={{ color: "red" }}>
                        {scoreCardCac !== undefined &&
                          scoreCardCac.length !== 0 &&
                          (scoreCardCac[0].CUST_CNT_LM_TY_VS_LY === "-999999"
                            ? "-"
                            : `${decimalCurrencyFormat(
                                Number(scoreCardCac[0].CUST_CNT_LM_TY_VS_LY)
                              )}%`)}
                      </span>
                    )}
                  </td>{" "}
                  <td>
                    {scoreCardCac !== undefined &&
                    scoreCardCac.length !== 0 &&
                    Number(scoreCardCac[0].VARIANCE_FORCAST_LM)
                      .toFixed(2)
                      .includes("-") ? (
                      <span style={{ color: "green" }}>
                        {scoreCardCac !== undefined &&
                          scoreCardCac.length !== 0 &&
                          (scoreCardCac[0].VARIANCE_FORCAST_LM === "-999999"
                            ? "-"
                            : `${decimalCurrencyFormat(
                                Number(scoreCardCac[0].VARIANCE_FORCAST_LM)
                              )}%`)}
                      </span>
                    ) : (
                      <span style={{ color: "red" }}>
                        {scoreCardCac !== undefined &&
                          scoreCardCac.length !== 0 &&
                          (scoreCardCac[0].VARIANCE_FORCAST_LM === "-999999"
                            ? "-"
                            : `${decimalCurrencyFormat(
                                Number(scoreCardCac[0].VARIANCE_FORCAST_LM)
                              )}%`)}
                      </span>
                    )}
                  </td>{" "}
                  <td>
                    {scoreCardCac !== undefined &&
                      scoreCardCac.length !== 0 &&
                      (scoreCardCac[0].GOAL_FORCAST_YTD === "-999999"
                        ? "-"
                        : decimalCurrencyFormat(
                            Number(scoreCardCac[0].GOAL_FORCAST_YTD)
                          ))}
                  </td>{" "}
                  <td>
                    {scoreCardCac !== undefined &&
                      scoreCardCac.length !== 0 &&
                      (scoreCardCac[0].CUST_CNT_YTD_TY === "-999999"
                        ? "-"
                        : decimalCurrencyFormat(
                            Number(scoreCardCac[0].CUST_CNT_YTD_TY)
                          ))}
                  </td>{" "}
                  <td>
                    {scoreCardCac !== undefined &&
                      scoreCardCac.length !== 0 &&
                      (scoreCardCac[0].CUST_CNT_YTD_LY === "-999999"
                        ? "-"
                        : decimalCurrencyFormat(
                            Number(scoreCardCac[0].CUST_CNT_YTD_LY)
                          ))}
                  </td>{" "}
                  <td>
                    {scoreCardCac !== undefined &&
                    scoreCardCac.length !== 0 &&
                    Number(scoreCardCac[0].CUST_CNT_YTD_TY_VS_LY)
                      .toFixed(2)
                      .includes("-") ? (
                      <span style={{ color: "green" }}>
                        {scoreCardCac !== undefined &&
                          scoreCardCac.length !== 0 &&
                          (scoreCardCac[0].CUST_CNT_YTD_TY_VS_LY === "-999999"
                            ? "-"
                            : `${decimalCurrencyFormat(
                                Number(scoreCardCac[0].CUST_CNT_YTD_TY_VS_LY)
                              )}%`)}
                      </span>
                    ) : (
                      <span style={{ color: "red" }}>
                        {scoreCardCac !== undefined &&
                          scoreCardCac.length !== 0 &&
                          (scoreCardCac[0].CUST_CNT_YTD_TY_VS_LY === "-999999"
                            ? "-"
                            : `${decimalCurrencyFormat(
                                Number(scoreCardCac[0].CUST_CNT_YTD_TY_VS_LY)
                              )}%`)}
                      </span>
                    )}
                  </td>{" "}
                  <td>
                    {scoreCardCac !== undefined &&
                    scoreCardCac.length !== 0 &&
                    Number(scoreCardCac[0].VARIANCE_FORCAST_YTD)
                      .toFixed(2)
                      .includes("-") ? (
                      <span style={{ color: "green" }}>
                        {scoreCardCac !== undefined &&
                          scoreCardCac.length !== 0 &&
                          (scoreCardCac[0].VARIANCE_FORCAST_YTD === "-999999"
                            ? "-"
                            : `${decimalCurrencyFormat(
                                Number(scoreCardCac[0].VARIANCE_FORCAST_YTD)
                              )}%`)}
                      </span>
                    ) : (
                      <span style={{ color: "red" }}>
                        {scoreCardCac !== undefined &&
                          scoreCardCac.length !== 0 &&
                          (scoreCardCac[0].VARIANCE_FORCAST_YTD === "-999999"
                            ? "-"
                            : `${decimalCurrencyFormat(
                                Number(scoreCardCac[0].VARIANCE_FORCAST_YTD)
                              )}%`)}
                      </span>
                    )}
                  </td>{" "}
                </>
              )}{" "}
            </tr>
            <tr>
              {" "}
              <th>
                Customer Retention Rate{" "}
                {gettooltip(
                  "CustomerRetentionRateInfoIcon",
                  "CustomerRetentionRate",
                  "CustomerRetentionRate",
                  "% of customers who shopped in L12M out of the ones that shopped a quarter prior to that"
                )}
              </th>{" "}
              {loading.crr ? (
                <>
                  <LoaderForRow tdCount={10} />
                </>
              ) : (
                <>
                  <td>
                    {scoreCardCrr !== undefined &&
                      scoreCardCrr.length !== 0 &&
                      (scoreCardCrr[0].GOAL_FORCAST_LM === "-999999"
                        ? "-"
                        : `${decimalCurrencyFormat(
                            Number(scoreCardCrr[0].GOAL_FORCAST_LM)
                          )}%`)}
                  </td>{" "}
                  <td>
                    {scoreCardCrr !== undefined &&
                      scoreCardCrr.length !== 0 &&
                      (scoreCardCrr[0].CUST_CNT_LM_TY === "-999999"
                        ? "-"
                        : `${decimalCurrencyFormat(
                            Number(scoreCardCrr[0].CUST_CNT_LM_TY)
                          )}%`)}
                  </td>{" "}
                  <td>
                    {scoreCardCrr !== undefined &&
                      scoreCardCrr.length !== 0 &&
                      (scoreCardCrr[0].CUST_CNT_LM_LY === "-999999"
                        ? "-"
                        : `${decimalCurrencyFormat(
                            Number(scoreCardCrr[0].CUST_CNT_LM_LY)
                          )}%`)}
                  </td>{" "}
                  <td>
                    {scoreCardCrr !== undefined &&
                    scoreCardCrr.length !== 0 &&
                    Number(scoreCardCrr[0].CUST_CNT_LM_TY_VS_LY)
                      .toFixed(2)
                      .includes("-") ? (
                      <span style={{ color: "red" }}>
                        {scoreCardCrr !== undefined &&
                          scoreCardCrr.length !== 0 &&
                          (scoreCardCrr[0].CUST_CNT_LM_TY_VS_LY === "-999999"
                            ? "-"
                            : decimalCurrencyFormat(
                                Number(scoreCardCrr[0].CUST_CNT_LM_TY_VS_LY)
                              ))}
                      </span>
                    ) : (
                      <span style={{ color: "green" }}>
                        {scoreCardCrr !== undefined &&
                          scoreCardCrr.length !== 0 &&
                          (scoreCardCrr[0].CUST_CNT_LM_TY_VS_LY === "-999999"
                            ? "-"
                            : decimalCurrencyFormat(
                                Number(scoreCardCrr[0].CUST_CNT_LM_TY_VS_LY)
                              ))}
                      </span>
                    )}
                  </td>{" "}
                  <td>
                    {scoreCardCrr !== undefined &&
                    scoreCardCrr.length !== 0 &&
                    Number(scoreCardCrr[0].VARIANCE_FORCAST_LM)
                      .toFixed(2)
                      .includes("-") ? (
                      <span style={{ color: "red" }}>
                        {scoreCardCrr !== undefined &&
                          scoreCardCrr.length !== 0 &&
                          (scoreCardCrr[0].VARIANCE_FORCAST_LM === "-999999"
                            ? "-"
                            : decimalCurrencyFormat(
                                Number(scoreCardCrr[0].VARIANCE_FORCAST_LM)
                              ))}
                      </span>
                    ) : (
                      <span style={{ color: "green" }}>
                        {scoreCardCrr !== undefined &&
                          scoreCardCrr.length !== 0 &&
                          (scoreCardCrr[0].VARIANCE_FORCAST_LM === "-999999"
                            ? "-"
                            : decimalCurrencyFormat(
                                Number(scoreCardCrr[0].VARIANCE_FORCAST_LM)
                              ))}
                      </span>
                    )}
                  </td>{" "}
                  <td>
                    {scoreCardCrr !== undefined &&
                      scoreCardCrr.length !== 0 &&
                      (scoreCardCrr[0].GOAL_FORCAST_YTD === "-999999"
                        ? "-"
                        : `${decimalCurrencyFormat(
                            Number(scoreCardCrr[0].GOAL_FORCAST_YTD)
                          )}%`)}
                  </td>{" "}
                  <td>
                    {scoreCardCrr !== undefined &&
                      scoreCardCrr.length !== 0 &&
                      (scoreCardCrr[0].CUST_CNT_YTD_TY === "-999999"
                        ? "-"
                        : `${decimalCurrencyFormat(
                            Number(scoreCardCrr[0].CUST_CNT_YTD_TY)
                          )}%`)}
                  </td>{" "}
                  <td>
                    {scoreCardCrr !== undefined &&
                      scoreCardCrr.length !== 0 &&
                      (scoreCardCrr[0].CUST_CNT_YTD_LY === "-999999"
                        ? "-"
                        : `${decimalCurrencyFormat(
                            Number(scoreCardCrr[0].CUST_CNT_YTD_LY)
                          )}%`)}
                  </td>{" "}
                  <td>
                    {scoreCardCrr !== undefined &&
                    scoreCardCrr.length !== 0 &&
                    Number(scoreCardCrr[0].CUST_CNT_YTD_TY_VS_LY)
                      .toFixed(2)
                      .includes("-") ? (
                      <span style={{ color: "red" }}>
                        {scoreCardCrr !== undefined &&
                          scoreCardCrr.length !== 0 &&
                          (scoreCardCrr[0].CUST_CNT_YTD_TY_VS_LY === "-999999"
                            ? "-"
                            : decimalCurrencyFormat(
                                Number(scoreCardCrr[0].CUST_CNT_YTD_TY_VS_LY)
                              ))}
                      </span>
                    ) : (
                      <span style={{ color: "green" }}>
                        {scoreCardCrr !== undefined &&
                          scoreCardCrr.length !== 0 &&
                          (scoreCardCrr[0].CUST_CNT_YTD_TY_VS_LY === "-999999"
                            ? "-"
                            : decimalCurrencyFormat(
                                Number(scoreCardCrr[0].CUST_CNT_YTD_TY_VS_LY)
                              ))}
                      </span>
                    )}
                  </td>{" "}
                  <td>
                    {scoreCardCrr !== undefined &&
                    scoreCardCrr.length !== 0 &&
                    Number(scoreCardCrr[0].VARIANCE_FORCAST_YTD)
                      .toFixed(2)
                      .includes("-") ? (
                      <span style={{ color: "red" }}>
                        {scoreCardCrr !== undefined &&
                          scoreCardCrr.length !== 0 &&
                          (scoreCardCrr[0].VARIANCE_FORCAST_YTD === "-999999"
                            ? "-"
                            : decimalCurrencyFormat(
                                Number(scoreCardCrr[0].VARIANCE_FORCAST_YTD)
                              ))}
                      </span>
                    ) : (
                      <span style={{ color: "green" }}>
                        {scoreCardCrr !== undefined &&
                          scoreCardCrr.length !== 0 &&
                          (scoreCardCrr[0].VARIANCE_FORCAST_YTD === "-999999"
                            ? "-"
                            : decimalCurrencyFormat(
                                Number(scoreCardCrr[0].VARIANCE_FORCAST_YTD)
                              ))}
                      </span>
                    )}
                  </td>{" "}
                </>
              )}
            </tr>
            <tr>
              {" "}
              <th>
                Growth Segment Count{" "}
                {gettooltip(
                  "GrowthSegmentCountInfoIcon",
                  "GrowthSegmentCount",
                  "GrowthSegmentCount",
                  "Number of CREATIVE persona customers in the period (Data available for BBBY US only)"
                )}
              </th>{" "}
              {loading.gsc ? (
                <>
                  <LoaderForRow tdCount={10} />
                </>
              ) : (
                <>
                  <td>
                    {scoreCardGsc !== undefined &&
                      scoreCardGsc.length !== 0 &&
                      (scoreCardGsc[0].GOAL_FORCAST_LM === "-999999"
                        ? "-"
                        : currencyFormat(
                            Number(scoreCardGsc[0].GOAL_FORCAST_LM)
                          ))}
                  </td>{" "}
                  <td>
                    {scoreCardGsc !== undefined &&
                      scoreCardGsc.length !== 0 &&
                      (scoreCardGsc[0].CUST_CNT_LM_TY === "-999999" ||
                      selectedScoreCardPeriodValue === "April (02)"
                        ? "-"
                        : currencyFormat(
                            Number(scoreCardGsc[0].CUST_CNT_LM_TY)
                          ))}
                  </td>{" "}
                  <td>
                    {scoreCardGsc !== undefined &&
                      scoreCardGsc.length !== 0 &&
                      (scoreCardGsc[0].CUST_CNT_LM_LY === "-999999"
                        ? "-"
                        : currencyFormat(
                            Number(scoreCardGsc[0].CUST_CNT_LM_LY)
                          ))}
                  </td>{" "}
                  <td>
                    {scoreCardGsc !== undefined &&
                    scoreCardGsc.length !== 0 &&
                    Number(scoreCardGsc[0].CUST_CNT_LM_TY_VS_LY)
                      .toFixed(2)
                      .includes("-") ? (
                      <span style={{ color: "red" }}>
                        {scoreCardGsc !== undefined &&
                          scoreCardGsc.length !== 0 &&
                          (scoreCardGsc[0].CUST_CNT_LM_TY_VS_LY === "-999999" ||
                          selectedScoreCardPeriodValue === "April (02)"
                            ? "-"
                            : `${decimalCurrencyFormat(
                                Number(scoreCardGsc[0].CUST_CNT_LM_TY_VS_LY)
                              )}%`)}
                      </span>
                    ) : (
                      <span style={{ color: "green" }}>
                        {scoreCardGsc !== undefined &&
                          scoreCardGsc.length !== 0 &&
                          (scoreCardGsc[0].CUST_CNT_LM_TY_VS_LY === "-999999" ||
                          selectedScoreCardPeriodValue === "April (02)"
                            ? "-"
                            : `${decimalCurrencyFormat(
                                Number(scoreCardGsc[0].CUST_CNT_LM_TY_VS_LY)
                              )}%`)}
                      </span>
                    )}
                  </td>{" "}
                  <td>
                    {scoreCardGsc !== undefined &&
                    scoreCardGsc.length !== 0 &&
                    Number(scoreCardGsc[0].VARIANCE_FORCAST_LM)
                      .toFixed(2)
                      .includes("-") ? (
                      <span style={{ color: "red" }}>
                        {scoreCardGsc !== undefined &&
                          scoreCardGsc.length !== 0 &&
                          (scoreCardGsc[0].VARIANCE_FORCAST_LM === "-999999" ||
                          selectedScoreCardPeriodValue === "April (02)"
                            ? "-"
                            : `${decimalCurrencyFormat(
                                Number(scoreCardGsc[0].VARIANCE_FORCAST_LM)
                              )}%`)}
                      </span>
                    ) : (
                      <span style={{ color: "green" }}>
                        {scoreCardGsc !== undefined &&
                          scoreCardGsc.length !== 0 &&
                          (scoreCardGsc[0].VARIANCE_FORCAST_LM === "-999999" ||
                          selectedScoreCardPeriodValue === "April (02)"
                            ? "-"
                            : `${decimalCurrencyFormat(
                                Number(scoreCardGsc[0].VARIANCE_FORCAST_LM)
                              )}%`)}
                      </span>
                    )}
                  </td>{" "}
                  <td>
                    {scoreCardGsc !== undefined &&
                      scoreCardGsc.length !== 0 &&
                      (scoreCardGsc[0].GOAL_FORCAST_YTD === "-999999"
                        ? "-"
                        : currencyFormat(
                            Number(scoreCardGsc[0].GOAL_FORCAST_YTD)
                          ))}
                  </td>{" "}
                  <td>
                    {scoreCardGsc !== undefined &&
                      scoreCardGsc.length !== 0 &&
                      (scoreCardGsc[0].CUST_CNT_YTD_TY === "-999999" ||
                      selectedScoreCardPeriodValue === "April (02)"
                        ? "-"
                        : currencyFormat(
                            Number(scoreCardGsc[0].CUST_CNT_YTD_TY)
                          ))}
                  </td>{" "}
                  <td>
                    {scoreCardGsc !== undefined &&
                      scoreCardGsc.length !== 0 &&
                      (scoreCardGsc[0].CUST_CNT_YTD_LY === "-999999"
                        ? "-"
                        : currencyFormat(
                            Number(scoreCardGsc[0].CUST_CNT_YTD_LY)
                          ))}
                  </td>{" "}
                  <td>
                    {scoreCardGsc !== undefined &&
                    scoreCardGsc.length !== 0 &&
                    Number(scoreCardGsc[0].CUST_CNT_YTD_TY_VS_LY)
                      .toFixed(2)
                      .includes("-") ? (
                      <span style={{ color: "red" }}>
                        {scoreCardGsc !== undefined &&
                          scoreCardGsc.length !== 0 &&
                          (scoreCardGsc[0].CUST_CNT_YTD_TY_VS_LY ===
                            "-999999" ||
                          selectedScoreCardPeriodValue === "April (02)"
                            ? "-"
                            : `${decimalCurrencyFormat(
                                Number(scoreCardGsc[0].CUST_CNT_YTD_TY_VS_LY)
                              )}%`)}
                      </span>
                    ) : (
                      <span style={{ color: "green" }}>
                        {scoreCardGsc !== undefined &&
                          scoreCardGsc.length !== 0 &&
                          (scoreCardGsc[0].CUST_CNT_YTD_TY_VS_LY ===
                            "-999999" ||
                          selectedScoreCardPeriodValue === "April (02)"
                            ? "-"
                            : `${decimalCurrencyFormat(
                                Number(scoreCardGsc[0].CUST_CNT_YTD_TY_VS_LY)
                              )}%`)}
                      </span>
                    )}
                  </td>{" "}
                  <td>
                    {scoreCardGsc !== undefined &&
                    scoreCardGsc.length !== 0 &&
                    Number(scoreCardGsc[0].VARIANCE_FORCAST_YTD)
                      .toFixed(2)
                      .includes("-") ? (
                      <span style={{ color: "red" }}>
                        {scoreCardGsc !== undefined &&
                          scoreCardGsc.length !== 0 &&
                          (scoreCardGsc[0].VARIANCE_FORCAST_YTD === "-999999" ||
                          selectedScoreCardPeriodValue === "April (02)"
                            ? "-"
                            : `${decimalCurrencyFormat(
                                Number(scoreCardGsc[0].VARIANCE_FORCAST_YTD)
                              )}%`)}
                      </span>
                    ) : (
                      <span style={{ color: "green" }}>
                        {scoreCardGsc !== undefined &&
                          scoreCardGsc.length !== 0 &&
                          (scoreCardGsc[0].VARIANCE_FORCAST_YTD === "-999999" ||
                          selectedScoreCardPeriodValue === "April (02)"
                            ? "-"
                            : `${decimalCurrencyFormat(
                                Number(scoreCardGsc[0].VARIANCE_FORCAST_YTD)
                              )}%`)}
                      </span>
                    )}
                  </td>{" "}
                </>
              )}
            </tr>
            <tr></tr>
            <tr>
              {" "}
              <th rowSpan="3" className="align-middle">
                {"Near Segments"}
              </th>
              <th>
                Total Customers{" "}
                {gettooltip(
                  "TotalCustomersInfoIcon",
                  "TotalCustomers",
                  "TotalCustomers",
                  "Number of active customers in the period"
                )}
              </th>
              {loading.active_customers ? (
                <>
                  <LoaderForRow tdCount={10} />
                </>
              ) : (
                <>
                  <td>
                    {scoreCardTotalActiveCustomers !== undefined &&
                      scoreCardTotalActiveCustomers.length !== 0 &&
                      (scoreCardTotalActiveCustomers[0].GOAL_FORCAST_LM ===
                      "-999999"
                        ? "-"
                        : currencyFormat(
                            Number(
                              scoreCardTotalActiveCustomers[0].GOAL_FORCAST_LM
                            )
                          ))}
                  </td>{" "}
                  <td>
                    {scoreCardTotalActiveCustomers !== undefined &&
                      scoreCardTotalActiveCustomers.length !== 0 &&
                      (scoreCardTotalActiveCustomers[0].CUST_CNT_LM_TY ===
                      "-999999"
                        ? "-"
                        : currencyFormat(
                            Number(
                              scoreCardTotalActiveCustomers[0].CUST_CNT_LM_TY
                            )
                          ))}
                  </td>{" "}
                  <td>
                    {scoreCardTotalActiveCustomers !== undefined &&
                      scoreCardTotalActiveCustomers.length !== 0 &&
                      (scoreCardTotalActiveCustomers[0].CUST_CNT_LM_LY ===
                      "-999999"
                        ? "-"
                        : currencyFormat(
                            Number(
                              scoreCardTotalActiveCustomers[0].CUST_CNT_LM_LY
                            )
                          ))}
                  </td>{" "}
                  <td>
                    {scoreCardTotalActiveCustomers !== undefined &&
                    scoreCardTotalActiveCustomers.length !== 0 &&
                    Number(
                      scoreCardTotalActiveCustomers[0].CUST_CNT_LM_TY_VS_LY
                    )
                      .toFixed(2)
                      .includes("-") ? (
                      <span style={{ color: "red" }}>
                        {scoreCardTotalActiveCustomers !== undefined &&
                          scoreCardTotalActiveCustomers.length !== 0 &&
                          (scoreCardTotalActiveCustomers[0]
                            .CUST_CNT_LM_TY_VS_LY === "-999999"
                            ? "-"
                            : `${decimalCurrencyFormat(
                                Number(
                                  scoreCardTotalActiveCustomers[0]
                                    .CUST_CNT_LM_TY_VS_LY
                                )
                              )}%`)}
                      </span>
                    ) : (
                      <span style={{ color: "green" }}>
                        {scoreCardTotalActiveCustomers !== undefined &&
                          scoreCardTotalActiveCustomers.length !== 0 &&
                          (scoreCardTotalActiveCustomers[0]
                            .CUST_CNT_LM_TY_VS_LY === "-999999"
                            ? "-"
                            : `${decimalCurrencyFormat(
                                Number(
                                  scoreCardTotalActiveCustomers[0]
                                    .CUST_CNT_LM_TY_VS_LY
                                )
                              )}%`)}
                      </span>
                    )}
                  </td>{" "}
                  <td>
                    {scoreCardTotalActiveCustomers !== undefined &&
                    scoreCardTotalActiveCustomers.length !== 0 &&
                    Number(
                      scoreCardTotalActiveCustomers[0].VARIANCE_FORCAST_LM
                    )
                      .toFixed(2)
                      .includes("-") ? (
                      <span style={{ color: "red" }}>
                        {scoreCardTotalActiveCustomers !== undefined &&
                          scoreCardTotalActiveCustomers.length !== 0 &&
                          (scoreCardTotalActiveCustomers[0]
                            .VARIANCE_FORCAST_LM === "-999999"
                            ? "-"
                            : `${decimalCurrencyFormat(
                                Number(
                                  scoreCardTotalActiveCustomers[0]
                                    .VARIANCE_FORCAST_LM
                                )
                              )}%`)}
                      </span>
                    ) : (
                      <span style={{ color: "green" }}>
                        {scoreCardTotalActiveCustomers !== undefined &&
                          scoreCardTotalActiveCustomers.length !== 0 &&
                          (scoreCardTotalActiveCustomers[0]
                            .VARIANCE_FORCAST_LM === "-999999"
                            ? "-"
                            : `${decimalCurrencyFormat(
                                Number(
                                  scoreCardTotalActiveCustomers[0]
                                    .VARIANCE_FORCAST_LM
                                )
                              )}%`)}
                      </span>
                    )}
                  </td>{" "}
                  <td>
                    {scoreCardTotalActiveCustomers !== undefined &&
                      scoreCardTotalActiveCustomers.length !== 0 &&
                      (scoreCardTotalActiveCustomers[0].GOAL_FORCAST_YTD ===
                      "-999999"
                        ? "-"
                        : currencyFormat(
                            Number(
                              scoreCardTotalActiveCustomers[0].GOAL_FORCAST_YTD
                            )
                          ))}
                  </td>{" "}
                  <td>
                    {scoreCardTotalActiveCustomers !== undefined &&
                      scoreCardTotalActiveCustomers.length !== 0 &&
                      (scoreCardTotalActiveCustomers[0].CUST_CNT_YTD_TY ===
                      "-999999"
                        ? "-"
                        : currencyFormat(
                            Number(
                              scoreCardTotalActiveCustomers[0].CUST_CNT_YTD_TY
                            )
                          ))}
                  </td>{" "}
                  <td>
                    {scoreCardTotalActiveCustomers !== undefined &&
                      scoreCardTotalActiveCustomers.length !== 0 &&
                      (scoreCardTotalActiveCustomers[0].CUST_CNT_YTD_LY ===
                      "-999999"
                        ? "-"
                        : currencyFormat(
                            Number(
                              scoreCardTotalActiveCustomers[0].CUST_CNT_YTD_LY
                            )
                          ))}
                  </td>{" "}
                  <td>
                    {scoreCardTotalActiveCustomers !== undefined &&
                    scoreCardTotalActiveCustomers.length !== 0 &&
                    Number(
                      scoreCardTotalActiveCustomers[0].CUST_CNT_YTD_TY_VS_LY
                    )
                      .toFixed(2)
                      .includes("-") ? (
                      <span style={{ color: "red" }}>
                        {scoreCardTotalActiveCustomers !== undefined &&
                          scoreCardTotalActiveCustomers.length !== 0 &&
                          (scoreCardTotalActiveCustomers[0]
                            .CUST_CNT_YTD_TY_VS_LY === "-999999"
                            ? "-"
                            : `${decimalCurrencyFormat(
                                Number(
                                  scoreCardTotalActiveCustomers[0]
                                    .CUST_CNT_YTD_TY_VS_LY
                                )
                              )}%`)}
                      </span>
                    ) : (
                      <span style={{ color: "green" }}>
                        {scoreCardTotalActiveCustomers !== undefined &&
                          scoreCardTotalActiveCustomers.length !== 0 &&
                          (scoreCardTotalActiveCustomers[0]
                            .CUST_CNT_YTD_TY_VS_LY === "-999999"
                            ? "-"
                            : `${decimalCurrencyFormat(
                                Number(
                                  scoreCardTotalActiveCustomers[0]
                                    .CUST_CNT_YTD_TY_VS_LY
                                )
                              )}%`)}
                      </span>
                    )}
                  </td>{" "}
                  <td>
                    {scoreCardTotalActiveCustomers !== undefined &&
                    scoreCardTotalActiveCustomers.length !== 0 &&
                    Number(
                      scoreCardTotalActiveCustomers[0].VARIANCE_FORCAST_YTD
                    )
                      .toFixed(2)
                      .includes("-") ? (
                      <span style={{ color: "red" }}>
                        {scoreCardTotalActiveCustomers !== undefined &&
                          scoreCardTotalActiveCustomers.length !== 0 &&
                          (scoreCardTotalActiveCustomers[0]
                            .VARIANCE_FORCAST_YTD === "-999999"
                            ? "-"
                            : `${decimalCurrencyFormat(
                                Number(
                                  scoreCardTotalActiveCustomers[0]
                                    .VARIANCE_FORCAST_YTD
                                )
                              )}%`)}
                      </span>
                    ) : (
                      <span style={{ color: "green" }}>
                        {scoreCardTotalActiveCustomers !== undefined &&
                          scoreCardTotalActiveCustomers.length !== 0 &&
                          (scoreCardTotalActiveCustomers[0]
                            .VARIANCE_FORCAST_YTD === "-999999"
                            ? "-"
                            : `${decimalCurrencyFormat(
                                Number(
                                  scoreCardTotalActiveCustomers[0]
                                    .VARIANCE_FORCAST_YTD
                                )
                              )}%`)}
                      </span>
                    )}
                  </td>{" "}
                </>
              )}
            </tr>
            <tr>
              {" "}
              <th>
                New/Reactivated Customers{" "}
                {gettooltip(
                  "NewReactivatedCustomers",
                  "NewReactivatedCustomers",
                  "NewReactivatedCustomers",
                  "New: Number of customers who made their first purchase in the past 36 months",
                  "Reactivated: Number of customers who made their first purchase in past 12 months, shopped previously 12+ months ago"
                )}
              </th>{" "}
              {loading.reActive_customers ? (
                <>
                  <LoaderForRow tdCount={10} />
                </>
              ) : (
                <>
                  <td>
                    {scoreCardReActiveCustomers !== undefined &&
                      scoreCardReActiveCustomers.length !== 0 &&
                      (scoreCardReActiveCustomers[0].GOAL_FORCAST_LM ===
                      "-999999"
                        ? "-"
                        : currencyFormat(
                            Number(
                              scoreCardReActiveCustomers[0].GOAL_FORCAST_LM
                            )
                          ))}
                  </td>{" "}
                  <td>
                    {scoreCardReActiveCustomers !== undefined &&
                      scoreCardReActiveCustomers.length !== 0 &&
                      (scoreCardReActiveCustomers[0].CUST_CNT_LM_TY ===
                      "-999999"
                        ? "-"
                        : currencyFormat(
                            Number(scoreCardReActiveCustomers[0].CUST_CNT_LM_TY)
                          ))}
                  </td>{" "}
                  <td>
                    {scoreCardReActiveCustomers !== undefined &&
                      scoreCardReActiveCustomers.length !== 0 &&
                      (scoreCardReActiveCustomers[0].CUST_CNT_LM_LY ===
                      "-999999"
                        ? "-"
                        : currencyFormat(
                            Number(scoreCardReActiveCustomers[0].CUST_CNT_LM_LY)
                          ))}
                  </td>{" "}
                  <td>
                    {scoreCardReActiveCustomers !== undefined &&
                    scoreCardReActiveCustomers.length !== 0 &&
                    Number(scoreCardReActiveCustomers[0].CUST_CNT_LM_TY_VS_LY)
                      .toFixed(2)
                      .includes("-") ? (
                      <span style={{ color: "red" }}>
                        {scoreCardReActiveCustomers !== undefined &&
                          scoreCardReActiveCustomers.length !== 0 &&
                          (scoreCardReActiveCustomers[0]
                            .CUST_CNT_LM_TY_VS_LY === "-999999"
                            ? "-"
                            : `${decimalCurrencyFormat(
                                Number(
                                  scoreCardReActiveCustomers[0]
                                    .CUST_CNT_LM_TY_VS_LY
                                )
                              )}%`)}
                      </span>
                    ) : (
                      <span style={{ color: "green" }}>
                        {scoreCardReActiveCustomers !== undefined &&
                          scoreCardReActiveCustomers.length !== 0 &&
                          (scoreCardReActiveCustomers[0]
                            .CUST_CNT_LM_TY_VS_LY === "-999999"
                            ? "-"
                            : `${decimalCurrencyFormat(
                                Number(
                                  scoreCardReActiveCustomers[0]
                                    .CUST_CNT_LM_TY_VS_LY
                                )
                              )}%`)}
                      </span>
                    )}
                  </td>{" "}
                  <td>
                    {scoreCardReActiveCustomers !== undefined &&
                    scoreCardReActiveCustomers.length !== 0 &&
                    Number(scoreCardReActiveCustomers[0].VARIANCE_FORCAST_LM)
                      .toFixed(2)
                      .includes("-") ? (
                      <span style={{ color: "red" }}>
                        {scoreCardReActiveCustomers !== undefined &&
                          scoreCardReActiveCustomers.length !== 0 &&
                          (scoreCardReActiveCustomers[0]
                            .VARIANCE_FORCAST_LM === "-999999"
                            ? "-"
                            : `${decimalCurrencyFormat(
                                Number(
                                  scoreCardReActiveCustomers[0]
                                    .VARIANCE_FORCAST_LM
                                )
                              )}%`)}
                      </span>
                    ) : (
                      <span style={{ color: "green" }}>
                        {scoreCardReActiveCustomers !== undefined &&
                          scoreCardReActiveCustomers.length !== 0 &&
                          (scoreCardReActiveCustomers[0]
                            .VARIANCE_FORCAST_LM === "-999999"
                            ? "-"
                            : `${decimalCurrencyFormat(
                                Number(
                                  scoreCardReActiveCustomers[0]
                                    .VARIANCE_FORCAST_LM
                                )
                              )}%`)}
                      </span>
                    )}
                  </td>{" "}
                  <td>
                    {scoreCardReActiveCustomers !== undefined &&
                      scoreCardReActiveCustomers.length !== 0 &&
                      (scoreCardReActiveCustomers[0].GOAL_FORCAST_YTD ===
                      "-999999"
                        ? "-"
                        : currencyFormat(
                            Number(
                              scoreCardReActiveCustomers[0].GOAL_FORCAST_YTD
                            )
                          ))}
                  </td>{" "}
                  <td>
                    {scoreCardReActiveCustomers !== undefined &&
                      scoreCardReActiveCustomers.length !== 0 &&
                      (scoreCardReActiveCustomers[0].CUST_CNT_YTD_TY ===
                      "-999999"
                        ? "-"
                        : currencyFormat(
                            Number(
                              scoreCardReActiveCustomers[0].CUST_CNT_YTD_TY
                            )
                          ))}
                  </td>{" "}
                  <td>
                    {scoreCardReActiveCustomers !== undefined &&
                      scoreCardReActiveCustomers.length !== 0 &&
                      (scoreCardReActiveCustomers[0].CUST_CNT_YTD_LY ===
                      "-999999"
                        ? "-"
                        : currencyFormat(
                            Number(
                              scoreCardReActiveCustomers[0].CUST_CNT_YTD_LY
                            )
                          ))}
                  </td>{" "}
                  <td>
                    {scoreCardReActiveCustomers !== undefined &&
                    scoreCardReActiveCustomers.length !== 0 &&
                    Number(scoreCardReActiveCustomers[0].CUST_CNT_YTD_TY_VS_LY)
                      .toFixed(2)
                      .includes("-") ? (
                      <span style={{ color: "red" }}>
                        {scoreCardReActiveCustomers !== undefined &&
                          scoreCardReActiveCustomers.length !== 0 &&
                          (scoreCardReActiveCustomers[0]
                            .CUST_CNT_YTD_TY_VS_LY === "-999999"
                            ? "-"
                            : `${decimalCurrencyFormat(
                                Number(
                                  scoreCardReActiveCustomers[0]
                                    .CUST_CNT_YTD_TY_VS_LY
                                )
                              )}%`)}
                      </span>
                    ) : (
                      <span style={{ color: "green" }}>
                        {scoreCardReActiveCustomers !== undefined &&
                          scoreCardReActiveCustomers.length !== 0 &&
                          (scoreCardReActiveCustomers[0]
                            .CUST_CNT_YTD_TY_VS_LY === "-999999"
                            ? "-"
                            : `${decimalCurrencyFormat(
                                Number(
                                  scoreCardReActiveCustomers[0]
                                    .CUST_CNT_YTD_TY_VS_LY
                                )
                              )}%`)}
                      </span>
                    )}
                  </td>{" "}
                  <td>
                    {scoreCardReActiveCustomers !== undefined &&
                    scoreCardReActiveCustomers.length !== 0 &&
                    Number(scoreCardReActiveCustomers[0].VARIANCE_FORCAST_YTD)
                      .toFixed(2)
                      .includes("-") ? (
                      <span style={{ color: "red" }}>
                        {scoreCardReActiveCustomers !== undefined &&
                          scoreCardReActiveCustomers.length !== 0 &&
                          (scoreCardReActiveCustomers[0]
                            .VARIANCE_FORCAST_YTD === "-999999"
                            ? "-"
                            : `${decimalCurrencyFormat(
                                Number(
                                  scoreCardReActiveCustomers[0]
                                    .VARIANCE_FORCAST_YTD
                                )
                              )}%`)}
                      </span>
                    ) : (
                      <span style={{ color: "green" }}>
                        {scoreCardReActiveCustomers !== undefined &&
                          scoreCardReActiveCustomers.length !== 0 &&
                          (scoreCardReActiveCustomers[0]
                            .VARIANCE_FORCAST_YTD === "-999999"
                            ? "-"
                            : `${decimalCurrencyFormat(
                                Number(
                                  scoreCardReActiveCustomers[0]
                                    .VARIANCE_FORCAST_YTD
                                )
                              )}%`)}
                      </span>
                    )}
                  </td>{" "}
                </>
              )}
            </tr>
            <tr>
              {" "}
              <th>
                Active/Engaged Customers{" "}
                {gettooltip(
                  "ActiveEngagedCustomers",
                  "ActiveEngagedCustomers",
                  "ActiveEngagedCustomers",
                  "Active: Number of customers who made second purchase in 12 months or 1 transaction not new",
                  "Engaged: Number of customers who made 3+ purchases in past 12 months"
                )}
              </th>{" "}
              {loading.engage_customers ? (
                <>
                  <LoaderForRow tdCount={10} />
                </>
              ) : (
                <>
                  <td>
                    {scoreCardEngageCustomers !== undefined &&
                      scoreCardEngageCustomers.length !== 0 &&
                      (scoreCardEngageCustomers[0].GOAL_FORCAST_LM === "-999999"
                        ? "-"
                        : currencyFormat(
                            Number(scoreCardEngageCustomers[0].GOAL_FORCAST_LM)
                          ))}
                  </td>{" "}
                  <td>
                    {scoreCardEngageCustomers !== undefined &&
                      scoreCardEngageCustomers.length !== 0 &&
                      (scoreCardEngageCustomers[0].CUST_CNT_LM_TY === "-999999"
                        ? "-"
                        : currencyFormat(
                            Number(scoreCardEngageCustomers[0].CUST_CNT_LM_TY)
                          ))}
                  </td>{" "}
                  <td>
                    {scoreCardEngageCustomers !== undefined &&
                      scoreCardEngageCustomers.length !== 0 &&
                      (scoreCardEngageCustomers[0].CUST_CNT_LM_LY === "-999999"
                        ? "-"
                        : currencyFormat(
                            Number(scoreCardEngageCustomers[0].CUST_CNT_LM_LY)
                          ))}
                  </td>{" "}
                  <td>
                    {scoreCardEngageCustomers !== undefined &&
                    scoreCardEngageCustomers.length !== 0 &&
                    Number(scoreCardEngageCustomers[0].CUST_CNT_LM_TY_VS_LY)
                      .toFixed(2)
                      .includes("-") ? (
                      <span style={{ color: "red" }}>
                        {scoreCardEngageCustomers !== undefined &&
                          scoreCardEngageCustomers.length !== 0 &&
                          (scoreCardEngageCustomers[0].CUST_CNT_LM_TY_VS_LY ===
                          "-999999"
                            ? "-"
                            : `${decimalCurrencyFormat(
                                Number(
                                  scoreCardEngageCustomers[0]
                                    .CUST_CNT_LM_TY_VS_LY
                                )
                              )}%`)}
                      </span>
                    ) : (
                      <span style={{ color: "green" }}>
                        {scoreCardEngageCustomers !== undefined &&
                          scoreCardEngageCustomers.length !== 0 &&
                          (scoreCardEngageCustomers[0].CUST_CNT_LM_TY_VS_LY ===
                          "-999999"
                            ? "-"
                            : `${decimalCurrencyFormat(
                                Number(
                                  scoreCardEngageCustomers[0]
                                    .CUST_CNT_LM_TY_VS_LY
                                )
                              )}%`)}
                      </span>
                    )}
                  </td>{" "}
                  <td>
                    {scoreCardEngageCustomers !== undefined &&
                    scoreCardEngageCustomers.length !== 0 &&
                    Number(scoreCardEngageCustomers[0].VARIANCE_FORCAST_LM)
                      .toFixed(2)
                      .includes("-") ? (
                      <span style={{ color: "red" }}>
                        {scoreCardEngageCustomers !== undefined &&
                          scoreCardEngageCustomers.length !== 0 &&
                          (scoreCardEngageCustomers[0].VARIANCE_FORCAST_LM ===
                          "-999999"
                            ? "-"
                            : `${decimalCurrencyFormat(
                                Number(
                                  scoreCardEngageCustomers[0]
                                    .VARIANCE_FORCAST_LM
                                )
                              )}%`)}
                      </span>
                    ) : (
                      <span style={{ color: "green" }}>
                        {scoreCardEngageCustomers !== undefined &&
                          scoreCardEngageCustomers.length !== 0 &&
                          (scoreCardEngageCustomers[0].VARIANCE_FORCAST_LM ===
                          "-999999"
                            ? "-"
                            : `${decimalCurrencyFormat(
                                Number(
                                  scoreCardEngageCustomers[0]
                                    .VARIANCE_FORCAST_LM
                                )
                              )}%`)}
                      </span>
                    )}
                  </td>{" "}
                  <td>
                    {scoreCardEngageCustomers !== undefined &&
                      scoreCardEngageCustomers.length !== 0 &&
                      (scoreCardEngageCustomers[0].GOAL_FORCAST_YTD ===
                      "-999999"
                        ? "-"
                        : currencyFormat(
                            Number(scoreCardEngageCustomers[0].GOAL_FORCAST_YTD)
                          ))}
                  </td>{" "}
                  <td>
                    {scoreCardEngageCustomers !== undefined &&
                      scoreCardEngageCustomers.length !== 0 &&
                      (scoreCardEngageCustomers[0].CUST_CNT_YTD_TY === "-999999"
                        ? "-"
                        : currencyFormat(
                            Number(scoreCardEngageCustomers[0].CUST_CNT_YTD_TY)
                          ))}
                  </td>{" "}
                  <td>
                    {scoreCardEngageCustomers !== undefined &&
                      scoreCardEngageCustomers.length !== 0 &&
                      (scoreCardEngageCustomers[0].CUST_CNT_YTD_LY === "-999999"
                        ? "-"
                        : currencyFormat(
                            Number(scoreCardEngageCustomers[0].CUST_CNT_YTD_LY)
                          ))}
                  </td>{" "}
                  <td>
                    {scoreCardEngageCustomers !== undefined &&
                    scoreCardEngageCustomers.length !== 0 &&
                    Number(scoreCardEngageCustomers[0].CUST_CNT_YTD_TY_VS_LY)
                      .toFixed(2)
                      .includes("-") ? (
                      <span style={{ color: "red" }}>
                        {scoreCardEngageCustomers !== undefined &&
                          scoreCardEngageCustomers.length !== 0 &&
                          (scoreCardEngageCustomers[0].CUST_CNT_YTD_TY_VS_LY ===
                          "-999999"
                            ? "-"
                            : `${decimalCurrencyFormat(
                                Number(
                                  scoreCardEngageCustomers[0]
                                    .CUST_CNT_YTD_TY_VS_LY
                                )
                              )}%`)}
                      </span>
                    ) : (
                      <span style={{ color: "green" }}>
                        {scoreCardEngageCustomers !== undefined &&
                          scoreCardEngageCustomers.length !== 0 &&
                          (scoreCardEngageCustomers[0].CUST_CNT_YTD_TY_VS_LY ===
                          "-999999"
                            ? "-"
                            : `${decimalCurrencyFormat(
                                Number(
                                  scoreCardEngageCustomers[0]
                                    .CUST_CNT_YTD_TY_VS_LY
                                )
                              )}%`)}
                      </span>
                    )}
                  </td>{" "}
                  <td>
                    {scoreCardEngageCustomers !== undefined &&
                    scoreCardEngageCustomers.length !== 0 &&
                    Number(scoreCardEngageCustomers[0].VARIANCE_FORCAST_YTD)
                      .toFixed(2)
                      .includes("-") ? (
                      <span style={{ color: "red" }}>
                        {scoreCardEngageCustomers !== undefined &&
                          scoreCardEngageCustomers.length !== 0 &&
                          (scoreCardEngageCustomers[0].VARIANCE_FORCAST_YTD ===
                          "-999999"
                            ? "-"
                            : `${decimalCurrencyFormat(
                                Number(
                                  scoreCardEngageCustomers[0]
                                    .VARIANCE_FORCAST_YTD
                                )
                              )}%`)}
                      </span>
                    ) : (
                      <span style={{ color: "green" }}>
                        {scoreCardEngageCustomers !== undefined &&
                          scoreCardEngageCustomers.length !== 0 &&
                          (scoreCardEngageCustomers[0].VARIANCE_FORCAST_YTD ===
                          "-999999"
                            ? "-"
                            : `${decimalCurrencyFormat(
                                Number(
                                  scoreCardEngageCustomers[0]
                                    .VARIANCE_FORCAST_YTD
                                )
                              )}%`)}
                      </span>
                    )}
                  </td>{" "}
                </>
              )}
            </tr>
            <tr className="align-middle">
              {" "}
              <th rowSpan="3">{"Channel"}</th>
              <th>
                Omni Customers (% of active <br />
                customers){" "}
                {gettooltip(
                  "OmniCustomersInfoIcon",
                  "OmniCustomers",
                  "OmniCustomers",
                  "% of customers who shopped through both online and",
                  "store channels out of total active customers"
                )}
              </th>{" "}
              {loading.omni ? (
                <>
                  <LoaderForRow tdCount={10} />
                </>
              ) : (
                <>
                  <td>
                    {scoreCardOmni !== undefined &&
                      scoreCardOmni.length !== 0 &&
                      (scoreCardOmni[0].GOAL_FORCAST_LM === "-999999"
                        ? "-"
                        : `${decimalCurrencyFormat(
                            Number(scoreCardOmni[0].GOAL_FORCAST_LM)
                          )}%`)}
                  </td>{" "}
                  <td>
                    {scoreCardOmni !== undefined &&
                      scoreCardOmni.length !== 0 &&
                      (scoreCardOmni[0].CUST_CNT_LM_TY === "-999999"
                        ? "-"
                        : `${decimalCurrencyFormat(
                            Number(scoreCardOmni[0].CUST_CNT_LM_TY)
                          )}%`)}
                  </td>{" "}
                  <td>
                    {scoreCardOmni !== undefined &&
                      scoreCardOmni.length !== 0 &&
                      (scoreCardOmni[0].CUST_CNT_LM_LY === "-999999"
                        ? "-"
                        : `${decimalCurrencyFormat(
                            Number(scoreCardOmni[0].CUST_CNT_LM_LY)
                          )}%`)}
                  </td>{" "}
                  <td>
                    {scoreCardOmni !== undefined &&
                    scoreCardOmni.length !== 0 &&
                    Number(scoreCardOmni[0].CUST_CNT_LM_TY_VS_LY)
                      .toFixed(2)
                      .includes("-") ? (
                      <span style={{ color: "red" }}>
                        {scoreCardOmni !== undefined &&
                          scoreCardOmni.length !== 0 &&
                          (scoreCardOmni[0].CUST_CNT_LM_TY_VS_LY === "-999999"
                            ? "-"
                            : decimalCurrencyFormat(
                                Number(scoreCardOmni[0].CUST_CNT_LM_TY_VS_LY)
                              ))}
                      </span>
                    ) : (
                      <span style={{ color: "green" }}>
                        {scoreCardOmni !== undefined &&
                          scoreCardOmni.length !== 0 &&
                          (scoreCardOmni[0].CUST_CNT_LM_TY_VS_LY === "-999999"
                            ? "-"
                            : decimalCurrencyFormat(
                                Number(scoreCardOmni[0].CUST_CNT_LM_TY_VS_LY)
                              ))}
                      </span>
                    )}
                  </td>{" "}
                  <td>
                    {scoreCardOmni !== undefined &&
                    scoreCardOmni.length !== 0 &&
                    Number(scoreCardOmni[0].VARIANCE_FORCAST_LM)
                      .toFixed(2)
                      .includes("-") ? (
                      <span style={{ color: "red" }}>
                        {scoreCardOmni !== undefined &&
                          scoreCardOmni.length !== 0 &&
                          (scoreCardOmni[0].VARIANCE_FORCAST_LM === "-999999"
                            ? "-"
                            : decimalCurrencyFormat(
                                Number(scoreCardOmni[0].VARIANCE_FORCAST_LM)
                              ))}
                      </span>
                    ) : (
                      <span style={{ color: "green" }}>
                        {scoreCardOmni !== undefined &&
                          scoreCardOmni.length !== 0 &&
                          (scoreCardOmni[0].VARIANCE_FORCAST_LM === "-999999"
                            ? "-"
                            : decimalCurrencyFormat(
                                Number(scoreCardOmni[0].VARIANCE_FORCAST_LM)
                              ))}
                      </span>
                    )}
                  </td>{" "}
                  <td>
                    {scoreCardOmni !== undefined &&
                      scoreCardOmni.length !== 0 &&
                      (scoreCardOmni[0].GOAL_FORCAST_YTD === "-999999"
                        ? "-"
                        : `${decimalCurrencyFormat(
                            Number(scoreCardOmni[0].GOAL_FORCAST_YTD)
                          )}%`)}
                  </td>{" "}
                  <td>
                    {scoreCardOmni !== undefined &&
                      scoreCardOmni.length !== 0 &&
                      (scoreCardOmni[0].CUST_CNT_YTD_TY === "-999999"
                        ? "-"
                        : `${decimalCurrencyFormat(
                            Number(scoreCardOmni[0].CUST_CNT_YTD_TY)
                          )}%`)}
                  </td>{" "}
                  <td>
                    {scoreCardOmni !== undefined &&
                      scoreCardOmni.length !== 0 &&
                      (scoreCardOmni[0].CUST_CNT_YTD_LY === "-999999"
                        ? "-"
                        : `${decimalCurrencyFormat(
                            Number(scoreCardOmni[0].CUST_CNT_YTD_LY)
                          )}%`)}
                  </td>{" "}
                  <td>
                    {scoreCardOmni !== undefined &&
                    scoreCardOmni.length !== 0 &&
                    Number(scoreCardOmni[0].CUST_CNT_YTD_TY_VS_LY)
                      .toFixed(2)
                      .includes("-") ? (
                      <span style={{ color: "red" }}>
                        {scoreCardOmni !== undefined &&
                          scoreCardOmni.length !== 0 &&
                          (scoreCardOmni[0].CUST_CNT_YTD_TY_VS_LY === "-999999"
                            ? "-"
                            : decimalCurrencyFormat(
                                Number(scoreCardOmni[0].CUST_CNT_YTD_TY_VS_LY)
                              ))}
                      </span>
                    ) : (
                      <span style={{ color: "green" }}>
                        {scoreCardOmni !== undefined &&
                          scoreCardOmni.length !== 0 &&
                          (scoreCardOmni[0].CUST_CNT_YTD_TY_VS_LY === "-999999"
                            ? "-"
                            : decimalCurrencyFormat(
                                Number(scoreCardOmni[0].CUST_CNT_YTD_TY_VS_LY)
                              ))}
                      </span>
                    )}
                  </td>{" "}
                  <td>
                    {scoreCardOmni !== undefined &&
                    scoreCardOmni.length !== 0 &&
                    Number(scoreCardOmni[0].VARIANCE_FORCAST_YTD)
                      .toFixed(2)
                      .includes("-") ? (
                      <span style={{ color: "red" }}>
                        {scoreCardOmni !== undefined &&
                          scoreCardOmni.length !== 0 &&
                          (scoreCardOmni[0].VARIANCE_FORCAST_YTD === "-999999"
                            ? "-"
                            : decimalCurrencyFormat(
                                Number(scoreCardOmni[0].VARIANCE_FORCAST_YTD)
                              ))}
                      </span>
                    ) : (
                      <span style={{ color: "green" }}>
                        {scoreCardOmni !== undefined &&
                          scoreCardOmni.length !== 0 &&
                          (scoreCardOmni[0].VARIANCE_FORCAST_YTD === "-999999"
                            ? "-"
                            : decimalCurrencyFormat(
                                Number(scoreCardOmni[0].VARIANCE_FORCAST_YTD)
                              ))}
                      </span>
                    )}
                  </td>{" "}
                </>
              )}
            </tr>
            <tr>
              {" "}
              <th>
                App Logins{" "}
                {gettooltip(
                  "AppLoginsInfoIcon",
                  "AppLogins",
                  "AppLogins",
                  "Number of customers who have logged in to the mobile app in the period"
                )}
              </th>{" "}
              {loading.app_Logins ? (
                <>
                  <LoaderForRow tdCount={10} />
                </>
              ) : (
                <>
                  <td>
                    {scoreCardAppLogin !== undefined &&
                      scoreCardAppLogin.length !== 0 &&
                      (scoreCardAppLogin[0].GOAL_FORCAST_LM === "-999999"
                        ? "-"
                        : currencyFormat(
                            Number(scoreCardAppLogin[0].GOAL_FORCAST_LM)
                          ))}
                  </td>{" "}
                  <td>
                    {scoreCardAppLogin !== undefined &&
                      scoreCardAppLogin.length !== 0 &&
                      (scoreCardAppLogin[0].CUST_CNT_LM_TY === "-999999"
                        ? "-"
                        : currencyFormat(
                            Number(scoreCardAppLogin[0].CUST_CNT_LM_TY)
                          ))}
                  </td>{" "}
                  <td>
                    {scoreCardAppLogin !== undefined &&
                      scoreCardAppLogin.length !== 0 &&
                      (scoreCardAppLogin[0].CUST_CNT_LM_LY === "-999999"
                        ? "-"
                        : currencyFormat(
                            Number(scoreCardAppLogin[0].CUST_CNT_LM_LY)
                          ))}
                  </td>{" "}
                  <td>
                    {scoreCardAppLogin !== undefined &&
                    scoreCardAppLogin.length !== 0 &&
                    Number(scoreCardAppLogin[0].CUST_CNT_LM_TY_VS_LY)
                      .toFixed(2)
                      .includes("-") ? (
                      <span style={{ color: "red" }}>
                        {scoreCardAppLogin !== undefined &&
                          scoreCardAppLogin.length !== 0 &&
                          (scoreCardAppLogin[0].CUST_CNT_LM_TY_VS_LY ===
                          "-999999"
                            ? "-"
                            : `${decimalCurrencyFormat(
                                Number(
                                  scoreCardAppLogin[0].CUST_CNT_LM_TY_VS_LY
                                )
                              )}%`)}
                      </span>
                    ) : (
                      <span style={{ color: "green" }}>
                        {scoreCardAppLogin !== undefined &&
                          scoreCardAppLogin.length !== 0 &&
                          (scoreCardAppLogin[0].CUST_CNT_LM_TY_VS_LY ===
                          "-999999"
                            ? "-"
                            : `${decimalCurrencyFormat(
                                Number(
                                  scoreCardAppLogin[0].CUST_CNT_LM_TY_VS_LY
                                )
                              )}%`)}
                      </span>
                    )}
                  </td>{" "}
                  <td>
                    {scoreCardAppLogin !== undefined &&
                    scoreCardAppLogin.length !== 0 &&
                    Number(scoreCardAppLogin[0].VARIANCE_FORCAST_LM)
                      .toFixed(2)
                      .includes("-") ? (
                      <span style={{ color: "red" }}>
                        {scoreCardAppLogin !== undefined &&
                          scoreCardAppLogin.length !== 0 &&
                          (scoreCardAppLogin[0].VARIANCE_FORCAST_LM ===
                          "-999999"
                            ? "-"
                            : `${decimalCurrencyFormat(
                                Number(
                                  scoreCardAppLogin[0].VARIANCE_FORCAST_LM
                                )
                              )}%`)}
                      </span>
                    ) : (
                      <span style={{ color: "green" }}>
                        {scoreCardAppLogin !== undefined &&
                          scoreCardAppLogin.length !== 0 &&
                          (scoreCardAppLogin[0].VARIANCE_FORCAST_LM ===
                          "-999999"
                            ? "-"
                            : `${decimalCurrencyFormat(
                                Number(
                                  scoreCardAppLogin[0].VARIANCE_FORCAST_LM
                                )
                              )}%`)}
                      </span>
                    )}
                  </td>{" "}
                  <td>
                    {scoreCardAppLogin !== undefined &&
                      scoreCardAppLogin.length !== 0 &&
                      (scoreCardAppLogin[0].GOAL_FORCAST_YTD === "-999999"
                        ? "-"
                        : currencyFormat(
                            Number(scoreCardAppLogin[0].GOAL_FORCAST_YTD)
                          ))}
                  </td>{" "}
                  <td>
                    {scoreCardAppLogin !== undefined &&
                      scoreCardAppLogin.length !== 0 &&
                      (scoreCardAppLogin[0].CUST_CNT_YTD_TY === "-999999"
                        ? "-"
                        : currencyFormat(
                            Number(scoreCardAppLogin[0].CUST_CNT_YTD_TY)
                          ))}
                  </td>{" "}
                  <td>
                    {scoreCardAppLogin !== undefined &&
                      scoreCardAppLogin.length !== 0 &&
                      (scoreCardAppLogin[0].CUST_CNT_YTD_LY === "-999999"
                        ? "-"
                        : currencyFormat(
                            Number(scoreCardAppLogin[0].CUST_CNT_YTD_LY)
                          ))}
                  </td>{" "}
                  <td>
                    {scoreCardAppLogin !== undefined &&
                    scoreCardAppLogin.length !== 0 &&
                    Number(scoreCardAppLogin[0].CUST_CNT_YTD_TY_VS_LY)
                      .toFixed(2)
                      .includes("-") ? (
                      <span style={{ color: "red" }}>
                        {scoreCardAppLogin !== undefined &&
                          scoreCardAppLogin.length !== 0 &&
                          (scoreCardAppLogin[0].CUST_CNT_YTD_TY_VS_LY ===
                          "-999999"
                            ? "-"
                            : `${decimalCurrencyFormat(
                                Number(
                                  scoreCardAppLogin[0].CUST_CNT_YTD_TY_VS_LY
                                )
                              )}%`)}
                      </span>
                    ) : (
                      <span style={{ color: "green" }}>
                        {scoreCardAppLogin !== undefined &&
                          scoreCardAppLogin.length !== 0 &&
                          (scoreCardAppLogin[0].CUST_CNT_YTD_TY_VS_LY ===
                          "-999999"
                            ? "-"
                            : `${decimalCurrencyFormat(
                                Number(
                                  scoreCardAppLogin[0].CUST_CNT_YTD_TY_VS_LY
                                )
                              )}%`)}
                      </span>
                    )}
                  </td>{" "}
                  <td>
                    {scoreCardAppLogin !== undefined &&
                    scoreCardAppLogin.length !== 0 &&
                    Number(scoreCardAppLogin[0].VARIANCE_FORCAST_YTD)
                      .toFixed(2)
                      .includes("-") ? (
                      <span style={{ color: "red" }}>
                        {scoreCardAppLogin !== undefined &&
                          scoreCardAppLogin.length !== 0 &&
                          (scoreCardAppLogin[0].VARIANCE_FORCAST_YTD ===
                          "-999999"
                            ? "-"
                            : `${decimalCurrencyFormat(
                                Number(
                                  scoreCardAppLogin[0].VARIANCE_FORCAST_YTD
                                )
                              )}%`)}
                      </span>
                    ) : (
                      <span style={{ color: "green" }}>
                        {scoreCardAppLogin !== undefined &&
                          scoreCardAppLogin.length !== 0 &&
                          (scoreCardAppLogin[0].VARIANCE_FORCAST_YTD ===
                          "-999999"
                            ? "-"
                            : `${decimalCurrencyFormat(
                                Number(
                                  scoreCardAppLogin[0].VARIANCE_FORCAST_YTD
                                )
                              )}%`)}
                      </span>
                    )}
                  </td>{" "}
                </>
              )}
            </tr>
            <tr>
              {" "}
              <th>
                App Shoppers{" "}
                {gettooltip(
                  "AppShoppersInfoIcon",
                  "AppShoppers",
                  "AppShoppers",
                  "Number of customers who have shopped using the mobile app in the period"
                )}
              </th>{" "}
              {loading.app_Shoppers ? (
                <>
                  <LoaderForRow tdCount={10} />
                </>
              ) : (
                <>
                  <td>
                    {scoreCardAppShoppers !== undefined &&
                      scoreCardAppShoppers.length !== 0 &&
                      (scoreCardAppShoppers[0].GOAL_FORCAST_LM === "-999999"
                        ? "-"
                        : currencyFormat(
                            Number(scoreCardAppShoppers[0].GOAL_FORCAST_LM)
                          ))}
                  </td>{" "}
                  <td>
                    {scoreCardAppShoppers !== undefined &&
                      scoreCardAppShoppers.length !== 0 &&
                      (scoreCardAppShoppers[0].CUST_CNT_LM_TY === "-999999"
                        ? "-"
                        : currencyFormat(
                            Number(scoreCardAppShoppers[0].CUST_CNT_LM_TY)
                          ))}
                  </td>{" "}
                  <td>
                    {scoreCardAppShoppers !== undefined &&
                      scoreCardAppShoppers.length !== 0 &&
                      (scoreCardAppShoppers[0].CUST_CNT_LM_LY === "-999999"
                        ? "-"
                        : currencyFormat(
                            Number(scoreCardAppShoppers[0].CUST_CNT_LM_LY)
                          ))}
                  </td>{" "}
                  <td>
                    {scoreCardAppShoppers !== undefined &&
                    scoreCardAppShoppers.length !== 0 &&
                    Number(scoreCardAppShoppers[0].CUST_CNT_LM_TY_VS_LY)
                      .toFixed(2)
                      .includes("-") ? (
                      <span style={{ color: "red" }}>
                        {scoreCardAppShoppers !== undefined &&
                          scoreCardAppShoppers.length !== 0 &&
                          (scoreCardAppShoppers[0].CUST_CNT_LM_TY_VS_LY ===
                          "-999999"
                            ? "-"
                            : `${decimalCurrencyFormat(
                                Number(
                                  scoreCardAppShoppers[0].CUST_CNT_LM_TY_VS_LY
                                )
                              )}%`)}
                      </span>
                    ) : (
                      <span style={{ color: "green" }}>
                        {scoreCardAppShoppers !== undefined &&
                          scoreCardAppShoppers.length !== 0 &&
                          (scoreCardAppShoppers[0].CUST_CNT_LM_TY_VS_LY ===
                          "-999999"
                            ? "-"
                            : `${decimalCurrencyFormat(
                                Number(
                                  scoreCardAppShoppers[0].CUST_CNT_LM_TY_VS_LY
                                )
                              )}%`)}
                      </span>
                    )}
                  </td>{" "}
                  <td>
                    {scoreCardAppShoppers !== undefined &&
                    scoreCardAppShoppers.length !== 0 &&
                    Number(scoreCardAppShoppers[0].VARIANCE_FORCAST_LM)
                      .toFixed(2)
                      .includes("-") ? (
                      <span style={{ color: "red" }}>
                        {scoreCardAppShoppers !== undefined &&
                          scoreCardAppShoppers.length !== 0 &&
                          (scoreCardAppShoppers[0].VARIANCE_FORCAST_LM ===
                          "-999999"
                            ? "-"
                            : `${decimalCurrencyFormat(
                                Number(
                                  scoreCardAppShoppers[0].VARIANCE_FORCAST_LM
                                )
                              )}%`)}
                      </span>
                    ) : (
                      <span style={{ color: "green" }}>
                        {scoreCardAppShoppers !== undefined &&
                          scoreCardAppShoppers.length !== 0 &&
                          (scoreCardAppShoppers[0].VARIANCE_FORCAST_LM ===
                          "-999999"
                            ? "-"
                            : `${decimalCurrencyFormat(
                                Number(
                                  scoreCardAppShoppers[0].VARIANCE_FORCAST_LM
                                )
                              )}%`)}
                      </span>
                    )}
                  </td>{" "}
                  <td>
                    {scoreCardAppShoppers !== undefined &&
                      scoreCardAppShoppers.length !== 0 &&
                      (scoreCardAppShoppers[0].GOAL_FORCAST_YTD === "-999999"
                        ? "-"
                        : currencyFormat(
                            Number(scoreCardAppShoppers[0].GOAL_FORCAST_YTD)
                          ))}
                  </td>{" "}
                  <td>
                    {scoreCardAppShoppers !== undefined &&
                      scoreCardAppShoppers.length !== 0 &&
                      (scoreCardAppShoppers[0].CUST_CNT_YTD_TY === "-999999"
                        ? "-"
                        : currencyFormat(
                            Number(scoreCardAppShoppers[0].CUST_CNT_YTD_TY)
                          ))}
                  </td>{" "}
                  <td>
                    {scoreCardAppShoppers !== undefined &&
                      scoreCardAppShoppers.length !== 0 &&
                      (scoreCardAppShoppers[0].CUST_CNT_YTD_LY === "-999999"
                        ? "-"
                        : currencyFormat(
                            Number(scoreCardAppShoppers[0].CUST_CNT_YTD_LY)
                          ))}
                  </td>{" "}
                  <td>
                    {scoreCardAppShoppers !== undefined &&
                    scoreCardAppShoppers.length !== 0 &&
                    Number(scoreCardAppShoppers[0].CUST_CNT_YTD_TY_VS_LY)
                      .toFixed(2)
                      .includes("-") ? (
                      <span style={{ color: "red" }}>
                        {scoreCardAppShoppers !== undefined &&
                          scoreCardAppShoppers.length !== 0 &&
                          (scoreCardAppShoppers[0].CUST_CNT_YTD_TY_VS_LY ===
                          "-999999"
                            ? "-"
                            : `${decimalCurrencyFormat(
                                Number(
                                  scoreCardAppShoppers[0].CUST_CNT_YTD_TY_VS_LY
                                )
                              )}%`)}
                      </span>
                    ) : (
                      <span style={{ color: "green" }}>
                        {scoreCardAppShoppers !== undefined &&
                          scoreCardAppShoppers.length !== 0 &&
                          (scoreCardAppShoppers[0].CUST_CNT_YTD_TY_VS_LY ===
                          "-999999"
                            ? "-"
                            : `${decimalCurrencyFormat(
                                Number(
                                  scoreCardAppShoppers[0].CUST_CNT_YTD_TY_VS_LY
                                )
                              )}%`)}
                      </span>
                    )}
                  </td>{" "}
                  <td>
                    {scoreCardAppShoppers !== undefined &&
                    scoreCardAppShoppers.length !== 0 &&
                    Number(scoreCardAppShoppers[0].VARIANCE_FORCAST_YTD)
                      .toFixed(2)
                      .includes("-") ? (
                      <span style={{ color: "red" }}>
                        {scoreCardAppShoppers !== undefined &&
                          scoreCardAppShoppers.length !== 0 &&
                          (scoreCardAppShoppers[0].VARIANCE_FORCAST_YTD ===
                          "-999999"
                            ? "-"
                            : `${decimalCurrencyFormat(
                                Number(
                                  scoreCardAppShoppers[0].VARIANCE_FORCAST_YTD
                                )
                              )}%`)}
                      </span>
                    ) : (
                      <span style={{ color: "green" }}>
                        {scoreCardAppShoppers !== undefined &&
                          scoreCardAppShoppers.length !== 0 &&
                          (scoreCardAppShoppers[0].VARIANCE_FORCAST_YTD ===
                          "-999999"
                            ? "-"
                            : `${decimalCurrencyFormat(
                                Number(
                                  scoreCardAppShoppers[0].VARIANCE_FORCAST_YTD
                                )
                              )}%`)}
                      </span>
                    )}
                  </td>{" "}
                </>
              )}
            </tr>
            <tr className="align-middle">
              {" "}
              <th rowSpan="3">{"Loyalty"}</th>
              <th>
                Beyond+ Active Base{" "}
                {gettooltip(
                  "ActiveBaseInfoIcon",
                  "ActiveBase",
                  "ActiveBase",
                  "Number of Beyond+ paid tier customers who are active in the period"
                )}
              </th>
              {loading.bplus ? (
                <>
                  <LoaderForRow tdCount={10} />
                </>
              ) : (
                <>
                  <td>
                    {scoreCardBPlus !== undefined &&
                      scoreCardBPlus.length !== 0 &&
                      (scoreCardBPlus[0].GOAL_FORCAST_LM === "-999999"
                        ? "-"
                        : currencyFormat(
                            Number(scoreCardBPlus[0].GOAL_FORCAST_LM)
                          ))}
                  </td>{" "}
                  <td>
                    {scoreCardBPlus !== undefined &&
                      scoreCardBPlus.length !== 0 &&
                      (scoreCardBPlus[0].CUST_CNT_LM_TY === "-999999"
                        ? "-"
                        : currencyFormat(
                            Number(scoreCardBPlus[0].CUST_CNT_LM_TY)
                          ))}
                  </td>{" "}
                  <td>
                    {scoreCardBPlus !== undefined &&
                      scoreCardBPlus.length !== 0 &&
                      (scoreCardBPlus[0].CUST_CNT_LM_LY === "-999999"
                        ? "-"
                        : currencyFormat(
                            Number(scoreCardBPlus[0].CUST_CNT_LM_LY)
                          ))}
                  </td>{" "}
                  <td>
                    {scoreCardBPlus !== undefined &&
                    scoreCardBPlus.length !== 0 &&
                    Number(scoreCardBPlus[0].CUST_CNT_LM_TY_VS_LY)
                      .toFixed(2)
                      .includes("-") ? (
                      <span style={{ color: "red" }}>
                        {scoreCardBPlus !== undefined &&
                          scoreCardBPlus.length !== 0 &&
                          (scoreCardBPlus[0].CUST_CNT_LM_TY_VS_LY === "-999999"
                            ? "-"
                            : `${decimalCurrencyFormat(
                                Number(scoreCardBPlus[0].CUST_CNT_LM_TY_VS_LY)
                              )}%`)}
                      </span>
                    ) : (
                      <span style={{ color: "green" }}>
                        {scoreCardBPlus !== undefined &&
                          scoreCardBPlus.length !== 0 &&
                          (scoreCardBPlus[0].CUST_CNT_LM_TY_VS_LY === "-999999"
                            ? "-"
                            : `${decimalCurrencyFormat(
                                Number(scoreCardBPlus[0].CUST_CNT_LM_TY_VS_LY)
                              )}%`)}
                      </span>
                    )}
                  </td>{" "}
                  <td>
                    {scoreCardBPlus !== undefined &&
                    scoreCardBPlus.length !== 0 &&
                    Number(scoreCardBPlus[0].VARIANCE_FORCAST_LM)
                      .toFixed(2)
                      .includes("-") ? (
                      <span style={{ color: "red" }}>
                        {scoreCardBPlus !== undefined &&
                          scoreCardBPlus.length !== 0 &&
                          (scoreCardBPlus[0].VARIANCE_FORCAST_LM === "-999999"
                            ? "-"
                            : `${decimalCurrencyFormat(
                                Number(scoreCardBPlus[0].VARIANCE_FORCAST_LM)
                              )}%`)}
                      </span>
                    ) : (
                      <span style={{ color: "green" }}>
                        {scoreCardBPlus !== undefined &&
                          scoreCardBPlus.length !== 0 &&
                          (scoreCardBPlus[0].VARIANCE_FORCAST_LM === "-999999"
                            ? "-"
                            : `${decimalCurrencyFormat(
                                Number(scoreCardBPlus[0].VARIANCE_FORCAST_LM)
                              )}%`)}
                      </span>
                    )}
                  </td>{" "}
                  <td>
                    {scoreCardBPlus !== undefined &&
                      scoreCardBPlus.length !== 0 &&
                      (scoreCardBPlus[0].GOAL_FORCAST_YTD === "-999999"
                        ? "-"
                        : currencyFormat(
                            Number(scoreCardBPlus[0].GOAL_FORCAST_YTD)
                          ))}
                  </td>{" "}
                  <td>
                    {scoreCardBPlus !== undefined &&
                      scoreCardBPlus.length !== 0 &&
                      (scoreCardBPlus[0].CUST_CNT_YTD_TY === "-999999"
                        ? "-"
                        : currencyFormat(
                            Number(scoreCardBPlus[0].CUST_CNT_YTD_TY)
                          ))}
                  </td>{" "}
                  <td>
                    {scoreCardBPlus !== undefined &&
                      scoreCardBPlus.length !== 0 &&
                      (scoreCardBPlus[0].CUST_CNT_YTD_LY === "-999999"
                        ? "-"
                        : currencyFormat(
                            Number(scoreCardBPlus[0].CUST_CNT_YTD_LY)
                          ))}
                  </td>{" "}
                  <td>
                    {scoreCardBPlus !== undefined &&
                    scoreCardBPlus.length !== 0 &&
                    Number(scoreCardBPlus[0].CUST_CNT_YTD_TY_VS_LY)
                      .toFixed(2)
                      .includes("-") ? (
                      <span style={{ color: "red" }}>
                        {scoreCardBPlus !== undefined &&
                          scoreCardBPlus.length !== 0 &&
                          (scoreCardBPlus[0].CUST_CNT_YTD_TY_VS_LY === "-999999"
                            ? "-"
                            : `${decimalCurrencyFormat(
                                Number(scoreCardBPlus[0].CUST_CNT_YTD_TY_VS_LY)
                              )}%`)}
                      </span>
                    ) : (
                      <span style={{ color: "green" }}>
                        {scoreCardBPlus !== undefined &&
                          scoreCardBPlus.length !== 0 &&
                          (scoreCardBPlus[0].CUST_CNT_YTD_TY_VS_LY === "-999999"
                            ? "-"
                            : `${decimalCurrencyFormat(
                                Number(scoreCardBPlus[0].CUST_CNT_YTD_TY_VS_LY)
                              )}%`)}
                      </span>
                    )}
                  </td>{" "}
                  <td>
                    {scoreCardBPlus !== undefined &&
                    scoreCardBPlus.length !== 0 &&
                    Number(scoreCardBPlus[0].VARIANCE_FORCAST_YTD)
                      .toFixed(2)
                      .includes("-") ? (
                      <span style={{ color: "red" }}>
                        {scoreCardBPlus !== undefined &&
                          scoreCardBPlus.length !== 0 &&
                          (scoreCardBPlus[0].VARIANCE_FORCAST_YTD === "-999999"
                            ? "-"
                            : `${decimalCurrencyFormat(
                                Number(scoreCardBPlus[0].VARIANCE_FORCAST_YTD)
                              )}%`)}
                      </span>
                    ) : (
                      <span style={{ color: "green" }}>
                        {scoreCardBPlus !== undefined &&
                          scoreCardBPlus.length !== 0 &&
                          (scoreCardBPlus[0].VARIANCE_FORCAST_YTD === "-999999"
                            ? "-"
                            : `${decimalCurrencyFormat(
                                Number(scoreCardBPlus[0].VARIANCE_FORCAST_YTD)
                              )}%`)}
                      </span>
                    )}
                  </td>{" "}
                </>
              )}
            </tr>
            <tr>
              {" "}
              <th>
                Earners (Post May Launch){" "}
                {gettooltip(
                  "EarnersInfoIcon",
                  "Earners",
                  "Earners",
                  "Number of customers who earned reward points in the period"
                )}
              </th>
              {loading.earners ? (
                <>
                  <LoaderForRow tdCount={10} />
                </>
              ) : (
                <>
                  <td>
                    {scoreCardMarketingEarners !== undefined &&
                      scoreCardMarketingEarners.length !== 0 &&
                      (scoreCardMarketingEarners[0].GOAL_FORCAST_LM ===
                      "-999999"
                        ? "-"
                        : currencyFormat(
                            Number(scoreCardMarketingEarners[0].GOAL_FORCAST_LM)
                          ))}
                  </td>{" "}
                  <td>
                    {scoreCardMarketingEarners !== undefined &&
                      scoreCardMarketingEarners.length !== 0 &&
                      (scoreCardMarketingEarners[0].CUST_CNT_LM_TY === "-999999"
                        ? "-"
                        : currencyFormat(
                            Number(scoreCardMarketingEarners[0].CUST_CNT_LM_TY)
                          ))}
                  </td>{" "}
                  <td>
                    {scoreCardMarketingEarners !== undefined &&
                      scoreCardMarketingEarners.length !== 0 &&
                      (scoreCardMarketingEarners[0].CUST_CNT_LM_LY === "-999999"
                        ? "-"
                        : currencyFormat(
                            Number(scoreCardMarketingEarners[0].CUST_CNT_LM_LY)
                          ))}
                  </td>{" "}
                  <td>
                    {scoreCardMarketingEarners !== undefined &&
                    scoreCardMarketingEarners.length !== 0 &&
                    Number(scoreCardMarketingEarners[0].CUST_CNT_LM_TY_VS_LY)
                      .toFixed(2)
                      .includes("-") ? (
                      <span style={{ color: "red" }}>
                        {scoreCardMarketingEarners !== undefined &&
                          scoreCardMarketingEarners.length !== 0 &&
                          (scoreCardMarketingEarners[0].CUST_CNT_LM_TY_VS_LY ===
                          "-999999"
                            ? "-"
                            : `${decimalCurrencyFormat(
                                Number(
                                  scoreCardMarketingEarners[0]
                                    .CUST_CNT_LM_TY_VS_LY
                                )
                              )}%`)}
                      </span>
                    ) : (
                      <span style={{ color: "green" }}>
                        {scoreCardMarketingEarners !== undefined &&
                          scoreCardMarketingEarners.length !== 0 &&
                          (scoreCardMarketingEarners[0].CUST_CNT_LM_TY_VS_LY ===
                          "-999999"
                            ? "-"
                            : `${decimalCurrencyFormat(
                                Number(
                                  scoreCardMarketingEarners[0]
                                    .CUST_CNT_LM_TY_VS_LY
                                )
                              )}%`)}
                      </span>
                    )}
                  </td>{" "}
                  <td>
                    {scoreCardMarketingEarners !== undefined &&
                    scoreCardMarketingEarners.length !== 0 &&
                    Number(scoreCardMarketingEarners[0].VARIANCE_FORCAST_LM)
                      .toFixed(2)
                      .includes("-") ? (
                      <span style={{ color: "red" }}>
                        {scoreCardMarketingEarners !== undefined &&
                          scoreCardMarketingEarners.length !== 0 &&
                          (scoreCardMarketingEarners[0].VARIANCE_FORCAST_LM ===
                          "-999999"
                            ? "-"
                            : `${decimalCurrencyFormat(
                                Number(
                                  scoreCardMarketingEarners[0]
                                    .VARIANCE_FORCAST_LM
                                )
                              )}%`)}
                      </span>
                    ) : (
                      <span style={{ color: "green" }}>
                        {scoreCardMarketingEarners !== undefined &&
                          scoreCardMarketingEarners.length !== 0 &&
                          (scoreCardMarketingEarners[0].VARIANCE_FORCAST_LM ===
                          "-999999"
                            ? "-"
                            : `${decimalCurrencyFormat(
                                Number(
                                  scoreCardMarketingEarners[0]
                                    .VARIANCE_FORCAST_LM
                                )
                              )}%`)}
                      </span>
                    )}
                  </td>{" "}
                  <td>
                    {scoreCardMarketingEarners !== undefined &&
                      scoreCardMarketingEarners.length !== 0 &&
                      (scoreCardMarketingEarners[0].GOAL_FORCAST_YTD ===
                      "-999999"
                        ? "-"
                        : currencyFormat(
                            Number(
                              scoreCardMarketingEarners[0].GOAL_FORCAST_YTD
                            )
                          ))}
                  </td>{" "}
                  <td>
                    {scoreCardMarketingEarners !== undefined &&
                      scoreCardMarketingEarners.length !== 0 &&
                      (scoreCardMarketingEarners[0].CUST_CNT_YTD_TY ===
                      "-999999"
                        ? "-"
                        : currencyFormat(
                            Number(scoreCardMarketingEarners[0].CUST_CNT_YTD_TY)
                          ))}
                  </td>{" "}
                  <td>
                    {scoreCardMarketingEarners !== undefined &&
                      scoreCardMarketingEarners.length !== 0 &&
                      (scoreCardMarketingEarners[0].CUST_CNT_YTD_LY ===
                      "-999999"
                        ? "-"
                        : currencyFormat(
                            Number(scoreCardMarketingEarners[0].CUST_CNT_YTD_LY)
                          ))}
                  </td>{" "}
                  <td>
                    {scoreCardMarketingEarners !== undefined &&
                    scoreCardMarketingEarners.length !== 0 &&
                    Number(scoreCardMarketingEarners[0].CUST_CNT_YTD_TY_VS_LY)
                      .toFixed(2)
                      .includes("-") ? (
                      <span style={{ color: "red" }}>
                        {scoreCardMarketingEarners !== undefined &&
                          scoreCardMarketingEarners.length !== 0 &&
                          (scoreCardMarketingEarners[0]
                            .CUST_CNT_YTD_TY_VS_LY === "-999999"
                            ? "-"
                            : `${decimalCurrencyFormat(
                                Number(
                                  scoreCardMarketingEarners[0]
                                    .CUST_CNT_YTD_TY_VS_LY
                                )
                              )}%`)}
                      </span>
                    ) : (
                      <span style={{ color: "green" }}>
                        {scoreCardMarketingEarners !== undefined &&
                          scoreCardMarketingEarners.length !== 0 &&
                          (scoreCardMarketingEarners[0]
                            .CUST_CNT_YTD_TY_VS_LY === "-999999"
                            ? "-"
                            : `${decimalCurrencyFormat(
                                Number(
                                  scoreCardMarketingEarners[0]
                                    .CUST_CNT_YTD_TY_VS_LY
                                )
                              )}%`)}
                      </span>
                    )}
                  </td>{" "}
                  <td>
                    {scoreCardMarketingEarners !== undefined &&
                    scoreCardMarketingEarners.length !== 0 &&
                    Number(scoreCardMarketingEarners[0].VARIANCE_FORCAST_YTD)
                      .toFixed(2)
                      .includes("-") ? (
                      <span style={{ color: "red" }}>
                        {scoreCardMarketingEarners !== undefined &&
                          scoreCardMarketingEarners.length !== 0 &&
                          (scoreCardMarketingEarners[0].VARIANCE_FORCAST_YTD ===
                          "-999999"
                            ? "-"
                            : `${decimalCurrencyFormat(
                                Number(
                                  scoreCardMarketingEarners[0]
                                    .VARIANCE_FORCAST_YTD
                                )
                              )}%`)}
                      </span>
                    ) : (
                      <span style={{ color: "green" }}>
                        {scoreCardMarketingEarners !== undefined &&
                          scoreCardMarketingEarners.length !== 0 &&
                          (scoreCardMarketingEarners[0].VARIANCE_FORCAST_YTD ===
                          "-999999"
                            ? "-"
                            : `${decimalCurrencyFormat(
                                Number(
                                  scoreCardMarketingEarners[0]
                                    .VARIANCE_FORCAST_YTD
                                )
                              )}%`)}
                      </span>
                    )}
                  </td>{" "}
                </>
              )}
            </tr>
            <tr>
              {" "}
              <th>
                Redeemers (Post May Launch){" "}
                {gettooltip(
                  "RedeemersInfoIcon",
                  "Redeemers",
                  "Redeemers",
                  "Number of customers who redeemed their reward points in the period"
                )}
              </th>
              {loading.redeemers ? (
                <>
                  <LoaderForRow tdCount={10} />
                </>
              ) : (
                <>
                  <td>
                    {scoreCardMarketingRedeemers !== undefined &&
                      scoreCardMarketingRedeemers.length !== 0 &&
                      (scoreCardMarketingRedeemers[0].GOAL_FORCAST_LM ===
                      "-999999"
                        ? "-"
                        : currencyFormat(
                            Number(
                              scoreCardMarketingRedeemers[0].GOAL_FORCAST_LM
                            )
                          ))}
                  </td>{" "}
                  <td>
                    {scoreCardMarketingRedeemers !== undefined &&
                      scoreCardMarketingRedeemers.length !== 0 &&
                      (scoreCardMarketingRedeemers[0].CUST_CNT_LM_TY ===
                      "-999999"
                        ? "-"
                        : currencyFormat(
                            Number(
                              scoreCardMarketingRedeemers[0].CUST_CNT_LM_TY
                            )
                          ))}
                  </td>{" "}
                  <td>
                    {scoreCardMarketingRedeemers !== undefined &&
                      scoreCardMarketingRedeemers.length !== 0 &&
                      (scoreCardMarketingRedeemers[0].CUST_CNT_LM_LY ===
                      "-999999"
                        ? "-"
                        : currencyFormat(
                            Number(
                              scoreCardMarketingRedeemers[0].CUST_CNT_LM_LY
                            )
                          ))}
                  </td>{" "}
                  <td>
                    {scoreCardMarketingRedeemers !== undefined &&
                    scoreCardMarketingRedeemers.length !== 0 &&
                    Number(scoreCardMarketingRedeemers[0].CUST_CNT_LM_TY_VS_LY)
                      .toFixed(2)
                      .includes("-") ? (
                      <span style={{ color: "red" }}>
                        {scoreCardMarketingRedeemers !== undefined &&
                          scoreCardMarketingRedeemers.length !== 0 &&
                          (scoreCardMarketingRedeemers[0]
                            .CUST_CNT_LM_TY_VS_LY === "-999999"
                            ? "-"
                            : `${decimalCurrencyFormat(
                                Number(
                                  scoreCardMarketingRedeemers[0]
                                    .CUST_CNT_LM_TY_VS_LY
                                )
                              )}%`)}
                      </span>
                    ) : (
                      <span style={{ color: "green" }}>
                        {scoreCardMarketingRedeemers !== undefined &&
                          scoreCardMarketingRedeemers.length !== 0 &&
                          (scoreCardMarketingRedeemers[0]
                            .CUST_CNT_LM_TY_VS_LY === "-999999"
                            ? "-"
                            : `${decimalCurrencyFormat(
                                Number(
                                  scoreCardMarketingRedeemers[0]
                                    .CUST_CNT_LM_TY_VS_LY
                                )
                              )}%`)}
                      </span>
                    )}
                  </td>{" "}
                  <td>
                    {scoreCardMarketingRedeemers !== undefined &&
                    scoreCardMarketingRedeemers.length !== 0 &&
                    Number(scoreCardMarketingRedeemers[0].VARIANCE_FORCAST_LM)
                      .toFixed(2)
                      .includes("-") ? (
                      <span style={{ color: "red" }}>
                        {scoreCardMarketingRedeemers !== undefined &&
                          scoreCardMarketingRedeemers.length !== 0 &&
                          (scoreCardMarketingRedeemers[0]
                            .VARIANCE_FORCAST_LM === "-999999"
                            ? "-"
                            : `${decimalCurrencyFormat(
                                Number(
                                  scoreCardMarketingRedeemers[0]
                                    .VARIANCE_FORCAST_LM
                                )
                              )}%`)}
                      </span>
                    ) : (
                      <span style={{ color: "green" }}>
                        {scoreCardMarketingRedeemers !== undefined &&
                          scoreCardMarketingRedeemers.length !== 0 &&
                          (scoreCardMarketingRedeemers[0]
                            .VARIANCE_FORCAST_LM === "-999999"
                            ? "-"
                            : `${decimalCurrencyFormat(
                                Number(
                                  scoreCardMarketingRedeemers[0]
                                    .VARIANCE_FORCAST_LM
                                )
                              )}%`)}
                      </span>
                    )}
                  </td>{" "}
                  <td>
                    {scoreCardMarketingRedeemers !== undefined &&
                      scoreCardMarketingRedeemers.length !== 0 &&
                      (scoreCardMarketingRedeemers[0].GOAL_FORCAST_YTD ===
                      "-999999"
                        ? "-"
                        : currencyFormat(
                            Number(
                              scoreCardMarketingRedeemers[0].GOAL_FORCAST_YTD
                            )
                          ))}
                  </td>{" "}
                  <td>
                    {scoreCardMarketingRedeemers !== undefined &&
                      scoreCardMarketingRedeemers.length !== 0 &&
                      (scoreCardMarketingRedeemers[0].CUST_CNT_YTD_TY ===
                      "-999999"
                        ? "-"
                        : currencyFormat(
                            Number(
                              scoreCardMarketingRedeemers[0].CUST_CNT_YTD_TY
                            )
                          ))}
                  </td>{" "}
                  <td>
                    {scoreCardMarketingRedeemers !== undefined &&
                      scoreCardMarketingRedeemers.length !== 0 &&
                      (scoreCardMarketingRedeemers[0].CUST_CNT_YTD_LY ===
                      "-999999"
                        ? "-"
                        : currencyFormat(
                            Number(
                              scoreCardMarketingRedeemers[0].CUST_CNT_YTD_LY
                            )
                          ))}
                  </td>{" "}
                  <td>
                    {scoreCardMarketingRedeemers !== undefined &&
                    scoreCardMarketingRedeemers.length !== 0 &&
                    Number(scoreCardMarketingRedeemers[0].CUST_CNT_YTD_TY_VS_LY)
                      .toFixed(2)
                      .includes("-") ? (
                      <span style={{ color: "red" }}>
                        {scoreCardMarketingRedeemers !== undefined &&
                          scoreCardMarketingRedeemers.length !== 0 &&
                          (scoreCardMarketingRedeemers[0]
                            .CUST_CNT_YTD_TY_VS_LY === "-999999"
                            ? "-"
                            : `${decimalCurrencyFormat(
                                Number(
                                  scoreCardMarketingRedeemers[0]
                                    .CUST_CNT_YTD_TY_VS_LY
                                )
                              )}%`)}
                      </span>
                    ) : (
                      <span style={{ color: "green" }}>
                        {scoreCardMarketingRedeemers !== undefined &&
                          scoreCardMarketingRedeemers.length !== 0 &&
                          (scoreCardMarketingRedeemers[0]
                            .CUST_CNT_YTD_TY_VS_LY === "-999999"
                            ? "-"
                            : `${decimalCurrencyFormat(
                                Number(
                                  scoreCardMarketingRedeemers[0]
                                    .CUST_CNT_YTD_TY_VS_LY
                                )
                              )}%`)}
                      </span>
                    )}
                  </td>{" "}
                  <td>
                    {scoreCardMarketingRedeemers !== undefined &&
                    scoreCardMarketingRedeemers.length !== 0 &&
                    Number(scoreCardMarketingRedeemers[0].VARIANCE_FORCAST_YTD)
                      .toFixed(2)
                      .includes("-") ? (
                      <span style={{ color: "red" }}>
                        {scoreCardMarketingRedeemers !== undefined &&
                          scoreCardMarketingRedeemers.length !== 0 &&
                          (scoreCardMarketingRedeemers[0]
                            .VARIANCE_FORCAST_YTD === "-999999"
                            ? "-"
                            : `${decimalCurrencyFormat(
                                Number(
                                  scoreCardMarketingRedeemers[0]
                                    .VARIANCE_FORCAST_YTD
                                )
                              )}%`)}
                      </span>
                    ) : (
                      <span style={{ color: "green" }}>
                        {scoreCardMarketingRedeemers !== undefined &&
                          scoreCardMarketingRedeemers.length !== 0 &&
                          (scoreCardMarketingRedeemers[0]
                            .VARIANCE_FORCAST_YTD === "-999999"
                            ? "-"
                            : `${decimalCurrencyFormat(
                                Number(
                                  scoreCardMarketingRedeemers[0]
                                    .VARIANCE_FORCAST_YTD
                                )
                              )}%`)}
                      </span>
                    )}
                  </td>{" "}
                </>
              )}
            </tr>
            <tr className="align-middle">
              {" "}
              <th rowSpan="3">{"Key Programs"}</th>
              <th>
                Credit Card Active Customers{" "}
                {gettooltip(
                  "CreditCardInfoIcon",
                  "CreditCard",
                  "CreditCard",
                  "Number of credit card customers who made a purchase in the period"
                )}
              </th>{" "}
              {loading.plcc ? (
                <>
                  <LoaderForRow tdCount={10} />
                </>
              ) : (
                <>
                  <td>
                    {scoreCardPlcc !== undefined &&
                      scoreCardPlcc.length !== 0 &&
                      (scoreCardPlcc[0].GOAL_FORCAST_LM === "-999999"
                        ? "-"
                        : currencyFormat(
                            Number(scoreCardPlcc[0].GOAL_FORCAST_LM)
                          ))}
                  </td>{" "}
                  <td>
                    {scoreCardPlcc !== undefined &&
                      scoreCardPlcc.length !== 0 &&
                      (scoreCardPlcc[0].CUST_CNT_LM_TY === "-999999"
                        ? "-"
                        : currencyFormat(
                            Number(scoreCardPlcc[0].CUST_CNT_LM_TY)
                          ))}
                  </td>{" "}
                  <td>
                    {scoreCardPlcc !== undefined &&
                      scoreCardPlcc.length !== 0 &&
                      (scoreCardPlcc[0].CUST_CNT_LM_LY === "-999999"
                        ? "-"
                        : currencyFormat(
                            Number(scoreCardPlcc[0].CUST_CNT_LM_LY)
                          ))}
                  </td>{" "}
                  <td>
                    {scoreCardPlcc !== undefined &&
                    scoreCardPlcc.length !== 0 &&
                    Number(scoreCardPlcc[0].CUST_CNT_LM_TY_VS_LY)
                      .toFixed(2)
                      .includes("-") ? (
                      <span style={{ color: "red" }}>
                        {scoreCardPlcc !== undefined &&
                          scoreCardPlcc.length !== 0 &&
                          (scoreCardPlcc[0].CUST_CNT_LM_TY_VS_LY === "-999999"
                            ? "-"
                            : `${decimalCurrencyFormat(
                                Number(scoreCardPlcc[0].CUST_CNT_LM_TY_VS_LY)
                              )}%`)}
                      </span>
                    ) : (
                      <span style={{ color: "green" }}>
                        {scoreCardPlcc !== undefined &&
                          scoreCardPlcc.length !== 0 &&
                          (scoreCardPlcc[0].CUST_CNT_LM_TY_VS_LY === "-999999"
                            ? "-"
                            : `${decimalCurrencyFormat(
                                Number(scoreCardPlcc[0].CUST_CNT_LM_TY_VS_LY)
                              )}%`)}
                      </span>
                    )}
                  </td>{" "}
                  <td>
                    {scoreCardPlcc !== undefined &&
                    scoreCardPlcc.length !== 0 &&
                    Number(scoreCardPlcc[0].VARIANCE_FORCAST_LM)
                      .toFixed(2)
                      .includes("-") ? (
                      <span style={{ color: "red" }}>
                        {scoreCardPlcc !== undefined &&
                          scoreCardPlcc.length !== 0 &&
                          (scoreCardPlcc[0].VARIANCE_FORCAST_LM === "-999999"
                            ? "-"
                            : `${decimalCurrencyFormat(
                                Number(scoreCardPlcc[0].VARIANCE_FORCAST_LM)
                              )}%`)}
                      </span>
                    ) : (
                      <span style={{ color: "green" }}>
                        {scoreCardPlcc !== undefined &&
                          scoreCardPlcc.length !== 0 &&
                          (scoreCardPlcc[0].VARIANCE_FORCAST_LM === "-999999"
                            ? "-"
                            : `${decimalCurrencyFormat(
                                Number(scoreCardPlcc[0].VARIANCE_FORCAST_LM)
                              )}%`)}
                      </span>
                    )}
                  </td>{" "}
                  <td>
                    {scoreCardPlcc !== undefined &&
                      scoreCardPlcc.length !== 0 &&
                      (scoreCardPlcc[0].GOAL_FORCAST_YTD === "-999999"
                        ? "-"
                        : currencyFormat(
                            Number(scoreCardPlcc[0].GOAL_FORCAST_YTD)
                          ))}
                  </td>{" "}
                  <td>
                    {scoreCardPlcc !== undefined &&
                      scoreCardPlcc.length !== 0 &&
                      (scoreCardPlcc[0].CUST_CNT_YTD_TY === "-999999"
                        ? "-"
                        : currencyFormat(
                            Number(scoreCardPlcc[0].CUST_CNT_YTD_TY)
                          ))}
                  </td>{" "}
                  <td>
                    {scoreCardPlcc !== undefined &&
                      scoreCardPlcc.length !== 0 &&
                      (scoreCardPlcc[0].CUST_CNT_YTD_LY === "-999999"
                        ? "-"
                        : currencyFormat(
                            Number(scoreCardPlcc[0].CUST_CNT_YTD_LY)
                          ))}
                  </td>{" "}
                  <td>
                    {scoreCardPlcc !== undefined &&
                    scoreCardPlcc.length !== 0 &&
                    Number(scoreCardPlcc[0].CUST_CNT_YTD_TY_VS_LY)
                      .toFixed(2)
                      .includes("-") ? (
                      <span style={{ color: "red" }}>
                        {scoreCardPlcc !== undefined &&
                          scoreCardPlcc.length !== 0 &&
                          (scoreCardPlcc[0].CUST_CNT_YTD_TY_VS_LY === "-999999"
                            ? "-"
                            : `${decimalCurrencyFormat(
                                Number(scoreCardPlcc[0].CUST_CNT_YTD_TY_VS_LY)
                              )}%`)}
                      </span>
                    ) : (
                      <span style={{ color: "green" }}>
                        {scoreCardPlcc !== undefined &&
                          scoreCardPlcc.length !== 0 &&
                          (scoreCardPlcc[0].CUST_CNT_YTD_TY_VS_LY === "-999999"
                            ? "-"
                            : `${decimalCurrencyFormat(
                                Number(scoreCardPlcc[0].CUST_CNT_YTD_TY_VS_LY)
                              )}%`)}
                      </span>
                    )}
                  </td>{" "}
                  <td>
                    {scoreCardPlcc !== undefined &&
                    scoreCardPlcc.length !== 0 &&
                    Number(scoreCardPlcc[0].VARIANCE_FORCAST_YTD)
                      .toFixed(2)
                      .includes("-") ? (
                      <span style={{ color: "red" }}>
                        {scoreCardPlcc !== undefined &&
                          scoreCardPlcc.length !== 0 &&
                          (scoreCardPlcc[0].VARIANCE_FORCAST_YTD === "-999999"
                            ? "-"
                            : `${decimalCurrencyFormat(
                                Number(scoreCardPlcc[0].VARIANCE_FORCAST_YTD)
                              )}%`)}
                      </span>
                    ) : (
                      <span style={{ color: "green" }}>
                        {scoreCardPlcc !== undefined &&
                          scoreCardPlcc.length !== 0 &&
                          (scoreCardPlcc[0].VARIANCE_FORCAST_YTD === "-999999"
                            ? "-"
                            : `${decimalCurrencyFormat(
                                Number(scoreCardPlcc[0].VARIANCE_FORCAST_YTD)
                              )}%`)}
                      </span>
                    )}
                  </td>{" "}
                </>
              )}
            </tr>
            <tr>
              {" "}
              <th>
                BNPL Active Customers{" "}
                {gettooltip(
                  "BNPLInfoIcon",
                  "BNPL",
                  "BNPL",
                  "Number of active customers who opted for buy now pay later offer"
                )}
              </th>
              {loading.bnpl ? (
                <>
                  <LoaderForRow tdCount={10} />
                </>
              ) : (
                <>
                  <td>
                    {scoreCardBnpl !== undefined &&
                      scoreCardBnpl.length !== 0 &&
                      (scoreCardBnpl[0].GOAL_FORCAST_LM === "-999999"
                        ? "-"
                        : currencyFormat(
                            Number(scoreCardBnpl[0].GOAL_FORCAST_LM)
                          ))}
                  </td>{" "}
                  <td>
                    {scoreCardBnpl !== undefined &&
                      scoreCardBnpl.length !== 0 &&
                      (scoreCardBnpl[0].CUST_CNT_LM_TY === "-999999"
                        ? "-"
                        : currencyFormat(
                            Number(scoreCardBnpl[0].CUST_CNT_LM_TY)
                          ))}
                  </td>{" "}
                  <td>
                    {scoreCardBnpl !== undefined &&
                      scoreCardBnpl.length !== 0 &&
                      (scoreCardBnpl[0].CUST_CNT_LM_LY === "-999999"
                        ? "-"
                        : currencyFormat(
                            Number(scoreCardBnpl[0].CUST_CNT_LM_LY)
                          ))}
                  </td>{" "}
                  <td>
                    {scoreCardBnpl !== undefined &&
                    scoreCardBnpl.length !== 0 &&
                    Number(scoreCardBnpl[0].CUST_CNT_LM_TY_VS_LY)
                      .toFixed(2)
                      .includes("-") ? (
                      <span style={{ color: "red" }}>
                        {scoreCardBnpl !== undefined &&
                          scoreCardBnpl.length !== 0 &&
                          (scoreCardBnpl[0].CUST_CNT_LM_TY_VS_LY === "-999999"
                            ? "-"
                            : `${decimalCurrencyFormat(
                                Number(scoreCardBnpl[0].CUST_CNT_LM_TY_VS_LY)
                              )}%`)}
                      </span>
                    ) : (
                      <span style={{ color: "green" }}>
                        {scoreCardBnpl !== undefined &&
                          scoreCardBnpl.length !== 0 &&
                          (scoreCardBnpl[0].CUST_CNT_LM_TY_VS_LY === "-999999"
                            ? "-"
                            : `${decimalCurrencyFormat(
                                Number(scoreCardBnpl[0].CUST_CNT_LM_TY_VS_LY)
                              )}%`)}
                      </span>
                    )}
                  </td>{" "}
                  <td>
                    {scoreCardBnpl !== undefined &&
                    scoreCardBnpl.length !== 0 &&
                    Number(scoreCardBnpl[0].VARIANCE_FORCAST_LM)
                      .toFixed(2)
                      .includes("-") ? (
                      <span style={{ color: "red" }}>
                        {scoreCardBnpl !== undefined &&
                          scoreCardBnpl.length !== 0 &&
                          (scoreCardBnpl[0].VARIANCE_FORCAST_LM === "-999999"
                            ? "-"
                            : `${decimalCurrencyFormat(
                                Number(scoreCardBnpl[0].VARIANCE_FORCAST_LM)
                              )}%`)}
                      </span>
                    ) : (
                      <span style={{ color: "green" }}>
                        {scoreCardBnpl !== undefined &&
                          scoreCardBnpl.length !== 0 &&
                          (scoreCardBnpl[0].VARIANCE_FORCAST_LM === "-999999"
                            ? "-"
                            : `${decimalCurrencyFormat(
                                Number(scoreCardBnpl[0].VARIANCE_FORCAST_LM)
                              )}%`)}
                      </span>
                    )}
                  </td>{" "}
                  <td>
                    {scoreCardBnpl !== undefined &&
                      scoreCardBnpl.length !== 0 &&
                      (scoreCardBnpl[0].GOAL_FORCAST_YTD === "-999999"
                        ? "-"
                        : currencyFormat(
                            Number(scoreCardBnpl[0].GOAL_FORCAST_YTD)
                          ))}
                  </td>{" "}
                  <td>
                    {scoreCardBnpl !== undefined &&
                      scoreCardBnpl.length !== 0 &&
                      (scoreCardBnpl[0].CUST_CNT_YTD_TY === "-999999"
                        ? "-"
                        : currencyFormat(
                            Number(scoreCardBnpl[0].CUST_CNT_YTD_TY)
                          ))}
                  </td>{" "}
                  <td>
                    {scoreCardBnpl !== undefined &&
                      scoreCardBnpl.length !== 0 &&
                      (scoreCardBnpl[0].CUST_CNT_YTD_LY === "-999999"
                        ? "-"
                        : currencyFormat(
                            Number(scoreCardBnpl[0].CUST_CNT_YTD_LY)
                          ))}
                  </td>{" "}
                  <td>
                    {scoreCardBnpl !== undefined &&
                    scoreCardBnpl.length !== 0 &&
                    Number(scoreCardBnpl[0].CUST_CNT_YTD_TY_VS_LY)
                      .toFixed(2)
                      .includes("-") ? (
                      <span style={{ color: "red" }}>
                        {scoreCardBnpl !== undefined &&
                          scoreCardBnpl.length !== 0 &&
                          (scoreCardBnpl[0].CUST_CNT_YTD_TY_VS_LY === "-999999"
                            ? "-"
                            : `${decimalCurrencyFormat(
                                Number(scoreCardBnpl[0].CUST_CNT_YTD_TY_VS_LY)
                              )}%`)}
                      </span>
                    ) : (
                      <span style={{ color: "green" }}>
                        {scoreCardBnpl !== undefined &&
                          scoreCardBnpl.length !== 0 &&
                          (scoreCardBnpl[0].CUST_CNT_YTD_TY_VS_LY === "-999999"
                            ? "-"
                            : `${decimalCurrencyFormat(
                                Number(scoreCardBnpl[0].CUST_CNT_YTD_TY_VS_LY)
                              )}%`)}
                      </span>
                    )}
                  </td>{" "}
                  <td>
                    {scoreCardBnpl !== undefined &&
                    scoreCardBnpl.length !== 0 &&
                    Number(scoreCardBnpl[0].VARIANCE_FORCAST_YTD)
                      .toFixed(2)
                      .includes("-") ? (
                      <span style={{ color: "red" }}>
                        {scoreCardBnpl !== undefined &&
                          scoreCardBnpl.length !== 0 &&
                          (scoreCardBnpl[0].VARIANCE_FORCAST_YTD === "-999999"
                            ? "-"
                            : `${decimalCurrencyFormat(
                                Number(scoreCardBnpl[0].VARIANCE_FORCAST_YTD)
                              )}%`)}
                      </span>
                    ) : (
                      <span style={{ color: "green" }}>
                        {scoreCardBnpl !== undefined &&
                          scoreCardBnpl.length !== 0 &&
                          (scoreCardBnpl[0].VARIANCE_FORCAST_YTD === "-999999"
                            ? "-"
                            : `${decimalCurrencyFormat(
                                Number(scoreCardBnpl[0].VARIANCE_FORCAST_YTD)
                              )}%`)}
                      </span>
                    )}
                  </td>{" "}
                </>
              )}
            </tr>
            <tr>
              {" "}
              <th>
                BOPIS/SDD Active Customers{" "}
                {gettooltip(
                  "BOPISSDDInfoIcon",
                  "BOPISSDD",
                  "BOPISSDD",
                  "Number of active customers who opted for buy online pickup instore",
                  "or same day delivery in the period"
                )}
              </th>{" "}
              {loading.bopis_sdd ? (
                <>
                  <LoaderForRow tdCount={10} />
                </>
              ) : (
                <>
                  <td>
                    {scoreCardBopisSdd !== undefined &&
                      scoreCardBopisSdd.length !== 0 &&
                      (scoreCardBopisSdd[0].GOAL_FORCAST_LM === "-999999"
                        ? "-"
                        : currencyFormat(
                            Number(scoreCardBopisSdd[0].GOAL_FORCAST_LM)
                          ))}
                  </td>{" "}
                  <td>
                    {scoreCardBopisSdd !== undefined &&
                      scoreCardBopisSdd.length !== 0 &&
                      (scoreCardBopisSdd[0].CUST_CNT_LM_TY === "-999999"
                        ? "-"
                        : currencyFormat(
                            Number(scoreCardBopisSdd[0].CUST_CNT_LM_TY)
                          ))}
                  </td>{" "}
                  <td>
                    {scoreCardBopisSdd !== undefined &&
                      scoreCardBopisSdd.length !== 0 &&
                      (scoreCardBopisSdd[0].CUST_CNT_LM_LY === "-999999"
                        ? "-"
                        : currencyFormat(
                            Number(scoreCardBopisSdd[0].CUST_CNT_LM_LY)
                          ))}
                  </td>{" "}
                  <td>
                    {scoreCardBopisSdd !== undefined &&
                    scoreCardBopisSdd.length !== 0 &&
                    Number(scoreCardBopisSdd[0].CUST_CNT_LM_TY_VS_LY)
                      .toFixed(2)
                      .includes("-") ? (
                      <span style={{ color: "red" }}>
                        {scoreCardBopisSdd !== undefined &&
                          scoreCardBopisSdd.length !== 0 &&
                          (scoreCardBopisSdd[0].CUST_CNT_LM_TY_VS_LY ===
                          "-999999"
                            ? "-"
                            : `${decimalCurrencyFormat(
                                Number(
                                  scoreCardBopisSdd[0].CUST_CNT_LM_TY_VS_LY
                                )
                              )}%`)}
                      </span>
                    ) : (
                      <span style={{ color: "green" }}>
                        {scoreCardBopisSdd !== undefined &&
                          scoreCardBopisSdd.length !== 0 &&
                          (scoreCardBopisSdd[0].CUST_CNT_LM_TY_VS_LY ===
                          "-999999"
                            ? "-"
                            : `${decimalCurrencyFormat(
                                Number(
                                  scoreCardBopisSdd[0].CUST_CNT_LM_TY_VS_LY
                                )
                              )}%`)}
                      </span>
                    )}
                  </td>{" "}
                  <td>
                    {scoreCardBopisSdd !== undefined &&
                    scoreCardBopisSdd.length !== 0 &&
                    Number(scoreCardBopisSdd[0].VARIANCE_FORCAST_LM)
                      .toFixed(2)
                      .includes("-") ? (
                      <span style={{ color: "red" }}>
                        {scoreCardBopisSdd !== undefined &&
                          scoreCardBopisSdd.length !== 0 &&
                          (scoreCardBopisSdd[0].VARIANCE_FORCAST_LM ===
                          "-999999"
                            ? "-"
                            : `${decimalCurrencyFormat(
                                Number(
                                  scoreCardBopisSdd[0].VARIANCE_FORCAST_LM
                                )
                              )}%`)}
                      </span>
                    ) : (
                      <span style={{ color: "green" }}>
                        {scoreCardBopisSdd !== undefined &&
                          scoreCardBopisSdd.length !== 0 &&
                          (scoreCardBopisSdd[0].VARIANCE_FORCAST_LM ===
                          "-999999"
                            ? "-"
                            : `${decimalCurrencyFormat(
                                Number(
                                  scoreCardBopisSdd[0].VARIANCE_FORCAST_LM
                                )
                              )}%`)}
                      </span>
                    )}
                  </td>{" "}
                  <td>
                    {scoreCardBopisSdd !== undefined &&
                      scoreCardBopisSdd.length !== 0 &&
                      (scoreCardBopisSdd[0].GOAL_FORCAST_YTD === "-999999"
                        ? "-"
                        : currencyFormat(
                            Number(scoreCardBopisSdd[0].GOAL_FORCAST_YTD)
                          ))}
                  </td>{" "}
                  <td>
                    {scoreCardBopisSdd !== undefined &&
                      scoreCardBopisSdd.length !== 0 &&
                      (scoreCardBopisSdd[0].CUST_CNT_YTD_TY === "-999999"
                        ? "-"
                        : currencyFormat(
                            Number(scoreCardBopisSdd[0].CUST_CNT_YTD_TY)
                          ))}
                  </td>{" "}
                  <td>
                    {scoreCardBopisSdd !== undefined &&
                      scoreCardBopisSdd.length !== 0 &&
                      (scoreCardBopisSdd[0].CUST_CNT_YTD_LY === "-999999"
                        ? "-"
                        : currencyFormat(
                            Number(scoreCardBopisSdd[0].CUST_CNT_YTD_LY)
                          ))}
                  </td>{" "}
                  <td>
                    {scoreCardBopisSdd !== undefined &&
                    scoreCardBopisSdd.length !== 0 &&
                    Number(scoreCardBopisSdd[0].CUST_CNT_YTD_TY_VS_LY)
                      .toFixed(2)
                      .includes("-") ? (
                      <span style={{ color: "red" }}>
                        {scoreCardBopisSdd !== undefined &&
                          scoreCardBopisSdd.length !== 0 &&
                          (scoreCardBopisSdd[0].CUST_CNT_YTD_TY_VS_LY ===
                          "-999999"
                            ? "-"
                            : `${decimalCurrencyFormat(
                                Number(
                                  scoreCardBopisSdd[0].CUST_CNT_YTD_TY_VS_LY
                                )
                              )}%`)}
                      </span>
                    ) : (
                      <span style={{ color: "green" }}>
                        {scoreCardBopisSdd !== undefined &&
                          scoreCardBopisSdd.length !== 0 &&
                          (scoreCardBopisSdd[0].CUST_CNT_YTD_TY_VS_LY ===
                          "-999999"
                            ? "-"
                            : `${decimalCurrencyFormat(
                                Number(
                                  scoreCardBopisSdd[0].CUST_CNT_YTD_TY_VS_LY
                                )
                              )}%`)}
                      </span>
                    )}
                  </td>{" "}
                  <td>
                    {scoreCardBopisSdd !== undefined &&
                    scoreCardBopisSdd.length !== 0 &&
                    Number(scoreCardBopisSdd[0].VARIANCE_FORCAST_YTD)
                      .toFixed(2)
                      .includes("-") ? (
                      <span style={{ color: "red" }}>
                        {scoreCardBopisSdd !== undefined &&
                          scoreCardBopisSdd.length !== 0 &&
                          (scoreCardBopisSdd[0].VARIANCE_FORCAST_YTD ===
                          "-999999"
                            ? "-"
                            : `${decimalCurrencyFormat(
                                Number(
                                  scoreCardBopisSdd[0].VARIANCE_FORCAST_YTD
                                )
                              )}%`)}
                      </span>
                    ) : (
                      <span style={{ color: "green" }}>
                        {scoreCardBopisSdd !== undefined &&
                          scoreCardBopisSdd.length !== 0 &&
                          (scoreCardBopisSdd[0].VARIANCE_FORCAST_YTD ===
                          "-999999"
                            ? "-"
                            : `${decimalCurrencyFormat(
                                Number(
                                  scoreCardBopisSdd[0].VARIANCE_FORCAST_YTD
                                )
                              )}%`)}
                      </span>
                    )}
                  </td>{" "}
                </>
              )}
            </tr>
            <tr className="align-middle">
              {" "}
              <th rowSpan="2">
                {"Marketing"} <br /> {"Performance"}
              </th>
              <th>
                Digital ROAS{" "}
                {gettooltip(
                  "DigitalROASInfoIcon",
                  "DigitalROAS",
                  "DigitalROAS",
                  "Ratio of digital revenue to total marketing spend in the period"
                )}
              </th>{" "}
              {loading.onroas ? (
                <>
                  <LoaderForRow tdCount={10} />
                </>
              ) : (
                <>
                  <td>
                    {scoreCardOnRoas !== undefined &&
                      scoreCardOnRoas.length !== 0 &&
                      (scoreCardOnRoas[0].GOAL_FORCAST_LM === "-999999"
                        ? "-"
                        : currencyFormat(
                            Number(scoreCardOnRoas[0].GOAL_FORCAST_LM)
                          ))}
                  </td>{" "}
                  <td>
                    {scoreCardOnRoas !== undefined &&
                      scoreCardOnRoas.length !== 0 &&
                      (scoreCardOnRoas[0].CUST_CNT_LM_TY === "-999999"
                        ? "-"
                        : decimalCurrencyFormat(
                            Number(scoreCardOnRoas[0].CUST_CNT_LM_TY)
                          ))}
                  </td>{" "}
                  <td>
                    {scoreCardOnRoas !== undefined &&
                      scoreCardOnRoas.length !== 0 &&
                      (scoreCardOnRoas[0].CUST_CNT_LM_LY === "-999999"
                        ? "-"
                        : decimalCurrencyFormat(
                            Number(scoreCardOnRoas[0].CUST_CNT_LM_LY)
                          ))}
                  </td>{" "}
                  <td>
                    {scoreCardOnRoas !== undefined &&
                    scoreCardOnRoas.length !== 0 &&
                    Number(scoreCardOnRoas[0].CUST_CNT_LM_TY_VS_LY)
                      .toFixed(2)
                      .includes("-") ? (
                      <span style={{ color: "red" }}>
                        {scoreCardOnRoas !== undefined &&
                          scoreCardOnRoas.length !== 0 &&
                          (scoreCardOnRoas[0].CUST_CNT_LM_TY_VS_LY === "-999999"
                            ? "-"
                            : `${decimalCurrencyFormat(
                                Number(scoreCardOnRoas[0].CUST_CNT_LM_TY_VS_LY)
                              )}`)}
                      </span>
                    ) : (
                      <span style={{ color: "green" }}>
                        {scoreCardOnRoas !== undefined &&
                          scoreCardOnRoas.length !== 0 &&
                          (scoreCardOnRoas[0].CUST_CNT_LM_TY_VS_LY === "-999999"
                            ? "-"
                            : `${decimalCurrencyFormat(
                                Number(scoreCardOnRoas[0].CUST_CNT_LM_TY_VS_LY)
                              )}`)}
                      </span>
                    )}
                  </td>{" "}
                  <td>
                    {scoreCardOnRoas !== undefined &&
                    scoreCardOnRoas.length !== 0 &&
                    Number(scoreCardOnRoas[0].VARIANCE_FORCAST_LM)
                      .toFixed(2)
                      .includes("-") ? (
                      <span style={{ color: "red" }}>
                        {scoreCardOnRoas !== undefined &&
                          scoreCardOnRoas.length !== 0 &&
                          (scoreCardOnRoas[0].VARIANCE_FORCAST_LM ===
                          "-999999"
                            ? "-"
                            : `${decimalCurrencyFormat(
                                Number(scoreCardOnRoas[0].VARIANCE_FORCAST_LM)
                              )}`)}
                      </span>
                    ) : (
                      <span style={{ color: "green" }}>
                        {scoreCardOnRoas !== undefined &&
                          scoreCardOnRoas.length !== 0 &&
                          (scoreCardOnRoas[0].VARIANCE_FORCAST_LM ===
                          "-999999"
                            ? "-"
                            : `${decimalCurrencyFormat(
                                Number(scoreCardOnRoas[0].VARIANCE_FORCAST_LM)
                              )}`)}
                      </span>
                    )}
                  </td>{" "}
                  <td>
                    {scoreCardOnRoas !== undefined &&
                      scoreCardOnRoas.length !== 0 &&
                      (scoreCardOnRoas[0].GOAL_FORCAST_YTD === "-999999"
                        ? "-"
                        : currencyFormat(
                            Number(scoreCardOnRoas[0].GOAL_FORCAST_YTD)
                          ))}
                  </td>{" "}
                  <td>
                    {scoreCardOnRoas !== undefined &&
                      scoreCardOnRoas.length !== 0 &&
                      (scoreCardOnRoas[0].CUST_CNT_YTD_TY === "-999999"
                        ? "-"
                        : decimalCurrencyFormat(
                            Number(scoreCardOnRoas[0].CUST_CNT_YTD_TY)
                          ))}
                  </td>{" "}
                  <td>
                    {scoreCardOnRoas !== undefined &&
                      scoreCardOnRoas.length !== 0 &&
                      (scoreCardOnRoas[0].CUST_CNT_YTD_LY === "-999999"
                        ? "-"
                        : decimalCurrencyFormat(
                            Number(scoreCardOnRoas[0].CUST_CNT_YTD_LY)
                          ))}
                  </td>{" "}
                  <td>
                    {scoreCardOnRoas !== undefined &&
                    scoreCardOnRoas.length !== 0 &&
                    Number(scoreCardOnRoas[0].CUST_CNT_YTD_TY_VS_LY)
                      .toFixed(2)
                      .includes("-") ? (
                      <span style={{ color: "red" }}>
                        {scoreCardOnRoas !== undefined &&
                          scoreCardOnRoas.length !== 0 &&
                          (scoreCardOnRoas[0].CUST_CNT_YTD_TY_VS_LY ===
                          "-999999"
                            ? "-"
                            : `${decimalCurrencyFormat(
                                Number(scoreCardOnRoas[0].CUST_CNT_YTD_TY_VS_LY)
                              )}`)}
                      </span>
                    ) : (
                      <span style={{ color: "green" }}>
                        {scoreCardOnRoas !== undefined &&
                          scoreCardOnRoas.length !== 0 &&
                          (scoreCardOnRoas[0].CUST_CNT_YTD_TY_VS_LY ===
                          "-999999"
                            ? "-"
                            : `${decimalCurrencyFormat(
                                Number(scoreCardOnRoas[0].CUST_CNT_YTD_TY_VS_LY)
                              )}`)}
                      </span>
                    )}
                  </td>{" "}
                  <td>
                    {scoreCardOnRoas !== undefined &&
                    scoreCardOnRoas.length !== 0 &&
                    Number(scoreCardOnRoas[0].VARIANCE_FORCAST_YTD)
                      .toFixed(2)
                      .includes("-") ? (
                      <span style={{ color: "red" }}>
                        {scoreCardOnRoas !== undefined &&
                          scoreCardOnRoas.length !== 0 &&
                          (scoreCardOnRoas[0].VARIANCE_FORCAST_YTD ===
                          "-999999"
                            ? "-"
                            : `${decimalCurrencyFormat(
                                Number(scoreCardOnRoas[0].VARIANCE_FORCAST_YTD)
                              )}`)}
                      </span>
                    ) : (
                      <span style={{ color: "green" }}>
                        {scoreCardOnRoas !== undefined &&
                          scoreCardOnRoas.length !== 0 &&
                          (scoreCardOnRoas[0].VARIANCE_FORCAST_YTD ===
                          "-999999"
                            ? "-"
                            : `${decimalCurrencyFormat(
                                Number(scoreCardOnRoas[0].VARIANCE_FORCAST_YTD)
                              )}`)}
                      </span>
                    )}
                  </td>{" "}
                </>
              )}
            </tr>
            <tr>
              {" "}
              <th>
                In-Store ROAS{" "}
                {gettooltip(
                  "InStoreROASInfoIcon",
                  "InStoreROAS",
                  "InStoreROAS",
                  "Ratio of in-store revenue to total marketing spend in the period"
                )}
              </th>
              {loading.inroas ? (
                <>
                  <LoaderForRow tdCount={10} />
                </>
              ) : (
                <>
                  <td>
                    {scoreCardInRoas !== undefined &&
                      scoreCardInRoas.length !== 0 &&
                      (scoreCardInRoas[0].GOAL_FORCAST_LM === "-999999"
                        ? "-"
                        : currencyFormat(
                            Number(scoreCardInRoas[0].GOAL_FORCAST_LM)
                          ))}
                  </td>{" "}
                  <td>
                    {scoreCardInRoas !== undefined &&
                      scoreCardInRoas.length !== 0 &&
                      (scoreCardInRoas[0].CUST_CNT_LM_TY === "-999999"
                        ? "-"
                        : decimalCurrencyFormat(
                            Number(scoreCardInRoas[0].CUST_CNT_LM_TY)
                          ))}
                  </td>{" "}
                  <td>
                    {scoreCardInRoas !== undefined &&
                      scoreCardInRoas.length !== 0 &&
                      (scoreCardInRoas[0].CUST_CNT_LM_LY === "-999999"
                        ? "-"
                        : decimalCurrencyFormat(
                            Number(scoreCardInRoas[0].CUST_CNT_LM_LY)
                          ))}
                  </td>{" "}
                  <td>
                    {scoreCardInRoas !== undefined &&
                    scoreCardInRoas.length !== 0 &&
                    Number(scoreCardInRoas[0].CUST_CNT_LM_TY_VS_LY)
                      .toFixed(2)
                      .includes("-") ? (
                      <span style={{ color: "red" }}>
                        {scoreCardInRoas !== undefined &&
                          scoreCardInRoas.length !== 0 &&
                          (scoreCardInRoas[0].CUST_CNT_LM_TY_VS_LY === "-999999"
                            ? "-"
                            : `${decimalCurrencyFormat(
                                Number(scoreCardInRoas[0].CUST_CNT_LM_TY_VS_LY)
                              )}`)}
                      </span>
                    ) : (
                      <span style={{ color: "green" }}>
                        {scoreCardInRoas !== undefined &&
                          scoreCardInRoas.length !== 0 &&
                          (scoreCardInRoas[0].CUST_CNT_LM_TY_VS_LY === "-999999"
                            ? "-"
                            : `${decimalCurrencyFormat(
                                Number(scoreCardInRoas[0].CUST_CNT_LM_TY_VS_LY)
                              )}`)}
                      </span>
                    )}
                  </td>{" "}
                  <td>
                    {scoreCardInRoas !== undefined &&
                    scoreCardInRoas.length !== 0 &&
                    Number(scoreCardInRoas[0].VARIANCE_FORCAST_LM)
                      .toFixed(2)
                      .includes("-") ? (
                      <span style={{ color: "red" }}>
                        {scoreCardInRoas !== undefined &&
                          scoreCardInRoas.length !== 0 &&
                          (scoreCardInRoas[0].VARIANCE_FORCAST_LM ===
                          "-999999"
                            ? "-"
                            : `${decimalCurrencyFormat(
                                Number(scoreCardInRoas[0].VARIANCE_FORCAST_LM)
                              )}`)}
                      </span>
                    ) : (
                      <span style={{ color: "green" }}>
                        {scoreCardInRoas !== undefined &&
                          scoreCardInRoas.length !== 0 &&
                          (scoreCardInRoas[0].VARIANCE_FORCAST_LM ===
                          "-999999"
                            ? "-"
                            : `${decimalCurrencyFormat(
                                Number(scoreCardInRoas[0].VARIANCE_FORCAST_LM)
                              )}`)}
                      </span>
                    )}
                  </td>{" "}
                  <td>
                    {scoreCardInRoas !== undefined &&
                      scoreCardInRoas.length !== 0 &&
                      (scoreCardInRoas[0].GOAL_FORCAST_YTD === "-999999"
                        ? "-"
                        : currencyFormat(
                            Number(scoreCardInRoas[0].GOAL_FORCAST_YTD)
                          ))}
                  </td>{" "}
                  <td>
                    {scoreCardInRoas !== undefined &&
                      scoreCardInRoas.length !== 0 &&
                      (scoreCardInRoas[0].CUST_CNT_YTD_TY === "-999999"
                        ? "-"
                        : decimalCurrencyFormat(
                            Number(scoreCardInRoas[0].CUST_CNT_YTD_TY)
                          ))}
                  </td>{" "}
                  <td>
                    {scoreCardInRoas !== undefined &&
                      scoreCardInRoas.length !== 0 &&
                      (scoreCardInRoas[0].CUST_CNT_YTD_LY === "-999999"
                        ? "-"
                        : decimalCurrencyFormat(
                            Number(scoreCardInRoas[0].CUST_CNT_YTD_LY)
                          ))}
                  </td>{" "}
                  <td>
                    {scoreCardInRoas !== undefined &&
                    scoreCardInRoas.length !== 0 &&
                    Number(scoreCardInRoas[0].CUST_CNT_YTD_TY_VS_LY)
                      .toFixed(2)
                      .includes("-") ? (
                      <span style={{ color: "red" }}>
                        {scoreCardInRoas !== undefined &&
                          scoreCardInRoas.length !== 0 &&
                          (scoreCardInRoas[0].CUST_CNT_YTD_TY_VS_LY ===
                          "-999999"
                            ? "-"
                            : `${decimalCurrencyFormat(
                                Number(scoreCardInRoas[0].CUST_CNT_YTD_TY_VS_LY)
                              )}`)}
                      </span>
                    ) : (
                      <span style={{ color: "green" }}>
                        {scoreCardInRoas !== undefined &&
                          scoreCardInRoas.length !== 0 &&
                          (scoreCardInRoas[0].CUST_CNT_YTD_TY_VS_LY ===
                          "-999999"
                            ? "-"
                            : `${decimalCurrencyFormat(
                                Number(scoreCardInRoas[0].CUST_CNT_YTD_TY_VS_LY)
                              )}`)}
                      </span>
                    )}
                  </td>{" "}
                  <td>
                    {scoreCardInRoas !== undefined &&
                    scoreCardInRoas.length !== 0 &&
                    Number(scoreCardInRoas[0].VARIANCE_FORCAST_YTD)
                      .toFixed(2)
                      .includes("-") ? (
                      <span style={{ color: "red" }}>
                        {scoreCardInRoas !== undefined &&
                          scoreCardInRoas.length !== 0 &&
                          (scoreCardInRoas[0].VARIANCE_FORCAST_YTD ===
                          "-999999"
                            ? "-"
                            : `${decimalCurrencyFormat(
                                Number(scoreCardInRoas[0].VARIANCE_FORCAST_YTD)
                              )}`)}
                      </span>
                    ) : (
                      <span style={{ color: "green" }}>
                        {scoreCardInRoas !== undefined &&
                          scoreCardInRoas.length !== 0 &&
                          (scoreCardInRoas[0].VARIANCE_FORCAST_YTD ===
                          "-999999"
                            ? "-"
                            : `${decimalCurrencyFormat(
                                Number(scoreCardInRoas[0].VARIANCE_FORCAST_YTD)
                              )}`)}
                      </span>
                    )}
                  </td>{" "}
                </>
              )}
            </tr>
          </tbody>
        </Table>
      </div>
    </div>
  );
}

export default Marketing;
