import React from "react";
import { useHistory } from "react-router-dom";
import "../ScoreCard/ScoreCard.css";
import { Table } from "react-bootstrap";
import LoaderForRow from "../LoaderForTable/LoaderForRow";
import { currencyFormat, decimalCurrencyFormat } from "./Marketing";
import { gettooltip, getDateFormatFromDB } from "../Utils";

function Inventory({
  loading,
  scoreCardStsr,
  scoreCardOnsr,
  scoreCardItrn,
  scoreCardAsku,
  scoreCardNBinStore,
  scoreCardFiscalDates,
  scoreCardOnnb,
}) {
  let history = useHistory();
  return (
    <div className="">
      <div className="p-3" style={{ marginBottom: "50px" }}>
        <Table striped bordered hover size="sm">
          <thead className="text">
            <tr>
              <th rowSpan="2"></th>
              <th rowSpan="2">Metrics</th>
              <th colSpan="5">
                Selected Fiscal Month{" ("}
                {scoreCardFiscalDates !== undefined &&
                scoreCardFiscalDates.length !== 0 &&
                scoreCardFiscalDates[0].SFM_START_DATE !== "-999999"
                  ? getDateFormatFromDB(scoreCardFiscalDates[0].SFM_START_DATE)
                  : ""}
                {" - "}
                {scoreCardFiscalDates !== undefined &&
                scoreCardFiscalDates.length !== 0 &&
                scoreCardFiscalDates[0].SFM_END_DATE !== "-999999"
                  ? getDateFormatFromDB(scoreCardFiscalDates[0].SFM_END_DATE)
                  : ""}
                {")"}
              </th>
              <th colSpan="5">
                YTD{" ("}
                {scoreCardFiscalDates !== undefined &&
                scoreCardFiscalDates.length !== 0 &&
                scoreCardFiscalDates[0].YTD_START_DATE !== "-999999"
                  ? getDateFormatFromDB(scoreCardFiscalDates[0].YTD_START_DATE)
                  : ""}
                {" - "}
                {scoreCardFiscalDates !== undefined &&
                scoreCardFiscalDates.length !== 0 &&
                scoreCardFiscalDates[0].YTD_END_DATE !== "-999999"
                  ? getDateFormatFromDB(scoreCardFiscalDates[0].YTD_END_DATE)
                  : ""}
                {")"}
              </th>
            </tr>
            <tr>
              <th>
                Goal/Forecast{" "}
                {gettooltip(
                  "GoalForecastInfoIcon",
                  "GoalForecast",
                  "GoalForecast",
                  "Goals provided are tentative and will be revisited later in discussion with business"
                )}
              </th>
              <th>Actual(TY)</th>
              <th>Actual(LY)</th>
              <th>Variance(YoY)</th>
              <th>Variance (vs.Forecast)</th>
              <th>
                Goal/Forecast{" "}
                {gettooltip(
                  "GoalForecastInfoIcon",
                  "GoalForecast",
                  "GoalForecast",
                  "Goals provided are tentative and will be revisited later in discussion with business"
                )}
              </th>
              <th>Actual(TY)</th>
              <th>Actual(LY)</th>
              <th>Variance(YoY)</th>
              <th>Variance (vs.Forecast)</th>
            </tr>
          </thead>
          <tbody className="text">
            <tr className="align-middle">
              {" "}
              <th rowSpan="4">{"Performance"}</th>
              <th>
                In-Stock Rate (Store){" "}
                {gettooltip(
                  "InStockStoreInfoIcon",
                  "InStockStore",
                  "InStockStore",
                  "Ratio of count of distinct SKU & Store having OH > 0 to",
                  "count of distinct SKU & Store"
                )}
              </th>{" "}
              {loading.stsr ? (
                <>
                  <LoaderForRow tdCount={10} />
                </>
              ) : (
                <>
                  <td>
                    {scoreCardStsr !== undefined &&
                      scoreCardStsr.length !== 0 &&
                      (scoreCardStsr[0].GOAL_FORCAST_LM === "-999999"
                        ? "-"
                        : `${currencyFormat(
                            Number(scoreCardStsr[0].GOAL_FORCAST_LM)
                          )}%`)}
                  </td>{" "}
                  <td>
                    {scoreCardStsr !== undefined &&
                      scoreCardStsr.length !== 0 &&
                      (scoreCardStsr[0].CUST_CNT_LM_TY === "-999999"
                        ? "-"
                        : `${currencyFormat(
                            Number(scoreCardStsr[0].CUST_CNT_LM_TY)
                          )}%`)}
                  </td>{" "}
                  <td>
                    {scoreCardStsr !== undefined &&
                      scoreCardStsr.length !== 0 &&
                      (scoreCardStsr[0].CUST_CNT_LM_LY === "-999999"
                        ? "-"
                        : `${currencyFormat(
                            Number(scoreCardStsr[0].CUST_CNT_LM_LY)
                          )}%`)}
                  </td>{" "}
                  <td>
                    {scoreCardStsr !== undefined &&
                    scoreCardStsr.length !== 0 &&
                    Number(scoreCardStsr[0].CUST_CNT_LM_TY_VS_LY)
                      .toFixed(2)
                      .includes("-") ? (
                      <span style={{ color: "red" }}>
                        {scoreCardStsr !== undefined &&
                          scoreCardStsr.length !== 0 &&
                          (scoreCardStsr[0].CUST_CNT_LM_TY_VS_LY === "-999999"
                            ? "-"
                            : decimalCurrencyFormat(
                                Number(scoreCardStsr[0].CUST_CNT_LM_TY_VS_LY)
                              ))}
                      </span>
                    ) : (
                      <span style={{ color: "green" }}>
                        {scoreCardStsr !== undefined &&
                          scoreCardStsr.length !== 0 &&
                          (scoreCardStsr[0].CUST_CNT_LM_TY_VS_LY === "-999999"
                            ? "-"
                            : decimalCurrencyFormat(
                                Number(scoreCardStsr[0].CUST_CNT_LM_TY_VS_LY)
                              ))}
                      </span>
                    )}
                  </td>{" "}
                  <td>
                  {scoreCardStsr !== undefined &&
                    scoreCardStsr.length !== 0 &&
                    Number(scoreCardStsr[0].VARIANCE_FORCAST_LM)
                      .toFixed(2)
                      .includes("-") ? (
                      <span style={{ color: "red" }}>
                        {scoreCardStsr !== undefined &&
                          scoreCardStsr.length !== 0 &&
                          (scoreCardStsr[0].VARIANCE_FORCAST_LM === "-999999"
                            ? "-"
                            : `${decimalCurrencyFormat(
                              Number(scoreCardStsr[0].VARIANCE_FORCAST_LM)
                            )}%`)}
                      </span>
                    ) : (
                      <span style={{ color: "green" }}>
                        {scoreCardStsr !== undefined &&
                          scoreCardStsr.length !== 0 &&
                          (scoreCardStsr[0].VARIANCE_FORCAST_LM === "-999999"
                            ? "-"
                            : `${decimalCurrencyFormat(
                              Number(scoreCardStsr[0].VARIANCE_FORCAST_LM)
                            )}%`)}
                      </span>
                    )}
                  </td>{" "}
                  <td>
                    {scoreCardStsr !== undefined &&
                      scoreCardStsr.length !== 0 &&
                      (scoreCardStsr[0].GOAL_FORCAST_YTD === "-999999"
                        ? "-"
                        : `${currencyFormat(
                            Number(scoreCardStsr[0].GOAL_FORCAST_YTD)
                          )}%`)}
                  </td>{" "}
                  <td>
                    {scoreCardStsr !== undefined &&
                      scoreCardStsr.length !== 0 &&
                      (scoreCardStsr[0].CUST_CNT_YTD_TY === "-999999"
                        ? "-"
                        : `${currencyFormat(
                            Number(scoreCardStsr[0].CUST_CNT_YTD_TY)
                          )}%`)}
                  </td>{" "}
                  <td>
                    {scoreCardStsr !== undefined &&
                      scoreCardStsr.length !== 0 &&
                      (scoreCardStsr[0].CUST_CNT_YTD_LY === "-999999"
                        ? "-"
                        : `${currencyFormat(
                            Number(scoreCardStsr[0].CUST_CNT_YTD_LY)
                          )}%`)}
                  </td>{" "}
                  <td>
                    {scoreCardStsr !== undefined &&
                    scoreCardStsr.length !== 0 &&
                    Number(scoreCardStsr[0].CUST_CNT_YTD_TY_VS_LY)
                      .toFixed(2)
                      .includes("-") ? (
                      <span style={{ color: "red" }}>
                        {scoreCardStsr !== undefined &&
                          scoreCardStsr.length !== 0 &&
                          (scoreCardStsr[0].CUST_CNT_YTD_TY_VS_LY === "-999999"
                            ? "-"
                            : decimalCurrencyFormat(
                                Number(scoreCardStsr[0].CUST_CNT_YTD_TY_VS_LY)
                              ))}
                      </span>
                    ) : (
                      <span style={{ color: "green" }}>
                        {scoreCardStsr !== undefined &&
                          scoreCardStsr.length !== 0 &&
                          (scoreCardStsr[0].CUST_CNT_YTD_TY_VS_LY === "-999999"
                            ? "-"
                            : decimalCurrencyFormat(
                                Number(scoreCardStsr[0].CUST_CNT_YTD_TY_VS_LY)
                              ))}
                      </span>
                    )}
                  </td>{" "}
                  <td>
                  {scoreCardStsr !== undefined &&
                    scoreCardStsr.length !== 0 &&
                    Number(scoreCardStsr[0].VARIANCE_FORCAST_YTD)
                      .toFixed(2)
                      .includes("-") ? (
                      <span style={{ color: "red" }}>
                        {scoreCardStsr !== undefined &&
                          scoreCardStsr.length !== 0 &&
                          (scoreCardStsr[0].VARIANCE_FORCAST_YTD === "-999999"
                            ? "-"
                            : `${decimalCurrencyFormat(
                              Number(scoreCardStsr[0].VARIANCE_FORCAST_YTD)
                            )}%`)}
                      </span>
                    ) : (
                      <span style={{ color: "green" }}>
                        {scoreCardStsr !== undefined &&
                          scoreCardStsr.length !== 0 &&
                          (scoreCardStsr[0].VARIANCE_FORCAST_YTD === "-999999"
                            ? "-"
                            : `${decimalCurrencyFormat(
                              Number(scoreCardStsr[0].VARIANCE_FORCAST_YTD)
                            )}%`)}
                      </span>
                    )}
                  </td>{" "}
                </>
              )}
            </tr>
            <tr>
              {" "}
              <th>
                Out-of-Stock Rate (Online){""}
                {gettooltip(
                  "OOSOnlineInfoIcon",
                  "OOSOnline",
                  "OOSOnline",
                  "Ratio of OOS view to SKU view"
                )}
              </th>{" "}
              {loading.onsr ? (
                <>
                  <LoaderForRow tdCount={10} />
                </>
              ) : (
                <>
                  <td>
                    {scoreCardOnsr !== undefined &&
                      scoreCardOnsr.length !== 0 &&
                      (scoreCardOnsr[0].GOAL_FORCAST_LM === "-999999"
                        ? "-"
                        : `${currencyFormat(
                            Number(scoreCardOnsr[0].GOAL_FORCAST_LM)
                          )}%`)}
                  </td>{" "}
                  <td>
                    {scoreCardOnsr !== undefined &&
                      scoreCardOnsr.length !== 0 &&
                      (scoreCardOnsr[0].CUST_CNT_LM_TY === "-999999"
                        ? "-"
                        : `${currencyFormat(
                            Number(scoreCardOnsr[0].CUST_CNT_LM_TY)
                          )}%`)}
                  </td>{" "}
                  <td>
                    {scoreCardOnsr !== undefined &&
                      scoreCardOnsr.length !== 0 &&
                      (scoreCardOnsr[0].CUST_CNT_LM_LY === "-999999"
                        ? "-"
                        : `${currencyFormat(
                            Number(scoreCardOnsr[0].CUST_CNT_LM_LY)
                          )}%`)}
                  </td>{" "}
                  <td>
                    {scoreCardOnsr !== undefined &&
                    scoreCardOnsr.length !== 0 &&
                    Number(scoreCardOnsr[0].CUST_CNT_LM_TY_VS_LY)
                      .toFixed(2)
                      .includes("-") ? (
                      <span style={{ color: "red" }}>
                        {scoreCardOnsr !== undefined &&
                          scoreCardOnsr.length !== 0 &&
                          (scoreCardOnsr[0].CUST_CNT_LM_TY_VS_LY === "-999999"
                            ? "-"
                            : decimalCurrencyFormat(
                                Number(scoreCardOnsr[0].CUST_CNT_LM_TY_VS_LY)
                              ))}
                      </span>
                    ) : (
                      <span style={{ color: "green" }}>
                        {scoreCardOnsr !== undefined &&
                          scoreCardOnsr.length !== 0 &&
                          (scoreCardOnsr[0].CUST_CNT_LM_TY_VS_LY === "-999999"
                            ? "-"
                            : decimalCurrencyFormat(
                                Number(scoreCardOnsr[0].CUST_CNT_LM_TY_VS_LY)
                              ))}
                      </span>
                    )}
                  </td>{" "}
                  <td>
                    {scoreCardOnsr !== undefined &&
                    scoreCardOnsr.length !== 0 &&
                    Number(scoreCardOnsr[0].VARIANCE_FORCAST_LM)
                      .toFixed(2)
                      .includes("-") ? (
                      <span style={{ color: "red" }}>
                        {scoreCardOnsr !== undefined &&
                          scoreCardOnsr.length !== 0 &&
                          (scoreCardOnsr[0].VARIANCE_FORCAST_LM === "-999999"
                            ? "-"
                            : decimalCurrencyFormat(
                                Number(scoreCardOnsr[0].VARIANCE_FORCAST_LM)
                              ))}
                      </span>
                    ) : (
                      <span style={{ color: "green" }}>
                        {scoreCardOnsr !== undefined &&
                          scoreCardOnsr.length !== 0 &&
                          (scoreCardOnsr[0].VARIANCE_FORCAST_LM === "-999999"
                            ? "-"
                            : decimalCurrencyFormat(
                                Number(scoreCardOnsr[0].VARIANCE_FORCAST_LM)
                              ))}
                      </span>
                    )}
                  </td>{" "}
                  <td>
                    {scoreCardOnsr !== undefined &&
                      scoreCardOnsr.length !== 0 &&
                      (scoreCardOnsr[0].GOAL_FORCAST_YTD === "-999999"
                        ? "-"
                        : `${currencyFormat(
                            Number(scoreCardOnsr[0].GOAL_FORCAST_YTD)
                          )}%`)}
                  </td>{" "}
                  <td>
                    {scoreCardOnsr !== undefined &&
                      scoreCardOnsr.length !== 0 &&
                      (scoreCardOnsr[0].CUST_CNT_YTD_TY === "-999999"
                        ? "-"
                        : `${currencyFormat(
                            Number(scoreCardOnsr[0].CUST_CNT_YTD_TY)
                          )}%`)}
                  </td>{" "}
                  <td>
                    {scoreCardOnsr !== undefined &&
                      scoreCardOnsr.length !== 0 &&
                      (scoreCardOnsr[0].CUST_CNT_YTD_LY === "-999999"
                        ? "-"
                        : `${currencyFormat(
                            Number(scoreCardOnsr[0].CUST_CNT_YTD_LY)
                          )}%`)}
                  </td>{" "}
                  <td>
                    {scoreCardOnsr !== undefined &&
                    scoreCardOnsr.length !== 0 &&
                    Number(scoreCardOnsr[0].CUST_CNT_YTD_TY_VS_LY)
                      .toFixed(2)
                      .includes("-") ? (
                      <span style={{ color: "red" }}>
                        {scoreCardOnsr !== undefined &&
                          scoreCardOnsr.length !== 0 &&
                          (scoreCardOnsr[0].CUST_CNT_YTD_TY_VS_LY === "-999999"
                            ? "-"
                            : decimalCurrencyFormat(
                                Number(scoreCardOnsr[0].CUST_CNT_YTD_TY_VS_LY)
                              ))}
                      </span>
                    ) : (
                      <span style={{ color: "green" }}>
                        {scoreCardOnsr !== undefined &&
                          scoreCardOnsr.length !== 0 &&
                          (scoreCardOnsr[0].CUST_CNT_YTD_TY_VS_LY === "-999999"
                            ? "-"
                            : decimalCurrencyFormat(
                                Number(scoreCardOnsr[0].CUST_CNT_YTD_TY_VS_LY)
                              ))}
                      </span>
                    )}
                  </td>{" "}
                  <td>
                    {scoreCardOnsr !== undefined &&
                    scoreCardOnsr.length !== 0 &&
                    Number(scoreCardOnsr[0].VARIANCE_FORCAST_YTD)
                      .toFixed(2)
                      .includes("-") ? (
                      <span style={{ color: "red" }}>
                        {scoreCardOnsr !== undefined &&
                          scoreCardOnsr.length !== 0 &&
                          (scoreCardOnsr[0].VARIANCE_FORCAST_YTD === "-999999"
                            ? "-"
                            : decimalCurrencyFormat(
                                Number(scoreCardOnsr[0].VARIANCE_FORCAST_YTD)
                              ))}
                      </span>
                    ) : (
                      <span style={{ color: "green" }}>
                        {scoreCardOnsr !== undefined &&
                          scoreCardOnsr.length !== 0 &&
                          (scoreCardOnsr[0].VARIANCE_FORCAST_YTD === "-999999"
                            ? "-"
                            : decimalCurrencyFormat(
                                Number(scoreCardOnsr[0].VARIANCE_FORCAST_YTD)
                              ))}
                      </span>
                    )}
                  </td>{" "}
                </>
              )}
            </tr>
            <tr>
              {" "}
              <th>
                Inventory Turns{" "}
                {gettooltip(
                  "InventoryTurnsInfoIcon",
                  "InventoryTurns",
                  "InventoryTurns",
                  "It is the number of times that the BBB sells and replaces its inventory."
                )}
              </th>{" "}
              {loading.itrn ? (
                <>
                  <LoaderForRow tdCount={10} />
                </>
              ) : (
                <>
                  <td>
                    {scoreCardItrn !== undefined &&
                      scoreCardItrn.length !== 0 &&
                      (scoreCardItrn[0].GOAL_FORCAST_LM === "-999999"
                        ? "-"
                        : decimalCurrencyFormat(
                            Number(scoreCardItrn[0].GOAL_FORCAST_LM)
                          ))}
                  </td>{" "}
                  <td>
                    {scoreCardItrn !== undefined &&
                      scoreCardItrn.length !== 0 &&
                      (scoreCardItrn[0].CUST_CNT_LM_TY === "-999999"
                        ? "-"
                        : decimalCurrencyFormat(
                            Number(scoreCardItrn[0].CUST_CNT_LM_TY)
                          ))}
                  </td>{" "}
                  <td>
                    {scoreCardItrn !== undefined &&
                      scoreCardItrn.length !== 0 &&
                      (scoreCardItrn[0].CUST_CNT_LM_LY === "-999999"
                        ? "-"
                        : decimalCurrencyFormat(
                            Number(scoreCardItrn[0].CUST_CNT_LM_LY)
                          ))}
                  </td>{" "}
                  <td>
                    {scoreCardItrn !== undefined &&
                    scoreCardItrn.length !== 0 &&
                    Number(scoreCardItrn[0].CUST_CNT_LM_TY_VS_LY)
                      .toFixed(2)
                      .includes("-") ? (
                      <span style={{ color: "red" }}>
                        {scoreCardItrn !== undefined &&
                          scoreCardItrn.length !== 0 &&
                          (scoreCardItrn[0].CUST_CNT_LM_TY_VS_LY === "-999999"
                            ? "-"
                            : `${decimalCurrencyFormat(
                                Number(scoreCardItrn[0].CUST_CNT_LM_TY_VS_LY)
                              )}%`)}
                      </span>
                    ) : (
                      <span style={{ color: "green" }}>
                        {scoreCardItrn !== undefined &&
                          scoreCardItrn.length !== 0 &&
                          (scoreCardItrn[0].CUST_CNT_LM_TY_VS_LY === "-999999"
                            ? "-"
                            : `${decimalCurrencyFormat(
                                Number(scoreCardItrn[0].CUST_CNT_LM_TY_VS_LY)
                              )}%`)}
                      </span>
                    )}
                  </td>{" "}
                  <td>
                    {scoreCardItrn !== undefined &&
                    scoreCardItrn.length !== 0 &&
                    Number(scoreCardItrn[0].VARIANCE_FORCAST_LM)
                      .toFixed(2)
                      .includes("-") ? (
                      <span style={{ color: "red" }}>
                        {scoreCardItrn !== undefined &&
                          scoreCardItrn.length !== 0 &&
                          (scoreCardItrn[0].VARIANCE_FORCAST_LM === "-999999"
                            ? "-"
                            : `${decimalCurrencyFormat(
                                Number(scoreCardItrn[0].VARIANCE_FORCAST_LM)
                              )}%`)}
                      </span>
                    ) : (
                      <span style={{ color: "green" }}>
                        {scoreCardItrn !== undefined &&
                          scoreCardItrn.length !== 0 &&
                          (scoreCardItrn[0].VARIANCE_FORCAST_LM === "-999999"
                            ? "-"
                            : `${decimalCurrencyFormat(
                                Number(scoreCardItrn[0].VARIANCE_FORCAST_LM)
                              )}%`)}
                      </span>
                    )}
                  </td>{" "}
                  <td>
                    {scoreCardItrn !== undefined &&
                      scoreCardItrn.length !== 0 &&
                      (scoreCardItrn[0].GOAL_FORCAST_YTD === "-999999"
                        ? "-"
                        : decimalCurrencyFormat(
                            Number(scoreCardItrn[0].GOAL_FORCAST_YTD)
                          ))}
                  </td>{" "}
                  <td>
                    {scoreCardItrn !== undefined &&
                      scoreCardItrn.length !== 0 &&
                      (scoreCardItrn[0].CUST_CNT_YTD_TY === "-999999"
                        ? "-"
                        : decimalCurrencyFormat(
                            Number(scoreCardItrn[0].CUST_CNT_YTD_TY)
                          ))}
                  </td>{" "}
                  <td>
                    {scoreCardItrn !== undefined &&
                      scoreCardItrn.length !== 0 &&
                      (scoreCardItrn[0].CUST_CNT_YTD_LY === "-999999"
                        ? "-"
                        : decimalCurrencyFormat(
                            Number(scoreCardItrn[0].CUST_CNT_YTD_LY)
                          ))}
                  </td>{" "}
                  <td>
                    {scoreCardItrn !== undefined &&
                    scoreCardItrn.length !== 0 &&
                    Number(scoreCardItrn[0].CUST_CNT_YTD_TY_VS_LY)
                      .toFixed(2)
                      .includes("-") ? (
                      <span style={{ color: "red" }}>
                        {scoreCardItrn !== undefined &&
                          scoreCardItrn.length !== 0 &&
                          (scoreCardItrn[0].CUST_CNT_YTD_TY_VS_LY === "-999999"
                            ? "-"
                            : `${decimalCurrencyFormat(
                                Number(scoreCardItrn[0].CUST_CNT_YTD_TY_VS_LY)
                              )}%`)}
                      </span>
                    ) : (
                      <span style={{ color: "green" }}>
                        {scoreCardItrn !== undefined &&
                          scoreCardItrn.length !== 0 &&
                          (scoreCardItrn[0].CUST_CNT_YTD_TY_VS_LY === "-999999"
                            ? "-"
                            : `${decimalCurrencyFormat(
                                Number(scoreCardItrn[0].CUST_CNT_YTD_TY_VS_LY)
                              )}%`)}
                      </span>
                    )}
                  </td>{" "}
                  <td>
                    {scoreCardItrn !== undefined &&
                    scoreCardItrn.length !== 0 &&
                    Number(scoreCardItrn[0].VARIANCE_FORCAST_YTD)
                      .toFixed(2)
                      .includes("-") ? (
                      <span style={{ color: "red" }}>
                        {scoreCardItrn !== undefined &&
                          scoreCardItrn.length !== 0 &&
                          (scoreCardItrn[0].VARIANCE_FORCAST_YTD === "-999999"
                            ? "-"
                            : `${decimalCurrencyFormat(
                                Number(scoreCardItrn[0].VARIANCE_FORCAST_YTD)
                              )}%`)}
                      </span>
                    ) : (
                      <span style={{ color: "green" }}>
                        {scoreCardItrn !== undefined &&
                          scoreCardItrn.length !== 0 &&
                          (scoreCardItrn[0].VARIANCE_FORCAST_YTD === "-999999"
                            ? "-"
                            : `${decimalCurrencyFormat(
                                Number(scoreCardItrn[0].VARIANCE_FORCAST_YTD)
                              )}%`)}
                      </span>
                    )}
                  </td>{" "}
                </>
              )}
            </tr>
            <tr>
              {" "}
              <th>
                Active SKU % (% of SKU with atleast
                <br /> one sale){" "}
                {gettooltip(
                  "ActiveSkuInfoIcon",
                  "ActiveSku",
                  "ActiveSku",
                  "Ratio of active SKU with one sales to total active SKU"
                )}
              </th>{" "}
              {loading.asku ? (
                <>
                  <LoaderForRow tdCount={10} />
                </>
              ) : (
                <>
                  <td>
                    {scoreCardAsku !== undefined &&
                      scoreCardAsku.length !== 0 &&
                      (scoreCardAsku[0].GOAL_FORCAST_LM === "-999999"
                        ? "-"
                        : `${decimalCurrencyFormat(
                            Number(scoreCardAsku[0].GOAL_FORCAST_LM)
                          )}%`)}
                  </td>{" "}
                  <td>
                    {scoreCardAsku !== undefined &&
                      scoreCardAsku.length !== 0 &&
                      (scoreCardAsku[0].CUST_CNT_LM_TY === "-999999"
                        ? "-"
                        : `${decimalCurrencyFormat(
                            Number(scoreCardAsku[0].CUST_CNT_LM_TY)
                          )}%`)}
                  </td>{" "}
                  <td>
                    {scoreCardAsku !== undefined &&
                      scoreCardAsku.length !== 0 &&
                      (scoreCardAsku[0].CUST_CNT_LM_LY === "-999999"
                        ? "-"
                        : `${decimalCurrencyFormat(
                            Number(scoreCardAsku[0].CUST_CNT_LM_LY)
                          )}%`)}
                  </td>{" "}
                  <td>
                    {scoreCardAsku !== undefined &&
                    scoreCardAsku.length !== 0 &&
                    Number(scoreCardAsku[0].CUST_CNT_LM_TY_VS_LY)
                      .toFixed(2)
                      .includes("-") ? (
                      <span style={{ color: "red" }}>
                        {scoreCardAsku !== undefined &&
                          scoreCardAsku.length !== 0 &&
                          (scoreCardAsku[0].CUST_CNT_LM_TY_VS_LY === "-999999"
                            ? "-"
                            : decimalCurrencyFormat(
                                Number(scoreCardAsku[0].CUST_CNT_LM_TY_VS_LY)
                              ))}
                      </span>
                    ) : (
                      <span style={{ color: "green" }}>
                        {scoreCardAsku !== undefined &&
                          scoreCardAsku.length !== 0 &&
                          (scoreCardAsku[0].CUST_CNT_LM_TY_VS_LY === "-999999"
                            ? "-"
                            : decimalCurrencyFormat(
                                Number(scoreCardAsku[0].CUST_CNT_LM_TY_VS_LY)
                              ))}
                      </span>
                    )}
                  </td>{" "}
                  <td>
                    {scoreCardAsku !== undefined &&
                    scoreCardAsku.length !== 0 &&
                    Number(scoreCardAsku[0].VARIANCE_FORCAST_LM)
                      .toFixed(2)
                      .includes("-") ? (
                      <span style={{ color: "red" }}>
                        {scoreCardAsku !== undefined &&
                          scoreCardAsku.length !== 0 &&
                          (scoreCardAsku[0].VARIANCE_FORCAST_LM === "-999999"
                            ? "-"
                            : `${decimalCurrencyFormat(
                              Number(scoreCardAsku[0].VARIANCE_FORCAST_LM)
                            )}%`)}
                      </span>
                    ) : (
                      <span style={{ color: "green" }}>
                        {scoreCardAsku !== undefined &&
                          scoreCardAsku.length !== 0 &&
                          (scoreCardAsku[0].VARIANCE_FORCAST_LM === "-999999"
                            ? "-"
                            : `${decimalCurrencyFormat(
                              Number(scoreCardAsku[0].VARIANCE_FORCAST_LM)
                            )}%`)}
                      </span>
                    )}
                  </td>{" "}
                  <td>
                    {scoreCardAsku !== undefined &&
                      scoreCardAsku.length !== 0 &&
                      (scoreCardAsku[0].GOAL_FORCAST_YTD === "-999999"
                        ? "-"
                        : `${decimalCurrencyFormat(
                            Number(scoreCardAsku[0].GOAL_FORCAST_YTD)
                          )}%`)}
                  </td>{" "}
                  <td>
                    {scoreCardAsku !== undefined &&
                      scoreCardAsku.length !== 0 &&
                      (scoreCardAsku[0].CUST_CNT_YTD_TY === "-999999"
                        ? "-"
                        : `${decimalCurrencyFormat(
                            Number(scoreCardAsku[0].CUST_CNT_YTD_TY)
                          )}%`)}
                  </td>{" "}
                  <td>
                    {scoreCardAsku !== undefined &&
                      scoreCardAsku.length !== 0 &&
                      (scoreCardAsku[0].CUST_CNT_YTD_LY === "-999999"
                        ? "-"
                        : `${decimalCurrencyFormat(
                            Number(scoreCardAsku[0].CUST_CNT_YTD_LY)
                          )}%`)}
                  </td>{" "}
                  <td>
                    {scoreCardAsku !== undefined &&
                    scoreCardAsku.length !== 0 &&
                    Number(scoreCardAsku[0].CUST_CNT_YTD_TY_VS_LY)
                      .toFixed(2)
                      .includes("-") ? (
                      <span style={{ color: "red" }}>
                        {scoreCardAsku !== undefined &&
                          scoreCardAsku.length !== 0 &&
                          (scoreCardAsku[0].CUST_CNT_YTD_TY_VS_LY === "-999999"
                            ? "-"
                            : decimalCurrencyFormat(
                                Number(scoreCardAsku[0].CUST_CNT_YTD_TY_VS_LY)
                              ))}
                      </span>
                    ) : (
                      <span style={{ color: "green" }}>
                        {scoreCardAsku !== undefined &&
                          scoreCardAsku.length !== 0 &&
                          (scoreCardAsku[0].CUST_CNT_YTD_TY_VS_LY === "-999999"
                            ? "-"
                            : decimalCurrencyFormat(
                                Number(scoreCardAsku[0].CUST_CNT_YTD_TY_VS_LY)
                              ))}
                      </span>
                    )}
                  </td>{" "}
                  <td>
                    {scoreCardAsku !== undefined &&
                    scoreCardAsku.length !== 0 &&
                    Number(scoreCardAsku[0].VARIANCE_FORCAST_YTD)
                      .toFixed(2)
                      .includes("-") ? (
                      <span style={{ color: "red" }}>
                        {scoreCardAsku !== undefined &&
                          scoreCardAsku.length !== 0 &&
                          (scoreCardAsku[0].VARIANCE_FORCAST_YTD === "-999999"
                            ? "-"
                            : `${decimalCurrencyFormat(
                              Number(scoreCardAsku[0].VARIANCE_FORCAST_YTD)
                            )}%`)}
                      </span>
                    ) : (
                      <span style={{ color: "green" }}>
                        {scoreCardAsku !== undefined &&
                          scoreCardAsku.length !== 0 &&
                          (scoreCardAsku[0].VARIANCE_FORCAST_YTD === "-999999"
                            ? "-"
                            : `${decimalCurrencyFormat(
                              Number(scoreCardAsku[0].VARIANCE_FORCAST_YTD)
                            )}%`)}
                      </span>
                    )}
                  </td>{" "}
                </>
              )}
            </tr>
            <tr></tr>
            <tr className="align-middle">
              {" "}
              <th rowSpan="2">{"National Brands"}</th>
              <th>
                In-Stock Rate (Store){" "}
                {gettooltip(
                  "InStStoreInfoIcon",
                  "InStStore",
                  "InStStore",
                  "Ratio of count of distinct SKU & Store having OH > 0",
                  "to  count of distinct SKU & Store for National Brands"
                )}{" "}
              </th>{" "}
              {loading.nbinstore ? (
                <>
                  <LoaderForRow tdCount={10} />
                </>
              ) : (
                <>
                  <td>
                    {scoreCardNBinStore !== undefined &&
                      scoreCardNBinStore.length !== 0 &&
                      (scoreCardNBinStore[0].GOAL_FORCAST_LM === "-999999"
                        ? "-"
                        : `${currencyFormat(
                            Number(scoreCardNBinStore[0].GOAL_FORCAST_LM)
                          )}%`)}
                  </td>{" "}
                  <td>
                    {scoreCardNBinStore !== undefined &&
                      scoreCardNBinStore.length !== 0 &&
                      (scoreCardNBinStore[0].CUST_CNT_LM_TY === "-999999"
                        ? "-"
                        : `${currencyFormat(
                            Number(scoreCardNBinStore[0].CUST_CNT_LM_TY)
                          )}%`)}
                  </td>{" "}
                  <td>
                    {scoreCardNBinStore !== undefined &&
                      scoreCardNBinStore.length !== 0 &&
                      (scoreCardNBinStore[0].CUST_CNT_LM_LY === "-999999"
                        ? "-"
                        : `${currencyFormat(
                            Number(scoreCardNBinStore[0].CUST_CNT_LM_LY)
                          )}%`)}
                  </td>{" "}
                  <td>
                    {scoreCardNBinStore !== undefined &&
                    scoreCardNBinStore.length !== 0 &&
                    Number(scoreCardNBinStore[0].CUST_CNT_LM_TY_VS_LY)
                      .toFixed(2)
                      .includes("-") ? (
                      <span style={{ color: "red" }}>
                        {scoreCardNBinStore !== undefined &&
                          scoreCardNBinStore.length !== 0 &&
                          (scoreCardNBinStore[0].CUST_CNT_LM_TY_VS_LY ===
                          "-999999"
                            ? "-"
                            : decimalCurrencyFormat(
                                Number(
                                  scoreCardNBinStore[0].CUST_CNT_LM_TY_VS_LY
                                )
                              ))}
                      </span>
                    ) : (
                      <span style={{ color: "green" }}>
                        {scoreCardNBinStore !== undefined &&
                          scoreCardNBinStore.length !== 0 &&
                          (scoreCardNBinStore[0].CUST_CNT_LM_TY_VS_LY ===
                          "-999999"
                            ? "-"
                            : decimalCurrencyFormat(
                                Number(
                                  scoreCardNBinStore[0].CUST_CNT_LM_TY_VS_LY
                                )
                              ))}
                      </span>
                    )}
                  </td>{" "}
                  <td>
                    {scoreCardNBinStore !== undefined &&
                    scoreCardNBinStore.length !== 0 &&
                    Number(scoreCardNBinStore[0].VARIANCE_FORCAST_LM)
                      .toFixed(2)
                      .includes("-") ? (
                      <span style={{ color: "red" }}>
                        {scoreCardNBinStore !== undefined &&
                          scoreCardNBinStore.length !== 0 &&
                          (scoreCardNBinStore[0].VARIANCE_FORCAST_LM ===
                          "-999999"
                            ? "-"
                            : `${decimalCurrencyFormat(
                              Number(scoreCardNBinStore[0].VARIANCE_FORCAST_LM)
                            )}%`)}
                      </span>
                    ) : (
                      <span style={{ color: "green" }}>
                        {scoreCardNBinStore !== undefined &&
                          scoreCardNBinStore.length !== 0 &&
                          (scoreCardNBinStore[0].VARIANCE_FORCAST_LM ===
                          "-999999"
                            ? "-"
                            : `${decimalCurrencyFormat(
                              Number(scoreCardNBinStore[0].VARIANCE_FORCAST_LM)
                            )}%`)}
                      </span>
                    )}
                  </td>{" "}
                  <td>
                    {scoreCardNBinStore !== undefined &&
                      scoreCardNBinStore.length !== 0 &&
                      (scoreCardNBinStore[0].GOAL_FORCAST_YTD === "-999999"
                        ? "-"
                        : `${currencyFormat(
                            Number(scoreCardNBinStore[0].GOAL_FORCAST_YTD)
                          )}%`)}
                  </td>{" "}
                  <td>
                    {scoreCardNBinStore !== undefined &&
                      scoreCardNBinStore.length !== 0 &&
                      (scoreCardNBinStore[0].CUST_CNT_YTD_TY === "-999999"
                        ? "-"
                        : `${currencyFormat(
                            Number(scoreCardNBinStore[0].CUST_CNT_YTD_TY)
                          )}%`)}
                  </td>{" "}
                  <td>
                    {scoreCardNBinStore !== undefined &&
                      scoreCardNBinStore.length !== 0 &&
                      (scoreCardNBinStore[0].CUST_CNT_YTD_LY === "-999999"
                        ? "-"
                        : `${currencyFormat(
                            Number(scoreCardNBinStore[0].CUST_CNT_YTD_LY)
                          )}%`)}
                  </td>{" "}
                  <td>
                    {scoreCardNBinStore !== undefined &&
                    scoreCardNBinStore.length !== 0 &&
                    Number(scoreCardNBinStore[0].CUST_CNT_YTD_TY_VS_LY)
                      .toFixed(2)
                      .includes("-") ? (
                      <span style={{ color: "red" }}>
                        {scoreCardNBinStore !== undefined &&
                          scoreCardNBinStore.length !== 0 &&
                          (scoreCardNBinStore[0].CUST_CNT_YTD_TY_VS_LY ===
                          "-999999"
                            ? "-"
                            : decimalCurrencyFormat(
                                Number(
                                  scoreCardNBinStore[0].CUST_CNT_YTD_TY_VS_LY
                                )
                              ))}
                      </span>
                    ) : (
                      <span style={{ color: "green" }}>
                        {scoreCardNBinStore !== undefined &&
                          scoreCardNBinStore.length !== 0 &&
                          (scoreCardNBinStore[0].CUST_CNT_YTD_TY_VS_LY ===
                          "-999999"
                            ? "-"
                            : decimalCurrencyFormat(
                                Number(
                                  scoreCardNBinStore[0].CUST_CNT_YTD_TY_VS_LY
                                )
                              ))}
                      </span>
                    )}
                  </td>{" "}
                  <td>
                    {scoreCardNBinStore !== undefined &&
                    scoreCardNBinStore.length !== 0 &&
                    Number(scoreCardNBinStore[0].VARIANCE_FORCAST_YTD)
                      .toFixed(2)
                      .includes("-") ? (
                      <span style={{ color: "red" }}>
                        {scoreCardNBinStore !== undefined &&
                          scoreCardNBinStore.length !== 0 &&
                          (scoreCardNBinStore[0].VARIANCE_FORCAST_YTD ===
                          "-999999"
                            ? "-"
                            : `${decimalCurrencyFormat(
                              Number(scoreCardNBinStore[0].VARIANCE_FORCAST_YTD)
                            )}%`)}
                      </span>
                    ) : (
                      <span style={{ color: "green" }}>
                        {scoreCardNBinStore !== undefined &&
                          scoreCardNBinStore.length !== 0 &&
                          (scoreCardNBinStore[0].VARIANCE_FORCAST_YTD ===
                          "-999999"
                            ? "-"
                            : `${decimalCurrencyFormat(
                              Number(scoreCardNBinStore[0].VARIANCE_FORCAST_YTD)
                            )}%`)}
                      </span>
                    )}
                  </td>{" "}
                </>
              )}
            </tr>
            <tr>
              {" "}
              <th>
                Out-of-Stock Rate (Online){" "}
                {gettooltip(
                  "OOSInfoIcon",
                  "OOS",
                  "OOS",
                  "Ratio of OOS view to SKU view"
                )}
              </th>{" "}
              {loading.onnb ? (
                <>
                  <LoaderForRow tdCount={10} />
                </>
              ) : (
                <>
                  <td>
                    {scoreCardOnnb !== undefined &&
                      scoreCardOnnb.length !== 0 &&
                      (scoreCardOnnb[0].GOAL_FORCAST_LM === "-999999"
                        ? "-"
                        : `${currencyFormat(
                            Number(scoreCardOnnb[0].GOAL_FORCAST_LM)
                          )}%`)}
                  </td>{" "}
                  <td>
                    {scoreCardOnnb !== undefined &&
                      scoreCardOnnb.length !== 0 &&
                      (scoreCardOnnb[0].CUST_CNT_LM_TY === "-999999"
                        ? "-"
                        : `${currencyFormat(
                            Number(scoreCardOnnb[0].CUST_CNT_LM_TY)
                          )}%`)}
                  </td>{" "}
                  <td>
                    {scoreCardOnnb !== undefined &&
                      scoreCardOnnb.length !== 0 &&
                      (scoreCardOnnb[0].CUST_CNT_LM_LY === "-999999"
                        ? "-"
                        : `${currencyFormat(
                            Number(scoreCardOnnb[0].CUST_CNT_LM_LY)
                          )}%`)}
                  </td>{" "}
                  <td>
                    {scoreCardOnnb !== undefined &&
                    scoreCardOnnb.length !== 0 &&
                    Number(scoreCardOnnb[0].CUST_CNT_LM_TY_VS_LY)
                      .toFixed(2)
                      .includes("-") ? (
                      <span style={{ color: "red" }}>
                        {scoreCardOnnb !== undefined &&
                          scoreCardOnnb.length !== 0 &&
                          (scoreCardOnnb[0].CUST_CNT_LM_TY_VS_LY === "-999999"
                            ? "-"
                            : decimalCurrencyFormat(
                                Number(scoreCardOnnb[0].CUST_CNT_LM_TY_VS_LY)
                              ))}
                      </span>
                    ) : (
                      <span style={{ color: "green" }}>
                        {scoreCardOnnb !== undefined &&
                          scoreCardOnnb.length !== 0 &&
                          (scoreCardOnnb[0].CUST_CNT_LM_TY_VS_LY === "-999999"
                            ? "-"
                            : decimalCurrencyFormat(
                                Number(scoreCardOnnb[0].CUST_CNT_LM_TY_VS_LY)
                              ))}
                      </span>
                    )}
                  </td>{" "}
                  <td>
                    {scoreCardOnnb !== undefined &&
                    scoreCardOnnb.length !== 0 &&
                    Number(scoreCardOnnb[0].VARIANCE_FORCAST_LM)
                      .toFixed(2)
                      .includes("-") ? (
                      <span style={{ color: "red" }}>
                        {scoreCardOnnb !== undefined &&
                          scoreCardOnnb.length !== 0 &&
                          (scoreCardOnnb[0].VARIANCE_FORCAST_LM === "-999999"
                            ? "-"
                            : `${decimalCurrencyFormat(
                              Number(scoreCardOnnb[0].VARIANCE_FORCAST_LM)
                            )}%`)}
                      </span>
                    ) : (
                      <span style={{ color: "green" }}>
                        {scoreCardOnnb !== undefined &&
                          scoreCardOnnb.length !== 0 &&
                          (scoreCardOnnb[0].VARIANCE_FORCAST_LM === "-999999"
                            ? "-"
                            : `${decimalCurrencyFormat(
                              Number(scoreCardOnnb[0].VARIANCE_FORCAST_LM)
                            )}%`)}
                      </span>
                    )}
                  </td>{" "}
                  <td>
                    {scoreCardOnnb !== undefined &&
                      scoreCardOnnb.length !== 0 &&
                      (scoreCardOnnb[0].GOAL_FORCAST_YTD === "-999999"
                        ? "-"
                        : `${currencyFormat(
                            Number(scoreCardOnnb[0].GOAL_FORCAST_YTD)
                          )}%`)}
                  </td>{" "}
                  <td>
                    {scoreCardOnnb !== undefined &&
                      scoreCardOnnb.length !== 0 &&
                      (scoreCardOnnb[0].CUST_CNT_YTD_TY === "-999999"
                        ? "-"
                        : `${currencyFormat(
                            Number(scoreCardOnnb[0].CUST_CNT_YTD_TY)
                          )}%`)}
                  </td>{" "}
                  <td>
                    {scoreCardOnnb !== undefined &&
                      scoreCardOnnb.length !== 0 &&
                      (scoreCardOnnb[0].CUST_CNT_YTD_LY === "-999999"
                        ? "-"
                        : `${currencyFormat(
                            Number(scoreCardOnnb[0].CUST_CNT_YTD_LY)
                          )}%`)}
                  </td>{" "}
                  <td>
                    {scoreCardOnnb !== undefined &&
                    scoreCardOnnb.length !== 0 &&
                    Number(scoreCardOnnb[0].CUST_CNT_YTD_TY_VS_LY)
                      .toFixed(2)
                      .includes("-") ? (
                      <span style={{ color: "red" }}>
                        {scoreCardOnnb !== undefined &&
                          scoreCardOnnb.length !== 0 &&
                          (scoreCardOnnb[0].CUST_CNT_YTD_TY_VS_LY === "-999999"
                            ? "-"
                            : decimalCurrencyFormat(
                                Number(scoreCardOnnb[0].CUST_CNT_YTD_TY_VS_LY)
                              ))}
                      </span>
                    ) : (
                      <span style={{ color: "green" }}>
                        {scoreCardOnnb !== undefined &&
                          scoreCardOnnb.length !== 0 &&
                          (scoreCardOnnb[0].CUST_CNT_YTD_TY_VS_LY === "-999999"
                            ? "-"
                            : decimalCurrencyFormat(
                                Number(scoreCardOnnb[0].CUST_CNT_YTD_TY_VS_LY)
                              ))}
                      </span>
                    )}
                  </td>{" "}
                  <td>
                    {scoreCardOnnb !== undefined &&
                    scoreCardOnnb.length !== 0 &&
                    Number(scoreCardOnnb[0].VARIANCE_FORCAST_YTD)
                      .toFixed(2)
                      .includes("-") ? (
                      <span style={{ color: "red" }}>
                        {scoreCardOnnb !== undefined &&
                          scoreCardOnnb.length !== 0 &&
                          (scoreCardOnnb[0].VARIANCE_FORCAST_YTD === "-999999"
                            ? "-"
                            : `${decimalCurrencyFormat(
                              Number(scoreCardOnnb[0].VARIANCE_FORCAST_YTD)
                            )}%`)}
                      </span>
                    ) : (
                      <span style={{ color: "green" }}>
                        {scoreCardOnnb !== undefined &&
                          scoreCardOnnb.length !== 0 &&
                          (scoreCardOnnb[0].VARIANCE_FORCAST_YTD === "-999999"
                            ? "-"
                            : `${decimalCurrencyFormat(
                              Number(scoreCardOnnb[0].VARIANCE_FORCAST_YTD)
                            )}%`)}
                      </span>
                    )}
                  </td>{" "}
                </>
              )}
            </tr>
            <tr></tr>
            <tr className="align-middle">
              {" "}
              <th rowSpan="3">
                {"CHI (Customer"} <br /> {"Health Index) Score"}
              </th>
              <th>-----------------------</th> <td></td> <td></td> <td></td>{" "}
              <td></td> <td></td> <td></td> <td></td> <td></td> <td></td>{" "}
              <td></td>{" "}
            </tr>
            <tr>
              {" "}
              <th>-----------------------</th> <td></td> <td></td> <td></td>{" "}
              <td></td> <td></td> <td></td> <td></td> <td></td> <td></td>{" "}
              <td></td>{" "}
            </tr>
            <tr>
              {" "}
              <th>-----------------------</th> <td></td> <td></td> <td></td>{" "}
              <td></td> <td></td> <td></td> <td></td> <td></td> <td></td>{" "}
              <td></td>{" "}
            </tr>
          </tbody>
        </Table>
      </div>
    </div>
  );
}
export default Inventory;
