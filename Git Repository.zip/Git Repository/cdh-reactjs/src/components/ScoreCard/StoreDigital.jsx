import React, { useState } from "react";
import { useHistory } from "react-router-dom";
import "../ScoreCard/ScoreCard.css";
import { Table, Modal } from "react-bootstrap";
import LoaderForRow from "../LoaderForTable/LoaderForRow";
import { currencyFormat, decimalCurrencyFormat } from "./Marketing";
import { gettooltip, getDateFormatFromDB } from "../Utils";

function StoreDigital({
  loading,
  scoreCardOnv,
  scoreCardCar,
  scoreCardOncr,
  scoreCardSt,
  scoreCardStsp,
  scoreCardStcr,
  scoreCardAov,
  scoreCardAbr,
  scoreCardOBplus,
  scoreCardSBplus,
  scoreCardSts,
  scoreCardOnsp,
  scoreCardStcs,
  scoreCardOncs,
  scoreCardFiscalDates,
  scoreCardStoreWelcome,
  scoreCardStoreWelcomePlus,
  scoreCardOnlineWelcome,
  scoreCardOnlineWelcomePlus,
}) {
  let history = useHistory();
  return (
    <div className="tableContainer">
      <div className="p-3" style={{ marginBottom: "50px" }}>
        <Table striped bordered hover size="sm">
          <thead className="text">
            <tr>
              <th rowSpan="2"></th>
              <th rowSpan="2">Metrics</th>
              <th colSpan="5">
                Selected Fiscal Month{" ("}
                {scoreCardFiscalDates !== undefined &&
                scoreCardFiscalDates.length !== 0 &&
                scoreCardFiscalDates[0].SFM_START_DATE !== "-999999"
                  ? getDateFormatFromDB(scoreCardFiscalDates[0].SFM_START_DATE)
                  : ""}
                {" - "}
                {scoreCardFiscalDates !== undefined &&
                scoreCardFiscalDates.length !== 0 &&
                scoreCardFiscalDates[0].SFM_END_DATE !== "-999999"
                  ? getDateFormatFromDB(scoreCardFiscalDates[0].SFM_END_DATE)
                  : ""}
                {")"}
              </th>
              <th colSpan="5">
                YTD{" ("}
                {scoreCardFiscalDates !== undefined &&
                scoreCardFiscalDates.length !== 0 &&
                scoreCardFiscalDates[0].YTD_START_DATE !== "-999999"
                  ? getDateFormatFromDB(scoreCardFiscalDates[0].YTD_START_DATE)
                  : ""}
                {" - "}
                {scoreCardFiscalDates !== undefined &&
                scoreCardFiscalDates.length !== 0 &&
                scoreCardFiscalDates[0].YTD_END_DATE !== "-999999"
                  ? getDateFormatFromDB(scoreCardFiscalDates[0].YTD_END_DATE)
                  : ""}
                {")"}
              </th>
            </tr>
            <tr>
              <th>
                Goal/Forecast{" "}
                {gettooltip(
                  "GoalForecastInfoIcon",
                  "GoalForecast",
                  "GoalForecast",
                  "Goals provided are tentative and will be revisited later in discussion with business"
                )}
              </th>
              <th>Actual(TY)</th>
              <th>Actual(LY)</th>
              <th>Variance(YoY)</th>
              <th>Variance (vs.Forecast)</th>
              <th>
                Goal/Forecast{" "}
                {gettooltip(
                  "GoalForecastInfoIcon",
                  "GoalForecast",
                  "GoalForecast",
                  "Goals provided are tentative and will be revisited later in discussion with business"
                )}
              </th>
              <th>Actual(TY)</th>
              <th>Actual(LY)</th>
              <th>Variance(YoY)</th>
              <th>Variance (vs.Forecast)</th>
            </tr>
          </thead>
          <tbody className="text">
            <tr>
              <div className="spanStyleStore">
                <span>STORES EXPERIENCE</span>
              </div>
            </tr>
            <tr className="align-middle">
              {" "}
              <th rowSpan="5">{"Performance"}</th>
              <th>
                Store Traffic{" "}
                {gettooltip(
                  "StoreTrafficInfoIcon",
                  "StoreTraffic",
                  "StoreTraffic",
                  "Number of customers who visited the store in the period"
                )}
              </th>
              {loading.st ? (
                <>
                  <LoaderForRow tdCount={10} />
                </>
              ) : (
                <>
                  <td>
                    {scoreCardSt !== undefined &&
                      scoreCardSt.length !== 0 &&
                      (scoreCardSt[0].GOAL_FORCAST_LM === "-999999"
                        ? "-"
                        : currencyFormat(
                            Number(scoreCardSt[0].GOAL_FORCAST_LM)
                          ))}
                  </td>{" "}
                  <td>
                    {scoreCardSt !== undefined &&
                      scoreCardSt.length !== 0 &&
                      (scoreCardSt[0].CUST_CNT_LM_TY === "-999999"
                        ? "-"
                        : currencyFormat(
                            Number(scoreCardSt[0].CUST_CNT_LM_TY)
                          ))}
                  </td>{" "}
                  <td>
                    {scoreCardSt !== undefined &&
                      scoreCardSt.length !== 0 &&
                      (scoreCardSt[0].CUST_CNT_LM_LY === "-999999"
                        ? "-"
                        : currencyFormat(
                            Number(scoreCardSt[0].CUST_CNT_LM_LY)
                          ))}
                  </td>{" "}
                  <td>
                    {scoreCardSt !== undefined &&
                    scoreCardSt.length !== 0 &&
                    Number(scoreCardSt[0].CUST_CNT_LM_TY_VS_LY)
                      .toFixed(2)
                      .includes("-") ? (
                      <span style={{ color: "red" }}>
                        {scoreCardSt !== undefined &&
                          scoreCardSt.length !== 0 &&
                          (scoreCardSt[0].CUST_CNT_LM_TY_VS_LY === "-999999"
                            ? "-"
                            : `${decimalCurrencyFormat(
                                Number(scoreCardSt[0].CUST_CNT_LM_TY_VS_LY)
                              )}%`)}
                      </span>
                    ) : (
                      <span style={{ color: "green" }}>
                        {scoreCardSt !== undefined &&
                          scoreCardSt.length !== 0 &&
                          (scoreCardSt[0].CUST_CNT_LM_TY_VS_LY === "-999999"
                            ? "-"
                            : `${decimalCurrencyFormat(
                                Number(scoreCardSt[0].CUST_CNT_LM_TY_VS_LY)
                              )}%`)}
                      </span>
                    )}
                  </td>{" "}
                  <td>
                  {scoreCardSt !== undefined &&
                    scoreCardSt.length !== 0 &&
                    Number(scoreCardSt[0].VARIANCE_FORCAST_LM)
                      .toFixed(2)
                      .includes("-") ? (
                      <span style={{ color: "red" }}>
                        {scoreCardSt !== undefined &&
                          scoreCardSt.length !== 0 &&
                          (scoreCardSt[0].VARIANCE_FORCAST_LM === "-999999"
                            ? "-"
                            : `${decimalCurrencyFormat(
                                Number(scoreCardSt[0].VARIANCE_FORCAST_LM)
                              )}%`)}
                      </span>
                    ) : (
                      <span style={{ color: "green" }}>
                        {scoreCardSt !== undefined &&
                          scoreCardSt.length !== 0 &&
                          (scoreCardSt[0].VARIANCE_FORCAST_LM === "-999999"
                            ? "-"
                            : `${decimalCurrencyFormat(
                                Number(scoreCardSt[0].VARIANCE_FORCAST_LM)
                              )}%`)}
                      </span>
                    )}
                  </td>{" "}
                  <td>
                    {scoreCardSt !== undefined &&
                      scoreCardSt.length !== 0 &&
                      (scoreCardSt[0].GOAL_FORCAST_YTD === "-999999"
                        ? "-"
                        : currencyFormat(
                            Number(scoreCardSt[0].GOAL_FORCAST_YTD)
                          ))}
                  </td>{" "}
                  <td>
                    {scoreCardSt !== undefined &&
                      scoreCardSt.length !== 0 &&
                      (scoreCardSt[0].CUST_CNT_YTD_TY === "-999999"
                        ? "-"
                        : currencyFormat(
                            Number(scoreCardSt[0].CUST_CNT_YTD_TY)
                          ))}
                  </td>{" "}
                  <td>
                    {scoreCardSt !== undefined &&
                      scoreCardSt.length !== 0 &&
                      (scoreCardSt[0].CUST_CNT_YTD_LY === "-999999"
                        ? "-"
                        : currencyFormat(
                            Number(scoreCardSt[0].CUST_CNT_YTD_LY)
                          ))}
                  </td>{" "}
                  <td>
                    {scoreCardSt !== undefined &&
                    scoreCardSt.length !== 0 &&
                    Number(scoreCardSt[0].CUST_CNT_YTD_TY_VS_LY)
                      .toFixed(2)
                      .includes("-") ? (
                      <span style={{ color: "red" }}>
                        {scoreCardSt !== undefined &&
                          scoreCardSt.length !== 0 &&
                          (scoreCardSt[0].CUST_CNT_YTD_TY_VS_LY === "-999999"
                            ? "-"
                            : `${decimalCurrencyFormat(
                                Number(scoreCardSt[0].CUST_CNT_YTD_TY_VS_LY)
                              )}%`)}
                      </span>
                    ) : (
                      <span style={{ color: "green" }}>
                        {scoreCardSt !== undefined &&
                          scoreCardSt.length !== 0 &&
                          (scoreCardSt[0].CUST_CNT_YTD_TY_VS_LY === "-999999"
                            ? "-"
                            : `${decimalCurrencyFormat(
                                Number(scoreCardSt[0].CUST_CNT_YTD_TY_VS_LY)
                              )}%`)}
                      </span>
                    )}
                  </td>{" "}
                  <td>
                  {scoreCardSt !== undefined &&
                    scoreCardSt.length !== 0 &&
                    Number(scoreCardSt[0].VARIANCE_FORCAST_YTD)
                      .toFixed(2)
                      .includes("-") ? (
                      <span style={{ color: "red" }}>
                        {scoreCardSt !== undefined &&
                          scoreCardSt.length !== 0 &&
                          (scoreCardSt[0].VARIANCE_FORCAST_YTD === "-999999"
                            ? "-"
                            : `${decimalCurrencyFormat(
                                Number(scoreCardSt[0].VARIANCE_FORCAST_YTD)
                              )}%`)}
                      </span>
                    ) : (
                      <span style={{ color: "green" }}>
                        {scoreCardSt !== undefined &&
                          scoreCardSt.length !== 0 &&
                          (scoreCardSt[0].VARIANCE_FORCAST_YTD === "-999999"
                            ? "-"
                            : `${decimalCurrencyFormat(
                                Number(scoreCardSt[0].VARIANCE_FORCAST_YTD)
                              )}%`)}
                      </span>
                    )}
                  </td>{" "}
                </>
              )}{" "}
            </tr>
            <tr className="align-middle">
              {" "}
              <th>
                Sales Penetration <br />
                (% of total){" "}
                {gettooltip(
                  "SalesPenetrationInfoIcon",
                  "SalesPenetration",
                  "SalesPenetration",
                  "Ratio of in-store net sales to total net sales in the period"
                )}
              </th>{" "}
              {loading.stsp ? (
                <>
                  <LoaderForRow tdCount={10} />
                </>
              ) : (
                <>
                  <td>
                    {scoreCardStsp !== undefined &&
                      scoreCardStsp.length !== 0 &&
                      (scoreCardStsp[0].GOAL_FORCAST_LM === "-999999"
                        ? "-"
                        : `${decimalCurrencyFormat(
                            Number(scoreCardStsp[0].GOAL_FORCAST_LM)
                          )}%`)}
                  </td>{" "}
                  <td>
                    {scoreCardStsp !== undefined &&
                      scoreCardStsp.length !== 0 &&
                      (scoreCardStsp[0].CUST_CNT_LM_TY === "-999999"
                        ? "-"
                        : `${decimalCurrencyFormat(
                            Number(scoreCardStsp[0].CUST_CNT_LM_TY)
                          )}%`)}
                  </td>{" "}
                  <td>
                    {scoreCardStsp !== undefined &&
                      scoreCardStsp.length !== 0 &&
                      (scoreCardStsp[0].CUST_CNT_LM_LY === "-999999"
                        ? "-"
                        : `${decimalCurrencyFormat(
                            Number(scoreCardStsp[0].CUST_CNT_LM_LY)
                          )}%`)}
                  </td>{" "}
                  <td>
                    {scoreCardStsp !== undefined &&
                    scoreCardStsp.length !== 0 &&
                    Number(scoreCardStsp[0].CUST_CNT_LM_TY_VS_LY)
                      .toFixed(2)
                      .includes("-") ? (
                      <span style={{ color: "red" }}>
                        {scoreCardStsp !== undefined &&
                          scoreCardStsp.length !== 0 &&
                          (scoreCardStsp[0].CUST_CNT_LM_TY_VS_LY === "-999999"
                            ? "-"
                            : decimalCurrencyFormat(
                                Number(scoreCardStsp[0].CUST_CNT_LM_TY_VS_LY)
                              ))}
                      </span>
                    ) : (
                      <span style={{ color: "green" }}>
                        {scoreCardStsp !== undefined &&
                          scoreCardStsp.length !== 0 &&
                          (scoreCardStsp[0].CUST_CNT_LM_TY_VS_LY === "-999999"
                            ? "-"
                            : decimalCurrencyFormat(
                                Number(scoreCardStsp[0].CUST_CNT_LM_TY_VS_LY)
                              ))}
                      </span>
                    )}
                  </td>{" "}
                  <td>
                  {scoreCardStsp !== undefined &&
                    scoreCardStsp.length !== 0 &&
                    Number(scoreCardStsp[0].VARIANCE_FORCAST_LM)
                      .toFixed(2)
                      .includes("-") ? (
                      <span style={{ color: "red" }}>
                        {scoreCardStsp !== undefined &&
                          scoreCardStsp.length !== 0 &&
                          (scoreCardStsp[0].VARIANCE_FORCAST_LM === "-999999"
                            ? "-"
                            : `${decimalCurrencyFormat(
                                Number(scoreCardStsp[0].VARIANCE_FORCAST_LM)
                              )}%`)}
                      </span>
                    ) : (
                      <span style={{ color: "green" }}>
                        {scoreCardStsp !== undefined &&
                          scoreCardStsp.length !== 0 &&
                          (scoreCardStsp[0].VARIANCE_FORCAST_LM === "-999999"
                            ? "-"
                            : `${decimalCurrencyFormat(
                                Number(scoreCardStsp[0].VARIANCE_FORCAST_LM)
                              )}%`)}
                      </span>
                    )}
                  </td>{" "}
                  <td>
                    {scoreCardStsp !== undefined &&
                      scoreCardStsp.length !== 0 &&
                      (scoreCardStsp[0].GOAL_FORCAST_YTD === "-999999"
                        ? "-"
                        : `${decimalCurrencyFormat(
                            Number(scoreCardStsp[0].GOAL_FORCAST_YTD)
                          )}%`)}
                  </td>{" "}
                  <td>
                    {scoreCardStsp !== undefined &&
                      scoreCardStsp.length !== 0 &&
                      (scoreCardStsp[0].CUST_CNT_YTD_TY === "-999999"
                        ? "-"
                        : `${decimalCurrencyFormat(
                            Number(scoreCardStsp[0].CUST_CNT_YTD_TY)
                          )}%`)}
                  </td>{" "}
                  <td>
                    {scoreCardStsp !== undefined &&
                      scoreCardStsp.length !== 0 &&
                      (scoreCardStsp[0].CUST_CNT_YTD_LY === "-999999"
                        ? "-"
                        : `${decimalCurrencyFormat(
                            Number(scoreCardStsp[0].CUST_CNT_YTD_LY)
                          )}%`)}
                  </td>{" "}
                  <td>
                    {scoreCardStsp !== undefined &&
                    scoreCardStsp.length !== 0 &&
                    Number(scoreCardStsp[0].CUST_CNT_YTD_TY_VS_LY)
                      .toFixed(2)
                      .includes("-") ? (
                      <span style={{ color: "red" }}>
                        {scoreCardStsp !== undefined &&
                          scoreCardStsp.length !== 0 &&
                          (scoreCardStsp[0].CUST_CNT_YTD_TY_VS_LY === "-999999"
                            ? "-"
                            : decimalCurrencyFormat(
                                Number(scoreCardStsp[0].CUST_CNT_YTD_TY_VS_LY)
                              ))}
                      </span>
                    ) : (
                      <span style={{ color: "green" }}>
                        {scoreCardStsp !== undefined &&
                          scoreCardStsp.length !== 0 &&
                          (scoreCardStsp[0].CUST_CNT_YTD_TY_VS_LY === "-999999"
                            ? "-"
                            : decimalCurrencyFormat(
                                Number(scoreCardStsp[0].CUST_CNT_YTD_TY_VS_LY)
                              ))}
                      </span>
                    )}
                  </td>{" "}
                  <td>
                  {scoreCardStsp !== undefined &&
                    scoreCardStsp.length !== 0 &&
                    Number(scoreCardStsp[0].VARIANCE_FORCAST_YTD)
                      .toFixed(2)
                      .includes("-") ? (
                      <span style={{ color: "red" }}>
                        {scoreCardStsp !== undefined &&
                          scoreCardStsp.length !== 0 &&
                          (scoreCardStsp[0].VARIANCE_FORCAST_YTD === "-999999"
                            ? "-"
                            : `${decimalCurrencyFormat(
                                Number(scoreCardStsp[0].VARIANCE_FORCAST_YTD)
                              )}%`)}
                      </span>
                    ) : (
                      <span style={{ color: "green" }}>
                        {scoreCardStsp !== undefined &&
                          scoreCardStsp.length !== 0 &&
                          (scoreCardStsp[0].VARIANCE_FORCAST_YTD === "-999999"
                            ? "-"
                            : `${decimalCurrencyFormat(
                                Number(scoreCardStsp[0].VARIANCE_FORCAST_YTD)
                              )}%`)}
                      </span>
                    )}
                  </td>{" "}
                </>
              )}{" "}
            </tr>
            <tr>
              {" "}
              <th>
                Conversion Rate{" "}
                {gettooltip(
                  "ConversionRateInfoIcon",
                  "ConversionRate",
                  "ConversionRate",
                  "Ratio of customers shopped in-store to",
                  "customers who visited the store in the period"
                )}
              </th>
              {loading.stcr ? (
                <>
                  <LoaderForRow tdCount={10} />
                </>
              ) : (
                <>
                  <td>
                    {scoreCardStcr !== undefined &&
                      scoreCardStcr.length !== 0 &&
                      (scoreCardStcr[0].GOAL_FORCAST_LM === "-999999"
                        ? "-"
                        : `${decimalCurrencyFormat(
                            Number(scoreCardStcr[0].GOAL_FORCAST_LM)
                          )}%`)}
                  </td>{" "}
                  <td>
                    {scoreCardStcr !== undefined &&
                      scoreCardStcr.length !== 0 &&
                      (scoreCardStcr[0].CUST_CNT_LM_TY === "-999999"
                        ? "-"
                        : `${decimalCurrencyFormat(
                            Number(scoreCardStcr[0].CUST_CNT_LM_TY)
                          )}%`)}
                  </td>{" "}
                  <td>
                    {scoreCardStcr !== undefined &&
                      scoreCardStcr.length !== 0 &&
                      (scoreCardStcr[0].CUST_CNT_LM_LY === "-999999"
                        ? "-"
                        : `${decimalCurrencyFormat(
                            Number(scoreCardStcr[0].CUST_CNT_LM_LY)
                          )}%`)}
                  </td>{" "}
                  <td>
                    {scoreCardStcr !== undefined &&
                    scoreCardStcr.length !== 0 &&
                    Number(scoreCardStcr[0].CUST_CNT_LM_TY_VS_LY)
                      .toFixed(2)
                      .includes("-") ? (
                      <span style={{ color: "red" }}>
                        {scoreCardStcr !== undefined &&
                          scoreCardStcr.length !== 0 &&
                          (scoreCardStcr[0].CUST_CNT_LM_TY_VS_LY === "-999999"
                            ? "-"
                            : decimalCurrencyFormat(
                                Number(scoreCardStcr[0].CUST_CNT_LM_TY_VS_LY)
                              ))}
                      </span>
                    ) : (
                      <span style={{ color: "green" }}>
                        {scoreCardStcr !== undefined &&
                          scoreCardStcr.length !== 0 &&
                          (scoreCardStcr[0].CUST_CNT_LM_TY_VS_LY === "-999999"
                            ? "-"
                            : decimalCurrencyFormat(
                                Number(scoreCardStcr[0].CUST_CNT_LM_TY_VS_LY)
                              ))}
                      </span>
                    )}
                  </td>{" "}
                  <td>
                  {scoreCardStcr !== undefined &&
                    scoreCardStcr.length !== 0 &&
                    Number(scoreCardStcr[0].VARIANCE_FORCAST_LM)
                      .toFixed(2)
                      .includes("-") ? (
                      <span style={{ color: "red" }}>
                        {scoreCardStcr !== undefined &&
                          scoreCardStcr.length !== 0 &&
                          (scoreCardStcr[0].VARIANCE_FORCAST_LM === "-999999"
                            ? "-"
                            : decimalCurrencyFormat(
                                Number(scoreCardStcr[0].VARIANCE_FORCAST_LM)
                              ))}
                      </span>
                    ) : (
                      <span style={{ color: "green" }}>
                        {scoreCardStcr !== undefined &&
                          scoreCardStcr.length !== 0 &&
                          (scoreCardStcr[0].VARIANCE_FORCAST_LM === "-999999"
                            ? "-"
                            : decimalCurrencyFormat(
                                Number(scoreCardStcr[0].VARIANCE_FORCAST_LM)
                              ))}
                      </span>
                    )}
                  </td>{" "}
                  <td>
                    {scoreCardStcr !== undefined &&
                      scoreCardStcr.length !== 0 &&
                      (scoreCardStcr[0].GOAL_FORCAST_YTD === "-999999"
                        ? "-"
                        : `${decimalCurrencyFormat(
                            Number(scoreCardStcr[0].GOAL_FORCAST_YTD)
                          )}%`)}
                  </td>{" "}
                  <td>
                    {scoreCardStcr !== undefined &&
                      scoreCardStcr.length !== 0 &&
                      (scoreCardStcr[0].CUST_CNT_YTD_TY === "-999999"
                        ? "-"
                        : `${decimalCurrencyFormat(
                            Number(scoreCardStcr[0].CUST_CNT_YTD_TY)
                          )}%`)}
                  </td>{" "}
                  <td>
                    {scoreCardStcr !== undefined &&
                      scoreCardStcr.length !== 0 &&
                      (scoreCardStcr[0].CUST_CNT_YTD_LY === "-999999"
                        ? "-"
                        : `${decimalCurrencyFormat(
                            Number(scoreCardStcr[0].CUST_CNT_YTD_LY)
                          )}%`)}
                  </td>{" "}
                  <td>
                    {scoreCardStcr !== undefined &&
                    scoreCardStcr.length !== 0 &&
                    Number(scoreCardStcr[0].CUST_CNT_YTD_TY_VS_LY)
                      .toFixed(2)
                      .includes("-") ? (
                      <span style={{ color: "red" }}>
                        {scoreCardStcr !== undefined &&
                          scoreCardStcr.length !== 0 &&
                          (scoreCardStcr[0].CUST_CNT_YTD_TY_VS_LY === "-999999"
                            ? "-"
                            : decimalCurrencyFormat(
                                Number(scoreCardStcr[0].CUST_CNT_YTD_TY_VS_LY)
                              ))}
                      </span>
                    ) : (
                      <span style={{ color: "green" }}>
                        {scoreCardStcr !== undefined &&
                          scoreCardStcr.length !== 0 &&
                          (scoreCardStcr[0].CUST_CNT_YTD_TY_VS_LY === "-999999"
                            ? "-"
                            : decimalCurrencyFormat(
                                Number(scoreCardStcr[0].CUST_CNT_YTD_TY_VS_LY)
                              ))}
                      </span>
                    )}
                  </td>{" "}
                  <td>
                  {scoreCardStcr !== undefined &&
                    scoreCardStcr.length !== 0 &&
                    Number(scoreCardStcr[0].VARIANCE_FORCAST_YTD)
                      .toFixed(2)
                      .includes("-") ? (
                      <span style={{ color: "red" }}>
                        {scoreCardStcr !== undefined &&
                          scoreCardStcr.length !== 0 &&
                          (scoreCardStcr[0].VARIANCE_FORCAST_YTD === "-999999"
                            ? "-"
                            : decimalCurrencyFormat(
                                Number(scoreCardStcr[0].VARIANCE_FORCAST_YTD)
                              ))}
                      </span>
                    ) : (
                      <span style={{ color: "green" }}>
                        {scoreCardStcr !== undefined &&
                          scoreCardStcr.length !== 0 &&
                          (scoreCardStcr[0].VARIANCE_FORCAST_YTD === "-999999"
                            ? "-"
                            : decimalCurrencyFormat(
                                Number(scoreCardStcr[0].VARIANCE_FORCAST_YTD)
                              ))}
                      </span>
                    )}
                  </td>{" "}
                </>
              )}{" "}
            </tr>
            <tr>
              {" "}
              <th>
                Average Order Value{" "}
                {gettooltip(
                  "AverageOrderValueInfoIcon",
                  "AverageOrder",
                  "AverageOrder",
                  "Ratio of total net sales to total transactions in store in the period "
                )}
              </th>{" "}
              {loading.aov ? (
                <>
                  <LoaderForRow tdCount={10} />
                </>
              ) : (
                <>
                  <td>
                    {scoreCardAov !== undefined &&
                      scoreCardAov.length !== 0 &&
                      (scoreCardAov[0].GOAL_FORCAST_LM === "-999999"
                        ? "-"
                        : currencyFormat(
                            Number(scoreCardAov[0].GOAL_FORCAST_LM)
                          ))}
                  </td>{" "}
                  <td>
                    {scoreCardAov !== undefined &&
                      scoreCardAov.length !== 0 &&
                      (scoreCardAov[0].CUST_CNT_LM_TY === "-999999"
                        ? "-"
                        : "$" +
                          `${decimalCurrencyFormat(
                            Number(scoreCardAov[0].CUST_CNT_LM_TY)
                          )}`)}
                  </td>{" "}
                  <td>
                    {scoreCardAov !== undefined &&
                      scoreCardAov.length !== 0 &&
                      (scoreCardAov[0].CUST_CNT_LM_LY === "-999999"
                        ? "-"
                        : "$" +
                          `${decimalCurrencyFormat(
                            Number(scoreCardAov[0].CUST_CNT_LM_LY)
                          )}`)}
                  </td>{" "}
                  <td>
                    {scoreCardAov !== undefined &&
                    scoreCardAov.length !== 0 &&
                    Number(scoreCardAov[0].CUST_CNT_LM_TY_VS_LY)
                      .toFixed(2)
                      .includes("-") ? (
                      <span style={{ color: "red" }}>
                        {scoreCardAov !== undefined &&
                          scoreCardAov.length !== 0 &&
                          (scoreCardAov[0].CUST_CNT_LM_TY_VS_LY === "-999999"
                            ? "-"
                            : `${decimalCurrencyFormat(
                                Number(scoreCardAov[0].CUST_CNT_LM_TY_VS_LY)
                              )}%`)}
                      </span>
                    ) : (
                      <span style={{ color: "green" }}>
                        {scoreCardAov !== undefined &&
                          scoreCardAov.length !== 0 &&
                          (scoreCardAov[0].CUST_CNT_LM_TY_VS_LY === "-999999"
                            ? "-"
                            : `${decimalCurrencyFormat(
                                Number(scoreCardAov[0].CUST_CNT_LM_TY_VS_LY)
                              )}%`)}
                      </span>
                    )}
                  </td>{" "}
                  <td>
                    {scoreCardAov !== undefined &&
                    scoreCardAov.length !== 0 &&
                    Number(scoreCardAov[0].VARIANCE_FORCAST_LM)
                      .toFixed(2)
                      .includes("-") ? (
                      <span style={{ color: "red" }}>
                        {scoreCardAov !== undefined &&
                          scoreCardAov.length !== 0 &&
                          (scoreCardAov[0].VARIANCE_FORCAST_LM === "-999999"
                            ? "-"
                            : `${decimalCurrencyFormat(
                                Number(scoreCardAov[0].VARIANCE_FORCAST_LM)
                              )}%`)}
                      </span>
                    ) : (
                      <span style={{ color: "green" }}>
                        {scoreCardAov !== undefined &&
                          scoreCardAov.length !== 0 &&
                          (scoreCardAov[0].VARIANCE_FORCAST_LM === "-999999"
                            ? "-"
                            : `${decimalCurrencyFormat(
                                Number(scoreCardAov[0].VARIANCE_FORCAST_LM)
                              )}%`)}
                      </span>
                    )}
                  </td>{" "}
                  <td>
                    {scoreCardAov !== undefined &&
                      scoreCardAov.length !== 0 &&
                      (scoreCardAov[0].GOAL_FORCAST_YTD === "-999999"
                        ? "-"
                        : currencyFormat(
                            Number(scoreCardAov[0].GOAL_FORCAST_YTD)
                          ))}
                  </td>{" "}
                  <td>
                    {scoreCardAov !== undefined &&
                      scoreCardAov.length !== 0 &&
                      (scoreCardAov[0].CUST_CNT_YTD_TY === "-999999"
                        ? "-"
                        : "$" +
                          `${decimalCurrencyFormat(
                            Number(scoreCardAov[0].CUST_CNT_YTD_TY)
                          )}`)}
                  </td>{" "}
                  <td>
                    {scoreCardAov !== undefined &&
                      scoreCardAov.length !== 0 &&
                      (scoreCardAov[0].CUST_CNT_YTD_LY === "-999999"
                        ? "-"
                        : "$" +
                          `${decimalCurrencyFormat(
                            Number(scoreCardAov[0].CUST_CNT_YTD_LY)
                          )}`)}
                  </td>{" "}
                  <td>
                    {scoreCardAov !== undefined &&
                    scoreCardAov.length !== 0 &&
                    Number(scoreCardAov[0].CUST_CNT_YTD_TY_VS_LY)
                      .toFixed(2)
                      .includes("-") ? (
                      <span style={{ color: "red" }}>
                        {scoreCardAov !== undefined &&
                          scoreCardAov.length !== 0 &&
                          (scoreCardAov[0].CUST_CNT_YTD_TY_VS_LY === "-999999"
                            ? "-"
                            : `${decimalCurrencyFormat(
                                Number(scoreCardAov[0].CUST_CNT_YTD_TY_VS_LY)
                              )}%`)}
                      </span>
                    ) : (
                      <span style={{ color: "green" }}>
                        {scoreCardAov !== undefined &&
                          scoreCardAov.length !== 0 &&
                          (scoreCardAov[0].CUST_CNT_YTD_TY_VS_LY === "-999999"
                            ? "-"
                            : `${decimalCurrencyFormat(
                                Number(scoreCardAov[0].CUST_CNT_YTD_TY_VS_LY)
                              )}%`)}
                      </span>
                    )}
                  </td>{" "}
                  <td>
                    {scoreCardAov !== undefined &&
                    scoreCardAov.length !== 0 &&
                    Number(scoreCardAov[0].VARIANCE_FORCAST_YTD)
                      .toFixed(2)
                      .includes("-") ? (
                      <span style={{ color: "red" }}>
                        {scoreCardAov !== undefined &&
                          scoreCardAov.length !== 0 &&
                          (scoreCardAov[0].VARIANCE_FORCAST_YTD === "-999999"
                            ? "-"
                            : `${decimalCurrencyFormat(
                                Number(scoreCardAov[0].VARIANCE_FORCAST_YTD)
                              )}%`)}
                      </span>
                    ) : (
                      <span style={{ color: "green" }}>
                        {scoreCardAov !== undefined &&
                          scoreCardAov.length !== 0 &&
                          (scoreCardAov[0].VARIANCE_FORCAST_YTD === "-999999"
                            ? "-"
                            : `${decimalCurrencyFormat(
                                Number(scoreCardAov[0].VARIANCE_FORCAST_YTD)
                              )}%`)}
                      </span>
                    )}
                  </td>{" "}
                </>
              )}{" "}
            </tr>
            <tr>
              {" "}
              <th>
                Top 10 State Traffic Share{" "}
                {gettooltip(
                  "StateTrafficShareInfoIcon",
                  "StateTrafficShare",
                  "StateTrafficShare",
                  "Number of the customer visits to stores in top 10 states in the period"
                )}
              </th>{" "}
              {loading.sts ? (
                <>
                  <LoaderForRow tdCount={10} />
                </>
              ) : (
                <>
                  <td>
                    {scoreCardSts !== undefined &&
                      scoreCardSts.length !== 0 &&
                      (scoreCardSts[0].GOAL_FORCAST_LM === "-999999"
                        ? "-"
                        : currencyFormat(
                            Number(scoreCardSts[0].GOAL_FORCAST_LM)
                          ))}
                  </td>{" "}
                  <td>
                    {scoreCardSts !== undefined &&
                      scoreCardSts.length !== 0 &&
                      (scoreCardSts[0].CUST_CNT_LM_TY === "-999999"
                        ? "-"
                        : currencyFormat(
                            Number(scoreCardSts[0].CUST_CNT_LM_TY)
                          ))}
                  </td>{" "}
                  <td>
                    {scoreCardSts !== undefined &&
                      scoreCardSts.length !== 0 &&
                      (scoreCardSts[0].CUST_CNT_LM_LY === "-999999"
                        ? "-"
                        : currencyFormat(
                            Number(scoreCardSts[0].CUST_CNT_LM_LY)
                          ))}
                  </td>{" "}
                  <td>
                    {scoreCardSts !== undefined &&
                    scoreCardSts.length !== 0 &&
                    Number(scoreCardSts[0].CUST_CNT_LM_TY_VS_LY)
                      .toFixed(2)
                      .includes("-") ? (
                      <span style={{ color: "red" }}>
                        {scoreCardSts !== undefined &&
                          scoreCardSts.length !== 0 &&
                          (scoreCardSts[0].CUST_CNT_LM_TY_VS_LY === "-999999"
                            ? "-"
                            : `${decimalCurrencyFormat(
                                Number(scoreCardSts[0].CUST_CNT_LM_TY_VS_LY)
                              )}%`)}
                      </span>
                    ) : (
                      <span style={{ color: "green" }}>
                        {scoreCardSts !== undefined &&
                          scoreCardSts.length !== 0 &&
                          (scoreCardSts[0].CUST_CNT_LM_TY_VS_LY === "-999999"
                            ? "-"
                            : `${decimalCurrencyFormat(
                                Number(scoreCardSts[0].CUST_CNT_LM_TY_VS_LY)
                              )}%`)}
                      </span>
                    )}
                  </td>{" "}
                  <td>
                    {scoreCardSts !== undefined &&
                    scoreCardSts.length !== 0 &&
                    Number(scoreCardSts[0].VARIANCE_FORCAST_LM)
                      .toFixed(2)
                      .includes("-") ? (
                      <span style={{ color: "red" }}>
                        {scoreCardSts !== undefined &&
                          scoreCardSts.length !== 0 &&
                          (scoreCardSts[0].VARIANCE_FORCAST_LM === "-999999"
                            ? "-"
                            : `${decimalCurrencyFormat(
                                Number(scoreCardSts[0].VARIANCE_FORCAST_LM)
                              )}%`)}
                      </span>
                    ) : (
                      <span style={{ color: "green" }}>
                        {scoreCardSts !== undefined &&
                          scoreCardSts.length !== 0 &&
                          (scoreCardSts[0].VARIANCE_FORCAST_LM === "-999999"
                            ? "-"
                            : `${decimalCurrencyFormat(
                                Number(scoreCardSts[0].VARIANCE_FORCAST_LM)
                              )}%`)}
                      </span>
                    )}
                  </td>{" "}
                  <td>
                    {scoreCardSts !== undefined &&
                      scoreCardSts.length !== 0 &&
                      (scoreCardSts[0].GOAL_FORCAST_YTD === "-999999"
                        ? "-"
                        : currencyFormat(
                            Number(scoreCardSts[0].GOAL_FORCAST_YTD)
                          ))}
                  </td>{" "}
                  <td>
                    {scoreCardSts !== undefined &&
                      scoreCardSts.length !== 0 &&
                      (scoreCardSts[0].CUST_CNT_YTD_TY === "-999999"
                        ? "-"
                        : currencyFormat(
                            Number(scoreCardSts[0].CUST_CNT_YTD_TY)
                          ))}
                  </td>{" "}
                  <td>
                    {scoreCardSts !== undefined &&
                      scoreCardSts.length !== 0 &&
                      (scoreCardSts[0].CUST_CNT_YTD_LY === "-999999"
                        ? "-"
                        : currencyFormat(
                            Number(scoreCardSts[0].CUST_CNT_YTD_LY)
                          ))}
                  </td>{" "}
                  <td>
                    {scoreCardSts !== undefined &&
                    scoreCardSts.length !== 0 &&
                    Number(scoreCardSts[0].CUST_CNT_YTD_TY_VS_LY)
                      .toFixed(2)
                      .includes("-") ? (
                      <span style={{ color: "red" }}>
                        {scoreCardSts !== undefined &&
                          scoreCardSts.length !== 0 &&
                          (scoreCardSts[0].CUST_CNT_YTD_TY_VS_LY === "-999999"
                            ? "-"
                            : `${decimalCurrencyFormat(
                                Number(scoreCardSts[0].CUST_CNT_YTD_TY_VS_LY)
                              )}%`)}
                      </span>
                    ) : (
                      <span style={{ color: "green" }}>
                        {scoreCardSts !== undefined &&
                          scoreCardSts.length !== 0 &&
                          (scoreCardSts[0].CUST_CNT_YTD_TY_VS_LY === "-999999"
                            ? "-"
                            : `${decimalCurrencyFormat(
                                Number(scoreCardSts[0].CUST_CNT_YTD_TY_VS_LY)
                              )}%`)}
                      </span>
                    )}
                  </td>{" "}
                  <td>
                    {scoreCardSts !== undefined &&
                    scoreCardSts.length !== 0 &&
                    Number(scoreCardSts[0].VARIANCE_FORCAST_YTD)
                      .toFixed(2)
                      .includes("-") ? (
                      <span style={{ color: "red" }}>
                        {scoreCardSts !== undefined &&
                          scoreCardSts.length !== 0 &&
                          (scoreCardSts[0].VARIANCE_FORCAST_YTD === "-999999"
                            ? "-"
                            : `${decimalCurrencyFormat(
                                Number(scoreCardSts[0].VARIANCE_FORCAST_YTD)
                              )}%`)}
                      </span>
                    ) : (
                      <span style={{ color: "green" }}>
                        {scoreCardSts !== undefined &&
                          scoreCardSts.length !== 0 &&
                          (scoreCardSts[0].VARIANCE_FORCAST_YTD === "-999999"
                            ? "-"
                            : `${decimalCurrencyFormat(
                                Number(scoreCardSts[0].VARIANCE_FORCAST_YTD)
                              )}%`)}
                      </span>
                    )}
                  </td>{" "}
                </>
              )}{" "}
            </tr>
            <tr></tr>
            <tr className="align-middle">
              {" "}
              <th rowSpan="4">{"Sign-ups in store"}</th>
              <th>
                Beyond+ Sign-Ups{" "}
                {gettooltip(
                  "BplusSignupsStoreInfoIcon",
                  "BplusSignupsStore",
                  "BplusSignupsStore",
                  "Number of customers who signed-up in-store",
                  "for beyond+ membership in the period "
                )}
              </th>{" "}
              {loading.sbplus ? (
                <>
                  <LoaderForRow tdCount={10} />
                </>
              ) : (
                <>
                  <td>
                    {scoreCardSBplus !== undefined &&
                      scoreCardSBplus.length !== 0 &&
                      (scoreCardSBplus[0].GOAL_FORCAST_LM === "-999999"
                        ? "-"
                        : currencyFormat(
                            Number(scoreCardSBplus[0].GOAL_FORCAST_LM)
                          ))}
                  </td>{" "}
                  <td>
                    {scoreCardSBplus !== undefined &&
                      scoreCardSBplus.length !== 0 &&
                      (scoreCardSBplus[0].CUST_CNT_LM_TY === "-999999"
                        ? "-"
                        : currencyFormat(
                            Number(scoreCardSBplus[0].CUST_CNT_LM_TY)
                          ))}
                  </td>{" "}
                  <td>
                    {scoreCardSBplus !== undefined &&
                      scoreCardSBplus.length !== 0 &&
                      (scoreCardSBplus[0].CUST_CNT_LM_LY === "-999999"
                        ? "-"
                        : currencyFormat(
                            Number(scoreCardSBplus[0].CUST_CNT_LM_LY)
                          ))}
                  </td>{" "}
                  <td>
                    {scoreCardSBplus !== undefined &&
                    scoreCardSBplus.length !== 0 &&
                    Number(scoreCardSBplus[0].CUST_CNT_LM_TY_VS_LY)
                      .toFixed(2)
                      .includes("-") ? (
                      <span style={{ color: "red" }}>
                        {scoreCardSBplus !== undefined &&
                          scoreCardSBplus.length !== 0 &&
                          (scoreCardSBplus[0].CUST_CNT_LM_TY_VS_LY === "-999999"
                            ? "-"
                            : `${decimalCurrencyFormat(
                                Number(scoreCardSBplus[0].CUST_CNT_LM_TY_VS_LY)
                              )}%`)}
                      </span>
                    ) : (
                      <span style={{ color: "green" }}>
                        {scoreCardSBplus !== undefined &&
                          scoreCardSBplus.length !== 0 &&
                          (scoreCardSBplus[0].CUST_CNT_LM_TY_VS_LY === "-999999"
                            ? "-"
                            : `${decimalCurrencyFormat(
                                Number(scoreCardSBplus[0].CUST_CNT_LM_TY_VS_LY)
                              )}%`)}
                      </span>
                    )}
                  </td>{" "}
                  <td>
                    {scoreCardSBplus !== undefined &&
                    scoreCardSBplus.length !== 0 &&
                    Number(scoreCardSBplus[0].VARIANCE_FORCAST_LM)
                      .toFixed(2)
                      .includes("-") ? (
                      <span style={{ color: "red" }}>
                        {scoreCardSBplus !== undefined &&
                          scoreCardSBplus.length !== 0 &&
                          (scoreCardSBplus[0].VARIANCE_FORCAST_LM === "-999999"
                            ? "-"
                            : `${decimalCurrencyFormat(
                                Number(scoreCardSBplus[0].VARIANCE_FORCAST_LM)
                              )}%`)}
                      </span>
                    ) : (
                      <span style={{ color: "green" }}>
                        {scoreCardSBplus !== undefined &&
                          scoreCardSBplus.length !== 0 &&
                          (scoreCardSBplus[0].VARIANCE_FORCAST_LM === "-999999"
                            ? "-"
                            : `${decimalCurrencyFormat(
                                Number(scoreCardSBplus[0].VARIANCE_FORCAST_LM)
                              )}%`)}
                      </span>
                    )}
                  </td>{" "}
                  <td>
                    {scoreCardSBplus !== undefined &&
                      scoreCardSBplus.length !== 0 &&
                      (scoreCardSBplus[0].GOAL_FORCAST_YTD === "-999999"
                        ? "-"
                        : currencyFormat(
                            Number(scoreCardSBplus[0].GOAL_FORCAST_YTD)
                          ))}
                  </td>{" "}
                  <td>
                    {scoreCardSBplus !== undefined &&
                      scoreCardSBplus.length !== 0 &&
                      (scoreCardSBplus[0].CUST_CNT_YTD_TY === "-999999"
                        ? "-"
                        : currencyFormat(
                            Number(scoreCardSBplus[0].CUST_CNT_YTD_TY)
                          ))}
                  </td>{" "}
                  <td>
                    {scoreCardSBplus !== undefined &&
                      scoreCardSBplus.length !== 0 &&
                      (scoreCardSBplus[0].CUST_CNT_YTD_LY === "-999999"
                        ? "-"
                        : currencyFormat(
                            Number(scoreCardSBplus[0].CUST_CNT_YTD_LY)
                          ))}
                  </td>{" "}
                  <td>
                    {scoreCardSBplus !== undefined &&
                    scoreCardSBplus.length !== 0 &&
                    Number(scoreCardSBplus[0].CUST_CNT_YTD_TY_VS_LY)
                      .toFixed(2)
                      .includes("-") ? (
                      <span style={{ color: "red" }}>
                        {scoreCardSBplus !== undefined &&
                          scoreCardSBplus.length !== 0 &&
                          (scoreCardSBplus[0].CUST_CNT_YTD_TY_VS_LY ===
                          "-999999"
                            ? "-"
                            : `${decimalCurrencyFormat(
                                Number(scoreCardSBplus[0].CUST_CNT_YTD_TY_VS_LY)
                              )}%`)}
                      </span>
                    ) : (
                      <span style={{ color: "green" }}>
                        {scoreCardSBplus !== undefined &&
                          scoreCardSBplus.length !== 0 &&
                          (scoreCardSBplus[0].CUST_CNT_YTD_TY_VS_LY ===
                          "-999999"
                            ? "-"
                            : `${decimalCurrencyFormat(
                                Number(scoreCardSBplus[0].CUST_CNT_YTD_TY_VS_LY)
                              )}%`)}
                      </span>
                    )}
                  </td>{" "}
                  <td>
                    {scoreCardSBplus !== undefined &&
                    scoreCardSBplus.length !== 0 &&
                    Number(scoreCardSBplus[0].VARIANCE_FORCAST_YTD)
                      .toFixed(2)
                      .includes("-") ? (
                      <span style={{ color: "red" }}>
                        {scoreCardSBplus !== undefined &&
                          scoreCardSBplus.length !== 0 &&
                          (scoreCardSBplus[0].VARIANCE_FORCAST_YTD === "-999999"
                            ? "-"
                            : `${decimalCurrencyFormat(
                                Number(scoreCardSBplus[0].VARIANCE_FORCAST_YTD)
                              )}%`)}
                      </span>
                    ) : (
                      <span style={{ color: "green" }}>
                        {scoreCardSBplus !== undefined &&
                          scoreCardSBplus.length !== 0 &&
                          (scoreCardSBplus[0].VARIANCE_FORCAST_YTD === "-999999"
                            ? "-"
                            : `${decimalCurrencyFormat(
                                Number(scoreCardSBplus[0].VARIANCE_FORCAST_YTD)
                              )}%`)}
                      </span>
                    )}
                  </td>{" "}
                </>
              )}
            </tr>
            <tr>
              {" "}
              <th>
                Credit Card Sign-Ups{" "}
                {gettooltip(
                  "CreditCardSignUpsStoreInfoIcon",
                  "CreditCardSignUpsStore",
                  "CreditCardSignUpsStore",
                  "Number of Credit card customers who signed up in-store in the period"
                )}
              </th>{" "}
              {loading.stcs ? (
                <>
                  <LoaderForRow tdCount={10} />
                </>
              ) : (
                <>
                  <td>
                    {scoreCardStcs !== undefined &&
                      scoreCardStcs.length !== 0 &&
                      (scoreCardStcs[0].GOAL_FORCAST_LM === "-999999"
                        ? "-"
                        : currencyFormat(
                            Number(scoreCardStcs[0].GOAL_FORCAST_LM)
                          ))}
                  </td>{" "}
                  <td>
                    {scoreCardStcs !== undefined &&
                      scoreCardStcs.length !== 0 &&
                      (scoreCardStcs[0].CUST_CNT_LM_TY === "-999999"
                        ? "-"
                        : currencyFormat(
                            Number(scoreCardStcs[0].CUST_CNT_LM_TY)
                          ))}
                  </td>{" "}
                  <td>
                    {scoreCardStcs !== undefined &&
                      scoreCardStcs.length !== 0 &&
                      (scoreCardStcs[0].CUST_CNT_LM_LY === "-999999"
                        ? "-"
                        : currencyFormat(
                            Number(scoreCardStcs[0].CUST_CNT_LM_LY)
                          ))}
                  </td>{" "}
                  <td>
                    {scoreCardStcs !== undefined &&
                    scoreCardStcs.length !== 0 &&
                    Number(scoreCardStcs[0].CUST_CNT_LM_TY_VS_LY)
                      .toFixed(2)
                      .includes("-") ? (
                      <span style={{ color: "red" }}>
                        {scoreCardStcs !== undefined &&
                          scoreCardStcs.length !== 0 &&
                          (scoreCardStcs[0].CUST_CNT_LM_TY_VS_LY === "-999999"
                            ? "-"
                            : `${decimalCurrencyFormat(
                                Number(scoreCardStcs[0].CUST_CNT_LM_TY_VS_LY)
                              )}%`)}
                      </span>
                    ) : (
                      <span style={{ color: "green" }}>
                        {scoreCardStcs !== undefined &&
                          scoreCardStcs.length !== 0 &&
                          (scoreCardStcs[0].CUST_CNT_LM_TY_VS_LY === "-999999"
                            ? "-"
                            : `${decimalCurrencyFormat(
                                Number(scoreCardStcs[0].CUST_CNT_LM_TY_VS_LY)
                              )}%`)}
                      </span>
                    )}
                  </td>{" "}
                  <td>
                    {scoreCardStcs !== undefined &&
                    scoreCardStcs.length !== 0 &&
                    Number(scoreCardStcs[0].VARIANCE_FORCAST_LM)
                      .toFixed(2)
                      .includes("-") ? (
                      <span style={{ color: "red" }}>
                        {scoreCardStcs !== undefined &&
                          scoreCardStcs.length !== 0 &&
                          (scoreCardStcs[0].VARIANCE_FORCAST_LM === "-999999"
                            ? "-"
                            : `${decimalCurrencyFormat(
                                Number(scoreCardStcs[0].VARIANCE_FORCAST_LM)
                              )}%`)}
                      </span>
                    ) : (
                      <span style={{ color: "green" }}>
                        {scoreCardStcs !== undefined &&
                          scoreCardStcs.length !== 0 &&
                          (scoreCardStcs[0].VARIANCE_FORCAST_LM === "-999999"
                            ? "-"
                            : `${decimalCurrencyFormat(
                                Number(scoreCardStcs[0].VARIANCE_FORCAST_LM)
                              )}%`)}
                      </span>
                    )}
                  </td>{" "}
                  <td>
                    {scoreCardStcs !== undefined &&
                      scoreCardStcs.length !== 0 &&
                      (scoreCardStcs[0].GOAL_FORCAST_YTD === "-999999"
                        ? "-"
                        : currencyFormat(
                            Number(scoreCardStcs[0].GOAL_FORCAST_YTD)
                          ))}
                  </td>{" "}
                  <td>
                    {scoreCardStcs !== undefined &&
                      scoreCardStcs.length !== 0 &&
                      (scoreCardStcs[0].CUST_CNT_YTD_TY === "-999999"
                        ? "-"
                        : currencyFormat(
                            Number(scoreCardStcs[0].CUST_CNT_YTD_TY)
                          ))}
                  </td>{" "}
                  <td>
                    {scoreCardStcs !== undefined &&
                      scoreCardStcs.length !== 0 &&
                      (scoreCardStcs[0].CUST_CNT_YTD_LY === "-999999"
                        ? "-"
                        : currencyFormat(
                            Number(scoreCardStcs[0].CUST_CNT_YTD_LY)
                          ))}
                  </td>{" "}
                  <td>
                    {scoreCardStcs !== undefined &&
                    scoreCardStcs.length !== 0 &&
                    Number(scoreCardStcs[0].CUST_CNT_YTD_TY_VS_LY)
                      .toFixed(2)
                      .includes("-") ? (
                      <span style={{ color: "red" }}>
                        {scoreCardStcs !== undefined &&
                          scoreCardStcs.length !== 0 &&
                          (scoreCardStcs[0].CUST_CNT_YTD_TY_VS_LY === "-999999"
                            ? "-"
                            : `${decimalCurrencyFormat(
                                Number(scoreCardStcs[0].CUST_CNT_YTD_TY_VS_LY)
                              )}%`)}
                      </span>
                    ) : (
                      <span style={{ color: "green" }}>
                        {scoreCardStcs !== undefined &&
                          scoreCardStcs.length !== 0 &&
                          (scoreCardStcs[0].CUST_CNT_YTD_TY_VS_LY === "-999999"
                            ? "-"
                            : `${decimalCurrencyFormat(
                                Number(scoreCardStcs[0].CUST_CNT_YTD_TY_VS_LY)
                              )}%`)}
                      </span>
                    )}
                  </td>{" "}
                  <td>
                    {scoreCardStcs !== undefined &&
                    scoreCardStcs.length !== 0 &&
                    Number(scoreCardStcs[0].VARIANCE_FORCAST_YTD)
                      .toFixed(2)
                      .includes("-") ? (
                      <span style={{ color: "red" }}>
                        {scoreCardStcs !== undefined &&
                          scoreCardStcs.length !== 0 &&
                          (scoreCardStcs[0].VARIANCE_FORCAST_YTD === "-999999"
                            ? "-"
                            : `${decimalCurrencyFormat(
                                Number(scoreCardStcs[0].VARIANCE_FORCAST_YTD)
                              )}%`)}
                      </span>
                    ) : (
                      <span style={{ color: "green" }}>
                        {scoreCardStcs !== undefined &&
                          scoreCardStcs.length !== 0 &&
                          (scoreCardStcs[0].VARIANCE_FORCAST_YTD === "-999999"
                            ? "-"
                            : `${decimalCurrencyFormat(
                                Number(scoreCardStcs[0].VARIANCE_FORCAST_YTD)
                              )}%`)}
                      </span>
                    )}
                  </td>{" "}
                </>
              )}
            </tr>
            <tr>
              {" "}
              <th>
                Welcome{" "}
                {gettooltip(
                  "WelcomeInfoIcon",
                  "Welcome",
                  "Welcome",
                  "Number of loyalty members who signed up in",
                  "store for Welcome membership in the period "
                )}
              </th>{" "}
              {loading.storeWelcome ? (
                <>
                  <LoaderForRow tdCount={10} />
                </>
              ) : (
                <>
                  <td>
                    {scoreCardStoreWelcome !== undefined &&
                      scoreCardStoreWelcome.length !== 0 &&
                      (scoreCardStoreWelcome[0].GOAL_FORCAST_LM === "-999999"
                        ? "-"
                        : currencyFormat(
                            Number(scoreCardStoreWelcome[0].GOAL_FORCAST_LM)
                          ))}
                  </td>{" "}
                  <td>
                    {scoreCardStoreWelcome !== undefined &&
                      scoreCardStoreWelcome.length !== 0 &&
                      (scoreCardStoreWelcome[0].CUST_CNT_LM_TY === "-999999"
                        ? "-"
                        : currencyFormat(
                            Number(scoreCardStoreWelcome[0].CUST_CNT_LM_TY)
                          ))}
                  </td>{" "}
                  <td>
                    {scoreCardStoreWelcome !== undefined &&
                      scoreCardStoreWelcome.length !== 0 &&
                      (scoreCardStoreWelcome[0].CUST_CNT_LM_LY === "-999999"
                        ? "-"
                        : currencyFormat(
                            Number(scoreCardStoreWelcome[0].CUST_CNT_LM_LY)
                          ))}
                  </td>{" "}
                  <td>
                    {scoreCardStoreWelcome !== undefined &&
                    scoreCardStoreWelcome.length !== 0 &&
                    Number(scoreCardStoreWelcome[0].CUST_CNT_LM_TY_VS_LY)
                      .toFixed(2)
                      .includes("-") ? (
                      <span style={{ color: "red" }}>
                        {scoreCardStoreWelcome !== undefined &&
                          scoreCardStoreWelcome.length !== 0 &&
                          (scoreCardStoreWelcome[0].CUST_CNT_LM_TY_VS_LY ===
                          "-999999"
                            ? "-"
                            : `${decimalCurrencyFormat(
                                Number(
                                  scoreCardStoreWelcome[0].CUST_CNT_LM_TY_VS_LY
                                )
                              )}%`)}
                      </span>
                    ) : (
                      <span style={{ color: "green" }}>
                        {scoreCardStoreWelcome !== undefined &&
                          scoreCardStoreWelcome.length !== 0 &&
                          (scoreCardStoreWelcome[0].CUST_CNT_LM_TY_VS_LY ===
                          "-999999"
                            ? "-"
                            : `${decimalCurrencyFormat(
                                Number(
                                  scoreCardStoreWelcome[0].CUST_CNT_LM_TY_VS_LY
                                )
                              )}%`)}
                      </span>
                    )}
                  </td>{" "}
                  <td>
                    {scoreCardStoreWelcome !== undefined &&
                    scoreCardStoreWelcome.length !== 0 &&
                    Number(scoreCardStoreWelcome[0].VARIANCE_FORCAST_LM)
                      .toFixed(2)
                      .includes("-") ? (
                      <span style={{ color: "red" }}>
                        {scoreCardStoreWelcome !== undefined &&
                          scoreCardStoreWelcome.length !== 0 &&
                          (scoreCardStoreWelcome[0].VARIANCE_FORCAST_LM ===
                          "-999999"
                            ? "-"
                            : `${decimalCurrencyFormat(
                                Number(
                                  scoreCardStoreWelcome[0].VARIANCE_FORCAST_LM
                                )
                              )}%`)}
                      </span>
                    ) : (
                      <span style={{ color: "green" }}>
                        {scoreCardStoreWelcome !== undefined &&
                          scoreCardStoreWelcome.length !== 0 &&
                          (scoreCardStoreWelcome[0].VARIANCE_FORCAST_LM ===
                          "-999999"
                            ? "-"
                            : `${decimalCurrencyFormat(
                                Number(
                                  scoreCardStoreWelcome[0].VARIANCE_FORCAST_LM
                                )
                              )}%`)}
                      </span>
                    )}
                  </td>{" "}
                  <td>
                    {scoreCardStoreWelcome !== undefined &&
                      scoreCardStoreWelcome.length !== 0 &&
                      (scoreCardStoreWelcome[0].GOAL_FORCAST_YTD === "-999999"
                        ? "-"
                        : currencyFormat(
                            Number(scoreCardStoreWelcome[0].GOAL_FORCAST_YTD)
                          ))}
                  </td>{" "}
                  <td>
                    {scoreCardStoreWelcome !== undefined &&
                      scoreCardStoreWelcome.length !== 0 &&
                      (scoreCardStoreWelcome[0].CUST_CNT_YTD_TY === "-999999"
                        ? "-"
                        : currencyFormat(
                            Number(scoreCardStoreWelcome[0].CUST_CNT_YTD_TY)
                          ))}
                  </td>{" "}
                  <td>
                    {scoreCardStoreWelcome !== undefined &&
                      scoreCardStoreWelcome.length !== 0 &&
                      (scoreCardStoreWelcome[0].CUST_CNT_YTD_LY === "-999999"
                        ? "-"
                        : currencyFormat(
                            Number(scoreCardStoreWelcome[0].CUST_CNT_YTD_LY)
                          ))}
                  </td>{" "}
                  <td>
                    {scoreCardStoreWelcome !== undefined &&
                    scoreCardStoreWelcome.length !== 0 &&
                    Number(scoreCardStoreWelcome[0].CUST_CNT_YTD_TY_VS_LY)
                      .toFixed(2)
                      .includes("-") ? (
                      <span style={{ color: "red" }}>
                        {scoreCardStoreWelcome !== undefined &&
                          scoreCardStoreWelcome.length !== 0 &&
                          (scoreCardStoreWelcome[0].CUST_CNT_YTD_TY_VS_LY ===
                          "-999999"
                            ? "-"
                            : `${decimalCurrencyFormat(
                                Number(
                                  scoreCardStoreWelcome[0].CUST_CNT_YTD_TY_VS_LY
                                )
                              )}%`)}
                      </span>
                    ) : (
                      <span style={{ color: "green" }}>
                        {scoreCardStoreWelcome !== undefined &&
                          scoreCardStoreWelcome.length !== 0 &&
                          (scoreCardStoreWelcome[0].CUST_CNT_YTD_TY_VS_LY ===
                          "-999999"
                            ? "-"
                            : `${decimalCurrencyFormat(
                                Number(
                                  scoreCardStoreWelcome[0].CUST_CNT_YTD_TY_VS_LY
                                )
                              )}%`)}
                      </span>
                    )}
                  </td>{" "}
                  <td>
                    {scoreCardStoreWelcome !== undefined &&
                    scoreCardStoreWelcome.length !== 0 &&
                    Number(scoreCardStoreWelcome[0].VARIANCE_FORCAST_YTD)
                      .toFixed(2)
                      .includes("-") ? (
                      <span style={{ color: "red" }}>
                        {scoreCardStoreWelcome !== undefined &&
                          scoreCardStoreWelcome.length !== 0 &&
                          (scoreCardStoreWelcome[0].VARIANCE_FORCAST_YTD ===
                          "-999999"
                            ? "-"
                            : `${decimalCurrencyFormat(
                                Number(
                                  scoreCardStoreWelcome[0].VARIANCE_FORCAST_YTD
                                )
                              )}%`)}
                      </span>
                    ) : (
                      <span style={{ color: "green" }}>
                        {scoreCardStoreWelcome !== undefined &&
                          scoreCardStoreWelcome.length !== 0 &&
                          (scoreCardStoreWelcome[0].VARIANCE_FORCAST_YTD ===
                          "-999999"
                            ? "-"
                            : `${decimalCurrencyFormat(
                                Number(
                                  scoreCardStoreWelcome[0].VARIANCE_FORCAST_YTD
                                )
                              )}%`)}
                      </span>
                    )}
                  </td>{" "}
                </>
              )}
            </tr>
            <tr>
              {" "}
              <th>
                Welcome+{" "}
                {gettooltip(
                  "WelcomePlusInfoIcon",
                  "WelcomePlus",
                  "WelcomePlus",
                  "Number of loyalty members who signed up in",
                  "store for Welcome+ membership in the period "
                )}
              </th>{" "}
              {loading.storeWelcomePlus ? (
                <>
                  <LoaderForRow tdCount={10} />
                </>
              ) : (
                <>
                  <td>
                    {scoreCardStoreWelcomePlus !== undefined &&
                      scoreCardStoreWelcomePlus.length !== 0 &&
                      (scoreCardStoreWelcomePlus[0].GOAL_FORCAST_LM ===
                      "-999999"
                        ? "-"
                        : currencyFormat(
                            Number(scoreCardStoreWelcomePlus[0].GOAL_FORCAST_LM)
                          ))}
                  </td>{" "}
                  <td>
                    {scoreCardStoreWelcomePlus !== undefined &&
                      scoreCardStoreWelcomePlus.length !== 0 &&
                      (scoreCardStoreWelcomePlus[0].CUST_CNT_LM_TY === "-999999"
                        ? "-"
                        : currencyFormat(
                            Number(scoreCardStoreWelcomePlus[0].CUST_CNT_LM_TY)
                          ))}
                  </td>{" "}
                  <td>
                    {scoreCardStoreWelcomePlus !== undefined &&
                      scoreCardStoreWelcomePlus.length !== 0 &&
                      (scoreCardStoreWelcomePlus[0].CUST_CNT_LM_LY === "-999999"
                        ? "-"
                        : currencyFormat(
                            Number(scoreCardStoreWelcomePlus[0].CUST_CNT_LM_LY)
                          ))}
                  </td>{" "}
                  <td>
                    {scoreCardStoreWelcomePlus !== undefined &&
                    scoreCardStoreWelcomePlus.length !== 0 &&
                    Number(scoreCardStoreWelcomePlus[0].CUST_CNT_LM_TY_VS_LY)
                      .toFixed(2)
                      .includes("-") ? (
                      <span style={{ color: "red" }}>
                        {scoreCardStoreWelcomePlus !== undefined &&
                          scoreCardStoreWelcomePlus.length !== 0 &&
                          (scoreCardStoreWelcomePlus[0].CUST_CNT_LM_TY_VS_LY ===
                          "-999999"
                            ? "-"
                            : `${decimalCurrencyFormat(
                                Number(
                                  scoreCardStoreWelcomePlus[0]
                                    .CUST_CNT_LM_TY_VS_LY
                                )
                              )}%`)}
                      </span>
                    ) : (
                      <span style={{ color: "green" }}>
                        {scoreCardStoreWelcomePlus !== undefined &&
                          scoreCardStoreWelcomePlus.length !== 0 &&
                          (scoreCardStoreWelcomePlus[0].CUST_CNT_LM_TY_VS_LY ===
                          "-999999"
                            ? "-"
                            : `${decimalCurrencyFormat(
                                Number(
                                  scoreCardStoreWelcomePlus[0]
                                    .CUST_CNT_LM_TY_VS_LY
                                )
                              )}%`)}
                      </span>
                    )}
                  </td>{" "}
                  <td>
                    {scoreCardStoreWelcomePlus !== undefined &&
                    scoreCardStoreWelcomePlus.length !== 0 &&
                    Number(scoreCardStoreWelcomePlus[0].VARIANCE_FORCAST_LM)
                      .toFixed(2)
                      .includes("-") ? (
                      <span style={{ color: "red" }}>
                        {scoreCardStoreWelcomePlus !== undefined &&
                          scoreCardStoreWelcomePlus.length !== 0 &&
                          (scoreCardStoreWelcomePlus[0].VARIANCE_FORCAST_LM ===
                          "-999999"
                            ? "-"
                            : `${decimalCurrencyFormat(
                                Number(
                                  scoreCardStoreWelcomePlus[0]
                                    .VARIANCE_FORCAST_LM
                                )
                              )}%`)}
                      </span>
                    ) : (
                      <span style={{ color: "green" }}>
                        {scoreCardStoreWelcomePlus !== undefined &&
                          scoreCardStoreWelcomePlus.length !== 0 &&
                          (scoreCardStoreWelcomePlus[0].VARIANCE_FORCAST_LM ===
                          "-999999"
                            ? "-"
                            : `${decimalCurrencyFormat(
                                Number(
                                  scoreCardStoreWelcomePlus[0]
                                    .VARIANCE_FORCAST_LM
                                )
                              )}%`)}
                      </span>
                    )}
                  </td>{" "}
                  <td>
                    {scoreCardStoreWelcomePlus !== undefined &&
                      scoreCardStoreWelcomePlus.length !== 0 &&
                      (scoreCardStoreWelcomePlus[0].GOAL_FORCAST_YTD ===
                      "-999999"
                        ? "-"
                        : currencyFormat(
                            Number(
                              scoreCardStoreWelcomePlus[0].GOAL_FORCAST_YTD
                            )
                          ))}
                  </td>{" "}
                  <td>
                    {scoreCardStoreWelcomePlus !== undefined &&
                      scoreCardStoreWelcomePlus.length !== 0 &&
                      (scoreCardStoreWelcomePlus[0].CUST_CNT_YTD_TY ===
                      "-999999"
                        ? "-"
                        : currencyFormat(
                            Number(scoreCardStoreWelcomePlus[0].CUST_CNT_YTD_TY)
                          ))}
                  </td>{" "}
                  <td>
                    {scoreCardStoreWelcomePlus !== undefined &&
                      scoreCardStoreWelcomePlus.length !== 0 &&
                      (scoreCardStoreWelcomePlus[0].CUST_CNT_YTD_LY ===
                      "-999999"
                        ? "-"
                        : currencyFormat(
                            Number(scoreCardStoreWelcomePlus[0].CUST_CNT_YTD_LY)
                          ))}
                  </td>{" "}
                  <td>
                    {scoreCardStoreWelcomePlus !== undefined &&
                    scoreCardStoreWelcomePlus.length !== 0 &&
                    Number(scoreCardStoreWelcomePlus[0].CUST_CNT_YTD_TY_VS_LY)
                      .toFixed(2)
                      .includes("-") ? (
                      <span style={{ color: "red" }}>
                        {scoreCardStoreWelcomePlus !== undefined &&
                          scoreCardStoreWelcomePlus.length !== 0 &&
                          (scoreCardStoreWelcomePlus[0]
                            .CUST_CNT_YTD_TY_VS_LY === "-999999"
                            ? "-"
                            : `${decimalCurrencyFormat(
                                Number(
                                  scoreCardStoreWelcomePlus[0]
                                    .CUST_CNT_YTD_TY_VS_LY
                                )
                              )}%`)}
                      </span>
                    ) : (
                      <span style={{ color: "green" }}>
                        {scoreCardStoreWelcomePlus !== undefined &&
                          scoreCardStoreWelcomePlus.length !== 0 &&
                          (scoreCardStoreWelcomePlus[0]
                            .CUST_CNT_YTD_TY_VS_LY === "-999999"
                            ? "-"
                            : `${decimalCurrencyFormat(
                                Number(
                                  scoreCardStoreWelcomePlus[0]
                                    .CUST_CNT_YTD_TY_VS_LY
                                )
                              )}%`)}
                      </span>
                    )}
                  </td>{" "}
                  <td>
                    {scoreCardStoreWelcomePlus !== undefined &&
                    scoreCardStoreWelcomePlus.length !== 0 &&
                    Number(scoreCardStoreWelcomePlus[0].VARIANCE_FORCAST_YTD)
                      .toFixed(2)
                      .includes("-") ? (
                      <span style={{ color: "red" }}>
                        {scoreCardStoreWelcomePlus !== undefined &&
                          scoreCardStoreWelcomePlus.length !== 0 &&
                          (scoreCardStoreWelcomePlus[0].VARIANCE_FORCAST_YTD ===
                          "-999999"
                            ? "-"
                            : `${decimalCurrencyFormat(
                                Number(
                                  scoreCardStoreWelcomePlus[0]
                                    .VARIANCE_FORCAST_YTD
                                )
                              )}%`)}
                      </span>
                    ) : (
                      <span style={{ color: "green" }}>
                        {scoreCardStoreWelcomePlus !== undefined &&
                          scoreCardStoreWelcomePlus.length !== 0 &&
                          (scoreCardStoreWelcomePlus[0].VARIANCE_FORCAST_YTD ===
                          "-999999"
                            ? "-"
                            : `${decimalCurrencyFormat(
                                Number(
                                  scoreCardStoreWelcomePlus[0]
                                    .VARIANCE_FORCAST_YTD
                                )
                              )}%`)}
                      </span>
                    )}
                  </td>{" "}
                </>
              )}
            </tr>
            <tr></tr>
            <tr className="align-middle">
              {" "}
              <th rowSpan="3">
                {"CHI (Customer"} <br /> {"Health Index) Score"}
              </th>
              <th>-----------------------</th> <td></td> <td></td> <td></td>{" "}
              <td></td> <td></td> <td></td> <td></td> <td></td> <td></td>{" "}
              <td></td>{" "}
            </tr>
            <tr>
              {" "}
              <th>-----------------------</th> <td></td> <td></td> <td></td>{" "}
              <td></td> <td></td> <td></td> <td></td> <td></td> <td></td>{" "}
              <td></td>{" "}
            </tr>
            <tr>
              {" "}
              <th>-----------------------</th> <td></td> <td></td> <td></td>{" "}
              <td></td> <td></td> <td></td> <td></td> <td></td> <td></td>{" "}
              <td></td>{" "}
            </tr>
            <tr></tr>
            <tr>
              <div className="spanStyleOnline">
                <span>ONLINE EXPERIENCE</span>
              </div>
            </tr>
            <tr></tr>
            <tr className="align-middle">
              {" "}
              <th rowSpan="5">{"Performance"}</th>
              <th>
                Online Visits{" "}
                {gettooltip(
                  "OnlineVisitsInfoIcon",
                  "OnlineVisits",
                  "OnlineVisits",
                  "Number of customers who visited online in the period"
                )}
              </th>{" "}
              {loading.onv ? (
                <>
                  <LoaderForRow tdCount={10} />
                </>
              ) : (
                <>
                  <td>
                    {scoreCardOnv !== undefined &&
                      scoreCardOnv.length !== 0 &&
                      (scoreCardOnv[0].GOAL_FORCAST_LM === "-999999"
                        ? "-"
                        : currencyFormat(
                            Number(scoreCardOnv[0].GOAL_FORCAST_LM)
                          ))}
                  </td>{" "}
                  <td>
                    {scoreCardOnv !== undefined &&
                      scoreCardOnv.length !== 0 &&
                      (scoreCardOnv[0].CUST_CNT_LM_TY === "-999999"
                        ? "-"
                        : currencyFormat(
                            Number(scoreCardOnv[0].CUST_CNT_LM_TY)
                          ))}
                  </td>{" "}
                  <td>
                    {scoreCardOnv !== undefined &&
                      scoreCardOnv.length !== 0 &&
                      (scoreCardOnv[0].CUST_CNT_LM_LY === "-999999"
                        ? "-"
                        : currencyFormat(
                            Number(scoreCardOnv[0].CUST_CNT_LM_LY)
                          ))}
                  </td>{" "}
                  <td>
                    {scoreCardOnv !== undefined &&
                    scoreCardOnv.length !== 0 &&
                    Number(scoreCardOnv[0].CUST_CNT_LM_TY_VS_LY)
                      .toFixed(2)
                      .includes("-") ? (
                      <span style={{ color: "red" }}>
                        {scoreCardOnv !== undefined &&
                          scoreCardOnv.length !== 0 &&
                          (scoreCardOnv[0].CUST_CNT_LM_TY_VS_LY === "-999999"
                            ? "-"
                            : `${decimalCurrencyFormat(
                                Number(scoreCardOnv[0].CUST_CNT_LM_TY_VS_LY)
                              )}%`)}
                      </span>
                    ) : (
                      <span style={{ color: "green" }}>
                        {scoreCardOnv !== undefined &&
                          scoreCardOnv.length !== 0 &&
                          (scoreCardOnv[0].CUST_CNT_LM_TY_VS_LY === "-999999"
                            ? "-"
                            : `${decimalCurrencyFormat(
                                Number(scoreCardOnv[0].CUST_CNT_LM_TY_VS_LY)
                              )}%`)}
                      </span>
                    )}
                  </td>{" "}
                  <td>
                    {scoreCardOnv !== undefined &&
                    scoreCardOnv.length !== 0 &&
                    Number(scoreCardOnv[0].VARIANCE_FORCAST_LM)
                      .toFixed(2)
                      .includes("-") ? (
                      <span style={{ color: "red" }}>
                        {scoreCardOnv !== undefined &&
                          scoreCardOnv.length !== 0 &&
                          (scoreCardOnv[0].VARIANCE_FORCAST_LM === "-999999"
                            ? "-"
                            : `${decimalCurrencyFormat(
                                Number(scoreCardOnv[0].VARIANCE_FORCAST_LM)
                              )}%`)}
                      </span>
                    ) : (
                      <span style={{ color: "green" }}>
                        {scoreCardOnv !== undefined &&
                          scoreCardOnv.length !== 0 &&
                          (scoreCardOnv[0].VARIANCE_FORCAST_LM === "-999999"
                            ? "-"
                            : `${decimalCurrencyFormat(
                                Number(scoreCardOnv[0].VARIANCE_FORCAST_LM)
                              )}%`)}
                      </span>
                    )}
                  </td>{" "}
                  <td>
                    {scoreCardOnv !== undefined &&
                      scoreCardOnv.length !== 0 &&
                      (scoreCardOnv[0].GOAL_FORCAST_YTD === "-999999"
                        ? "-"
                        : currencyFormat(
                            Number(scoreCardOnv[0].GOAL_FORCAST_YTD)
                          ))}
                  </td>{" "}
                  <td>
                    {scoreCardOnv !== undefined &&
                      scoreCardOnv.length !== 0 &&
                      (scoreCardOnv[0].CUST_CNT_YTD_TY === "-999999"
                        ? "-"
                        : currencyFormat(
                            Number(scoreCardOnv[0].CUST_CNT_YTD_TY)
                          ))}
                  </td>{" "}
                  <td>
                    {scoreCardOnv !== undefined &&
                      scoreCardOnv.length !== 0 &&
                      (scoreCardOnv[0].CUST_CNT_YTD_LY === "-999999"
                        ? "-"
                        : currencyFormat(
                            Number(scoreCardOnv[0].CUST_CNT_YTD_LY)
                          ))}
                  </td>{" "}
                  <td>
                    {scoreCardOnv !== undefined &&
                    scoreCardOnv.length !== 0 &&
                    Number(scoreCardOnv[0].CUST_CNT_YTD_TY_VS_LY)
                      .toFixed(2)
                      .includes("-") ? (
                      <span style={{ color: "red" }}>
                        {scoreCardOnv !== undefined &&
                          scoreCardOnv.length !== 0 &&
                          (scoreCardOnv[0].CUST_CNT_YTD_TY_VS_LY === "-999999"
                            ? "-"
                            : `${decimalCurrencyFormat(
                                Number(scoreCardOnv[0].CUST_CNT_YTD_TY_VS_LY)
                              )}%`)}
                      </span>
                    ) : (
                      <span style={{ color: "green" }}>
                        {scoreCardOnv !== undefined &&
                          scoreCardOnv.length !== 0 &&
                          (scoreCardOnv[0].CUST_CNT_YTD_TY_VS_LY === "-999999"
                            ? "-"
                            : `${decimalCurrencyFormat(
                                Number(scoreCardOnv[0].CUST_CNT_YTD_TY_VS_LY)
                              )}%`)}
                      </span>
                    )}
                  </td>{" "}
                  <td>
                    {scoreCardOnv !== undefined &&
                    scoreCardOnv.length !== 0 &&
                    Number(scoreCardOnv[0].VARIANCE_FORCAST_YTD)
                      .toFixed(2)
                      .includes("-") ? (
                      <span style={{ color: "red" }}>
                        {scoreCardOnv !== undefined &&
                          scoreCardOnv.length !== 0 &&
                          (scoreCardOnv[0].VARIANCE_FORCAST_YTD === "-999999"
                            ? "-"
                            : `${decimalCurrencyFormat(
                                Number(scoreCardOnv[0].VARIANCE_FORCAST_YTD)
                              )}%`)}
                      </span>
                    ) : (
                      <span style={{ color: "green" }}>
                        {scoreCardOnv !== undefined &&
                          scoreCardOnv.length !== 0 &&
                          (scoreCardOnv[0].VARIANCE_FORCAST_YTD === "-999999"
                            ? "-"
                            : `${decimalCurrencyFormat(
                                Number(scoreCardOnv[0].VARIANCE_FORCAST_YTD)
                              )}%`)}
                      </span>
                    )}
                  </td>{" "}
                </>
              )}
            </tr>
            <tr class="align-middle">
              {" "}
              <th>
                Sales Penetration <br />
                (% of total){" "}
                {gettooltip(
                  "SalesPenetInfoIcon",
                  "SalesPenet",
                  "SalesPenet",
                  "Ratio of online net sales to total net sales in the period"
                )}
              </th>
              {loading.onsp ? (
                <>
                  <LoaderForRow tdCount={10} />
                </>
              ) : (
                <>
                  <td>
                    {scoreCardOnsp !== undefined &&
                      scoreCardOnsp.length !== 0 &&
                      (scoreCardOnsp[0].GOAL_FORCAST_LM === "-999999"
                        ? "-"
                        : `${decimalCurrencyFormat(
                            Number(scoreCardOnsp[0].GOAL_FORCAST_LM)
                          )}%`)}
                  </td>{" "}
                  <td>
                    {scoreCardOnsp !== undefined &&
                      scoreCardOnsp.length !== 0 &&
                      (scoreCardOnsp[0].CUST_CNT_LM_TY === "-999999"
                        ? "-"
                        : `${decimalCurrencyFormat(
                            Number(scoreCardOnsp[0].CUST_CNT_LM_TY)
                          )}%`)}
                  </td>{" "}
                  <td>
                    {scoreCardOnsp !== undefined &&
                      scoreCardOnsp.length !== 0 &&
                      (scoreCardOnsp[0].CUST_CNT_LM_LY === "-999999"
                        ? "-"
                        : `${decimalCurrencyFormat(
                            Number(scoreCardOnsp[0].CUST_CNT_LM_LY)
                          )}%`)}
                  </td>{" "}
                  <td>
                    {scoreCardOnsp !== undefined &&
                    scoreCardOnsp.length !== 0 &&
                    Number(scoreCardOnsp[0].CUST_CNT_LM_TY_VS_LY)
                      .toFixed(2)
                      .includes("-") ? (
                      <span style={{ color: "red" }}>
                        {scoreCardOnsp !== undefined &&
                          scoreCardOnsp.length !== 0 &&
                          (scoreCardOnsp[0].CUST_CNT_LM_TY_VS_LY === "-999999"
                            ? "-"
                            : decimalCurrencyFormat(
                                Number(scoreCardOnsp[0].CUST_CNT_LM_TY_VS_LY)
                              ))}
                      </span>
                    ) : (
                      <span style={{ color: "green" }}>
                        {scoreCardOnsp !== undefined &&
                          scoreCardOnsp.length !== 0 &&
                          (scoreCardOnsp[0].CUST_CNT_LM_TY_VS_LY === "-999999"
                            ? "-"
                            : decimalCurrencyFormat(
                                Number(scoreCardOnsp[0].CUST_CNT_LM_TY_VS_LY)
                              ))}
                      </span>
                    )}
                  </td>{" "}
                  <td>
                    {scoreCardOnsp !== undefined &&
                    scoreCardOnsp.length !== 0 &&
                    Number(scoreCardOnsp[0].VARIANCE_FORCAST_LM)
                      .toFixed(2)
                      .includes("-") ? (
                      <span style={{ color: "red" }}>
                        {scoreCardOnsp !== undefined &&
                          scoreCardOnsp.length !== 0 &&
                          (scoreCardOnsp[0].VARIANCE_FORCAST_LM === "-999999"
                            ? "-"
                            : decimalCurrencyFormat(
                                Number(scoreCardOnsp[0].VARIANCE_FORCAST_LM)
                              ))}
                      </span>
                    ) : (
                      <span style={{ color: "green" }}>
                        {scoreCardOnsp !== undefined &&
                          scoreCardOnsp.length !== 0 &&
                          (scoreCardOnsp[0].VARIANCE_FORCAST_LM === "-999999"
                            ? "-"
                            : decimalCurrencyFormat(
                                Number(scoreCardOnsp[0].VARIANCE_FORCAST_LM)
                              ))}
                      </span>
                    )}
                  </td>{" "}
                  <td>
                    {scoreCardOnsp !== undefined &&
                      scoreCardOnsp.length !== 0 &&
                      (scoreCardOnsp[0].GOAL_FORCAST_YTD === "-999999"
                        ? "-"
                        : `${decimalCurrencyFormat(
                            Number(scoreCardOnsp[0].GOAL_FORCAST_YTD)
                          )}%`)}
                  </td>{" "}
                  <td>
                    {scoreCardOnsp !== undefined &&
                      scoreCardOnsp.length !== 0 &&
                      (scoreCardOnsp[0].CUST_CNT_YTD_TY === "-999999"
                        ? "-"
                        : `${decimalCurrencyFormat(
                            Number(scoreCardOnsp[0].CUST_CNT_YTD_TY)
                          )}%`)}
                  </td>{" "}
                  <td>
                    {scoreCardOnsp !== undefined &&
                      scoreCardOnsp.length !== 0 &&
                      (scoreCardOnsp[0].CUST_CNT_YTD_LY === "-999999"
                        ? "-"
                        : `${decimalCurrencyFormat(
                            Number(scoreCardOnsp[0].CUST_CNT_YTD_LY)
                          )}%`)}
                  </td>{" "}
                  <td>
                    {scoreCardOnsp !== undefined &&
                    scoreCardOnsp.length !== 0 &&
                    Number(scoreCardOnsp[0].CUST_CNT_YTD_TY_VS_LY)
                      .toFixed(2)
                      .includes("-") ? (
                      <span style={{ color: "red" }}>
                        {scoreCardOnsp !== undefined &&
                          scoreCardOnsp.length !== 0 &&
                          (scoreCardOnsp[0].CUST_CNT_YTD_TY_VS_LY === "-999999"
                            ? "-"
                            : decimalCurrencyFormat(
                                Number(scoreCardOnsp[0].CUST_CNT_YTD_TY_VS_LY)
                              ))}
                      </span>
                    ) : (
                      <span style={{ color: "green" }}>
                        {scoreCardOnsp !== undefined &&
                          scoreCardOnsp.length !== 0 &&
                          (scoreCardOnsp[0].CUST_CNT_YTD_TY_VS_LY === "-999999"
                            ? "-"
                            : decimalCurrencyFormat(
                                Number(scoreCardOnsp[0].CUST_CNT_YTD_TY_VS_LY)
                              ))}
                      </span>
                    )}
                  </td>{" "}
                  <td>
                    {scoreCardOnsp !== undefined &&
                    scoreCardOnsp.length !== 0 &&
                    Number(scoreCardOnsp[0].VARIANCE_FORCAST_YTD)
                      .toFixed(2)
                      .includes("-") ? (
                      <span style={{ color: "red" }}>
                        {scoreCardOnsp !== undefined &&
                          scoreCardOnsp.length !== 0 &&
                          (scoreCardOnsp[0].VARIANCE_FORCAST_YTD === "-999999"
                            ? "-"
                            : decimalCurrencyFormat(
                                Number(scoreCardOnsp[0].VARIANCE_FORCAST_YTD)
                              ))}
                      </span>
                    ) : (
                      <span style={{ color: "green" }}>
                        {scoreCardOnsp !== undefined &&
                          scoreCardOnsp.length !== 0 &&
                          (scoreCardOnsp[0].VARIANCE_FORCAST_YTD === "-999999"
                            ? "-"
                            : decimalCurrencyFormat(
                                Number(scoreCardOnsp[0].VARIANCE_FORCAST_YTD)
                              ))}
                      </span>
                    )}
                  </td>{" "}
                </>
              )}
            </tr>
            <tr>
              {" "}
              <th>
                Cart Addition Rate{" "}
                {gettooltip(
                  "CARInfoIcon",
                  "CAR",
                  "CAR",
                  "Ratio of number of cart additions to online visits in the period"
                )}
              </th>
              {loading.car ? (
                <>
                  <LoaderForRow tdCount={10} />
                </>
              ) : (
                <>
                  <td>
                    {scoreCardCar !== undefined &&
                      scoreCardCar.length !== 0 &&
                      (scoreCardCar[0].GOAL_FORCAST_LM === "-999999"
                        ? "-"
                        : `${decimalCurrencyFormat(
                            Number(scoreCardCar[0].GOAL_FORCAST_LM)
                          )}%`)}
                  </td>{" "}
                  <td>
                    {scoreCardCar !== undefined &&
                      scoreCardCar.length !== 0 &&
                      (scoreCardCar[0].CUST_CNT_LM_TY === "-999999"
                        ? "-"
                        : `${decimalCurrencyFormat(
                            Number(scoreCardCar[0].CUST_CNT_LM_TY)
                          )}%`)}
                  </td>{" "}
                  <td>
                    {scoreCardCar !== undefined &&
                      scoreCardCar.length !== 0 &&
                      (scoreCardCar[0].CUST_CNT_LM_LY === "-999999"
                        ? "-"
                        : `${decimalCurrencyFormat(
                            Number(scoreCardCar[0].CUST_CNT_LM_LY)
                          )}%`)}
                  </td>{" "}
                  <td>
                    {scoreCardCar !== undefined &&
                    scoreCardCar.length !== 0 &&
                    Number(scoreCardCar[0].CUST_CNT_LM_TY_VS_LY)
                      .toFixed(2)
                      .includes("-") ? (
                      <span style={{ color: "red" }}>
                        {scoreCardCar !== undefined &&
                          scoreCardCar.length !== 0 &&
                          (scoreCardCar[0].CUST_CNT_LM_TY_VS_LY === "-999999"
                            ? "-"
                            : decimalCurrencyFormat(
                                Number(scoreCardCar[0].CUST_CNT_LM_TY_VS_LY)
                              ))}
                      </span>
                    ) : (
                      <span style={{ color: "green" }}>
                        {scoreCardCar !== undefined &&
                          scoreCardCar.length !== 0 &&
                          (scoreCardCar[0].CUST_CNT_LM_TY_VS_LY === "-999999"
                            ? "-"
                            : decimalCurrencyFormat(
                                Number(scoreCardCar[0].CUST_CNT_LM_TY_VS_LY)
                              ))}
                      </span>
                    )}
                  </td>{" "}
                  <td>
                    {scoreCardCar !== undefined &&
                    scoreCardCar.length !== 0 &&
                    Number(scoreCardCar[0].VARIANCE_FORCAST_LM)
                      .toFixed(2)
                      .includes("-") ? (
                      <span style={{ color: "red" }}>
                        {scoreCardCar !== undefined &&
                          scoreCardCar.length !== 0 &&
                          (scoreCardCar[0].VARIANCE_FORCAST_LM === "-999999"
                            ? "-"
                            : decimalCurrencyFormat(
                                Number(scoreCardCar[0].VARIANCE_FORCAST_LM)
                              ))}
                      </span>
                    ) : (
                      <span style={{ color: "green" }}>
                        {scoreCardCar !== undefined &&
                          scoreCardCar.length !== 0 &&
                          (scoreCardCar[0].VARIANCE_FORCAST_LM === "-999999"
                            ? "-"
                            : decimalCurrencyFormat(
                                Number(scoreCardCar[0].VARIANCE_FORCAST_LM)
                              ))}
                      </span>
                    )}
                  </td>{" "}
                  <td>
                    {scoreCardCar !== undefined &&
                      scoreCardCar.length !== 0 &&
                      (scoreCardCar[0].GOAL_FORCAST_YTD === "-999999"
                        ? "-"
                        : `${decimalCurrencyFormat(
                            Number(scoreCardCar[0].GOAL_FORCAST_YTD)
                          )}%`)}
                  </td>{" "}
                  <td>
                    {scoreCardCar !== undefined &&
                      scoreCardCar.length !== 0 &&
                      (scoreCardCar[0].CUST_CNT_YTD_TY === "-999999"
                        ? "-"
                        : `${decimalCurrencyFormat(
                            Number(scoreCardCar[0].CUST_CNT_YTD_TY)
                          )}%`)}
                  </td>{" "}
                  <td>
                    {scoreCardCar !== undefined &&
                      scoreCardCar.length !== 0 &&
                      (scoreCardCar[0].CUST_CNT_YTD_LY === "-999999"
                        ? "-"
                        : `${decimalCurrencyFormat(
                            Number(scoreCardCar[0].CUST_CNT_YTD_LY)
                          )}%`)}
                  </td>{" "}
                  <td>
                    {scoreCardCar !== undefined &&
                    scoreCardCar.length !== 0 &&
                    Number(scoreCardCar[0].CUST_CNT_YTD_TY_VS_LY)
                      .toFixed(2)
                      .includes("-") ? (
                      <span style={{ color: "red" }}>
                        {scoreCardCar !== undefined &&
                          scoreCardCar.length !== 0 &&
                          (scoreCardCar[0].CUST_CNT_YTD_TY_VS_LY === "-999999"
                            ? "-"
                            : decimalCurrencyFormat(
                                Number(scoreCardCar[0].CUST_CNT_YTD_TY_VS_LY)
                              ))}
                      </span>
                    ) : (
                      <span style={{ color: "green" }}>
                        {scoreCardCar !== undefined &&
                          scoreCardCar.length !== 0 &&
                          (scoreCardCar[0].CUST_CNT_YTD_TY_VS_LY === "-999999"
                            ? "-"
                            : decimalCurrencyFormat(
                                Number(scoreCardCar[0].CUST_CNT_YTD_TY_VS_LY)
                              ))}
                      </span>
                    )}
                  </td>{" "}
                  <td>
                    {scoreCardCar !== undefined &&
                    scoreCardCar.length !== 0 &&
                    Number(scoreCardCar[0].VARIANCE_FORCAST_YTD)
                      .toFixed(2)
                      .includes("-") ? (
                      <span style={{ color: "red" }}>
                        {scoreCardCar !== undefined &&
                          scoreCardCar.length !== 0 &&
                          (scoreCardCar[0].VARIANCE_FORCAST_YTD === "-999999"
                            ? "-"
                            : decimalCurrencyFormat(
                                Number(scoreCardCar[0].VARIANCE_FORCAST_YTD)
                              ))}
                      </span>
                    ) : (
                      <span style={{ color: "green" }}>
                        {scoreCardCar !== undefined &&
                          scoreCardCar.length !== 0 &&
                          (scoreCardCar[0].VARIANCE_FORCAST_YTD === "-999999"
                            ? "-"
                            : decimalCurrencyFormat(
                                Number(scoreCardCar[0].VARIANCE_FORCAST_YTD)
                              ))}
                      </span>
                    )}
                  </td>{" "}
                </>
              )}{" "}
            </tr>
            <tr>
              {" "}
              <th>
                Conversion Rate{" "}
                {gettooltip(
                  "ConversionRatesInfoIcon",
                  "ConversionRates",
                  "ConversionRates",
                  "Ratio of customers who shopped online to online visits in the period "
                )}
              </th>{" "}
              {loading.oncr ? (
                <>
                  <LoaderForRow tdCount={10} />
                </>
              ) : (
                <>
                  <td>
                    {scoreCardOncr !== undefined &&
                      scoreCardOncr.length !== 0 &&
                      (scoreCardOncr[0].GOAL_FORCAST_LM === "-999999"
                        ? "-"
                        : `${decimalCurrencyFormat(
                            Number(scoreCardOncr[0].GOAL_FORCAST_LM)
                          )}%`)}
                  </td>{" "}
                  <td>
                    {scoreCardOncr !== undefined &&
                      scoreCardOncr.length !== 0 &&
                      (scoreCardOncr[0].CUST_CNT_LM_TY === "-999999"
                        ? "-"
                        : `${decimalCurrencyFormat(
                            Number(scoreCardOncr[0].CUST_CNT_LM_TY)
                          )}%`)}
                  </td>{" "}
                  <td>
                    {scoreCardOncr !== undefined &&
                      scoreCardOncr.length !== 0 &&
                      (scoreCardOncr[0].CUST_CNT_LM_LY === "-999999"
                        ? "-"
                        : `${decimalCurrencyFormat(
                            Number(scoreCardOncr[0].CUST_CNT_LM_LY)
                          )}%`)}
                  </td>{" "}
                  <td>
                    {scoreCardOncr !== undefined &&
                    scoreCardOncr.length !== 0 &&
                    Number(scoreCardOncr[0].CUST_CNT_LM_TY_VS_LY)
                      .toFixed(2)
                      .includes("-") ? (
                      <span style={{ color: "red" }}>
                        {scoreCardOncr !== undefined &&
                          scoreCardOncr.length !== 0 &&
                          (scoreCardOncr[0].CUST_CNT_LM_TY_VS_LY === "-999999"
                            ? "-"
                            : decimalCurrencyFormat(
                                Number(scoreCardOncr[0].CUST_CNT_LM_TY_VS_LY)
                              ))}
                      </span>
                    ) : (
                      <span style={{ color: "green" }}>
                        {scoreCardOncr !== undefined &&
                          scoreCardOncr.length !== 0 &&
                          (scoreCardOncr[0].CUST_CNT_LM_TY_VS_LY === "-999999"
                            ? "-"
                            : decimalCurrencyFormat(
                                Number(scoreCardOncr[0].CUST_CNT_LM_TY_VS_LY)
                              ))}
                      </span>
                    )}
                  </td>{" "}
                  <td>
                    {scoreCardOncr !== undefined &&
                    scoreCardOncr.length !== 0 &&
                    Number(scoreCardOncr[0].VARIANCE_FORCAST_LM)
                      .toFixed(2)
                      .includes("-") ? (
                      <span style={{ color: "red" }}>
                        {scoreCardOncr !== undefined &&
                          scoreCardOncr.length !== 0 &&
                          (scoreCardOncr[0].VARIANCE_FORCAST_LM === "-999999"
                            ? "-"
                            : decimalCurrencyFormat(
                                Number(scoreCardOncr[0].VARIANCE_FORCAST_LM)
                              ))}
                      </span>
                    ) : (
                      <span style={{ color: "green" }}>
                        {scoreCardOncr !== undefined &&
                          scoreCardOncr.length !== 0 &&
                          (scoreCardOncr[0].VARIANCE_FORCAST_LM === "-999999"
                            ? "-"
                            : decimalCurrencyFormat(
                                Number(scoreCardOncr[0].VARIANCE_FORCAST_LM)
                              ))}
                      </span>
                    )}
                  </td>{" "}
                  <td>
                    {scoreCardOncr !== undefined &&
                      scoreCardOncr.length !== 0 &&
                      (scoreCardOncr[0].GOAL_FORCAST_YTD === "-999999"
                        ? "-"
                        : `${decimalCurrencyFormat(
                            Number(scoreCardOncr[0].GOAL_FORCAST_YTD)
                          )}%`)}
                  </td>{" "}
                  <td>
                    {scoreCardOncr !== undefined &&
                      scoreCardOncr.length !== 0 &&
                      (scoreCardOncr[0].CUST_CNT_YTD_TY === "-999999"
                        ? "-"
                        : `${decimalCurrencyFormat(
                            Number(scoreCardOncr[0].CUST_CNT_YTD_TY)
                          )}%`)}
                  </td>{" "}
                  <td>
                    {scoreCardOncr !== undefined &&
                      scoreCardOncr.length !== 0 &&
                      (scoreCardOncr[0].CUST_CNT_YTD_LY === "-999999"
                        ? "-"
                        : `${decimalCurrencyFormat(
                            Number(scoreCardOncr[0].CUST_CNT_YTD_LY)
                          )}%`)}
                  </td>{" "}
                  <td>
                    {scoreCardOncr !== undefined &&
                    scoreCardOncr.length !== 0 &&
                    Number(scoreCardOncr[0].CUST_CNT_YTD_TY_VS_LY)
                      .toFixed(2)
                      .includes("-") ? (
                      <span style={{ color: "red" }}>
                        {scoreCardOncr !== undefined &&
                          scoreCardOncr.length !== 0 &&
                          (scoreCardOncr[0].CUST_CNT_YTD_TY_VS_LY === "-999999"
                            ? "-"
                            : decimalCurrencyFormat(
                                Number(scoreCardOncr[0].CUST_CNT_YTD_TY_VS_LY)
                              ))}
                      </span>
                    ) : (
                      <span style={{ color: "green" }}>
                        {scoreCardOncr !== undefined &&
                          scoreCardOncr.length !== 0 &&
                          (scoreCardOncr[0].CUST_CNT_YTD_TY_VS_LY === "-999999"
                            ? "-"
                            : decimalCurrencyFormat(
                                Number(scoreCardOncr[0].CUST_CNT_YTD_TY_VS_LY)
                              ))}
                      </span>
                    )}
                  </td>{" "}
                  <td>
                    {scoreCardOncr !== undefined &&
                    scoreCardOncr.length !== 0 &&
                    Number(scoreCardOncr[0].VARIANCE_FORCAST_YTD)
                      .toFixed(2)
                      .includes("-") ? (
                      <span style={{ color: "red" }}>
                        {scoreCardOncr !== undefined &&
                          scoreCardOncr.length !== 0 &&
                          (scoreCardOncr[0].VARIANCE_FORCAST_YTD === "-999999"
                            ? "-"
                            : decimalCurrencyFormat(
                                Number(scoreCardOncr[0].VARIANCE_FORCAST_YTD)
                              ))}
                      </span>
                    ) : (
                      <span style={{ color: "green" }}>
                        {scoreCardOncr !== undefined &&
                          scoreCardOncr.length !== 0 &&
                          (scoreCardOncr[0].VARIANCE_FORCAST_YTD === "-999999"
                            ? "-"
                            : decimalCurrencyFormat(
                                Number(scoreCardOncr[0].VARIANCE_FORCAST_YTD)
                              ))}
                      </span>
                    )}
                  </td>{" "}
                </>
              )}{" "}
            </tr>
            <tr>
              {" "}
              <th>
                Abandonment Rate{" "}
                {gettooltip(
                  "ARInfoIcon",
                  "AR",
                  "AR",
                  "(Number of Carts - Number of orders)*100 / Number of Carts"
                )}
              </th>
              {loading.abr ? (
                <>
                  <LoaderForRow tdCount={10} />
                </>
              ) : (
                <>
                  <td>
                    {scoreCardAbr !== undefined &&
                      scoreCardAbr.length !== 0 &&
                      (scoreCardAbr[0].GOAL_FORCAST_LM === "-999999"
                        ? "-"
                        : `${decimalCurrencyFormat(
                            Number(scoreCardAbr[0].GOAL_FORCAST_LM)
                          )}%`)}
                  </td>{" "}
                  <td>
                    {scoreCardAbr !== undefined &&
                      scoreCardAbr.length !== 0 &&
                      (scoreCardAbr[0].CUST_CNT_LM_TY === "-999999"
                        ? "-"
                        : `${decimalCurrencyFormat(
                            Number(scoreCardAbr[0].CUST_CNT_LM_TY)
                          )}%`)}
                  </td>{" "}
                  <td>
                    {scoreCardAbr !== undefined &&
                      scoreCardAbr.length !== 0 &&
                      (scoreCardAbr[0].CUST_CNT_LM_LY === "-999999"
                        ? "-"
                        : `${decimalCurrencyFormat(
                            Number(scoreCardAbr[0].CUST_CNT_LM_LY)
                          )}%`)}
                  </td>{" "}
                  <td>
                    {scoreCardAbr !== undefined &&
                    scoreCardAbr.length !== 0 &&
                    Number(scoreCardAbr[0].CUST_CNT_LM_TY_VS_LY)
                      .toFixed(2)
                      .includes("-") ? (
                      <span style={{ color: "green" }}>
                        {scoreCardAbr !== undefined &&
                          scoreCardAbr.length !== 0 &&
                          (scoreCardAbr[0].CUST_CNT_LM_TY_VS_LY === "-999999"
                            ? "-"
                            : decimalCurrencyFormat(
                                Number(scoreCardAbr[0].CUST_CNT_LM_TY_VS_LY)
                              ))}
                      </span>
                    ) : (
                      <span style={{ color: "red" }}>
                        {scoreCardAbr !== undefined &&
                          scoreCardAbr.length !== 0 &&
                          (scoreCardAbr[0].CUST_CNT_LM_TY_VS_LY === "-999999"
                            ? "-"
                            : decimalCurrencyFormat(
                                Number(scoreCardAbr[0].CUST_CNT_LM_TY_VS_LY)
                              ))}
                      </span>
                    )}
                  </td>{" "}
                  <td>
                    {scoreCardAbr !== undefined &&
                    scoreCardAbr.length !== 0 &&
                    Number(scoreCardAbr[0].VARIANCE_FORCAST_LM)
                      .toFixed(2)
                      .includes("-") ? (
                      <span style={{ color: "green" }}>
                        {scoreCardAbr !== undefined &&
                          scoreCardAbr.length !== 0 &&
                          (scoreCardAbr[0].VARIANCE_FORCAST_LM === "-999999"
                            ? "-"
                            : decimalCurrencyFormat(
                                Number(scoreCardAbr[0].VARIANCE_FORCAST_LM)
                              ))}
                      </span>
                    ) : (
                      <span style={{ color: "red" }}>
                        {scoreCardAbr !== undefined &&
                          scoreCardAbr.length !== 0 &&
                          (scoreCardAbr[0].VARIANCE_FORCAST_LM === "-999999"
                            ? "-"
                            : decimalCurrencyFormat(
                                Number(scoreCardAbr[0].VARIANCE_FORCAST_LM)
                              ))}
                      </span>
                    )}
                  </td>{" "}
                  <td>
                    {scoreCardAbr !== undefined &&
                      scoreCardAbr.length !== 0 &&
                      (scoreCardAbr[0].GOAL_FORCAST_YTD === "-999999"
                        ? "-"
                        : `${decimalCurrencyFormat(
                            Number(scoreCardAbr[0].GOAL_FORCAST_YTD)
                          )}%`)}
                  </td>{" "}
                  <td>
                    {scoreCardAbr !== undefined &&
                      scoreCardAbr.length !== 0 &&
                      (scoreCardAbr[0].CUST_CNT_YTD_TY === "-999999"
                        ? "-"
                        : `${decimalCurrencyFormat(
                            Number(scoreCardAbr[0].CUST_CNT_YTD_TY)
                          )}%`)}
                  </td>{" "}
                  <td>
                    {scoreCardAbr !== undefined &&
                      scoreCardAbr.length !== 0 &&
                      (scoreCardAbr[0].CUST_CNT_YTD_LY === "-999999"
                        ? "-"
                        : `${decimalCurrencyFormat(
                            Number(scoreCardAbr[0].CUST_CNT_YTD_LY)
                          )}%`)}
                  </td>{" "}
                  <td>
                    {scoreCardAbr !== undefined &&
                    scoreCardAbr.length !== 0 &&
                    Number(scoreCardAbr[0].CUST_CNT_YTD_TY_VS_LY)
                      .toFixed(2)
                      .includes("-") ? (
                      <span style={{ color: "green" }}>
                        {scoreCardAbr !== undefined &&
                          scoreCardAbr.length !== 0 &&
                          (scoreCardAbr[0].CUST_CNT_YTD_TY_VS_LY === "-999999"
                            ? "-"
                            : decimalCurrencyFormat(
                                Number(scoreCardAbr[0].CUST_CNT_YTD_TY_VS_LY)
                              ))}
                      </span>
                    ) : (
                      <span style={{ color: "red" }}>
                        {scoreCardAbr !== undefined &&
                          scoreCardAbr.length !== 0 &&
                          (scoreCardAbr[0].CUST_CNT_YTD_TY_VS_LY === "-999999"
                            ? "-"
                            : decimalCurrencyFormat(
                                Number(scoreCardAbr[0].CUST_CNT_YTD_TY_VS_LY)
                              ))}
                      </span>
                    )}
                  </td>{" "}
                  <td>
                    {scoreCardAbr !== undefined &&
                    scoreCardAbr.length !== 0 &&
                    Number(scoreCardAbr[0].VARIANCE_FORCAST_YTD)
                      .toFixed(2)
                      .includes("-") ? (
                      <span style={{ color: "green" }}>
                        {scoreCardAbr !== undefined &&
                          scoreCardAbr.length !== 0 &&
                          (scoreCardAbr[0].VARIANCE_FORCAST_YTD === "-999999"
                            ? "-"
                            : decimalCurrencyFormat(
                                Number(scoreCardAbr[0].VARIANCE_FORCAST_YTD)
                              ))}
                      </span>
                    ) : (
                      <span style={{ color: "red" }}>
                        {scoreCardAbr !== undefined &&
                          scoreCardAbr.length !== 0 &&
                          (scoreCardAbr[0].VARIANCE_FORCAST_YTD === "-999999"
                            ? "-"
                            : decimalCurrencyFormat(
                                Number(scoreCardAbr[0].VARIANCE_FORCAST_YTD)
                              ))}
                      </span>
                    )}
                  </td>{" "}
                </>
              )}{" "}
            </tr>
            <tr></tr>
            <tr className="align-middle">
              {" "}
              <th rowSpan="4">{"Sign-ups"}</th>
              <th>
                Beyond+ Sign-Ups{" "}
                {gettooltip(
                  "BplusInfoIcon",
                  "Bplus",
                  "Bplus",
                  "Number of customers who signed-up online",
                  "for beyond+ membership in the period "
                )}
              </th>{" "}
              {loading.obplus ? (
                <>
                  <LoaderForRow tdCount={10} />
                </>
              ) : (
                <>
                  <td>
                    {scoreCardOBplus !== undefined &&
                      scoreCardOBplus.length !== 0 &&
                      (scoreCardOBplus[0].GOAL_FORCAST_LM === "-999999"
                        ? "-"
                        : currencyFormat(
                            Number(scoreCardOBplus[0].GOAL_FORCAST_LM)
                          ))}
                  </td>{" "}
                  <td>
                    {scoreCardOBplus !== undefined &&
                      scoreCardOBplus.length !== 0 &&
                      (scoreCardOBplus[0].CUST_CNT_LM_TY === "-999999"
                        ? "-"
                        : currencyFormat(
                            Number(scoreCardOBplus[0].CUST_CNT_LM_TY)
                          ))}
                  </td>{" "}
                  <td>
                    {scoreCardOBplus !== undefined &&
                      scoreCardOBplus.length !== 0 &&
                      (scoreCardOBplus[0].CUST_CNT_LM_LY === "-999999"
                        ? "-"
                        : currencyFormat(
                            Number(scoreCardOBplus[0].CUST_CNT_LM_LY)
                          ))}
                  </td>{" "}
                  <td>
                    {scoreCardOBplus !== undefined &&
                    scoreCardOBplus.length !== 0 &&
                    Number(scoreCardOBplus[0].CUST_CNT_LM_TY_VS_LY)
                      .toFixed(2)
                      .includes("-") ? (
                      <span style={{ color: "red" }}>
                        {scoreCardOBplus !== undefined &&
                          scoreCardOBplus.length !== 0 &&
                          (scoreCardOBplus[0].CUST_CNT_LM_TY_VS_LY === "-999999"
                            ? "-"
                            : `${decimalCurrencyFormat(
                                Number(scoreCardOBplus[0].CUST_CNT_LM_TY_VS_LY)
                              )}%`)}
                      </span>
                    ) : (
                      <span style={{ color: "green" }}>
                        {scoreCardOBplus !== undefined &&
                          scoreCardOBplus.length !== 0 &&
                          (scoreCardOBplus[0].CUST_CNT_LM_TY_VS_LY === "-999999"
                            ? "-"
                            : `${decimalCurrencyFormat(
                                Number(scoreCardOBplus[0].CUST_CNT_LM_TY_VS_LY)
                              )}%`)}
                      </span>
                    )}
                  </td>{" "}
                  <td>
                    {scoreCardOBplus !== undefined &&
                      scoreCardOBplus.length !== 0 &&
                      (scoreCardOBplus[0].VARIANCE_FORCAST_LM === "-999999"
                        ? "-"
                        : currencyFormat(
                            Number(scoreCardOBplus[0].VARIANCE_FORCAST_LM)
                          ))}
                  </td>{" "}
                  <td>
                    {scoreCardOBplus !== undefined &&
                      scoreCardOBplus.length !== 0 &&
                      (scoreCardOBplus[0].GOAL_FORCAST_YTD === "-999999"
                        ? "-"
                        : currencyFormat(
                            Number(scoreCardOBplus[0].GOAL_FORCAST_YTD)
                          ))}
                  </td>{" "}
                  <td>
                    {scoreCardOBplus !== undefined &&
                      scoreCardOBplus.length !== 0 &&
                      (scoreCardOBplus[0].CUST_CNT_YTD_TY === "-999999"
                        ? "-"
                        : currencyFormat(
                            Number(scoreCardOBplus[0].CUST_CNT_YTD_TY)
                          ))}
                  </td>{" "}
                  <td>
                    {scoreCardOBplus !== undefined &&
                      scoreCardOBplus.length !== 0 &&
                      (scoreCardOBplus[0].CUST_CNT_YTD_LY === "-999999"
                        ? "-"
                        : currencyFormat(
                            Number(scoreCardOBplus[0].CUST_CNT_YTD_LY)
                          ))}
                  </td>{" "}
                  <td>
                    {scoreCardOBplus !== undefined &&
                    scoreCardOBplus.length !== 0 &&
                    Number(scoreCardOBplus[0].CUST_CNT_YTD_TY_VS_LY)
                      .toFixed(2)
                      .includes("-") ? (
                      <span style={{ color: "red" }}>
                        {scoreCardOBplus !== undefined &&
                          scoreCardOBplus.length !== 0 &&
                          (scoreCardOBplus[0].CUST_CNT_YTD_TY_VS_LY ===
                          "-999999"
                            ? "-"
                            : `${decimalCurrencyFormat(
                                Number(scoreCardOBplus[0].CUST_CNT_YTD_TY_VS_LY)
                              )}%`)}
                      </span>
                    ) : (
                      <span style={{ color: "green" }}>
                        {scoreCardOBplus !== undefined &&
                          scoreCardOBplus.length !== 0 &&
                          (scoreCardOBplus[0].CUST_CNT_YTD_TY_VS_LY ===
                          "-999999"
                            ? "-"
                            : `${decimalCurrencyFormat(
                                Number(scoreCardOBplus[0].CUST_CNT_YTD_TY_VS_LY)
                              )}%`)}
                      </span>
                    )}
                  </td>{" "}
                  <td>
                    {scoreCardOBplus !== undefined &&
                    scoreCardOBplus.length !== 0 &&
                    Number(scoreCardOBplus[0].VARIANCE_FORCAST_YTD)
                      .toFixed(2)
                      .includes("-") ? (
                      <span style={{ color: "red" }}>
                        {scoreCardOBplus !== undefined &&
                          scoreCardOBplus.length !== 0 &&
                          (scoreCardOBplus[0].VARIANCE_FORCAST_YTD === "-999999"
                            ? "-"
                            : `${decimalCurrencyFormat(
                                Number(scoreCardOBplus[0].GOAL_FORCAST_LM)
                              )}%`)}
                      </span>
                    ) : (
                      <span style={{ color: "green" }}>
                        {scoreCardOBplus !== undefined &&
                          scoreCardOBplus.length !== 0 &&
                          (scoreCardOBplus[0].VARIANCE_FORCAST_YTD === "-999999"
                            ? "-"
                            : `${decimalCurrencyFormat(
                                Number(scoreCardOBplus[0].VARIANCE_FORCAST_YTD)
                              )}%`)}
                      </span>
                    )}
                  </td>{" "}
                </>
              )}
            </tr>
            <tr>
              {" "}
              <th>
                Credit Card Sign-Ups{" "}
                {gettooltip(
                  "CcInfoIcon",
                  "Cc",
                  "Cc",
                  "Number of Credit card customers who signed up online in the period "
                )}
              </th>{" "}
              {loading.oncs ? (
                <>
                  <LoaderForRow tdCount={10} />
                </>
              ) : (
                <>
                  <td>
                    {scoreCardOncs !== undefined &&
                      scoreCardOncs.length !== 0 &&
                      (scoreCardOncs[0].GOAL_FORCAST_LM === "-999999"
                        ? "-"
                        : currencyFormat(
                            Number(scoreCardOncs[0].GOAL_FORCAST_LM)
                          ))}
                  </td>{" "}
                  <td>
                    {scoreCardOncs !== undefined &&
                      scoreCardOncs.length !== 0 &&
                      (scoreCardOncs[0].CUST_CNT_LM_TY === "-999999"
                        ? "-"
                        : currencyFormat(
                            Number(scoreCardOncs[0].CUST_CNT_LM_TY)
                          ))}
                  </td>{" "}
                  <td>
                    {scoreCardOncs !== undefined &&
                      scoreCardOncs.length !== 0 &&
                      (scoreCardOncs[0].CUST_CNT_LM_LY === "-999999"
                        ? "-"
                        : currencyFormat(
                            Number(scoreCardOncs[0].CUST_CNT_LM_LY)
                          ))}
                  </td>{" "}
                  <td>
                    {scoreCardOncs !== undefined &&
                    scoreCardOncs.length !== 0 &&
                    Number(scoreCardOncs[0].CUST_CNT_LM_TY_VS_LY)
                      .toFixed(2)
                      .includes("-") ? (
                      <span style={{ color: "red" }}>
                        {scoreCardOncs !== undefined &&
                          scoreCardOncs.length !== 0 &&
                          (scoreCardOncs[0].CUST_CNT_LM_TY_VS_LY === "-999999"
                            ? "-"
                            : `${decimalCurrencyFormat(
                                Number(scoreCardOncs[0].CUST_CNT_LM_TY_VS_LY)
                              )}%`)}
                      </span>
                    ) : (
                      <span style={{ color: "green" }}>
                        {scoreCardOncs !== undefined &&
                          scoreCardOncs.length !== 0 &&
                          (scoreCardOncs[0].CUST_CNT_LM_TY_VS_LY === "-999999"
                            ? "-"
                            : `${decimalCurrencyFormat(
                                Number(scoreCardOncs[0].CUST_CNT_LM_TY_VS_LY)
                              )}%`)}
                      </span>
                    )}
                  </td>{" "}
                  <td>
                    {scoreCardOncs !== undefined &&
                    scoreCardOncs.length !== 0 &&
                    Number(scoreCardOncs[0].VARIANCE_FORCAST_LM)
                      .toFixed(2)
                      .includes("-") ? (
                      <span style={{ color: "red" }}>
                        {scoreCardOncs !== undefined &&
                          scoreCardOncs.length !== 0 &&
                          (scoreCardOncs[0].VARIANCE_FORCAST_LM === "-999999"
                            ? "-"
                            : `${decimalCurrencyFormat(
                                Number(scoreCardOncs[0].VARIANCE_FORCAST_LM)
                              )}%`)}
                      </span>
                    ) : (
                      <span style={{ color: "green" }}>
                        {scoreCardOncs !== undefined &&
                          scoreCardOncs.length !== 0 &&
                          (scoreCardOncs[0].VARIANCE_FORCAST_LM === "-999999"
                            ? "-"
                            : `${decimalCurrencyFormat(
                                Number(scoreCardOncs[0].VARIANCE_FORCAST_LM)
                              )}%`)}
                      </span>
                    )}
                  </td>{" "}
                  <td>
                    {scoreCardOncs !== undefined &&
                      scoreCardOncs.length !== 0 &&
                      (scoreCardOncs[0].GOAL_FORCAST_YTD === "-999999"
                        ? "-"
                        : currencyFormat(
                            Number(scoreCardOncs[0].GOAL_FORCAST_YTD)
                          ))}
                  </td>{" "}
                  <td>
                    {scoreCardOncs !== undefined &&
                      scoreCardOncs.length !== 0 &&
                      (scoreCardOncs[0].CUST_CNT_YTD_TY === "-999999"
                        ? "-"
                        : currencyFormat(
                            Number(scoreCardOncs[0].CUST_CNT_YTD_TY)
                          ))}
                  </td>{" "}
                  <td>
                    {scoreCardOncs !== undefined &&
                      scoreCardOncs.length !== 0 &&
                      (scoreCardOncs[0].CUST_CNT_YTD_LY === "-999999"
                        ? "-"
                        : currencyFormat(
                            Number(scoreCardOncs[0].CUST_CNT_YTD_LY)
                          ))}
                  </td>{" "}
                  <td>
                    {scoreCardOncs !== undefined &&
                    scoreCardOncs.length !== 0 &&
                    Number(scoreCardOncs[0].CUST_CNT_YTD_TY_VS_LY)
                      .toFixed(2)
                      .includes("-") ? (
                      <span style={{ color: "red" }}>
                        {scoreCardOncs !== undefined &&
                          scoreCardOncs.length !== 0 &&
                          (scoreCardOncs[0].CUST_CNT_YTD_TY_VS_LY === "-999999"
                            ? "-"
                            : `${decimalCurrencyFormat(
                                Number(scoreCardOncs[0].CUST_CNT_YTD_TY_VS_LY)
                              )}%`)}
                      </span>
                    ) : (
                      <span style={{ color: "green" }}>
                        {scoreCardOncs !== undefined &&
                          scoreCardOncs.length !== 0 &&
                          (scoreCardOncs[0].CUST_CNT_YTD_TY_VS_LY === "-999999"
                            ? "-"
                            : `${decimalCurrencyFormat(
                                Number(scoreCardOncs[0].CUST_CNT_YTD_TY_VS_LY)
                              )}%`)}
                      </span>
                    )}
                  </td>{" "}
                  <td>
                    {scoreCardOncs !== undefined &&
                    scoreCardOncs.length !== 0 &&
                    Number(scoreCardOncs[0].VARIANCE_FORCAST_YTD)
                      .toFixed(2)
                      .includes("-") ? (
                      <span style={{ color: "red" }}>
                        {scoreCardOncs !== undefined &&
                          scoreCardOncs.length !== 0 &&
                          (scoreCardOncs[0].VARIANCE_FORCAST_YTD === "-999999"
                            ? "-"
                            : `${decimalCurrencyFormat(
                                Number(scoreCardOncs[0].VARIANCE_FORCAST_YTD)
                              )}%`)}
                      </span>
                    ) : (
                      <span style={{ color: "green" }}>
                        {scoreCardOncs !== undefined &&
                          scoreCardOncs.length !== 0 &&
                          (scoreCardOncs[0].VARIANCE_FORCAST_YTD === "-999999"
                            ? "-"
                            : `${decimalCurrencyFormat(
                                Number(scoreCardOncs[0].VARIANCE_FORCAST_YTD)
                              )}%`)}
                      </span>
                    )}
                  </td>{" "}
                </>
              )}
            </tr>
            <tr>
              {" "}
              <th>
                Welcome{" "}
                {gettooltip(
                  "WelInfoIcon",
                  "Wel",
                  "Wel",
                  "Number of loyalty members who signed up online",
                  "for Welcome membership in the period "
                )}
              </th>{" "}
              {loading.onlineWelcome ? (
                <>
                  <LoaderForRow tdCount={10} />
                </>
              ) : (
                <>
                  <td>
                    {scoreCardOnlineWelcome !== undefined &&
                      scoreCardOnlineWelcome.length !== 0 &&
                      (scoreCardOnlineWelcome[0].GOAL_FORCAST_LM === "-999999"
                        ? "-"
                        : currencyFormat(
                            Number(scoreCardOnlineWelcome[0].GOAL_FORCAST_LM)
                          ))}
                  </td>{" "}
                  <td>
                    {scoreCardOnlineWelcome !== undefined &&
                      scoreCardOnlineWelcome.length !== 0 &&
                      (scoreCardOnlineWelcome[0].CUST_CNT_LM_TY === "-999999"
                        ? "-"
                        : currencyFormat(
                            Number(scoreCardOnlineWelcome[0].CUST_CNT_LM_TY)
                          ))}
                  </td>{" "}
                  <td>
                    {scoreCardOnlineWelcome !== undefined &&
                      scoreCardOnlineWelcome.length !== 0 &&
                      (scoreCardOnlineWelcome[0].CUST_CNT_LM_LY === "-999999"
                        ? "-"
                        : currencyFormat(
                            Number(scoreCardOnlineWelcome[0].CUST_CNT_LM_LY)
                          ))}
                  </td>{" "}
                  <td>
                    {scoreCardOnlineWelcome !== undefined &&
                    scoreCardOnlineWelcome.length !== 0 &&
                    Number(scoreCardOnlineWelcome[0].CUST_CNT_LM_TY_VS_LY)
                      .toFixed(2)
                      .includes("-") ? (
                      <span style={{ color: "red" }}>
                        {scoreCardOnlineWelcome !== undefined &&
                          scoreCardOnlineWelcome.length !== 0 &&
                          (scoreCardOnlineWelcome[0].CUST_CNT_LM_TY_VS_LY ===
                          "-999999"
                            ? "-"
                            : `${decimalCurrencyFormat(
                                Number(
                                  scoreCardOnlineWelcome[0].CUST_CNT_LM_TY_VS_LY
                                )
                              )}%`)}
                      </span>
                    ) : (
                      <span style={{ color: "green" }}>
                        {scoreCardOnlineWelcome !== undefined &&
                          scoreCardOnlineWelcome.length !== 0 &&
                          (scoreCardOnlineWelcome[0].CUST_CNT_LM_TY_VS_LY ===
                          "-999999"
                            ? "-"
                            : `${decimalCurrencyFormat(
                                Number(
                                  scoreCardOnlineWelcome[0].CUST_CNT_LM_TY_VS_LY
                                )
                              )}%`)}
                      </span>
                    )}
                  </td>{" "}
                  <td>
                    {scoreCardOnlineWelcome !== undefined &&
                    scoreCardOnlineWelcome.length !== 0 &&
                    Number(scoreCardOnlineWelcome[0].VARIANCE_FORCAST_LM)
                      .toFixed(2)
                      .includes("-") ? (
                      <span style={{ color: "red" }}>
                        {scoreCardOnlineWelcome !== undefined &&
                          scoreCardOnlineWelcome.length !== 0 &&
                          (scoreCardOnlineWelcome[0].VARIANCE_FORCAST_LM ===
                          "-999999"
                            ? "-"
                            : `${decimalCurrencyFormat(
                                Number(
                                  scoreCardOnlineWelcome[0].VARIANCE_FORCAST_LM
                                )
                              )}%`)}
                      </span>
                    ) : (
                      <span style={{ color: "green" }}>
                        {scoreCardOnlineWelcome !== undefined &&
                          scoreCardOnlineWelcome.length !== 0 &&
                          (scoreCardOnlineWelcome[0].VARIANCE_FORCAST_LM ===
                          "-999999"
                            ? "-"
                            : `${decimalCurrencyFormat(
                                Number(
                                  scoreCardOnlineWelcome[0].VARIANCE_FORCAST_LM
                                )
                              )}%`)}
                      </span>
                    )}
                  </td>{" "}
                  <td>
                    {scoreCardOnlineWelcome !== undefined &&
                      scoreCardOnlineWelcome.length !== 0 &&
                      (scoreCardOnlineWelcome[0].GOAL_FORCAST_YTD === "-999999"
                        ? "-"
                        : currencyFormat(
                            Number(scoreCardOnlineWelcome[0].GOAL_FORCAST_YTD)
                          ))}
                  </td>{" "}
                  <td>
                    {scoreCardOnlineWelcome !== undefined &&
                      scoreCardOnlineWelcome.length !== 0 &&
                      (scoreCardOnlineWelcome[0].CUST_CNT_YTD_TY === "-999999"
                        ? "-"
                        : currencyFormat(
                            Number(scoreCardOnlineWelcome[0].CUST_CNT_YTD_TY)
                          ))}
                  </td>{" "}
                  <td>
                    {scoreCardOnlineWelcome !== undefined &&
                      scoreCardOnlineWelcome.length !== 0 &&
                      (scoreCardOnlineWelcome[0].CUST_CNT_YTD_LY === "-999999"
                        ? "-"
                        : currencyFormat(
                            Number(scoreCardOnlineWelcome[0].CUST_CNT_YTD_LY)
                          ))}
                  </td>{" "}
                  <td>
                    {scoreCardOnlineWelcome !== undefined &&
                    scoreCardOnlineWelcome.length !== 0 &&
                    Number(scoreCardOnlineWelcome[0].CUST_CNT_YTD_TY_VS_LY)
                      .toFixed(2)
                      .includes("-") ? (
                      <span style={{ color: "red" }}>
                        {scoreCardOnlineWelcome !== undefined &&
                          scoreCardOnlineWelcome.length !== 0 &&
                          (scoreCardOnlineWelcome[0].CUST_CNT_YTD_TY_VS_LY ===
                          "-999999"
                            ? "-"
                            : `${decimalCurrencyFormat(
                                Number(
                                  scoreCardOnlineWelcome[0]
                                    .CUST_CNT_YTD_TY_VS_LY
                                )
                              )}%`)}
                      </span>
                    ) : (
                      <span style={{ color: "green" }}>
                        {scoreCardOnlineWelcome !== undefined &&
                          scoreCardOnlineWelcome.length !== 0 &&
                          (scoreCardOnlineWelcome[0].CUST_CNT_YTD_TY_VS_LY ===
                          "-999999"
                            ? "-"
                            : `${decimalCurrencyFormat(
                                Number(
                                  scoreCardOnlineWelcome[0]
                                    .CUST_CNT_YTD_TY_VS_LY
                                )
                              )}%`)}
                      </span>
                    )}
                  </td>{" "}
                  <td>
                    {scoreCardOnlineWelcome !== undefined &&
                    scoreCardOnlineWelcome.length !== 0 &&
                    Number(scoreCardOnlineWelcome[0].VARIANCE_FORCAST_YTD)
                      .toFixed(2)
                      .includes("-") ? (
                      <span style={{ color: "red" }}>
                        {scoreCardOnlineWelcome !== undefined &&
                          scoreCardOnlineWelcome.length !== 0 &&
                          (scoreCardOnlineWelcome[0].VARIANCE_FORCAST_YTD ===
                          "-999999"
                            ? "-"
                            : `${decimalCurrencyFormat(
                                Number(
                                  scoreCardOnlineWelcome[0].VARIANCE_FORCAST_YTD
                                )
                              )}%`)}
                      </span>
                    ) : (
                      <span style={{ color: "green" }}>
                        {scoreCardOnlineWelcome !== undefined &&
                          scoreCardOnlineWelcome.length !== 0 &&
                          (scoreCardOnlineWelcome[0].VARIANCE_FORCAST_YTD ===
                          "-999999"
                            ? "-"
                            : `${decimalCurrencyFormat(
                                Number(
                                  scoreCardOnlineWelcome[0].VARIANCE_FORCAST_YTD
                                )
                              )}%`)}
                      </span>
                    )}
                  </td>{" "}
                </>
              )}
            </tr>
            <tr>
              {" "}
              <th>
                Welcome+{" "}
                {gettooltip(
                  "WPlusInfoIcon",
                  "WPlus",
                  "WPlus",
                  "Number of loyalty members who signed up online",
                  "for Welcome+ membership in the period "
                )}
              </th>{" "}
              {loading.onlineWelcomePlus ? (
                <>
                  <LoaderForRow tdCount={10} />
                </>
              ) : (
                <>
                  <td>
                    {scoreCardOnlineWelcomePlus !== undefined &&
                      scoreCardOnlineWelcomePlus.length !== 0 &&
                      (scoreCardOnlineWelcomePlus[0].GOAL_FORCAST_LM ===
                      "-999999"
                        ? "-"
                        : currencyFormat(
                            Number(
                              scoreCardOnlineWelcomePlus[0].GOAL_FORCAST_LM
                            )
                          ))}
                  </td>{" "}
                  <td>
                    {scoreCardOnlineWelcomePlus !== undefined &&
                      scoreCardOnlineWelcomePlus.length !== 0 &&
                      (scoreCardOnlineWelcomePlus[0].CUST_CNT_LM_TY ===
                      "-999999"
                        ? "-"
                        : currencyFormat(
                            Number(scoreCardOnlineWelcomePlus[0].CUST_CNT_LM_TY)
                          ))}
                  </td>{" "}
                  <td>
                    {scoreCardOnlineWelcomePlus !== undefined &&
                      scoreCardOnlineWelcomePlus.length !== 0 &&
                      (scoreCardOnlineWelcomePlus[0].CUST_CNT_LM_LY ===
                      "-999999"
                        ? "-"
                        : currencyFormat(
                            Number(scoreCardOnlineWelcomePlus[0].CUST_CNT_LM_LY)
                          ))}
                  </td>{" "}
                  <td>
                    {scoreCardOnlineWelcomePlus !== undefined &&
                    scoreCardOnlineWelcomePlus.length !== 0 &&
                    Number(scoreCardOnlineWelcomePlus[0].CUST_CNT_LM_TY_VS_LY)
                      .toFixed(2)
                      .includes("-") ? (
                      <span style={{ color: "red" }}>
                        {scoreCardOnlineWelcomePlus !== undefined &&
                          scoreCardOnlineWelcomePlus.length !== 0 &&
                          (scoreCardOnlineWelcomePlus[0]
                            .CUST_CNT_LM_TY_VS_LY === "-999999"
                            ? "-"
                            : `${decimalCurrencyFormat(
                                Number(
                                  scoreCardOnlineWelcomePlus[0]
                                    .CUST_CNT_LM_TY_VS_LY
                                )
                              )}%`)}
                      </span>
                    ) : (
                      <span style={{ color: "green" }}>
                        {scoreCardOnlineWelcomePlus !== undefined &&
                          scoreCardOnlineWelcomePlus.length !== 0 &&
                          (scoreCardOnlineWelcomePlus[0]
                            .CUST_CNT_LM_TY_VS_LY === "-999999"
                            ? "-"
                            : `${decimalCurrencyFormat(
                                Number(
                                  scoreCardOnlineWelcomePlus[0]
                                    .CUST_CNT_LM_TY_VS_LY
                                )
                              )}%`)}
                      </span>
                    )}
                  </td>{" "}
                  <td>
                    {scoreCardOnlineWelcomePlus !== undefined &&
                    scoreCardOnlineWelcomePlus.length !== 0 &&
                    Number(scoreCardOnlineWelcomePlus[0].VARIANCE_FORCAST_LM)
                      .toFixed(2)
                      .includes("-") ? (
                      <span style={{ color: "red" }}>
                        {scoreCardOnlineWelcomePlus !== undefined &&
                          scoreCardOnlineWelcomePlus.length !== 0 &&
                          (scoreCardOnlineWelcomePlus[0]
                            .VARIANCE_FORCAST_LM === "-999999"
                            ? "-"
                            : `${decimalCurrencyFormat(
                                Number(
                                  scoreCardOnlineWelcomePlus[0]
                                    .VARIANCE_FORCAST_LM
                                )
                              )}%`)}
                      </span>
                    ) : (
                      <span style={{ color: "green" }}>
                        {scoreCardOnlineWelcomePlus !== undefined &&
                          scoreCardOnlineWelcomePlus.length !== 0 &&
                          (scoreCardOnlineWelcomePlus[0]
                            .VARIANCE_FORCAST_LM === "-999999"
                            ? "-"
                            : `${decimalCurrencyFormat(
                                Number(
                                  scoreCardOnlineWelcomePlus[0]
                                    .VARIANCE_FORCAST_LM
                                )
                              )}%`)}
                      </span>
                    )}
                  </td>{" "}
                  <td>
                    {scoreCardOnlineWelcomePlus !== undefined &&
                      scoreCardOnlineWelcomePlus.length !== 0 &&
                      (scoreCardOnlineWelcomePlus[0].GOAL_FORCAST_YTD ===
                      "-999999"
                        ? "-"
                        : currencyFormat(
                            Number(
                              scoreCardOnlineWelcomePlus[0].GOAL_FORCAST_YTD
                            )
                          ))}
                  </td>{" "}
                  <td>
                    {scoreCardOnlineWelcomePlus !== undefined &&
                      scoreCardOnlineWelcomePlus.length !== 0 &&
                      (scoreCardOnlineWelcomePlus[0].CUST_CNT_YTD_TY ===
                      "-999999"
                        ? "-"
                        : currencyFormat(
                            Number(
                              scoreCardOnlineWelcomePlus[0].CUST_CNT_YTD_TY
                            )
                          ))}
                  </td>{" "}
                  <td>
                    {scoreCardOnlineWelcomePlus !== undefined &&
                      scoreCardOnlineWelcomePlus.length !== 0 &&
                      (scoreCardOnlineWelcomePlus[0].CUST_CNT_YTD_LY ===
                      "-999999"
                        ? "-"
                        : currencyFormat(
                            Number(
                              scoreCardOnlineWelcomePlus[0].CUST_CNT_YTD_LY
                            )
                          ))}
                  </td>{" "}
                  <td>
                    {scoreCardOnlineWelcomePlus !== undefined &&
                    scoreCardOnlineWelcomePlus.length !== 0 &&
                    Number(scoreCardOnlineWelcomePlus[0].CUST_CNT_YTD_TY_VS_LY)
                      .toFixed(2)
                      .includes("-") ? (
                      <span style={{ color: "red" }}>
                        {scoreCardOnlineWelcomePlus !== undefined &&
                          scoreCardOnlineWelcomePlus.length !== 0 &&
                          (scoreCardOnlineWelcomePlus[0]
                            .CUST_CNT_YTD_TY_VS_LY === "-999999"
                            ? "-"
                            : `${decimalCurrencyFormat(
                                Number(
                                  scoreCardOnlineWelcomePlus[0]
                                    .CUST_CNT_YTD_TY_VS_LY
                                )
                              )}%`)}
                      </span>
                    ) : (
                      <span style={{ color: "green" }}>
                        {scoreCardOnlineWelcomePlus !== undefined &&
                          scoreCardOnlineWelcomePlus.length !== 0 &&
                          (scoreCardOnlineWelcomePlus[0]
                            .CUST_CNT_YTD_TY_VS_LY === "-999999"
                            ? "-"
                            : `${decimalCurrencyFormat(
                                Number(
                                  scoreCardOnlineWelcomePlus[0]
                                    .CUST_CNT_YTD_TY_VS_LY
                                )
                              )}%`)}
                      </span>
                    )}
                  </td>{" "}
                  <td>
                    {scoreCardOnlineWelcomePlus !== undefined &&
                    scoreCardOnlineWelcomePlus.length !== 0 &&
                    Number(scoreCardOnlineWelcomePlus[0].VARIANCE_FORCAST_YTD)
                      .toFixed(2)
                      .includes("-") ? (
                      <span style={{ color: "red" }}>
                        {scoreCardOnlineWelcomePlus !== undefined &&
                          scoreCardOnlineWelcomePlus.length !== 0 &&
                          (scoreCardOnlineWelcomePlus[0]
                            .VARIANCE_FORCAST_YTD === "-999999"
                            ? "-"
                            : `${decimalCurrencyFormat(
                                Number(
                                  scoreCardOnlineWelcomePlus[0]
                                    .VARIANCE_FORCAST_YTD
                                )
                              )}%`)}
                      </span>
                    ) : (
                      <span style={{ color: "green" }}>
                        {scoreCardOnlineWelcomePlus !== undefined &&
                          scoreCardOnlineWelcomePlus.length !== 0 &&
                          (scoreCardOnlineWelcomePlus[0]
                            .VARIANCE_FORCAST_YTD === "-999999"
                            ? "-"
                            : `${decimalCurrencyFormat(
                                Number(
                                  scoreCardOnlineWelcomePlus[0]
                                    .VARIANCE_FORCAST_YTD
                                )
                              )}%`)}
                      </span>
                    )}
                  </td>{" "}
                </>
              )}
            </tr>
            <tr></tr>
            <tr className="align-middle">
              {" "}
              <th rowSpan="3">
                {"CHI (Customer"} <br /> {"Health Index) Score"}
              </th>
              <th>-----------------------</th> <td></td> <td></td> <td></td>{" "}
              <td></td> <td></td> <td></td> <td></td> <td></td> <td></td>{" "}
              <td></td>{" "}
            </tr>
            <tr>
              {" "}
              <th>-----------------------</th> <td></td> <td></td> <td></td>{" "}
              <td></td> <td></td> <td></td> <td></td> <td></td> <td></td>{" "}
              <td></td>{" "}
            </tr>
            <tr>
              {" "}
              <th>-----------------------</th> <td></td> <td></td> <td></td>{" "}
              <td></td> <td></td> <td></td> <td></td> <td></td> <td></td>{" "}
              <td></td>{" "}
            </tr>
          </tbody>
        </Table>
      </div>
    </div>
  );
}

export default StoreDigital;
