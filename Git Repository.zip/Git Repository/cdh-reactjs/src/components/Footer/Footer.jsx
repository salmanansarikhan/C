import React from 'react'
import './Footer.css';
function Footer() {
  return (
    <div>
      <footer className="cdh-footer">
        <div className=" copyright_container copyright">
          @2022 Bed Bath & Beyond Inc. and subsidiaries
        </div>
      </footer>
    </div>
  );
}

export default React.memo(Footer)
