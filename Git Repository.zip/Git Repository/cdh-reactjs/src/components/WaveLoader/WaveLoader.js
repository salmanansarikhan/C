import React from 'react';
import '../WaveLoader/WaveLoader.css';
function WaveLoader() {
    return (
        <div className='wave-loader-container'>
        <ul className='wave-loader-ul mb-0'>
        <li className='wave-loader-li'></li>
        <li className='wave-loader-li'></li>
        <li className='wave-loader-li'></li>
        <li className='wave-loader-li'></li>
        <li className='wave-loader-li'></li>
    </ul>
    </div>
    );
  }
export default WaveLoader;