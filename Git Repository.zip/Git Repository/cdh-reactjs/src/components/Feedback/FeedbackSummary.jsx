import React, { useState } from "react";
import { Table } from "react-bootstrap";
import LoaderForRow from "../LoaderForTable/LoaderForRow";
import { currencyFormat } from "../CdhHome/CdhHome";
import { decimalCurrencyFormat } from "../ScoreCard/Marketing";
import "../Store/StoreContainer.css";
import { gettooltip } from "../Utils";
import { FontAwesomeIcon } from "@fortawesome/react-fontawesome";
import { faCaretUp, faCaretDown } from "@fortawesome/free-solid-svg-icons";

function FeedbackSummary({
  loading,
  setSummaryActive,
  feedbackSummaryData,
  handleFeedbackJourney,
  handleFeedbackJourneyWithStore,
  showStoreField,
  sortSelection,
  sortSummaryData,
  selectedFeedbackChannelTypeValue,
  showDistrictField,
  feedbackSummaryDataTotal,
  selectedStorePeriodValue,
}) {
  const avgRatingDiffHeading =
    selectedStorePeriodValue === "Yesterday"
      ? "Vs Prior day yesterday"
      : selectedStorePeriodValue === "WTD"
      ? "WOW"
      : selectedStorePeriodValue === "MTD"
      ? "MOM"
      : selectedStorePeriodValue === "QTD"
      ? "QOQ"
      : selectedStorePeriodValue === "YTD"
      ? "YOY"
      : "";
  return (
    <div>
      <div className="p-3" style={{ marginBottom: "50px" }}>
        <Table striped bordered hover size="sm">
          <thead>
            <tr>
              <th
                style={{ cursor: "pointer" }}
                onClick={() => {
                  sortSummaryData("journey");
                }}
              >
                Journey{" "}
                {(sortSelection.arrowIcon === "journeyUp" &&
                  feedbackSummaryData !== undefined &&
                  feedbackSummaryData.length !== 0 && (
                    <FontAwesomeIcon
                      style={{ paddingLeft: "5px" }}
                      icon={faCaretUp}
                    />
                  )) ||
                  (sortSelection.arrowIcon === "journeyDown" &&
                    feedbackSummaryData !== undefined &&
                    feedbackSummaryData.length !== 0 && (
                      <FontAwesomeIcon
                        style={{ paddingLeft: "5px" }}
                        icon={faCaretDown}
                      />
                    ))}
              </th>
              {selectedFeedbackChannelTypeValue === "All" && (
                <th
                  style={{ cursor: "pointer" }}
                  onClick={() => {
                    sortSummaryData("channel");
                  }}
                >
                  Channel{" "}
                  {(sortSelection.arrowIcon === "channelUp" &&
                    feedbackSummaryData !== undefined &&
                    feedbackSummaryData.length !== 0 && (
                      <FontAwesomeIcon
                        style={{ paddingLeft: "5px" }}
                        icon={faCaretUp}
                      />
                    )) ||
                    (sortSelection.arrowIcon === "channelDown" &&
                      feedbackSummaryData !== undefined &&
                      feedbackSummaryData.length !== 0 && (
                        <FontAwesomeIcon
                          style={{ paddingLeft: "5px" }}
                          icon={faCaretDown}
                        />
                      ))}
                </th>
              )}
              {showStoreField &&
                showDistrictField &&
                selectedFeedbackChannelTypeValue === "Store" && (
                  <th
                    style={{ cursor: "pointer" }}
                    onClick={() => {
                      sortSummaryData("district");
                    }}
                  >
                    District{" "}
                    {(sortSelection.arrowIcon === "districtUp" &&
                      feedbackSummaryData !== undefined &&
                      feedbackSummaryData.length !== 0 && (
                        <FontAwesomeIcon
                          style={{ paddingLeft: "5px" }}
                          icon={faCaretUp}
                        />
                      )) ||
                      (sortSelection.arrowIcon === "districtDown" &&
                        feedbackSummaryData !== undefined &&
                        feedbackSummaryData.length !== 0 && (
                          <FontAwesomeIcon
                            style={{ paddingLeft: "5px" }}
                            icon={faCaretDown}
                          />
                        ))}
                  </th>
                )}
              {showStoreField && selectedFeedbackChannelTypeValue === "Store" && (
                <th
                  style={{ cursor: "pointer" }}
                  onClick={() => {
                    sortSummaryData("store");
                  }}
                >
                  Store No{" "}
                  {(sortSelection.arrowIcon === "storeUp" &&
                    feedbackSummaryData !== undefined &&
                    feedbackSummaryData.length !== 0 && (
                      <FontAwesomeIcon
                        style={{ paddingLeft: "5px" }}
                        icon={faCaretUp}
                      />
                    )) ||
                    (sortSelection.arrowIcon === "storeDown" &&
                      feedbackSummaryData !== undefined &&
                      feedbackSummaryData.length !== 0 && (
                        <FontAwesomeIcon
                          style={{ paddingLeft: "5px" }}
                          icon={faCaretDown}
                        />
                      ))}
                </th>
              )}
              <th
                style={{ cursor: "pointer" }}
                onClick={() => {
                  sortSummaryData("avgRating");
                }}
              >
                Average Rating{" "}
                {(sortSelection.arrowIcon === "avgRatingUp" &&
                  feedbackSummaryData !== undefined &&
                  feedbackSummaryData.length !== 0 && (
                    <FontAwesomeIcon
                      style={{ paddingLeft: "5px" }}
                      icon={faCaretUp}
                    />
                  )) ||
                  (sortSelection.arrowIcon === "avgRatingDown" &&
                    feedbackSummaryData !== undefined &&
                    feedbackSummaryData.length !== 0 && (
                      <FontAwesomeIcon
                        style={{ paddingLeft: "5px" }}
                        icon={faCaretDown}
                      />
                    ))}
              </th>
              {selectedStorePeriodValue !== "Date Range" && (
                <th
                  style={{ cursor: "pointer" }}
                  onClick={() => {
                    sortSummaryData("avgRatingDiff");
                  }}
                >
                  {avgRatingDiffHeading}{" "}
                  {(sortSelection.arrowIcon === "avgRatingDiffUp" &&
                    feedbackSummaryData !== undefined &&
                    feedbackSummaryData.length !== 0 && (
                      <FontAwesomeIcon
                        style={{ paddingLeft: "5px" }}
                        icon={faCaretUp}
                      />
                    )) ||
                    (sortSelection.arrowIcon === "avgRatingDiffDown" &&
                      feedbackSummaryData !== undefined &&
                      feedbackSummaryData.length !== 0 && (
                        <FontAwesomeIcon
                          style={{ paddingLeft: "5px" }}
                          icon={faCaretDown}
                        />
                      ))}
                </th>
              )}
              <th
                style={{ cursor: "pointer" }}
                onClick={() => {
                  sortSummaryData("noRating");
                }}
              >
                No of Ratings{" "}
                {(sortSelection.arrowIcon === "noRatingUp" &&
                  feedbackSummaryData !== undefined &&
                  feedbackSummaryData.length !== 0 && (
                    <FontAwesomeIcon
                      style={{ paddingLeft: "5px" }}
                      icon={faCaretUp}
                    />
                  )) ||
                  (sortSelection.arrowIcon === "noRatingDown" &&
                    feedbackSummaryData !== undefined &&
                    feedbackSummaryData.length !== 0 && (
                      <FontAwesomeIcon
                        style={{ paddingLeft: "5px" }}
                        icon={faCaretDown}
                      />
                    ))}
              </th>
              <th
                style={{ cursor: "pointer" }}
                onClick={() => {
                  sortSummaryData("comments");
                }}
              >
                No of Comments{" "}
                {(sortSelection.arrowIcon === "commentsUp" &&
                  feedbackSummaryData !== undefined &&
                  feedbackSummaryData.length !== 0 && (
                    <FontAwesomeIcon
                      style={{ paddingLeft: "5px" }}
                      icon={faCaretUp}
                    />
                  )) ||
                  (sortSelection.arrowIcon === "commentsDown" &&
                    feedbackSummaryData !== undefined &&
                    feedbackSummaryData.length !== 0 && (
                      <FontAwesomeIcon
                        style={{ paddingLeft: "5px" }}
                        icon={faCaretDown}
                      />
                    ))}
              </th>
            </tr>
          </thead>
          <tbody>
            {loading.feedbackSummary ||
            loading.journeyData ||
            loading.storeSummary ||
            loading.regionSummary ||
            loading.districtSummary ||
            loading.feedbackPeriod ? (
              <tr>
                {selectedStorePeriodValue === "Date Range" ? (
                  showStoreField &&
                  showDistrictField &&
                  selectedFeedbackChannelTypeValue === "Store" ? (
                    <LoaderForRow height={"700px"} tdCount={6} />
                  ) : !showStoreField &&
                    !showDistrictField &&
                    selectedFeedbackChannelTypeValue === "Store" ? (
                    <LoaderForRow height={"700px"} tdCount={4} />
                  ) : selectedFeedbackChannelTypeValue === "Online" ||
                    selectedFeedbackChannelTypeValue === "Call Center" ? (
                    <LoaderForRow height={"700px"} tdCount={4} />
                  ) : (
                    <LoaderForRow height={"700px"} tdCount={5} />
                  )
                ) : showStoreField &&
                  showDistrictField &&
                  selectedFeedbackChannelTypeValue === "Store" ? (
                  <LoaderForRow height={"700px"} tdCount={7} />
                ) : !showStoreField &&
                  !showDistrictField &&
                  selectedFeedbackChannelTypeValue === "Store" ? (
                  <LoaderForRow height={"700px"} tdCount={5} />
                ) : selectedFeedbackChannelTypeValue === "Online" ||
                  selectedFeedbackChannelTypeValue === "Call Center" ? (
                  <LoaderForRow height={"700px"} tdCount={5} />
                ) : (
                  <LoaderForRow height={"700px"} tdCount={6} />
                )}
              </tr>
            ) : feedbackSummaryData !== undefined &&
              feedbackSummaryData.length !== 0 ? (
              feedbackSummaryData.map((data) => {
                return (
                  <tr className="align-middle">
                    <td
                      style={{ cursor: "pointer" }}
                      onClick={() => {
                        setSummaryActive(false);
                        selectedFeedbackChannelTypeValue === "Store"
                          ? handleFeedbackJourneyWithStore({
                              target: {
                                innerText: data.JOURNEY_DESC,
                                id: data.JOURNEY_CD,
                                storeId: data.STORE_ID,
                                channelId: data.CHANNEL,
                              },
                            })
                          : handleFeedbackJourney({
                              target: {
                                innerText: data.JOURNEY_DESC,
                                id: data.JOURNEY_CD,
                                channelId: data.CHANNEL,
                              },
                            });
                      }}
                    >
                      {data.JOURNEY_DESC !== undefined &&
                      data.JOURNEY_DESC.length !== 0 &&
                      data.JOURNEY_DESC !== "-999999"
                        ? data.JOURNEY_DESC
                        : "-"}
                    </td>
                    {selectedFeedbackChannelTypeValue === "All" && (
                      <td>
                        {data.CHANNEL !== undefined &&
                        data.CHANNEL.length !== 0 &&
                        data.CHANNEL !== "-999999"
                          ? data.CHANNEL
                          : "-"}
                      </td>
                    )}
                    {showStoreField &&
                      showDistrictField &&
                      selectedFeedbackChannelTypeValue === "Store" && (
                        <td>
                          {data.DISTRICT_NAME !== undefined &&
                          data.DISTRICT_NAME.length !== 0 &&
                          data.DISTRICT_NAME !== "-999999"
                            ? data.DISTRICT_NAME
                            : "-"}
                        </td>
                      )}
                    {showStoreField &&
                      selectedFeedbackChannelTypeValue === "Store" && (
                        <td>
                          {data.STORE_ID !== undefined &&
                          data.STORE_ID.length !== 0 &&
                          data.STORE_ID !== "-999999"
                            ? data.STORE_ID
                            : "Online"}
                        </td>
                      )}
                    <td>
                      {data.AVG_RATING !== undefined &&
                      data.AVG_RATING.length !== 0 &&
                      data.AVG_RATING !== "-999999"
                        ? decimalCurrencyFormat(data.AVG_RATING)
                        : "-"}
                    </td>
                    {selectedStorePeriodValue !== "Date Range" && (
                      <td>
                        {data !== undefined &&
                        data.length !== 0 &&
                        Number(data.AVG_RATING_DIFF).toFixed(2).includes("-")
                          ? data !== undefined &&
                            data.length !== 0 &&
                            (data.AVG_RATING_DIFF === "-999999" ? (
                              "-"
                            ) : (
                              <span style={{ color: "red" }}>
                                {decimalCurrencyFormat(data.AVG_RATING_DIFF)}
                              </span>
                            ))
                          : data !== undefined &&
                            data.length !== 0 &&
                            (data.AVG_RATING_DIFF === "-999999" ? (
                              "-"
                            ) : (
                              <span style={{ color: "green" }}>
                                {decimalCurrencyFormat(data.AVG_RATING_DIFF)}
                              </span>
                            ))}
                      </td>
                    )}
                    <td>
                      {data.RATING_CNT !== undefined &&
                      data.RATING_CNT.length !== 0 &&
                      data.RATING_CNT !== "-999999"
                        ? data.RATING_CNT
                        : "-"}
                    </td>
                    <td>
                      {data.COMMENTS_CNT !== undefined &&
                      data.COMMENTS_CNT.length !== 0 &&
                      data.COMMENTS_CNT !== "-999999"
                        ? data.COMMENTS_CNT
                        : "-"}
                    </td>
                  </tr>
                );
              })
            ) : (
              <tr>
                {showStoreField &&
                showDistrictField &&
                selectedFeedbackChannelTypeValue === "Store" ? (
                  <td align="center" colSpan="7" style={{ fontWeight: "500" }}>
                    DATA NOT AVAILABLE
                  </td>
                ) : showStoreField &&
                  !showDistrictField &&
                  selectedFeedbackChannelTypeValue === "Store" ? (
                  <td align="center" colSpan="6" style={{ fontWeight: "500" }}>
                    DATA NOT AVAILABLE
                  </td>
                ) : !showStoreField &&
                  !showDistrictField &&
                  selectedFeedbackChannelTypeValue === "Store" ? (
                  <td align="center" colSpan="5" style={{ fontWeight: "500" }}>
                    DATA NOT AVAILABLE
                  </td>
                ) : (
                  <td align="center" colSpan="5" style={{ fontWeight: "500" }}>
                    DATA NOT AVAILABLE
                  </td>
                )}
              </tr>
            )}
            {loading.feedbackSummaryDataTotal ||
            loading.storeSummaryTotal ||
            loading.regionSummaryTotal ||
            loading.districtSummaryTotal ||
            loading.feedbackSummary ||
            loading.journeyData ||
            loading.storeSummary ||
            loading.regionSummary ||
            loading.districtSummary ||
            loading.feedbackPeriod ? (
              <tr key={"#SubTotal"}>
                {selectedStorePeriodValue === "Date Range" ? (
                  showStoreField &&
                  showDistrictField &&
                  selectedFeedbackChannelTypeValue === "Store" ? (
                    <LoaderForRow height={"700px"} tdCount={6} />
                  ) : !showStoreField &&
                    !showDistrictField &&
                    selectedFeedbackChannelTypeValue === "Store" ? (
                    <LoaderForRow height={"700px"} tdCount={4} />
                  ) : selectedFeedbackChannelTypeValue === "Online" ||
                    selectedFeedbackChannelTypeValue === "Call Center" ? (
                    <LoaderForRow height={"700px"} tdCount={4} />
                  ) : (
                    <LoaderForRow height={"700px"} tdCount={5} />
                  )
                ) : showStoreField &&
                  showDistrictField &&
                  selectedFeedbackChannelTypeValue === "Store" ? (
                  <LoaderForRow height={"700px"} tdCount={7} />
                ) : !showStoreField &&
                  !showDistrictField &&
                  selectedFeedbackChannelTypeValue === "Store" ? (
                  <LoaderForRow height={"700px"} tdCount={5} />
                ) : selectedFeedbackChannelTypeValue === "Online" ||
                  selectedFeedbackChannelTypeValue === "Call Center" ? (
                  <LoaderForRow height={"700px"} tdCount={5} />
                ) : (
                  <LoaderForRow height={"700px"} tdCount={6} />
                )}
              </tr>
            ) : (
              feedbackSummaryData.length !== 0 &&
              feedbackSummaryDataTotal !== undefined &&
              feedbackSummaryDataTotal.length !== 0 &&
              feedbackSummaryDataTotal.map((data) => {
                return (
                  <tr>
                    <th
                      colSpan={
                        showStoreField && showDistrictField
                          ? "3"
                          : showStoreField && !showDistrictField
                          ? "2"
                          : selectedFeedbackChannelTypeValue === "Store" ||
                            selectedFeedbackChannelTypeValue === "Online" ||
                            selectedFeedbackChannelTypeValue === "Call Center"
                          ? "1"
                          : "2"
                      }
                      style={{ backgroundColor: "lightgrey" }}
                    >
                      Total
                    </th>
                    <th>
                      {data.AVG_RATING !== undefined &&
                      data.AVG_RATING !== "-999999"
                        ? decimalCurrencyFormat(data.AVG_RATING)
                        : "-"}
                    </th>
                    {selectedStorePeriodValue !== "Date Range" && (
                      <th>
                        {data.AVG_RATING_DIFF !== undefined &&
                        data.AVG_RATING_DIFF !== "-999999"
                          ? decimalCurrencyFormat(data.AVG_RATING_DIFF)
                          : "-"}
                      </th>
                    )}
                    <th>
                      {data.RATING_CNT !== undefined &&
                      data.RATING_CNT !== "-999999"
                        ? currencyFormat(Number(data.RATING_CNT))
                        : "-"}
                    </th>
                    <th>
                      {data.COMMENTS_CNT !== undefined &&
                      data.COMMENTS_CNT !== "-999999"
                        ? currencyFormat(Number(data.COMMENTS_CNT))
                        : "-"}
                    </th>
                  </tr>
                );
              })
            )}
          </tbody>
        </Table>
      </div>
    </div>
  );
}

export default FeedbackSummary;
