import React from "react";
import { Table } from "react-bootstrap";
import LoaderForRow from "../LoaderForTable/LoaderForRow";
import { currencyFormat } from "../CdhHome/CdhHome";
import { decimalCurrencyFormat } from "../ScoreCard/Marketing";
import "../Store/StoreContainer.css";
import "./Feedback.css";
import { gettooltip } from "../Utils";
import Content from "../../components/ReadMore/ReadMore";
import { FontAwesomeIcon } from "@fortawesome/react-fontawesome";
import { faCaretUp, faCaretDown } from "@fortawesome/free-solid-svg-icons";
import { getDateFormat, UTCtoEST } from "../Utils";

function FeedbackHome({
  loading,
  feedbackData,
  sortDetailSelection,
  sortDetailData,
  feedbackSelectedChannelId,
  selectedFeedbackChannelTypeValue,
  allFeedbackJourneys,
  selectedFeedbackJourneyId,
}) {
  let filterArray = allFeedbackJourneys.filter(
    (data) => data.JOURNEY_CD === selectedFeedbackJourneyId
  );
  const selectedJourneyChannel = filterArray.length
    ? filterArray[0].CHANNEL
    : "";
  const showNoComments =
    feedbackSelectedChannelId === "Call Center" &&
    selectedFeedbackJourneyId === "J24";
  const ShowNoCommentsFromDetails = selectedFeedbackJourneyId === "J24";
  return (
    <div>
      <div className="p-3" style={{ marginBottom: "50px" }}>
        <Table striped bordered hover size="sm">
          <thead>
            <tr>
              <th>Journey</th>
              <th
                style={{ cursor: "pointer" }}
                onClick={() => {
                  sortDetailData("detailRating");
                }}
              >
                Rating{" "}
                {(sortDetailSelection.arrowIcon === "detailRatingUp" &&
                  feedbackData !== undefined &&
                  feedbackData.length !== 0 && (
                    <FontAwesomeIcon
                      style={{ paddingLeft: "5px" }}
                      icon={faCaretUp}
                    />
                  )) ||
                  (sortDetailSelection.arrowIcon === "detailRatingDown" &&
                    feedbackData !== undefined &&
                    feedbackData.length !== 0 && (
                      <FontAwesomeIcon
                        style={{ paddingLeft: "5px" }}
                        icon={faCaretDown}
                      />
                    ))}
              </th>
              {(selectedJourneyChannel === "Store" ||
                feedbackSelectedChannelId === "Store") && (
                <>
                  <th
                    style={{
                      cursor: "pointer",
                      "text-align": "center",
                      width: "10%",
                    }}
                    onClick={() => {
                      sortDetailData("detailStore");
                    }}
                  >
                    Store <br /> number{" "}
                    {(sortDetailSelection.arrowIcon === "detailStoreUp" &&
                      feedbackData !== undefined &&
                      feedbackData.length !== 0 && (
                        <FontAwesomeIcon
                          style={{ paddingLeft: "5px" }}
                          icon={faCaretUp}
                        />
                      )) ||
                      (sortDetailSelection.arrowIcon === "detailStoreDown" &&
                        feedbackData !== undefined &&
                        feedbackData.length !== 0 && (
                          <FontAwesomeIcon
                            style={{ paddingLeft: "5px" }}
                            icon={faCaretDown}
                          />
                        ))}
                  </th>
                  <th
                    style={{ cursor: "pointer" }}
                    onClick={() => {
                      sortDetailData("detailDistrict");
                    }}
                  >
                    District{" "}
                    {(sortDetailSelection.arrowIcon === "detailDistrictUp" &&
                      feedbackData !== undefined &&
                      feedbackData.length !== 0 && (
                        <FontAwesomeIcon
                          style={{ paddingLeft: "5px" }}
                          icon={faCaretUp}
                        />
                      )) ||
                      (sortDetailSelection.arrowIcon === "detailDistrictDown" &&
                        feedbackData !== undefined &&
                        feedbackData.length !== 0 && (
                          <FontAwesomeIcon
                            style={{ paddingLeft: "5px" }}
                            icon={faCaretDown}
                          />
                        ))}
                  </th>
                  <th
                    style={{ cursor: "pointer" }}
                    onClick={() => {
                      sortDetailData("detailRegion");
                    }}
                  >
                    Region{" "}
                    {(sortDetailSelection.arrowIcon === "detailRegionUp" &&
                      feedbackData !== undefined &&
                      feedbackData.length !== 0 && (
                        <FontAwesomeIcon
                          style={{ paddingLeft: "5px" }}
                          icon={faCaretUp}
                        />
                      )) ||
                      (sortDetailSelection.arrowIcon === "detailRegionDown" &&
                        feedbackData !== undefined &&
                        feedbackData.length !== 0 && (
                          <FontAwesomeIcon
                            style={{ paddingLeft: "5px" }}
                            icon={faCaretDown}
                          />
                        ))}
                  </th>
                </>
              )}
              <th
                style={{ cursor: "pointer" }}
                onClick={() => {
                  sortDetailData("detailDate");
                }}
              >
                Date{" "}
                {(sortDetailSelection.arrowIcon === "detailDateUp" &&
                  feedbackData !== undefined &&
                  feedbackData.length !== 0 && (
                    <FontAwesomeIcon
                      style={{ paddingLeft: "5px" }}
                      icon={faCaretUp}
                    />
                  )) ||
                  (sortDetailSelection.arrowIcon === "detailDateDown" &&
                    feedbackData !== undefined &&
                    feedbackData.length !== 0 && (
                      <FontAwesomeIcon
                        style={{ paddingLeft: "5px" }}
                        icon={faCaretDown}
                      />
                    ))}
              </th>
              {!showNoComments && !ShowNoCommentsFromDetails && (
                <>
                  <th
                    style={{ cursor: "pointer" }}
                    onClick={() => {
                      sortDetailData("orderNo");
                    }}
                  >
                    Order no{" "}
                    {(sortDetailSelection.arrowIcon === "orderNoUp" &&
                      feedbackData !== undefined &&
                      feedbackData.length !== 0 && (
                        <FontAwesomeIcon
                          style={{ paddingLeft: "5px" }}
                          icon={faCaretUp}
                        />
                      )) ||
                      (sortDetailSelection.arrowIcon === "orderNoDown" &&
                        feedbackData !== undefined &&
                        feedbackData.length !== 0 && (
                          <FontAwesomeIcon
                            style={{ paddingLeft: "5px" }}
                            icon={faCaretDown}
                          />
                        ))}
                  </th>
                  <th
                    style={
                      selectedJourneyChannel === "Store" ||
                      feedbackSelectedChannelId === "Store"
                        ? {
                            cursor: "pointer",
                            "text-align": "center",
                            width: "10%",
                          }
                        : { cursor: "pointer", width: "10%" }
                    }
                    onClick={() => {
                      sortDetailData("customerInformation");
                    }}
                  >
                    {selectedJourneyChannel === "Store" ||
                    feedbackSelectedChannelId === "Store" ? (
                      <span>
                        Customer <br /> information{" "}
                      </span>
                    ) : (
                      <span>Customer information </span>
                    )}
                    {(sortDetailSelection.arrowIcon ===
                      "customerInformationUp" &&
                      feedbackData !== undefined &&
                      feedbackData.length !== 0 && (
                        <FontAwesomeIcon
                          style={{ paddingLeft: "5px" }}
                          icon={faCaretUp}
                        />
                      )) ||
                      (sortDetailSelection.arrowIcon ===
                        "customerInformationDown" &&
                        feedbackData !== undefined &&
                        feedbackData.length !== 0 && (
                          <FontAwesomeIcon
                            style={{ paddingLeft: "5px" }}
                            icon={faCaretDown}
                          />
                        ))}
                  </th>
                  <th>Comments</th>{" "}
                </>
              )}
            </tr>
          </thead>
          <tbody>
            {loading.feedbackData || loading.journeyData ? (
              <tr>
                {selectedJourneyChannel === "Store" ||
                feedbackSelectedChannelId === "Store" ? (
                  <LoaderForRow height={"700px"} tdCount={9} />
                ) : selectedJourneyChannel === "Online" ||
                  feedbackSelectedChannelId === "Online" ? (
                  <LoaderForRow height={"700px"} tdCount={6} />
                ) : (
                  <LoaderForRow height={"700px"} tdCount={5} />
                )}
              </tr>
            ) : feedbackData !== undefined && feedbackData.length !== 0 ? (
              feedbackData.map((data) => {
                return (
                  <tr className="align-middle" style={{ fontSize: "14px" }}>
                    <td>
                      {data.JOURNEY_DESC !== undefined &&
                      data.JOURNEY_DESC.length !== 0 &&
                      data.JOURNEY_DESC !== "-999999"
                        ? data.JOURNEY_DESC
                        : "-"}
                    </td>

                    <td>
                      {data.RATING !== undefined &&
                      data.RATING.length !== 0 &&
                      data.RATING !== "-999999"
                        ? data.RATING
                        : "-"}
                    </td>
                    {(selectedJourneyChannel === "Store" ||
                      feedbackSelectedChannelId === "Store") && (
                      <>
                        <td>
                          {data.STORE_ID !== undefined &&
                          data.STORE_ID.length !== 0 &&
                          data.STORE_ID !== "-999999"
                            ? data.STORE_ID
                            : "-"}
                        </td>
                        <td>
                          {data.DISTRICT !== undefined &&
                          data.DISTRICT.length !== 0 &&
                          data.DISTRICT !== "-999999"
                            ? data.DISTRICT
                            : "-"}
                        </td>
                        <td style={{ width: "100px" }}>
                          {data.REGION !== undefined &&
                          data.REGION.length !== 0 &&
                          data.REGION !== "-999999"
                            ? data.REGION
                            : "-"}
                        </td>
                      </>
                    )}
                    <td>
                      {data.SUBDATE !== undefined &&
                      data.SUBDATE.length !== 0 &&
                      data.SUBDATE !== "-999999"
                        ? getDateFormat(data.SUBDATE) +
                          " " +
                          data.SUBDATE.match(/\d\d:\d\d/)
                        : // ? (data.SUBDATE)
                          "-"}
                    </td>
                    {!showNoComments && !ShowNoCommentsFromDetails && (
                      <>
                        <td>
                          {data.ORDER_NUM !== undefined &&
                          data.ORDER_NUM.length !== 0 &&
                          data.ORDER_NUM !== "-999999"
                            ? data.ORDER_NUM
                            : "-"}
                        </td>
                        <td>
                          {data.IS_CUST_INFO_AVAIL !== undefined &&
                          data.IS_CUST_INFO_AVAIL.length !== 0 &&
                          data.IS_CUST_INFO_AVAIL !== "-999999"
                            ? data.IS_CUST_INFO_AVAIL
                            : "-"}
                        </td>
                        <td className="commentsText">
                          {data.COMMENTS !== undefined &&
                          data.COMMENTS.length !== 0 &&
                          data.COMMENTS !== "-999999" ? (
                            data.COMMENTS.length > 50 ? (
                              <Content text={data.COMMENTS} />
                            ) : (
                              <span className="container">{data.COMMENTS}</span>
                            )
                          ) : (
                            <span className="hyphen"> - </span>

                          )}
                        </td>{" "}
                      </>
                    )}
                  </tr>
                );
              })
            ) : (
              <tr>
                <td align="center" colSpan="7" style={{ fontWeight: "500" }}>
                  DATA NOT AVAILABLE
                </td>
              </tr>
            )}
          </tbody>
        </Table>
      </div>
    </div>
  );
}

export default FeedbackHome;
