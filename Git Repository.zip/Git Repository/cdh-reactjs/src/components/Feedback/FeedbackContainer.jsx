import React, { useCallback, useEffect, useState } from "react";
import { Modal, Table, Dropdown, Button } from "react-bootstrap";
import { useDispatch, useSelector } from "react-redux";
import { handleFeedbackPeriodChange } from "../../Redux/Actions/FeedbackPeriodChangeActions";
import { handleFeedbackBannerChange } from "../../Redux/Actions/BannerChangeActions";
import {
  handleFeedbackJourneyChange,
  handleFeedbackSelectedStoreId,
  handleFeedbackSelectedChannelId,
} from "../../Redux/Actions/FeedbackJourneyChangeActions";
import {
  handleFeedbackStoreChange,
  handleFeedbackRegionChange,
  handleFeedbackDistrictChange,
} from "../../Redux/Actions/FeedbackDDChangeActions";
import { handleFeedbackChannelTypeChange } from "../../Redux/Actions/CategoryChangeActions";
import axios from "axios";
import { getDateFormatFromDB } from "../Utils";
import FeedbackHome from "./FeedbackHome";
import FeedbackSummary from "./FeedbackSummary";
import { FontAwesomeIcon } from "@fortawesome/react-fontawesome";
import { faArrowsRotate } from "@fortawesome/free-solid-svg-icons";
import ReactTooltip from "react-tooltip";
import NotificationMessage from "../NotificationMessage/NotificationMessage";
import { UTCtoEST, DateCompare } from "../Utils";
import DatePicker from "react-datetime";
import moment from "moment";
import calender from "../../assests/images/calender.svg";
import NoAccess from "../NoAccess/NoAccess";

function FeedbackContainer() {
  const dispatch = useDispatch();

  const FeedbackPeriods = [
    { value: "Yesterday", id: "0" },
    { value: "WTD", id: "1" },
    { value: "MTD", id: "2" },
    { value: "QTD", id: "3" },
    { value: "YTD", id: "4" },
    { value: "Date Range", id: "5" },
  ];

  const FeedbackBanners = [
    { value: "All Banner", id: "0,1,2,3,5" },
    { value: "BBBY US", id: "1" },
    { value: "BBBY CA", id: "2" },
    { value: "buy buy Baby", id: "3" },
    { value: "Harmon", id: "5" },
  ];

  const FeedbackChannelType = [
    { value: "All", id: "Online','Store','Call Center" },
    { value: "Store", id: "Store" },
    { value: "Online", id: "Online" },
    { value: "Call Center", id: "Call Center" },
  ];

  const [loading, setLoader] = useState({
    feedbackPeriod: false,
    journeyData: false,
    storeData: false,
    regionData: false,
    districtData: false,
    feedbackData: false,
    feedbackSummary: false,
    regionSummary: false,
    storeSummary: false,
    districtSummary: false,
    refreshTime: false,
    feedbackSummaryTotal: false,
    regionSummaryTotal: false,
    districtSummaryTotal: false,
    storeSummaryTotal: false,
    maxDate: false,
  });
  const [allStorePeriods, setAllStorePeriods] = useState([]);
  const [allFeedbackStores, setAllFeedbackStores] = useState([]);
  const [allFeedbackDistricts, setAllFeedbackDistricts] = useState([]);
  const [allFeedbackRegions, setAllFeedbackRegions] = useState([]);
  const [allFeedbackJourneys, setAllFeedbackJourneys] = useState([]);
  // const [periodStartDateLY, setPeriodStartDateLY] = useState("");
  // const [periodEndDateLY, setPeriodEndDateLY] = useState("");
  const [periodStartDateTY, setPeriodStartDateTY] = useState("");
  const [periodEndDateTY, setPeriodEndDateTY] = useState("");
  const [periodStartDateTY_FB, setPeriodStartDateTY_FB] = useState("");
  const [periodEndDateTY_FB, setPeriodEndDateTY_FB] = useState("");
  const [correctDateRange, setCorrectDateRange] = useState(false);
  const [feedbackSummaryData, setFeedbackSummaryData] = useState([]);
  const [summaryActive, setSummaryActive] = useState(true);
  const [showStoreField, setShowStoreField] = useState(false);
  const [showDistrictField, setShowDistrictField] = useState(true);
  const [feedbackData, setFeedBackDetailsData] = useState([]);
  const [feedbackSummaryDataTotal, setFeedbackSummaryDataTotal] = useState([]);
  const [submitActive, setSubmitActive] = useState(false);
  const [refreshTime, setRefreshTime] = useState("");
  const [maxDate, setMaxDate] = useState("");
  const [selectedDateCorrect, isSelectedDateCorrect] = useState(false);

  const refreshDate =
    refreshTime.length > 0 && UTCtoEST(refreshTime[0].end_time * 1000);

  const selectedStorePeriodValue = useSelector(
    (store) => store.FeedbackPeriod.value
  );
  const selectedFeedbackPeriodId = useSelector(
    (store) => store.FeedbackPeriod.id
  );

  const [selectedFeedbackBanner, setSelectedFeedbackBanner] = useState(
    FeedbackBanners[0]
  );

  const [selectedFeedbackChannelType, setSelectedFeedbackChannelType] =
    useState(FeedbackChannelType[0]);

  const [selectedFeedbackRegion, setSelectedFeedbackRegion] = useState({
    value: "(Select)",
    id: "(Select)",
  });
  const [selectedFeedbackStore, setSelectedFeedbackStore] = useState({
    value: "(Select)",
    id: "(Select)",
  });
  const [selectedFeedbackDistrict, setSelectedFeedbackDistrict] = useState({
    value: "(Select)",
    id: "(Select)",
  });

  const [selectedFeedbackJourney, setSelectedFeedbackJourney] = useState("");

  const selectedFeedbackBannerId = useSelector(
    (store) => store.FeedbackBanner.id
  );

  const selectedFeedbackJourneyId = useSelector(
    (store) => store.FeedbackJourney.id
  );

  const selectedFeedbackRegionId = useSelector(
    (store) => store.FeedbackRegion.id
  );

  const selectedFeedbackDistrictId = useSelector(
    (store) => store.FeedbackDistrict.id
  );

  const selectedFeedbackStoreId = useSelector(
    (store) => store.FeedbackStore.id
  );

  const selectedFeedbackChannelTypeId = useSelector(
    (store) => store.FeedbackChannelTypeId.id
  );

  const selectedFeedbackChannelTypeValue = useSelector(
    (store) => store.FeedbackChannelTypeId.value
  );

  // on click of journey - store id
  const feedbackSelectedStoreId = useSelector(
    (store) => store.FeedbackSelectedStoreId.id
  );
  const feedbackSelectedChannelId = useSelector(
    (store) => store.FeedbackSelectedChannel.id
  );
  const [sortSelection, setSortSelector] = useState({
    journeyAscending: false,
    avgRatingAscending: false,
    noRatingAscending: false,
    commentsAscending: false,
    storeAscending: false,
    channelAscending: true,
    districtAscending: false,
    avgRatingDiffAscending: false,
    arrowIcon: "channelUp",
  });

  const disableCustomDt = (current) => {
    return current.isBefore(moment().subtract(1, "days"));
  };

  const sortSummaryData = (value) => {
    if (value === "avgRating") {
      let newArr = [...feedbackSummaryData];
      sortSelection.avgRatingAscending
        ? newArr.sort((a, b) => {
            return Number(b.AVG_RATING) - Number(a.AVG_RATING);
          })
        : newArr.sort((a, b) => {
            return Number(a.AVG_RATING) - Number(b.AVG_RATING);
          });
      setFeedbackSummaryData(newArr);
      sortSelection.avgRatingAscending
        ? setSortSelector(() => ({
            journeyAscending: false,
            avgRatingAscending: false,
            noRatingAscending: false,
            commentsAscending: false,
            storeAscending: false,
            channelAscending: false,
            districtAscending: false,
            arrowIcon: "avgRatingDown",
          }))
        : setSortSelector(() => ({
            journeyAscending: false,
            avgRatingAscending: true,
            noRatingAscending: false,
            commentsAscending: false,
            storeAscending: false,
            channelAscending: false,
            districtAscending: false,
            arrowIcon: "avgRatingUp",
          }));
    } else if (value === "journey") {
      let newArr = [...feedbackSummaryData];
      sortSelection.journeyAscending
        ? newArr.sort((a, b) => {
            return b.JOURNEY_DESC.localeCompare(a.JOURNEY_DESC);
          })
        : newArr.sort((a, b) => {
            return a.JOURNEY_DESC.localeCompare(b.JOURNEY_DESC);
          });
      setFeedbackSummaryData(newArr);
      sortSelection.journeyAscending
        ? setSortSelector(() => ({
            journeyAscending: false,
            avgRatingAscending: false,
            noRatingAscending: false,
            commentsAscending: false,
            storeAscending: false,
            channelAscending: false,
            districtAscending: false,
            arrowIcon: "journeyDown",
          }))
        : setSortSelector(() => ({
            journeyAscending: true,
            avgRatingAscending: false,
            noRatingAscending: false,
            commentsAscending: false,
            storeAscending: false,
            channelAscending: false,
            districtAscending: false,
            arrowIcon: "journeyUp",
          }));
    } else if (value === "noRating") {
      let newArr = [...feedbackSummaryData];
      sortSelection.noRatingAscending
        ? newArr.sort((a, b) => {
            return Number(b.RATING_CNT) - Number(a.RATING_CNT);
          })
        : newArr.sort((a, b) => {
            return Number(a.RATING_CNT) - Number(b.RATING_CNT);
          });
      setFeedbackSummaryData(newArr);
      sortSelection.noRatingAscending
        ? setSortSelector(() => ({
            journeyAscending: false,
            avgRatingAscending: false,
            noRatingAscending: false,
            commentsAscending: false,
            storeAscending: false,
            channelAscending: false,
            districtAscending: false,
            arrowIcon: "noRatingDown",
          }))
        : setSortSelector(() => ({
            journeyAscending: false,
            avgRatingAscending: false,
            noRatingAscending: true,
            commentsAscending: false,
            storeAscending: false,
            channelAscending: false,
            districtAscending: false,
            arrowIcon: "noRatingUp",
          }));
    } else if (value === "comments") {
      let newArr = [...feedbackSummaryData];
      sortSelection.commentsAscending
        ? newArr.sort((a, b) => {
            return Number(b.COMMENTS_CNT) - Number(a.COMMENTS_CNT);
          })
        : newArr.sort((a, b) => {
            return Number(a.COMMENTS_CNT) - Number(b.COMMENTS_CNT);
          });
      setFeedbackSummaryData(newArr);
      sortSelection.commentsAscending
        ? setSortSelector(() => ({
            journeyAscending: false,
            avgRatingAscending: false,
            noRatingAscending: false,
            commentsAscending: false,
            storeAscending: false,
            channelAscending: false,
            districtAscending: false,
            arrowIcon: "commentsDown",
          }))
        : setSortSelector(() => ({
            journeyAscending: false,
            avgRatingAscending: false,
            noRatingAscending: false,
            commentsAscending: true,
            storeAscending: false,
            channelAscending: false,
            districtAscending: false,
            arrowIcon: "commentsUp",
          }));
    } else if (value === "store") {
      let newArr = [...feedbackSummaryData];
      sortSelection.storeAscending
        ? newArr.sort((a, b) => {
            return Number(b.STORE_ID) - Number(a.STORE_ID);
          })
        : newArr.sort((a, b) => {
            return Number(a.STORE_ID) - Number(b.STORE_ID);
          });
      setFeedbackSummaryData(newArr);
      sortSelection.storeAscending
        ? setSortSelector(() => ({
            journeyAscending: false,
            avgRatingAscending: false,
            noRatingAscending: false,
            commentsAscending: false,
            storeAscending: false,
            channelAscending: false,
            districtAscending: false,
            arrowIcon: "storeDown",
          }))
        : setSortSelector(() => ({
            journeyAscending: false,
            avgRatingAscending: false,
            noRatingAscending: false,
            commentsAscending: false,
            storeAscending: true,
            channelAscending: false,
            districtAscending: false,
            arrowIcon: "storeUp",
          }));
    } else if (value === "channel") {
      let newArr = [...feedbackSummaryData];
      sortSelection.channelAscending
        ? newArr.sort((a, b) => {
            return b.CHANNEL.localeCompare(a.CHANNEL);
          })
        : newArr.sort((a, b) => {
            return a.CHANNEL.localeCompare(b.CHANNEL);
          });
      setFeedbackSummaryData(newArr);
      sortSelection.channelAscending
        ? setSortSelector(() => ({
            journeyAscending: false,
            avgRatingAscending: false,
            noRatingAscending: false,
            commentsAscending: false,
            storeAscending: false,
            channelAscending: false,
            districtAscending: false,
            arrowIcon: "channelDown",
          }))
        : setSortSelector(() => ({
            journeyAscending: false,
            avgRatingAscending: false,
            noRatingAscending: false,
            commentsAscending: false,
            storeAscending: false,
            channelAscending: true,
            districtAscending: false,
            arrowIcon: "channelUp",
          }));
    } else if (value === "district") {
      let newArr = [...feedbackSummaryData];
      sortSelection.districtAscending
        ? newArr.sort((a, b) => {
            return b.DISTRICT_NAME.localeCompare(a.DISTRICT_NAME);
          })
        : newArr.sort((a, b) => {
            return a.DISTRICT_NAME.localeCompare(b.DISTRICT_NAME);
          });
      setFeedbackSummaryData(newArr);
      sortSelection.districtAscending
        ? setSortSelector(() => ({
            journeyAscending: false,
            avgRatingAscending: false,
            noRatingAscending: false,
            commentsAscending: false,
            storeAscending: false,
            channelAscending: false,
            districtAscending: false,
            arrowIcon: "districtDown",
          }))
        : setSortSelector(() => ({
            journeyAscending: false,
            avgRatingAscending: false,
            noRatingAscending: false,
            commentsAscending: false,
            storeAscending: false,
            channelAscending: false,
            districtAscending: true,
            arrowIcon: "districtUp",
          }));
    } else if (value === "avgRatingDiff") {
      {
        let newArr = [...feedbackSummaryData];
        sortSelection.avgRatingDiffAscending
          ? newArr.sort((a, b) => {
              return Number(b.AVG_RATING_DIFF) - Number(a.AVG_RATING_DIFF);
            })
          : newArr.sort((a, b) => {
              return Number(a.AVG_RATING_DIFF) - Number(b.AVG_RATING_DIFF);
            });
        setFeedbackSummaryData(newArr);
        sortSelection.avgRatingDiffAscending
          ? setSortSelector(() => ({
              journeyAscending: false,
              avgRatingAscending: false,
              avgRatingDiffAscending: false,
              noRatingAscending: false,
              commentsAscending: false,
              storeAscending: false,
              channelAscending: false,
              districtAscending: false,
              arrowIcon: "avgRatingDiffDown",
            }))
          : setSortSelector(() => ({
              journeyAscending: false,
              avgRatingAscending: false,
              avgRatingDiffAscending: true,
              noRatingAscending: false,
              commentsAscending: false,
              storeAscending: false,
              channelAscending: false,
              districtAscending: false,
              arrowIcon: "avgRatingDiffUp",
            }));
      }
    }
  };

  const [sortDetailSelection, setSortDetailSelector] = useState({
    detailRatingAscending: false,
    detailStoreAscending: true,
    detailDistrictAscending: false,
    detailRegionAscending: false,
    detailDateAscending: false,
    detailOrderNoAscending: false,
    detailCustomerInformation: false,
    arrowIcon: "detailStoreUp",
  });

  const sortDetailData = (value) => {
    if (value === "detailRating") {
      let newArr = [...feedbackData];
      sortDetailSelection.detailRatingAscending
        ? newArr.sort((a, b) => {
            return Number(b.RATING) - Number(a.RATING);
          })
        : newArr.sort((a, b) => {
            return Number(a.RATING) - Number(b.RATING);
          });
      setFeedBackDetailsData(newArr);
      sortDetailSelection.detailRatingAscending
        ? setSortDetailSelector(() => ({
            detailRatingAscending: false,
            detailStoreAscending: false,
            detailDistrictAscending: false,
            detailRegionAscending: false,
            detailDateAscending: false,
            detailOrderNoAscending: false,
            detailCustomerInformation: false,
            arrowIcon: "detailRatingDown",
          }))
        : setSortDetailSelector(() => ({
            detailRatingAscending: true,
            detailStoreAscending: false,
            detailDistrictAscending: false,
            detailRegionAscending: false,
            detailDateAscending: false,
            detailOrderNoAscending: false,
            detailCustomerInformation: false,
            arrowIcon: "detailRatingUp",
          }));
    } else if (value === "detailStore") {
      let newArr = [...feedbackData];
      sortDetailSelection.detailStoreAscending
        ? newArr.sort((a, b) => {
            return Number(b.STORE_ID) - Number(a.STORE_ID);
          })
        : newArr.sort((a, b) => {
            return Number(a.STORE_ID) - Number(b.STORE_ID);
          });
      setFeedBackDetailsData(newArr);
      sortDetailSelection.detailStoreAscending
        ? setSortDetailSelector(() => ({
            detailRatingAscending: false,
            detailStoreAscending: false,
            detailDistrictAscending: false,
            detailRegionAscending: false,
            detailDateAscending: false,
            detailOrderNoAscending: false,
            detailCustomerInformation: false,
            arrowIcon: "detailStoreDown",
          }))
        : setSortDetailSelector(() => ({
            detailRatingAscending: false,
            detailStoreAscending: true,
            detailDistrictAscending: false,
            detailRegionAscending: false,
            detailDateAscending: false,
            detailOrderNoAscending: false,
            detailCustomerInformation: false,
            arrowIcon: "detailStoreUp",
          }));
    } else if (value === "detailRegion") {
      let newArr = [...feedbackData];
      sortDetailSelection.detailRegionAscending
        ? newArr.sort((a, b) => {
            return b.REGION.localeCompare(a.REGION);
          })
        : newArr.sort((a, b) => {
            return a.REGION.localeCompare(b.REGION);
          });
      setFeedBackDetailsData(newArr);
      sortDetailSelection.detailRegionAscending
        ? setSortDetailSelector(() => ({
            detailRatingAscending: false,
            detailStoreAscending: false,
            detailDistrictAscending: false,
            detailRegionAscending: false,
            detailDateAscending: false,
            detailOrderNoAscending: false,
            detailCustomerInformation: false,
            arrowIcon: "detailRegionDown",
          }))
        : setSortDetailSelector(() => ({
            detailRatingAscending: false,
            detailStoreAscending: false,
            detailDistrictAscending: false,
            detailRegionAscending: true,
            detailDateAscending: false,
            detailOrderNoAscending: false,
            detailCustomerInformation: false,
            arrowIcon: "detailRegionUp",
          }));
    } else if (value === "detailDistrict") {
      let newArr = [...feedbackData];
      sortDetailSelection.detailDistrictAscending
        ? newArr.sort((a, b) => {
            return b.DISTRICT.localeCompare(a.DISTRICT);
          })
        : newArr.sort((a, b) => {
            return a.DISTRICT.localeCompare(b.DISTRICT);
          });
      setFeedBackDetailsData(newArr);
      sortDetailSelection.detailDistrictAscending
        ? setSortDetailSelector(() => ({
            detailRatingAscending: false,
            detailStoreAscending: false,
            detailDistrictAscending: false,
            detailRegionAscending: false,
            detailDateAscending: false,
            detailOrderNoAscending: false,
            detailCustomerInformation: false,
            arrowIcon: "detailDistrictDown",
          }))
        : setSortDetailSelector(() => ({
            detailRatingAscending: false,
            detailStoreAscending: false,
            detailDistrictAscending: true,
            detailRegionAscending: false,
            detailDateAscending: false,
            detailOrderNoAscending: false,
            detailCustomerInformation: false,
            arrowIcon: "detailDistrictUp",
          }));
    } else if (value === "detailDate") {
      let newArr = [...feedbackData];
      sortDetailSelection.detailDateAscending
        ? newArr.sort((a, b) => {
            return b.SUBDATE.localeCompare(a.SUBDATE);
          })
        : newArr.sort((a, b) => {
            return a.SUBDATE.localeCompare(b.SUBDATE);
          });
      setFeedBackDetailsData(newArr);
      sortDetailSelection.detailDateAscending
        ? setSortDetailSelector(() => ({
            detailRatingAscending: false,
            detailStoreAscending: false,
            detailDistrictAscending: false,
            detailRegionAscending: false,
            detailDateAscending: false,
            detailOrderNoAscending: false,
            detailCustomerInformation: false,
            arrowIcon: "detailDateDown",
          }))
        : setSortDetailSelector(() => ({
            detailRatingAscending: false,
            detailStoreAscending: false,
            detailDistrictAscending: false,
            detailRegionAscending: false,
            detailDateAscending: true,
            detailOrderNoAscending: false,
            detailCustomerInformation: false,
            arrowIcon: "detailDateUp",
          }));
    } else if (value === "orderNo") {
      let newArr = [...feedbackData];
      sortDetailSelection.detailOrderNoAscending
        ? newArr.sort((a, b) => {
            return b.ORDER_NUM.localeCompare(a.ORDER_NUM);
          })
        : newArr.sort((a, b) => {
            return a.ORDER_NUM.localeCompare(b.ORDER_NUM);
          });
      setFeedBackDetailsData(newArr);
      sortDetailSelection.detailOrderNoAscending
        ? setSortDetailSelector(() => ({
            detailRatingAscending: false,
            detailStoreAscending: false,
            detailDistrictAscending: false,
            detailRegionAscending: false,
            detailDateAscending: false,
            detailOrderNoAscending: false,
            detailCustomerInformation: false,
            arrowIcon: "orderNoDown",
          }))
        : setSortDetailSelector(() => ({
            detailRatingAscending: false,
            detailStoreAscending: false,
            detailDistrictAscending: false,
            detailRegionAscending: false,
            detailDateAscending: false,
            detailOrderNoAscending: true,
            detailCustomerInformation: false,
            arrowIcon: "orderNoUp",
          }));
    } else if (value === "customerInformation") {
      let newArr = [...feedbackData];
      sortDetailSelection.detailCustomerInformation
        ? newArr.sort((a, b) => {
            return b.IS_CUST_INFO_AVAIL.localeCompare(a.IS_CUST_INFO_AVAIL);
          })
        : newArr.sort((a, b) => {
            return a.IS_CUST_INFO_AVAIL.localeCompare(b.IS_CUST_INFO_AVAIL);
          });
      setFeedBackDetailsData(newArr);
      sortDetailSelection.detailCustomerInformation
        ? setSortDetailSelector(() => ({
            detailRatingAscending: false,
            detailStoreAscending: false,
            detailDistrictAscending: false,
            detailRegionAscending: false,
            detailDateAscending: false,
            detailOrderNoAscending: false,
            detailCustomerInformation: false,
            arrowIcon: "customerInformationDown",
          }))
        : setSortDetailSelector(() => ({
            detailRatingAscending: false,
            detailStoreAscending: false,
            detailDistrictAscending: false,
            detailRegionAscending: false,
            detailDateAscending: false,
            detailOrderNoAscending: false,
            detailCustomerInformation: true,
            arrowIcon: "customerInformationUp",
          }));
    }
  };

  const handleFeedbackPeriod = useCallback(
    (event) => {
      dispatch(
        handleFeedbackPeriodChange({
          value: event.target.innerText,
          id: event.target.id,
        })
      );
      if (event.target.innerText === "Date Range") {
        setPeriodStartDateTY("");
        setPeriodEndDateTY("");
        setPeriodStartDateTY_FB("1970-01-01"); //passing dummy date to handle the case in api
        setPeriodEndDateTY_FB("1970-01-01"); //passing dummy date to handle the case in api
        setFeedbackSummaryData([]);
        setFeedbackSummaryDataTotal([]);
        setFeedBackDetailsData([]);
      } else {
        setSubmitActive(false);
        setCorrectDateRange(false);
        isSelectedDateCorrect(false);
      }
    },
    [selectedFeedbackPeriodId]
  );

  const handleStartDate = (dateSelected) => {
    if (moment(dateSelected, "MM/DD/YYYY", true).isValid()) {
      setPeriodStartDateTY(dateSelected.format("YYYY-MM-DD"));
      periodEndDateTY !== "" && setSubmitActive(true);
    }
    setCorrectDateRange(false);
    setLoader((currValue) => ({
      ...currValue,
      feedbackData: false,
    }));
  };

  const handleEndDate = (dateSelected) => {
    if (moment(dateSelected, "MM/DD/YYYY", true).isValid()) {
      setPeriodEndDateTY(dateSelected.format("YYYY-MM-DD"));
      periodStartDateTY !== "" && setSubmitActive(true);
    }
    setCorrectDateRange(false);
    setLoader((currValue) => ({
      ...currValue,
      feedbackData: false,
    }));
  };

  const handleSubmit = () => {
    if (DateCompare(periodStartDateTY, periodEndDateTY) > 0) {
      alert("Start date cannot be greater than end date");
      isSelectedDateCorrect(false);
      setCorrectDateRange(false);
    } else {
      setSubmitActive(false);
      isSelectedDateCorrect(true);
      setCorrectDateRange(true);
    }
  };

  const handleFeedbackBanner = useCallback(
    (event) => {
      setSelectedFeedbackBanner((prevsValue) => ({
        ...prevsValue,
        value: event.target.innerText,
        id: event.target.id,
      }));
      dispatch(
        handleFeedbackBannerChange({
          value: event.target.innerText,
          id: event.target.id,
        })
      );
      setCorrectDateRange(true);
    },
    [selectedFeedbackBannerId]
  );

  const handleFeedbackChannelType = useCallback(
    (event) => {
      setSelectedFeedbackChannelType((prevsValue) => ({
        ...prevsValue,
        value: event.target.innerText,
        id: event.target.id,
      }));
      dispatch(
        handleFeedbackChannelTypeChange({
          value: event.target.innerText,
          id: event.target.id,
        })
      );
      setShowStoreField(false);
      setShowDistrictField(false);
      setCorrectDateRange(true);
      //setSubmitActive(false);
    },
    [selectedFeedbackChannelTypeId]
  );

  const handleFeedbackJourney = useCallback((event) => {
    setSelectedFeedbackJourney((prevsValue) => ({
      ...prevsValue,
      value: event.target.innerText,
      id: event.target.id,
    }));
    dispatch(
      handleFeedbackJourneyChange({
        value: event.target.innerText,
        id: event.target.id,
      })
    );
    dispatch(
      handleFeedbackSelectedStoreId({
        value: "",
        id: "",
      })
    );
    dispatch(
      handleFeedbackSelectedChannelId({
        value: "",
        id: event.target.channelId,
      })
    );
    setCorrectDateRange(true);
    if (
      selectedStorePeriodValue === "Date Range" &&
      feedbackSelectedStoreId === ""
    ) {
      isSelectedDateCorrect(false);
      // setLoader((currValue) => ({
      //   ...currValue,
      //   feedbackData: true,
      // }));
    }
  }, []);

  const handleFeedbackJourneyWithStore = useCallback((event) => {
    setSelectedFeedbackJourney((prevsValue) => ({
      ...prevsValue,
      value: event.target.innerText,
      id: event.target.id,
    }));
    dispatch(
      handleFeedbackJourneyChange({
        value: event.target.innerText,
        id: event.target.id,
      })
    );
    dispatch(
      handleFeedbackSelectedStoreId({
        value: "",
        id: event.target.storeId,
      })
    );
    dispatch(
      handleFeedbackSelectedChannelId({
        value: "",
        id: event.target.channelId,
      })
    );
    setCorrectDateRange(true);
    if (selectedStorePeriodValue === "Date Range") isSelectedDateCorrect(false);
  }, []);

  const handleFeedbackRegion = useCallback((event) => {
    setSelectedFeedbackRegion((prevsValue) => ({
      ...prevsValue,
      value: event.target.innerText,
      id: event.target.innerText,
    }));
    dispatch(
      handleFeedbackRegionChange({
        value: event.target.innerText,
        id: event.target.innerText,
      })
    );
    setShowStoreField(true);
    setShowDistrictField(true);
    setSelectedFeedbackDistrict((prevsValue) => ({
      ...prevsValue,
      value: "(Select)",
      id: "(Select)",
    }));
    dispatch(
      handleFeedbackDistrictChange({
        value: "(Select)",
        id: "(Select)",
      })
    );
    setSelectedFeedbackStore((prevsValue) => ({
      ...prevsValue,
      value: "(Select)",
      id: "(Select)",
    }));
    dispatch(
      handleFeedbackStoreChange({
        value: "(Select)",
        id: "(Select)",
      })
    );
    setCorrectDateRange(true);
  }, []);

  const handleFeedbackDistrict = useCallback((event) => {
    setSelectedFeedbackDistrict((prevsValue) => ({
      ...prevsValue,
      value: event.target.innerText,
      id: event.target.innerText,
    }));
    dispatch(
      handleFeedbackDistrictChange({
        value: event.target.innerText,
        id: event.target.innerText,
      })
    );
    setShowStoreField(true);
    setShowDistrictField(false);
    setSelectedFeedbackRegion((prevsValue) => ({
      ...prevsValue,
      value: "(Select)",
      id: "(Select)",
    }));
    dispatch(
      handleFeedbackRegionChange({
        value: "(Select)",
        id: "(Select)",
      })
    );
    setSelectedFeedbackStore((prevsValue) => ({
      ...prevsValue,
      value: "(Select)",
      id: "(Select)",
    }));
    dispatch(
      handleFeedbackStoreChange({
        value: "(Select)",
        id: "(Select)",
      })
    );
    setCorrectDateRange(true);
  }, []);

  const handleFeedbackStore = useCallback((event) => {
    setSelectedFeedbackStore((prevsValue) => ({
      ...prevsValue,
      value: event.target.innerText,
      id: event.target.id,
    }));
    dispatch(
      handleFeedbackStoreChange({
        value: event.target.innerText,
        id: event.target.id,
      })
    );
    setShowStoreField(false);
    setShowDistrictField(false);
    setSelectedFeedbackDistrict((prevsValue) => ({
      ...prevsValue,
      value: "(Select)",
      id: "(Select)",
    }));
    dispatch(
      handleFeedbackDistrictChange({
        value: "(Select)",
        id: "(Select)",
      })
    );
    setSelectedFeedbackRegion((prevsValue) => ({
      ...prevsValue,
      value: "(Select)",
      id: "(Select)",
    }));
    dispatch(
      handleFeedbackRegionChange({
        value: "(Select)",
        id: "(Select)",
      })
    );
    setCorrectDateRange(true);
  }, []);

  useEffect(() => {
    if (
      selectedFeedbackChannelTypeId === "Online','Store','Call Center" ||
      selectedFeedbackChannelTypeId === "Online" ||
      selectedFeedbackChannelTypeId === "Call Center"
    ) {
      setSelectedFeedbackRegion((prevsValue) => ({
        ...prevsValue,
        value: "(Select)",
        id: "(Select)",
      }));
      dispatch(
        handleFeedbackRegionChange({
          value: "(Select)",
          id: "(Select)",
        })
      );
      setSelectedFeedbackDistrict((prevsValue) => ({
        ...prevsValue,
        value: "(Select)",
        id: "(Select)",
      }));
      dispatch(
        handleFeedbackDistrictChange({
          value: "(Select)",
          id: "(Select)",
        })
      );
      setSelectedFeedbackStore((prevsValue) => ({
        ...prevsValue,
        value: "(Select)",
        id: "(Select)",
      }));
      dispatch(
        handleFeedbackStoreChange({
          value: "(Select)",
          id: "(Select)",
        })
      );
    }
  }, [selectedFeedbackChannelTypeId]);

  useEffect(() => {
    const getLastRefreshTime = async () => {
      try {
        setLoader((currValue) => ({
          ...currValue,
          refreshTime: true,
        }));
        let url =
          process.env.REACT_APP_API_ENDPOINT +
          process.env.REACT_APP_REFRESH_TIME +
          "dagId=FEEDBACK";
        await axios({ url }).then((res) => {
          setLoader((currValue) => ({
            ...currValue,
            refreshTime: false,
          }));
          setRefreshTime(res.data);
        });
      } catch (err) {
        setLoader((currValue) => ({
          ...currValue,
          refreshTime: true,
        }));
        console.log("err-getLastRefreshTime", err);
      }
    };
    const getMaxDate = async () => {
      try {
        setLoader((currValue) => ({
          ...currValue,
          maxDate: true,
        }));
        let url =
          process.env.REACT_APP_API_ENDPOINT +
          process.env.REACT_APP_FEEDBACK_MAX_DATE;
        await axios({ url }).then((res) => {
          setLoader((currValue) => ({
            ...currValue,
            maxDate: false,
          }));
          setMaxDate(res.data);
        });
      } catch (err) {
        setLoader((currValue) => ({
          ...currValue,
          maxDate: true,
        }));
        console.log("err-getMaxDate", err);
      }
    };
    getLastRefreshTime();
    getMaxDate();
  }, []);

  useEffect(() => {
    const getFeedbackPeriods = async () => {
      try {
        setLoader((currValue) => ({
          ...currValue,
          feedbackPeriod: true,
        }));
        let url =
          process.env.REACT_APP_API_ENDPOINT +
          process.env.REACT_APP_FEEDBACK_DATE_FILTER;
        await axios({ url }).then((res) => {
          setLoader((currValue) => ({
            ...currValue,
            feedbackPeriod: false,
          }));
          setAllStorePeriods(res.data);
          if (
            selectedFeedbackPeriodId === "0" &&
            allStorePeriods[0] !== undefined &&
            allStorePeriods[0] !== null
          ) {
            setPeriodStartDateTY(allStorePeriods[0].TY_YESTERDAY);
            setPeriodEndDateTY(allStorePeriods[0].TY_YESTERDAY);
            setPeriodStartDateTY_FB(allStorePeriods[0].TY_YESTERDAY_FB);
            setPeriodEndDateTY_FB(allStorePeriods[0].TY_YESTERDAY_FB);
            // setPeriodStartDateLY(allStorePeriods[0].LY_YESTERDAY);
            // setPeriodEndDateLY(allStorePeriods[0].LY_YESTERDAY);
            setCorrectDateRange(true);
          }
        });
      } catch (err) {
        setLoader((currValue) => ({
          ...currValue,
          feedbackPeriod: true,
        }));
        console.log("err-getFeedbackPeriods", err);
      }
    };
    getFeedbackPeriods();
  }, []);

  useEffect(() => {
    const getFeedbackSummaryData = async () => {
      try {
        setLoader((currValue) => ({
          ...currValue,
          feedbackSummary: true,
        }));
        let url =
          process.env.REACT_APP_API_ENDPOINT +
          process.env.REACT_APP_FEEDBACK_SUMMARY_DATA +
          "?startDate=" +
          periodStartDateTY +
          "&endDate=" +
          periodEndDateTY +
          "&fbStartDt=" +
          periodStartDateTY_FB +
          "&fbEndDt=" +
          periodEndDateTY_FB +
          "&concept=" +
          selectedFeedbackBannerId +
          "&channel=" +
          selectedFeedbackChannelTypeId;
        if (
          correctDateRange &&
          periodStartDateTY !== "" &&
          periodEndDateTY !== ""
        ) {
          setSubmitActive(false);
          await axios({ url }).then((res) => {
            setLoader((currValue) => ({
              ...currValue,
              feedbackSummary: false,
            }));
            setFeedbackSummaryData(
              res.data.sort((a, b) => {
                return a.CHANNEL.localeCompare(b.CHANNEL);
              })
            );
          });
          setCorrectDateRange(false);
          isSelectedDateCorrect(false);
        } else {
          setLoader((currValue) => ({
            ...currValue,
            feedbackSummary: false,
          }));
        }
      } catch (err) {
        setLoader((currValue) => ({
          ...currValue,
          feedbackSummary: true,
        }));
        console.log("err-getFeedbackSummaryData", err);
      }
    };
    const getFeedbackSummaryDataTotal = async () => {
      try {
        setLoader((currValue) => ({
          ...currValue,
          feedbackSummaryTotal: true,
        }));
        let url =
          process.env.REACT_APP_API_ENDPOINT +
          process.env.REACT_APP_FEEDBACK_SUMMARY_DATA_TOTAL +
          "startDate=" +
          periodStartDateTY +
          "&endDate=" +
          periodEndDateTY +
          "&concept=" +
          selectedFeedbackBannerId +
          "&channel=" +
          selectedFeedbackChannelTypeId +
          "&fbStartDt=" +
          periodStartDateTY_FB +
          "&fbEndDt=" +
          periodEndDateTY_FB;
        if (
          correctDateRange &&
          periodStartDateTY !== "" &&
          periodEndDateTY !== ""
        ) {
          setSubmitActive(false);
          await axios({ url }).then((res) => {
            setLoader((currValue) => ({
              ...currValue,
              feedbackSummaryTotal: false,
            }));
            setFeedbackSummaryDataTotal(res.data);
          });
          setCorrectDateRange(false);
          isSelectedDateCorrect(false);
        } else {
          setLoader((currValue) => ({
            ...currValue,
            feedbackSummaryTotal: true,
          }));
        }
      } catch (err) {
        setLoader((currValue) => ({
          ...currValue,
          feedbackSummaryTotal: true,
        }));
        console.log("err-getFeedbackSummaryDataTotal", err);
      }
    };
    if (
      localStorage.getItem("isCUSTOMER_FEEDBACK") === "Y" &&
      periodStartDateTY !== "" &&
      periodEndDateTY !== "" &&
      selectedFeedbackRegionId === "(Select)" &&
      selectedFeedbackDistrictId === "(Select)" &&
      selectedFeedbackStoreId === "(Select)" &&
      correctDateRange &&
      DateCompare(periodStartDateTY, periodEndDateTY) <= 0
    ) {
      getFeedbackSummaryData();
      getFeedbackSummaryDataTotal();
    }
    setSortSelector(() => ({
      journeyAscending: false,
      avgRatingAscending: false,
      avgRatingDiffAscending: false,
      noRatingAscending: false,
      commentsAscending: false,
      storeAscending: false,
      channelAscending: true,
      districtAscending: false,
      arrowIcon: "channelUp",
    }));
  }, [
    selectedFeedbackPeriodId,
    selectedFeedbackBannerId,
    periodStartDateTY,
    periodEndDateTY,
    summaryActive,
    selectedFeedbackRegionId,
    selectedFeedbackDistrictId,
    selectedFeedbackStoreId,
    correctDateRange,
    //submitActive,
    selectedDateCorrect,
  ]);
  useEffect(() => {
    const assignDates = () => {
      if (selectedFeedbackPeriodId === "0") {
        setPeriodStartDateTY(allStorePeriods[0].TY_YESTERDAY);
        setPeriodEndDateTY(allStorePeriods[0].TY_YESTERDAY);
        setPeriodStartDateTY_FB(allStorePeriods[0].TY_YESTERDAY_FB);
        setPeriodEndDateTY_FB(allStorePeriods[0].TY_YESTERDAY_FB);
        // setPeriodStartDateLY(allStorePeriods[0].LY_YESTERDAY);
        // setPeriodEndDateLY(allStorePeriods[0].LY_YESTERDAY);
        setCorrectDateRange(true);
      } else if (selectedFeedbackPeriodId === "1") {
        setPeriodStartDateTY(allStorePeriods[0].TY_WTD_START_DATE);
        setPeriodEndDateTY(allStorePeriods[0].TY_WTD_END_DATE);
        setPeriodStartDateTY_FB(allStorePeriods[0].TY_WTD_START_DATE_FB);
        setPeriodEndDateTY_FB(allStorePeriods[0].TY_WTD_END_DATE_FB);
        // setPeriodStartDateLY(allStorePeriods[0].LY_WTD_START_DATE);
        // setPeriodEndDateLY(allStorePeriods[0].LY_WTD_END_DATE);
        setCorrectDateRange(true);
      } else if (selectedFeedbackPeriodId === "2") {
        setPeriodStartDateTY(allStorePeriods[0].TY_MTD_START_DATE);
        setPeriodEndDateTY(allStorePeriods[0].TY_MTD_END_DATE);
        setPeriodStartDateTY_FB(allStorePeriods[0].TY_MTD_START_DATE_FB);
        setPeriodEndDateTY_FB(allStorePeriods[0].TY_MTD_END_DATE_FB);
        // setPeriodStartDateLY(allStorePeriods[0].LY_MTD_START_DATE);
        // setPeriodEndDateLY(allStorePeriods[0].LY_MTD_END_DATE);
        setCorrectDateRange(true);
      } else if (selectedFeedbackPeriodId === "3") {
        setPeriodStartDateTY(allStorePeriods[0].TY_QTD_START_DATE);
        setPeriodEndDateTY(allStorePeriods[0].TY_QTD_END_DATE);
        setPeriodStartDateTY_FB(allStorePeriods[0].TY_QTD_START_DATE_FB);
        setPeriodEndDateTY_FB(allStorePeriods[0].TY_QTD_END_DATE_FB);
        // setPeriodStartDateLY(allStorePeriods[0].LY_QTD_START_DATE);
        // setPeriodEndDateLY(allStorePeriods[0].LY_QTD_END_DATE);
        setCorrectDateRange(true);
      } else if (selectedFeedbackPeriodId === "4") {
        setPeriodStartDateTY(allStorePeriods[0].TY_YTD_START_DATE);
        setPeriodEndDateTY(allStorePeriods[0].TY_YTD_END_DATE);
        setPeriodStartDateTY_FB(allStorePeriods[0].TY_YTD_START_DATE_FB);
        setPeriodEndDateTY_FB(allStorePeriods[0].TY_YTD_END_DATE_FB);
        // setPeriodStartDateLY(allStorePeriods[0].LY_YTD_START_DATE);
        // setPeriodEndDateLY(allStorePeriods[0].LY_YTD_END_DATE);
        setCorrectDateRange(true);
      }
    };
    allStorePeriods[0] !== undefined &&
      allStorePeriods[0] !== null &&
      correctDateRange === false &&
      assignDates();
  }, [
    allStorePeriods,
    selectedFeedbackPeriodId,
    //periodEndDateLY,
    periodEndDateTY,
    //periodStartDateLY,
    periodStartDateTY,
    //correctDateRange,
  ]);

  useEffect(() => {
    const getFeedbackJourneys = async () => {
      try {
        setLoader((currValue) => ({
          ...currValue,
          journeyData: true,
        }));
        let url =
          process.env.REACT_APP_API_ENDPOINT +
          process.env.REACT_APP_FEEDBACK_JOURNEYS;
        await axios({ url }).then((res) => {
          setLoader((currValue) => ({
            ...currValue,
            journeyData: false,
          }));
          setAllFeedbackJourneys(
            res.data.sort((a, b) => {
              return a.JOURNEY_DESC.localeCompare(b.JOURNEY_DESC);
            })
          );
        });
      } catch (err) {
        setLoader((currValue) => ({
          ...currValue,
          journeyData: true,
        }));
        console.log("err-getFeedbackJourneys", err);
      }
    };

    const getFeedbackStores = async () => {
      try {
        setLoader((currValue) => ({
          ...currValue,
          storeData: true,
        }));
        let url =
          process.env.REACT_APP_API_ENDPOINT +
          process.env.REACT_APP_FEEDBACK_STORES;
        await axios({ url }).then((res) => {
          setLoader((currValue) => ({
            ...currValue,
            storeData: false,
          }));
          setAllFeedbackStores(res.data);
        });
      } catch (err) {
        setLoader((currValue) => ({
          ...currValue,
          storeData: true,
        }));
        console.log("err-getFeedbackStores", err);
      }
    };

    const getFeedbackDistricts = async () => {
      try {
        setLoader((currValue) => ({
          ...currValue,
          districtData: true,
        }));
        let url =
          process.env.REACT_APP_API_ENDPOINT +
          process.env.REACT_APP_FEEDBACK_DISTRICTS;
        await axios({ url }).then((res) => {
          setLoader((currValue) => ({
            ...currValue,
            districtData: false,
          }));
          setAllFeedbackDistricts(res.data);
        });
      } catch (err) {
        setLoader((currValue) => ({
          ...currValue,
          districtData: true,
        }));
        console.log("err-getFeedbackDistricts", err);
      }
    };

    const getFeedbackRegions = async () => {
      try {
        setLoader((currValue) => ({
          ...currValue,
          regionData: true,
        }));
        let url =
          process.env.REACT_APP_API_ENDPOINT +
          process.env.REACT_APP_FEEDBACK_REGIONS;
        await axios({ url }).then((res) => {
          setLoader((currValue) => ({
            ...currValue,
            regionData: false,
          }));
          setAllFeedbackRegions(res.data);
        });
      } catch (err) {
        setLoader((currValue) => ({
          ...currValue,
          regionData: true,
        }));
        console.log("err-getFeedbackRegions", err);
      }
    };
    if (localStorage.getItem("isCUSTOMER_FEEDBACK") === "Y") {
      getFeedbackJourneys();
      getFeedbackStores();
      getFeedbackDistricts();
      getFeedbackRegions();
    }
  }, []);

  useEffect(() => {
    const getFeedbackRegionSummary = async () => {
      try {
        setLoader((currValue) => ({
          ...currValue,
          regionSummary: true,
        }));
        let url =
          process.env.REACT_APP_API_ENDPOINT +
          process.env.REACT_APP_FEEDBACK_SUMMARY_REGION_DATA +
          "?startDate=" +
          periodStartDateTY +
          "&endDate=" +
          periodEndDateTY +
          "&fbStartDt=" +
          periodStartDateTY_FB +
          "&fbEndDt=" +
          periodEndDateTY_FB +
          "&concept=" +
          selectedFeedbackBannerId +
          "&region=" +
          selectedFeedbackRegionId +
          "&channel=" +
          selectedFeedbackChannelTypeId;

        if (
          correctDateRange &&
          periodStartDateTY !== "" &&
          periodEndDateTY !== ""
        ) {
          setSubmitActive(false);
          await axios({ url }).then((res) => {
            setLoader((currValue) => ({
              ...currValue,
              regionSummary: false,
            }));
            setFeedbackSummaryData(
              res.data.sort((a, b) => {
                return a.JOURNEY_DESC.localeCompare(b.JOURNEY_DESC);
              })
            );
          });
          setCorrectDateRange(false);
          isSelectedDateCorrect(false);
        } else {
          setLoader((currValue) => ({
            ...currValue,
            regionSummary: false,
          }));
        }
      } catch (err) {
        setLoader((currValue) => ({
          ...currValue,
          regionSummary: true,
        }));
        console.log("err-getFeedbackRegionSummary", err);
      }
    };

    const getFeedbackStoreSummary = async () => {
      try {
        setLoader((currValue) => ({
          ...currValue,
          storeSummary: true,
        }));
        let url =
          process.env.REACT_APP_API_ENDPOINT +
          process.env.REACT_APP_FEEDBACK_SUMMARY_STORE_DATA +
          "?startDate=" +
          periodStartDateTY +
          "&endDate=" +
          periodEndDateTY +
          "&fbStartDt=" +
          periodStartDateTY_FB +
          "&fbEndDt=" +
          periodEndDateTY_FB +
          "&concept=" +
          selectedFeedbackBannerId +
          "&storeNum=" +
          selectedFeedbackStoreId +
          "&channel=" +
          selectedFeedbackChannelTypeId;
        if (
          correctDateRange &&
          periodStartDateTY !== "" &&
          periodEndDateTY !== ""
        ) {
          setSubmitActive(false);
          await axios({ url }).then((res) => {
            setLoader((currValue) => ({
              ...currValue,
              storeSummary: false,
            }));
            setFeedbackSummaryData(
              res.data.sort((a, b) => {
                return a.JOURNEY_DESC.localeCompare(b.JOURNEY_DESC);
              })
            );
          });
          setCorrectDateRange(false);
          isSelectedDateCorrect(false);
        } else {
          setLoader((currValue) => ({
            ...currValue,
            storeSummary: false,
          }));
        }
      } catch (err) {
        setLoader((currValue) => ({
          ...currValue,
          storeSummary: true,
        }));
        console.log("err-getFeedbackStoreSummary", err);
      }
    };

    const getFeedbackDistrictSummary = async () => {
      try {
        setLoader((currValue) => ({
          ...currValue,
          districtSummary: true,
        }));
        let url =
          process.env.REACT_APP_API_ENDPOINT +
          process.env.REACT_APP_FEEDBACK_SUMMARY_DISTRICT_DATA +
          "?startDate=" +
          periodStartDateTY +
          "&endDate=" +
          periodEndDateTY +
          "&fbStartDt=" +
          periodStartDateTY_FB +
          "&fbEndDt=" +
          periodEndDateTY_FB +
          "&concept=" +
          selectedFeedbackBannerId +
          "&district=" +
          selectedFeedbackDistrictId +
          "&channel=" +
          selectedFeedbackChannelTypeId;
        if (
          correctDateRange &&
          periodStartDateTY !== "" &&
          periodEndDateTY !== ""
        ) {
          setSubmitActive(false);
          await axios({ url }).then((res) => {
            setLoader((currValue) => ({
              ...currValue,
              districtSummary: false,
            }));
            setFeedbackSummaryData(
              res.data.sort((a, b) => {
                return a.JOURNEY_DESC.localeCompare(b.JOURNEY_DESC);
              })
            );
          });
          setCorrectDateRange(false);
          isSelectedDateCorrect(false);
        } else {
          setLoader((currValue) => ({
            ...currValue,
            districtSummary: false,
          }));
        }
      } catch (err) {
        setLoader((currValue) => ({
          ...currValue,
          districtSummary: true,
        }));
        console.log("err-getFeedbackDistrictSummary", err);
      }
    };
    const getFeedbackRegionSummaryTotal = async () => {
      try {
        setLoader((currValue) => ({
          ...currValue,
          regionSummaryTotal: true,
        }));
        let url =
          process.env.REACT_APP_API_ENDPOINT +
          process.env.REACT_APP_FEEDBACK_SUMMARY_REGION_DATA_TOTAL +
          "startDate=" +
          periodStartDateTY +
          "&endDate=" +
          periodEndDateTY +
          "&concept=" +
          selectedFeedbackBannerId +
          "&region=" +
          selectedFeedbackRegionId +
          "&fbStartDt=" +
          periodStartDateTY_FB +
          "&fbEndDt=" +
          periodEndDateTY_FB;
        if (
          correctDateRange &&
          periodStartDateTY !== "" &&
          periodEndDateTY !== ""
        ) {
          setSubmitActive(false);
          await axios({ url }).then((res) => {
            setLoader((currValue) => ({
              ...currValue,
              regionSummaryTotal: false,
            }));
            setFeedbackSummaryDataTotal(res.data);
          });
          setCorrectDateRange(false);
          isSelectedDateCorrect(false);
        } else {
          setLoader((currValue) => ({
            ...currValue,
            regionSummaryTotal: false,
          }));
        }
      } catch (err) {
        setLoader((currValue) => ({
          ...currValue,
          regionSummaryTotal: true,
        }));
        console.log("err-getFeedbackRegionSummaryTotal", err);
      }
    };
    const getFeedbackStoreSummaryTotal = async () => {
      try {
        setLoader((currValue) => ({
          ...currValue,
          storeSummaryTotal: true,
        }));
        let url =
          process.env.REACT_APP_API_ENDPOINT +
          process.env.REACT_APP_FEEDBACK_SUMMARY_STORE_DATA_TOTAL +
          "startDate=" +
          periodStartDateTY +
          "&endDate=" +
          periodEndDateTY +
          "&concept=" +
          selectedFeedbackBannerId +
          "&storeNumber=" +
          selectedFeedbackStoreId +
          "&fbStartDt=" +
          periodStartDateTY_FB +
          "&fbEndDt=" +
          periodEndDateTY_FB;
        if (
          correctDateRange &&
          periodStartDateTY !== "" &&
          periodEndDateTY !== ""
        ) {
          setSubmitActive(false);
          await axios({ url }).then((res) => {
            setLoader((currValue) => ({
              ...currValue,
              storeSummaryTotal: false,
            }));
            setFeedbackSummaryDataTotal(res.data);
          });
          setCorrectDateRange(false);
          isSelectedDateCorrect(false);
        } else {
          setLoader((currValue) => ({
            ...currValue,
            storeSummaryTotal: false,
          }));
        }
      } catch (err) {
        setLoader((currValue) => ({
          ...currValue,
          storeSummaryTotal: true,
        }));
        console.log("err-getFeedbackStoreSummaryTotal", err);
      }
    };
    const getFeedbackDistrictSummaryTotal = async () => {
      try {
        setLoader((currValue) => ({
          ...currValue,
          districtSummaryTotal: true,
        }));
        let url =
          process.env.REACT_APP_API_ENDPOINT +
          process.env.REACT_APP_FEEDBACK_SUMMARY_DISTRICT_DATA_TOTAL +
          "startDate=" +
          periodStartDateTY +
          "&endDate=" +
          periodEndDateTY +
          "&concept=" +
          selectedFeedbackBannerId +
          "&district=" +
          selectedFeedbackDistrictId +
          "&fbStartDt=" +
          periodStartDateTY_FB +
          "&fbEndDt=" +
          periodEndDateTY_FB;
        if (
          correctDateRange &&
          periodStartDateTY !== "" &&
          periodEndDateTY !== ""
        ) {
          setSubmitActive(false);
          await axios({ url }).then((res) => {
            setLoader((currValue) => ({
              ...currValue,
              districtSummaryTotal: false,
            }));
            setFeedbackSummaryDataTotal(res.data);
          });
          setCorrectDateRange(false);
          isSelectedDateCorrect(false);
        } else {
          setLoader((currValue) => ({
            ...currValue,
            districtSummaryTotal: false,
          }));
        }
      } catch (err) {
        setLoader((currValue) => ({
          ...currValue,
          districtSummaryTotal: true,
        }));
        console.log("err-getFeedbackDistrictSummaryTotal", err);
      }
    };

    if (
      selectedFeedbackRegionId !== "(Select)" &&
      selectedFeedbackDistrictId === "(Select)" &&
      selectedFeedbackStoreId === "(Select)" &&
      DateCompare(periodStartDateTY, periodEndDateTY) <= 0
    ) {
      getFeedbackRegionSummary();
      getFeedbackRegionSummaryTotal();
    } else if (
      selectedFeedbackRegionId === "(Select)" &&
      selectedFeedbackDistrictId === "(Select)" &&
      selectedFeedbackStoreId !== "(Select)" &&
      DateCompare(periodStartDateTY, periodEndDateTY) <= 0
    ) {
      getFeedbackStoreSummary();
      getFeedbackStoreSummaryTotal();
    } else if (
      selectedFeedbackRegionId === "(Select)" &&
      selectedFeedbackDistrictId !== "(Select)" &&
      selectedFeedbackStoreId === "(Select)" &&
      DateCompare(periodStartDateTY, periodEndDateTY) <= 0
    ) {
      getFeedbackDistrictSummary();
      getFeedbackDistrictSummaryTotal();
    }
  }, [
    allStorePeriods,
    selectedFeedbackPeriodId,
    //periodEndDateLY,
    periodEndDateTY,
    //periodStartDateLY,
    periodStartDateTY,
    selectedFeedbackRegionId,
    selectedFeedbackBannerId,
    selectedFeedbackDistrictId,
    selectedFeedbackStoreId,
    //submitActive,
    selectedDateCorrect,
  ]);

  useEffect(() => {
    const getFeedBackDetailsDataWithJourneyFilter = async () => {
      try {
        setLoader((currValue) => ({
          ...currValue,
          feedbackData: true,
        }));
        let url =
          process.env.REACT_APP_API_ENDPOINT +
          process.env.REACT_APP_FEEDBACK_DETAIL_WITH_JOURNEY_DATA +
          "startDate=" +
          periodStartDateTY +
          "&endDate=" +
          periodEndDateTY +
          "&concept=" +
          selectedFeedbackBannerId +
          "&journey=" +
          selectedFeedbackJourneyId;
        if (correctDateRange) {
          setSubmitActive(false);
          await axios({ url }).then((res) => {
            setLoader((currValue) => ({
              ...currValue,
              feedbackData: false,
            }));
            setFeedBackDetailsData(
              res.data.sort((a, b) => {
                return Number(a.STORE_ID) - Number(b.STORE_ID);
              })
            );
          });
          setCorrectDateRange(false);
        } else {
          setLoader((currValue) => ({
            ...currValue,
            feedbackData: false,
          }));
        }
      } catch (err) {
        setLoader((currValue) => ({
          ...currValue,
          feedbackData: true,
        }));
        console.log("err-getFeedBackDetailsDataWithJourneyFilter", err);
      }
    };
    const getFeedBackDetailsDataWithJourneyStoreFilter = async () => {
      try {
        setLoader((currValue) => ({
          ...currValue,
          feedbackData: true,
        }));
        let url =
          process.env.REACT_APP_API_ENDPOINT +
          process.env.REACT_APP_FEEDBACK_DETAIL_WITH_JOURNEY_STORE_DATA +
          "startDate=" +
          periodStartDateTY +
          "&endDate=" +
          periodEndDateTY +
          "&concept=" +
          selectedFeedbackBannerId +
          "&journey=" +
          selectedFeedbackJourneyId +
          "&storeNum=" +
          feedbackSelectedStoreId;
        if (correctDateRange) {
          setSubmitActive(false);
          await axios({ url }).then((res) => {
            setLoader((currValue) => ({
              ...currValue,
              feedbackData: false,
            }));
            setFeedBackDetailsData(
              res.data.sort((a, b) => {
                return Number(a.STORE_ID) - Number(b.STORE_ID);
              })
            );
          });
          setCorrectDateRange(false);
        } else {
          setLoader((currValue) => ({
            ...currValue,
            feedbackData: false,
          }));
        }
      } catch (err) {
        setLoader((currValue) => ({
          ...currValue,
          feedbackData: true,
        }));
        console.log("err-getFeedBackDetailsDataWithJourneyStoreFilter", err);
      }
    };
    if (
      periodStartDateTY !== "" &&
      periodEndDateTY !== "" &&
      selectedFeedbackJourneyId !== "" &&
      !summaryActive &&
      DateCompare(periodStartDateTY, periodEndDateTY) <= 0
    ) {
      if (feedbackSelectedStoreId) {
        getFeedBackDetailsDataWithJourneyStoreFilter();
      } else {
        getFeedBackDetailsDataWithJourneyFilter();
      }
      setSortDetailSelector(() => ({
        detailRatingAscending: false,
        detailStoreAscending: true,
        detailDistrictAscending: false,
        detailRegionAscending: false,
        arrowIcon: "detailStoreUp",
      }));
    }
  }, [
    selectedFeedbackPeriodId,
    selectedFeedbackBannerId,
    selectedFeedbackJourneyId,
    periodStartDateTY,
    periodEndDateTY,
    summaryActive,
    //submitActive,
    selectedDateCorrect,
  ]);

  const handleGoToSummary = () => {
    setSummaryActive(true);
  };

  return localStorage.getItem("isCUSTOMER_FEEDBACK") === "Y" ? (
    <>
      {refreshTime.length > 0 && (
        <NotificationMessage message={refreshDate} maxDate={maxDate} />
      )}

      <div className="p-3" style={{ marginBottom: "50px" }}>
        <div className="mt-1 d-flex align-items-center headings">
          <div className="d-flex justify-content-start p-3">
            <span className="progselectupText">Concept</span>
          </div>
          {summaryActive && (
            <div className="d-flex justify-content-start p-3">
              <span
                className="progselectupText"
                style={
                  selectedFeedbackChannelType.value.length > 10
                    ? { paddingLeft: "37px" }
                    : selectedFeedbackChannelType.value.length > 3
                    ? { paddingLeft: "18px" }
                    : { paddingLeft: "8px" }
                }
              >
                Channel
              </span>
            </div>
          )}
          {!summaryActive && (
            <div className="d-flex justify-content-start p-3">
              <span
                className="progselectupText"
                style={
                  selectedFeedbackJourney.value.length > 30
                    ? { paddingLeft: "180px" }
                    : selectedFeedbackJourney.value.length > 20
                    ? { paddingLeft: "100px" }
                    : { paddingLeft: "50px" }
                }
              >
                Journey
              </span>
            </div>
          )}
          {summaryActive && (
            <div className="d-flex justify-content-start p-3">
              <span
                className="progselectupText"
                style={
                  selectedFeedbackRegion.value.length > 12
                    ? { paddingLeft: "43px" }
                    : selectedFeedbackRegion.value.length > 9
                    ? { paddingLeft: "25px" }
                    : { paddingLeft: "3px" }
                }
              >
                Region
              </span>
            </div>
          )}
          {summaryActive && (
            <div className="d-flex justify-content-start p-3">
              <span
                className="progselectupText"
                style={
                  selectedFeedbackDistrict.value.length > 15
                    ? { paddingLeft: "70px" }
                    : selectedFeedbackDistrict.value.length > 14
                    ? { paddingLeft: "60px" }
                    : selectedFeedbackDistrict.value.length > 8
                    ? { paddingLeft: "43px" }
                    : { paddingLeft: "25px" }
                }
              >
                District
              </span>
            </div>
          )}
          {summaryActive && (
            <div className="d-flex justify-content-start p-3">
              <span
                className="progselectupText"
                style={
                  selectedFeedbackStore.value.length > 15
                    ? { paddingLeft: "120px" }
                    : selectedFeedbackStore.value.length > 8
                    ? { paddingLeft: "50px" }
                    : { paddingLeft: "30px" }
                }
              >
                Store
              </span>
            </div>
          )}
          {selectedStorePeriodValue === "Date Range" && (
            <div className="d-flex justify-content-start p-3">
              <span
                className="progselectupText"
                style={{ paddingLeft: "202px" }}
              >
                Start Date
              </span>
            </div>
          )}
          {selectedStorePeriodValue === "Date Range" && (
            <div className="d-flex justify-content-start p-3">
              <span
                className="progselectupText"
                style={{ paddingLeft: "56px" }}
              >
                End Date
              </span>
            </div>
          )}
        </div>
        <div className="mt-3 d-flex align-items-center">
          <div className="d-flex justify-content-start p-3">
            <Dropdown className="d-inline">
              <Dropdown.Toggle>{selectedFeedbackBanner.value}</Dropdown.Toggle>
              <Dropdown.Menu
                className="dropdown-menu-ext"
                onClick={(e) => handleFeedbackBanner(e)}
              >
                {FeedbackBanners.map((data) => {
                  return (
                    <Dropdown.Item
                      key={data.id}
                      className="dropdown-item-ext"
                      id={data.id}
                    >
                      {data.value}
                    </Dropdown.Item>
                  );
                })}
              </Dropdown.Menu>
            </Dropdown>
          </div>
          {summaryActive && (
            <div className="d-flex justify-content-start p-3">
              <Dropdown className="d-inline">
                <Dropdown.Toggle>
                  {selectedFeedbackChannelType.value}
                </Dropdown.Toggle>
                <Dropdown.Menu
                  className="dropdown-menu-ext"
                  onClick={(e) => handleFeedbackChannelType(e)}
                >
                  {FeedbackChannelType.map((data) => {
                    return (
                      <Dropdown.Item
                        key={data.id}
                        className="dropdown-item-ext"
                        id={data.id}
                      >
                        {data.value}
                      </Dropdown.Item>
                    );
                  })}
                </Dropdown.Menu>
              </Dropdown>
            </div>
          )}
          {!summaryActive && (
            <div className="d-flex justify-content-start p-3">
              <Dropdown className="d-inline">
                <Dropdown.Toggle>
                  {allFeedbackJourneys !== undefined &&
                  allFeedbackJourneys !== null &&
                  allFeedbackJourneys.length !== 0 ? (
                    selectedFeedbackJourney.value
                  ) : loading.journeyData ? (
                    <span style={{ fontStyle: "Italic", fontSize: "13px" }}>
                      Loading
                    </span>
                  ) : (
                    allFeedbackJourneys.length === 0 && (
                      <span style={{ fontStyle: "Italic", fontSize: "13px" }}>
                        No Data
                      </span>
                    )
                  )}
                </Dropdown.Toggle>
                <Dropdown.Menu
                  className="dropdown-menu dropdown-primary force-scroll"
                  onClick={(e) => handleFeedbackJourney(e)}
                  style={{
                    overflowY: "scroll",
                    height: "200px",
                  }}
                >
                  {allFeedbackJourneys.map((data) => {
                    return (
                      <Dropdown.Item
                        key={data.JOURNEY_CD}
                        className="dropdown-item-ext"
                        id={data.JOURNEY_CD}
                      >
                        {data.JOURNEY_DESC}
                      </Dropdown.Item>
                    );
                  })}
                </Dropdown.Menu>
              </Dropdown>
            </div>
          )}
          {summaryActive && (
            <div className="d-flex justify-content-start p-3">
              <Dropdown
                className="d-inline"
                id={
                  selectedFeedbackChannelTypeValue !== "Store" && "nav-dropdown"
                }
              >
                <Dropdown.Toggle
                  className= 
                  {
                    selectedFeedbackChannelType.value === "Store"
                      ? ""
                      : "divMain"
                  }
                >
                  {allFeedbackRegions !== undefined &&
                  allFeedbackRegions !== null &&
                  allFeedbackRegions.length !== 0 ? (
                    selectedFeedbackRegion.value
                  ) : loading.regionData ? (
                    <span style={{ fontStyle: "Italic", fontSize: "13px" }}>
                      Loading
                    </span>
                  ) : (
                    allFeedbackRegions.length === 0 && (
                      <span style={{ fontStyle: "Italic", fontSize: "13px" }}>
                        No Data
                      </span>
                    )
                  )}
                </Dropdown.Toggle>
                <Dropdown.Menu
                  className="dropdown-menu dropdown-primary force-scroll"
                  onClick={(e) => handleFeedbackRegion(e)}
                  style={{
                    overflowY: "scroll",
                    height: "200px",
                  }}
                >
                  {allFeedbackRegions.map((data) => {
                    return (
                      <Dropdown.Item
                        key={data.REGION_NAME}
                        className="dropdown-item-ext"
                        id={data.REGION_NAME}
                      >
                        {data.REGION_NAME}
                      </Dropdown.Item>
                    );
                  })}
                </Dropdown.Menu>
              </Dropdown>
            </div>
          )}
          {summaryActive && (
            <div className="d-flex justify-content-start p-3">
              <Dropdown
                className="d-inline"
                id={
                  selectedFeedbackChannelTypeValue !== "Store" && "nav-dropdown"
                }
              >
                <Dropdown.Toggle
                  className={
                    selectedFeedbackChannelType.value === "Store"
                      ? ""
                      : "divMain"
                  }
                >
                  {allFeedbackDistricts !== undefined &&
                  allFeedbackDistricts !== null &&
                  allFeedbackDistricts.length !== 0 ? (
                    selectedFeedbackDistrict.value
                  ) : loading.districtData ? (
                    <span style={{ fontStyle: "Italic", fontSize: "13px" }}>
                      Loading
                    </span>
                  ) : (
                    allFeedbackDistricts.length === 0 && (
                      <span style={{ fontStyle: "Italic", fontSize: "13px" }}>
                        No Data
                      </span>
                    )
                  )}
                </Dropdown.Toggle>
                <Dropdown.Menu
                  className="dropdown-menu dropdown-primary force-scroll"
                  onClick={(e) => handleFeedbackDistrict(e)}
                  style={{
                    overflowY: "scroll",
                    height: "200px",
                  }}
                >
                  {allFeedbackDistricts.map((data) => {
                    return (
                      <Dropdown.Item
                        key={data.DISTRICT_NAME}
                        className="dropdown-item-ext"
                        id={data.DISTRICT_NAME}
                      >
                        {data.DISTRICT_NAME}
                      </Dropdown.Item>
                    );
                  })}
                </Dropdown.Menu>
              </Dropdown>
            </div>
          )}

          {summaryActive && (
            <div className="d-flex justify-content-start p-3">
              <Dropdown
                className="d-inline"
                id={
                  selectedFeedbackChannelTypeValue !== "Store" && "nav-dropdown"
                }
              >
                <Dropdown.Toggle
                  className= {
                    selectedFeedbackChannelType.value === "Store"
                      ? ""
                      : "divMain"
                  }
                >
                  {allFeedbackStores !== undefined &&
                  allFeedbackStores !== null &&
                  allFeedbackStores.length !== 0 ? (
                    selectedFeedbackStore.value
                  ) : loading.storeData ? (
                    <span style={{ fontStyle: "Italic", fontSize: "13px" }}>
                      Loading
                    </span>
                  ) : (
                    allFeedbackStores.length === 0 && (
                      <span style={{ fontStyle: "Italic", fontSize: "13px" }}>
                        No Data
                      </span>
                    )
                  )}
                </Dropdown.Toggle>
                <Dropdown.Menu
                  className="dropdown-menu dropdown-primary force-scroll"
                  onClick={(e) => handleFeedbackStore(e)}
                  style={{
                    overflowY: "scroll",
                    height: "250px",
                  }}
                >
                  {allFeedbackStores.map((data) => {
                    return (
                      <Dropdown.Item
                        key={data.STORE_NUMBER}
                        className="dropdown-item-ext"
                        id={data.STORE_NUMBER}
                      >
                        {data.STORE_DESC}
                      </Dropdown.Item>
                    );
                  })}
                </Dropdown.Menu>
              </Dropdown>
            </div>
          )}
          <div className="d-flex justify-content-start p-3">
            <Dropdown className="d-inline">
              <Dropdown.Toggle>{selectedStorePeriodValue}</Dropdown.Toggle>
              <Dropdown.Menu
                className="dropdown-menu-ext"
                onClick={(e) => handleFeedbackPeriod(e)}
              >
                {FeedbackPeriods.map((data) => {
                  return (
                    <Dropdown.Item
                      key={data.id}
                      className="dropdown-item-ext"
                      id={data.id}
                    >
                      {data.value}
                    </Dropdown.Item>
                  );
                })}
              </Dropdown.Menu>
            </Dropdown>
          </div>
          <div>
            {selectedStorePeriodValue !== "Date Range" &&
            periodEndDateTY !== "" ? (
              <div>
                <span>{`(${getDateFormatFromDB(
                  periodStartDateTY
                )} - ${getDateFormatFromDB(periodEndDateTY)})`}</span>
              </div>
            ) : (
              <div>
                {selectedStorePeriodValue !== "Date Range" && (
                  <span>{`( - )`}</span>
                )}
              </div>
            )}
          </div>
          {selectedStorePeriodValue === "Date Range" && (
            <div
              className="d-flex justify-content-start p-3"
              style={{ marginRight: "-5rem" }}
            >
              <label
                className="d-flex datepicker"
                onClick={(e) => e.preventDefault()}
              >
                <DatePicker
                  timeFormat={false}
                  value={periodStartDateTY}
                  isValidDate={disableCustomDt}
                  onChange={(date) => handleStartDate(date)}
                  closeOnSelect
                  inputProps={{ readOnly: true }}
                />
                <img src={calender} className="date-picker-icon" />
              </label>
            </div>
          )}
          {selectedStorePeriodValue === "Date Range" && (
            <div
              className="d-flex justify-content-start p-3"
              style={{ marginRight: "-5rem" }}
            >
              <label
                className="d-flex datepicker"
                onClick={(e) => e.preventDefault()}
              >
                <DatePicker
                  timeFormat={false}
                  value={periodEndDateTY}
                  isValidDate={disableCustomDt}
                  onChange={(date) => handleEndDate(date)}
                  closeOnSelect
                  inputProps={{ readOnly: true }}
                />
                <img src={calender} className="date-picker-icon" />
              </label>
            </div>
          )}
          {selectedStorePeriodValue === "Date Range" && (
            <Button
              type="button"
              class="btn btn-primary"
              id={submitActive ? "submit" : "noSubmit"}
              onClick={() => handleSubmit()}
            >
              Submit
            </Button>
          )}
          <span>
            <FontAwesomeIcon
              style={{ marginLeft: "15px", cursor: "pointer" }}
              icon={faArrowsRotate}
              onClick={() => window.location.reload(false)}
              data-tip
              data-for="refresh"
            />
            <ReactTooltip
              className="tooltip_css "
              id="refresh"
              place="top"
              effect="float"
              backgroundColor="#595959"
            >
              Refresh
            </ReactTooltip>
          </span>
        </div>
        {!summaryActive && (
          <div>
            <span
              style={{
                fontWeight: "500",
                textDecoration: "underline",
                cursor: "pointer",
              }}
              onClick={() => handleGoToSummary()}
            >
              Go to Summary Page
            </span>
          </div>
        )}
        {summaryActive ? (
          <FeedbackSummary
            loading={loading}
            setSummaryActive={setSummaryActive}
            feedbackSummaryData={feedbackSummaryData}
            handleFeedbackJourney={handleFeedbackJourney}
            handleFeedbackJourneyWithStore={handleFeedbackJourneyWithStore}
            showStoreField={showStoreField}
            sortSummaryData={sortSummaryData}
            sortSelection={sortSelection}
            selectedFeedbackChannelTypeValue={selectedFeedbackChannelTypeValue}
            showDistrictField={showDistrictField}
            feedbackSummaryDataTotal={feedbackSummaryDataTotal}
            selectedStorePeriodValue={selectedStorePeriodValue}
          />
        ) : (
          <FeedbackHome
            loading={loading}
            feedbackData={feedbackData}
            sortDetailSelection={sortDetailSelection}
            sortDetailData={sortDetailData}
            feedbackSelectedChannelId={feedbackSelectedChannelId}
            allFeedbackJourneys={allFeedbackJourneys}
            selectedFeedbackJourneyId={selectedFeedbackJourneyId}
          />
        )}
      </div>
    </>
  ) : (
    <NoAccess tabName="Customer feedback" />
  );
}

export default FeedbackContainer;
