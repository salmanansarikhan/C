import React, { useState } from "react";
import { useHistory, useLocation } from "react-router-dom";
import { Modal, Table, Dropdown } from "react-bootstrap";
import axios from "axios";
import "./Header.css";
import { FontAwesomeIcon } from "@fortawesome/react-fontawesome";
import { faUserCircle } from "@fortawesome/free-solid-svg-icons";

function Header() {
  //const isLoggedIn = localStorage.getItem("isLoggedIn");
  let history = useHistory();
  let location = useLocation();
  //const userName = localStorage.getItem("username");
  const logoutHandler = () => {
    // setIsLogoutClicked(true);
    const logoutUrl =
      process.env.REACT_APP_API_ENDPOINT + process.env.REACT_APP_LOGOUT;
    axios.get(logoutUrl).then((response) => {
      if (response.data.statusCode === "200") {
        history.push("/cdh/");
        // <Redirect to={"/cdh/"}/>
        localStorage.removeItem("username");
        localStorage.removeItem("userId");
        localStorage.removeItem("isLoggedIn");
        localStorage.removeItem("currentTabName");
        localStorage.removeItem("isOVERALL_HEALTH");
        //localStorage.removeItem("isADMIN");
        localStorage.removeItem("isCHANNEL");
        localStorage.removeItem("isCUSTOMER_FEEDBACK");
        localStorage.removeItem("isDECILES");
        localStorage.removeItem("isFUNNEL");
        localStorage.removeItem("isLOYALTY");
        localStorage.removeItem("isMARKETING");
        localStorage.removeItem("isPROGRAM");
        localStorage.removeItem("isSCORECARD");
        localStorage.removeItem("isSTORES");
        localStorage.removeItem("isCUSTOMERFILEHEALTH");
        //localStorage.removeItem("isSUPER_ADMIN");
        // setIsLogoutClicked(false);
      } else {
        alert("logout failed");
      }
    });
  };
  const FeedbackMenu = [
    { value: "Scorecard", id: "scorecard" },
    { value: "Funnel", id: "funnel" },
  ];

  const [selectedTab, setTabClicked] = useState("#Tab1");
  const handleTabChange = (e) => {
    setTabClicked(e.target.id);
    localStorage.setItem("currentTabName", e.target.id);
    history.push(`/cdh/${e.target.id}`);
  };
  const currentTabname = localStorage?.getItem("currentTabName");

  const userName = localStorage.getItem("username");
  const [userNameVisible, setUserNameVisible] = useState(false);

  const userNameClick = () => {
    setUserNameVisible(true);
  };

  const closeUserDropdown = () => {
    setUserNameVisible(false);
  };

  return (
    <>
      <div className=" d-flex HeaderStyle justify-content-between align-items-center">
        <div className="d-flex BrandName">Customer Data Hub</div>
        <div className="d-flex align-self-center">
          {localStorage.getItem("isOVERALL_HEALTH") === "Y" && (
            <div
              onClick={(e) => handleTabChange(e)}
              className="d-flex HeaderTabContainer align-self-center"
            >
              <div
                id={"home"}
                className={
                  location.pathname === "/cdh/home"
                    ? " d-flex  active-Tab "
                    : " d-flex Header-Tab "
                }
              >
                Overall health
              </div>
            </div>
          )}
          {localStorage.getItem("isSCORECARD") === "Y" && (
            <div
              onClick={(e) => handleTabChange(e)}
              className="d-flex HeaderTabContainer align-self-center"
            >
              <div
                id={"scorecard"}
                className={
                  location.pathname === "/cdh/scorecard"
                    ? " d-flex  active-Tab "
                    : " d-flex Header-Tab "
                }
              >
                Scorecard
              </div>
            </div>
          )}
          {(localStorage.getItem("isOVERALL_HEALTH") === "Y" ||
            localStorage.getItem("isSCORECARD") === "Y") && (
            <div className="d-flex HeaderLine align-self-center">
              <h3>|</h3>
            </div>
          )}

          {localStorage.getItem("isCUSTOMER_FEEDBACK") === "Y" && (
            <div
              onClick={(e) => handleTabChange(e)}
              className="d-flex HeaderTabContainer align-self-center"
            >
              <div
                id={"feedback"}
                className={
                  location.pathname === "/cdh/feedback"
                    ? " d-flex  active-Tab "
                    : " d-flex Header-Tab "
                }
              >
                Customer feedback
              </div>
            </div>
          )}
          {localStorage.getItem("isCUSTOMER_FEEDBACK") === "Y" && (
            <div className="d-flex HeaderLine align-self-center">
              <h3>|</h3>
            </div>
          )}

          {localStorage.getItem("isDECILES") === "Y" && (
            <div
              onClick={(e) => handleTabChange(e)}
              className="d-flex HeaderTabContainer align-self-center"
            >
              <div
                id={"deciles"}
                className={
                  location.pathname === "/cdh/deciles"
                    ? " d-flex active-Tab "
                    : " d-flex Header-Tab "
                }
              >
                Deciles
              </div>
            </div>
          )}
          {localStorage.getItem("isCHANNEL") === "Y" && (
            <div
              onClick={(e) => handleTabChange(e)}
              className="d-flex HeaderTabContainer align-self-center"
            >
              <div
                id={"channel"}
                className={
                  location.pathname === "/cdh/channel"
                    ? " d-flex active-Tab "
                    : " d-flex Header-Tab "
                }
              >
                Channel
              </div>
            </div>
          )}
          {localStorage.getItem("isPROGRAM") === "Y" && (
            <div
              onClick={(e) => handleTabChange(e)}
              className="d-flex HeaderTabContainer align-self-center"
            >
              <div
                id={"program"}
                className={
                  location.pathname === "/cdh/program"
                    ? " d-flex active-Tab "
                    : " d-flex Header-Tab "
                }
              >
                Program
              </div>
            </div>
          )}
          {localStorage.getItem("isMARKETING") === "Y" && (
            <div
              onClick={(e) => handleTabChange(e)}
              className="d-flex HeaderTabContainer align-self-center"
            >
              <div
                id={"marketing"}
                className={
                  location.pathname === "/cdh/marketing"
                    ? " d-flex active-Tab "
                    : " d-flex Header-Tab "
                }
              >
                Marketing
              </div>
            </div>
          )}
          {/* <div
            onClick={(e) => handleTabChange(e)}
            className="d-flex HeaderTabContainer align-self-center"
          >
            <div
              id={"#Tab6"}
              className={
                selectedTab === "#Tab6"
                  ? " d-flex active-Tab "
                  : " d-flex Header-Tab "
              }
            >
              Product
            </div>
          </div>
          <div
            onClick={(e) => handleTabChange(e)}
            className="d-flex HeaderTabContainer align-self-center"
          >
            <div
              id={"#Tab7"}
              className={
                selectedTab === "#Tab7"
                  ? " d-flex active-Tab "
                  : " d-flex Header-Tab "
              }
            >
              Segments
            </div>
          </div> */}
          {localStorage.getItem("isLOYALTY") === "Y" && (
            <div
              onClick={(e) => handleTabChange(e)}
              className="d-flex HeaderTabContainer align-self-center"
            >
              <div
                id={"loyalty"}
                className={
                  location.pathname === "/cdh/loyalty"
                    ? " d-flex active-Tab "
                    : " d-flex Header-Tab "
                }
              >
                Loyalty
              </div>
            </div>
          )}
          {/* <div
            onClick={(e) => handleTabChange(e)}
            className="d-flex HeaderTabContainer align-self-center"
          >
            <div
              id={"scorecard"}
              className={
                location.pathname === "/cdh/scorecard"
                  ? " d-flex active-Tab "
                  : " d-flex Header-Tab "
              }
            >
              Scorecard
            </div>
          </div>
          <div
            onClick={(e) => handleTabChange(e)}
            className="d-flex HeaderTabContainer align-self-center"
          >
            <div
              id={"funnel"}
              className={
                location.pathname === "/cdh/funnel"
                  ? " d-flex active-Tab "
                  : " d-flex Header-Tab "
              }
            >
              Funnel
            </div>
          </div> */}
          {localStorage.getItem("isSTORES") === "Y" && (
            <div
              onClick={(e) => handleTabChange(e)}
              className="d-flex HeaderTabContainer align-self-center"
            >
              <div
                id={"stores"}
                className={
                  location.pathname === "/cdh/stores"
                    ? " d-flex active-Tab "
                    : " d-flex Header-Tab "
                }
              >
                Stores
              </div>
            </div>
          )}
          {localStorage.getItem("isCUSTOMERFILEHEALTH") === "Y" && (
            <div
              onClick={(e) => handleTabChange(e)}
              className="d-flex HeaderTabContainer align-self-center"
            >
              <div
                id={"customerfilehealth"}
                className={
                  location.pathname === "/cdh/customerfilehealth"
                    ? " d-flex  active-Tab "
                    : " d-flex Header-Tab "
                }
              >
                Customer
                <br />
                File Health
              </div>
            </div>
          )}
        </div>
        <div className="align-self-center">
          <div className="dropDown">
            <div
              className="username"
              style={{ cursor: "pointer" }}
              onClick={() => userNameClick()}
            >
              <span className="usernameSection">
                <FontAwesomeIcon icon={faUserCircle} />
              </span>
              <span
                className="usernameSection name"
                style={{
                  fontSize: "14px",
                  paddingLeft: "5px",
                }}
              >
                {userName.length > 0 && userName.split(" ")[0]}
              </span>
            </div>
            {userNameVisible && (
              <div
                class="dropDown_Content"
                onMouseLeave={() => closeUserDropdown()}
              >
                <a onClick={logoutHandler}>
                  <b style={{ cursor: "pointer" }}>Logout</b>
                </a>
              </div>
            )}
          </div>
        </div>
      </div>
    </>
  );
}

export default React.memo(Header);
