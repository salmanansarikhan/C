import './LoaderForTable.css';
import React from "react";
import PropTypes from "prop-types";
const LoaderForRow = ({tdCount=1,height}) => {
  let i = 1;
  let arr = [];
  for (i; i <= tdCount; i++) {
    arr.push(i);
  }
  return (
    <>
      {arr.map((d,dIndex) => {
        return <td key={dIndex} style={{"height":height}} className="skleton-Loader-Table-Row"></td>;
      })}
    </>
  );
};
LoaderForRow.propTypes = {
  tdCount: PropTypes.number,
};
export default LoaderForRow;

