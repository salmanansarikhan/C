import React, { useEffect, useState, useCallback } from "react";
import { useSelector, useDispatch } from "react-redux";
import axios from "axios";
import { Dropdown } from "react-bootstrap";
import DatePicker from "react-datetime";
import moment from "moment";
import { handleFunnelBannerChange } from "../../Redux/Actions/BannerChangeActions";
import { handleFunnelDateChange } from "../../Redux/Actions/DateChangeActions";
import { handleFunnelTypeChange } from "../../Redux/Actions/CategoryChangeActions";
import calender from "../../assests/images/calender.svg";
import LoyalityTopCust from "./LoyalityTopCust";
import LoyalityTopCustNew from "./LoyalityTopCustNew";
import Channel from "./Channel";
import Near from "./Near";
import NationalOwn from "./NationalOwn";
import { UTCtoEST } from "../Utils";
import NotificationMessage from "../NotificationMessage/NotificationMessage";
import NoAccess from "../NoAccess/NoAccess";

const FunnelBanners = [
  { value: "All Banner", id: "0" },
  { value: "BBBY US", id: "1" },
  { value: "BBBY CA", id: "2" },
  { value: "buy buy Baby", id: "3" },
  { value: "Harmon", id: "5" },
];
const FunnelType = [
  { value: "Loyalty and Top Cust New", id: "0" },
  { value: "Loyalty and Top Cust", id: "1" },
  { value: "Channel", id: "2" },
  { value: "NEAR", id: "3" },
  { value: "National Own", id: "4" },
];
function FunnelContainer() {
  const dispatch = useDispatch();
  const [selectedFunnelBanner, setSelectedFunnelBanner] = useState(
    FunnelBanners[0]
  );
  const [selectedFunnelType, setSelectedFunnelType] = useState(FunnelType[0]);
  const [tableOneUrl, setTableOneUrl] = useState();
  const [tableTwoUrl, setTableTwoUrl] = useState();
  const [tableThreeUrl, setTableThreeUrl] = useState();
  const [tableForthUrl, setTableForthUrl] = useState();
  const [tableFifthUrl, setTableFifthUrl] = useState();
  const [channelTableOneUrl, setChannelTableOneUrl] = useState();
  const [channelTableTwoUrl, setChannelTableTwoUrl] = useState();
  const [channelTableThreeUrl, setChannelTableThreeUrl] = useState();
  const [channelTableForthUrl, setChannelTableForthUrl] = useState();
  const [channelTableFifthUrl, setChannelTableFifthUrl] = useState();
  const [channelTableSixthUrl, setChannelTableSixthUrl] = useState();
  const [channelTableSeventhUrl, setChannelTableSeventhUrl] = useState();
  const [channelTableEighthUrl, setChannelTableEightUrl] = useState();
  const [channelTableNinthUrl, setChannelTableNinthUrl] = useState();
  const [channelTableTenthUrl, setChannelTableTenthUrl] = useState();
  const [nearTableOneUrl, setNearTableOneUrl] = useState();
  const [nearTableTwoUrl, setNearTableTwoUrl] = useState();
  const [nearTableThreeUrl, setNearTableThreeUrl] = useState();
  const [nearTableForthUrl, setNearTableForthUrl] = useState();
  const [nearTableFifthUrl, setNearTableFifthUrl] = useState();
  const [nearTableSixthUrl, setNearTableSixthUrl] = useState();
  const [nearTableSeventhUrl, setNearTableSeventhUrl] = useState();
  const [nearTableEighthUrl, setNearTableEightUrl] = useState();
  const [nearTableNinthUrl, setNearTableNinthUrl] = useState();
  const [nearTableTenthUrl, setNearTableTenthUrl] = useState();
  const [nationalTableOneUrl, setNationalTableOneUrl] = useState();
  const [nationalTableSLFirstUrl, setNationalTableSLFirstUrl] = useState();
  const [nationalTableSLSecondUrl, setNationalTableSLSecondUrl] = useState();
  const [nationalTableSLThreeUrl, setNationalTableSLThreeUrl] = useState();
  const [nationalTableSLForthUrl, setNationalTableSLForthUrl] = useState();
  const [nationalTableSLFifthUrl, setNationalTableSLFifthUrl] = useState();
  const [nationalTableSLSixthUrl, setNationalTableSLSixthUrl] = useState();
  const [nationalTableSLSeventhUrl, setNationalTableSLSeventhUrl] = useState();
  const [nationalTableForthUrl, setNationalTableForthUrl] = useState();
  const [nationalTableFifthUrl, setNationalTableFifthUrl] = useState();
  const [nationalTableSixthUrl, setNationalTableSixthUrl] = useState();
  const [nationalTableSeventhUrl, setNationalTableSeventhUrl] = useState();
  const [nationalTableEighthUrl, setNationalTableEightUrl] = useState();
  const [nationalTableNinthUrl, setNationalTableNinthUrl] = useState();
  const [nationalTableTenthUrl, setNationalTableTenthUrl] = useState();
  const [nationalTableEleventhUrl, setNationalTableEleventhUrl] = useState();
  const [nationalTableTwelthUrl, setNationalTableTwelthUrl] = useState();
  const [nationalTableThirteenthUrl, setNationalTableThirteenthUrl] =
    useState();
  const [nationalTableForteenthUrl, setNationalTableForteenthUrl] = useState();
  const [nationalTableFifteenthUrl, setNationalTableFifteenthUrl] = useState();
  const [nationalTableSixteenthUrl, setNationalTableSixteenthUrl] = useState();
  const [nationalTableSeventeenthUrl, setNationalTableSeventeenthUrl] =
    useState();
  const [nationalTableEighteethUrl, setNationalTableEighteenthUrl] = useState();

  const [defaultDate, setDefaultDate] = useState(moment().subtract(2, "days"));
  const selectedDate = useSelector((store) => store.FunnelDate.value);

  const selectedFunnelBannerId = useSelector((store) => store.FunnelBanner.id);
  const selectedFunnelTypeId = useSelector((store) => store.FunnelType.id);

  const [levelTwoBoxes, setLevelTwoBoxes] = useState(false);
  const [levelThreeBoxes, setLevelThreeBoxes] = useState(false);
  const [vennDiagramDisplayed, setVennDiagramDisplayed] = useState(false);

  const [welcomeTableOneUrl, setWelcomeTableFirstUrl] = useState();
  const [welcomeTableTwoUrl, setWelcomeTableSLSecondUrl] = useState();
  const [welcomeTableThreeUrl, setWelcomeTableSLThirdUrl] = useState();
  const [welcomeTableForthUrl, setWelcomeTableSLForthUrl] = useState();
  const [welcomeTableFifthUrl, setWelcomeTableSLFifthUrl] = useState();
  const [welcomeTableTLSixthUrl, setWelcomeTableTLSixthUrl] = useState();
  const [welcomeTableTLSeventhUrl, setWelcomeTableTLSeventhUrl] = useState();
  const [welcomeTableTLEighthUrl, setWelcomeTableTLEighthUrl] = useState();
  const [welcomeTableTLNinthUrl, setWelcomeTableTLNinthUrl] = useState();

  const [refreshTime, setRefreshTime] = useState("");

  const refreshDate =
    refreshTime.length > 0 && UTCtoEST(refreshTime[0].end_time * 1000);

  const showLevelTwoBoxes = () => {
    setLevelTwoBoxes(true);
  };

  const hideLevelTwoBoxes = () => {
    setLevelTwoBoxes(false);
    setLevelThreeBoxes(false);
  };

  const showLevelThreeBoxes = () => {
    setLevelThreeBoxes(true);
  };

  const hideLevelThreeBoxes = () => {
    setLevelThreeBoxes(false);
  };

  const [channelLevelTwoBoxes, setChannelLevelTwoBoxes] = useState(false);
  const showChannelLevelTwoBoxes = () => {
    setChannelLevelTwoBoxes(true);
  };

  const hideChannelLevelTwoBoxes = () => {
    setChannelLevelTwoBoxes(false);
    setChannelLevelThreeBoxes(false);
    setChannelLevelFourFirstHalfBoxes(false);
    setChannelLevelFourSecondHalfBoxes(false);
  };

  const [channelLevelThreeBoxes, setChannelLevelThreeBoxes] = useState(false);
  const showChannelLevelThreeBoxes = () => {
    setChannelLevelThreeBoxes(true);
    setChannelLevelFourFirstHalfBoxes(false);
    setChannelLevelFourSecondHalfBoxes(false);
  };

  const hideChannelLevelThreeBoxes = () => {
    setChannelLevelThreeBoxes(false);
    setChannelLevelFourFirstHalfBoxes(false);
    setChannelLevelFourSecondHalfBoxes(false);
  };

  const [channelLevelFourFirstHalfBoxes, setChannelLevelFourFirstHalfBoxes] =
    useState(false);
  const showChannelLevelFourFirstHalfBoxes = () => {
    setChannelLevelFourFirstHalfBoxes(true);
    setChannelLevelThreeBoxes(false);
    setChannelLevelFourSecondHalfBoxes(false);
  };

  const [channelLevelFourSecondHalfBoxes, setChannelLevelFourSecondHalfBoxes] =
    useState(false);
  const showChannelLevelFourSecondHalfBoxes = () => {
    setChannelLevelFourSecondHalfBoxes(true);
    setChannelLevelThreeBoxes(false);
    setChannelLevelFourFirstHalfBoxes(false);
  };

  const [nearLevelTwoBoxes, setNearLevelTwoBoxes] = useState(false);
  const showNearLevelTwoBoxes = () => {
    setNearLevelTwoBoxes(true);
  };

  const hideNearLevelTwoBoxes = () => {
    setNearLevelTwoBoxes(false);
    setNearLevelThreeBoxes(false);
    setNearLevelFourFirstHalfBoxes(false);
    setNearLevelFourSecondHalfBoxes(false);
  };

  const [nearLevelThreeBoxes, setNearLevelThreeBoxes] = useState(false);
  const showNearLevelThreeBoxes = () => {
    setNearLevelThreeBoxes(true);
    setNearLevelFourFirstHalfBoxes(false);
    setNearLevelFourSecondHalfBoxes(false);
  };

  const hideNearLevelThreeBoxes = () => {
    setNearLevelThreeBoxes(false);
    setNearLevelFourFirstHalfBoxes(false);
    setNearLevelFourSecondHalfBoxes(false);
  };

  const [nearLevelFourFirstHalfBoxes, setNearLevelFourFirstHalfBoxes] =
    useState(false);
  const showNearLevelFourFirstHalfBoxes = () => {
    setNearLevelFourFirstHalfBoxes(true);
    setNearLevelThreeBoxes(false);
    setNearLevelFourSecondHalfBoxes(false);
  };

  const [nearLevelFourSecondHalfBoxes, setNearLevelFourSecondHalfBoxes] =
    useState(false);
  const showNearLevelFourSecondHalfBoxes = () => {
    setNearLevelFourSecondHalfBoxes(true);
    setNearLevelThreeBoxes(false);
    setNearLevelFourFirstHalfBoxes(false);
  };

  const [nationalLevelTwoBoxes, setNationalLevelTwoBoxes] = useState(false);
  const showNationalLevelTwoBoxes = () => {
    setNationalLevelTwoBoxes(true);
  };

  const [welcomeLevelTwoBoxes, setWelcomeLevelTwoBoxes] = useState(false);
  const showWelcomeLevelTwoBoxes = () => {
    setWelcomeLevelTwoBoxes(true);
  };

  const hideNationalLevelTwoBoxes = () => {
    setNationalLevelTwoBoxes(false);
    setNationalLevelThreeBoxes(false);
    setNationalLevelFourFirstHalfBoxes(false);
    setNationalLevelFourSecondHalfBoxes(false);
  };

  const hideWelcomeLevelTwoBoxes = () => {
    setWelcomeLevelTwoBoxes(false);
  };

  const [nationalLevelThreeBoxes, setNationalLevelThreeBoxes] = useState(false);
  const showNationalLevelThreeBoxes = () => {
    setNationalLevelThreeBoxes(true);
    setNationalLevelFourFirstHalfBoxes(false);
    setNationalLevelFourSecondHalfBoxes(false);
  };

  const hideNationalLevelThreeBoxes = () => {
    setNationalLevelThreeBoxes(false);
    setNationalLevelFourFirstHalfBoxes(false);
    setNationalLevelFourSecondHalfBoxes(false);
  };

  const hideWelcomeLevelThreeBoxes = () => {
    //setWelcomeLevelThreeBoxes(false);
    setWelcomeLevelFourFirstHalfBoxes(false);
    //seWelcomeLevelFourSecondHalfBoxes(false);
  };

  const [nationalLevelFourFirstHalfBoxes, setNationalLevelFourFirstHalfBoxes] =
    useState(false);
  const showNationalLevelFourFirstHalfBoxes = () => {
    setNationalLevelFourFirstHalfBoxes(true);
    setNationalLevelThreeBoxes(false);
    setNationalLevelFourSecondHalfBoxes(false);
  };

  const [welcomeLevelFourFirstHalfBoxes, setWelcomeLevelFourFirstHalfBoxes] =
    useState(false);
  const showWelcomeLevelFourFirstHalfBoxes = () => {
    setWelcomeLevelFourFirstHalfBoxes(true);
    // setWelcomeLevelThreeBoxes(false);
    // setWelcomeLevelFourSecondHalfBoxes(false);
  };

  const [
    nationalLevelFourSecondHalfBoxes,
    setNationalLevelFourSecondHalfBoxes,
  ] = useState(false);
  const showNationalLevelFourSecondHalfBoxes = () => {
    setNationalLevelFourFirstHalfBoxes(false);
    setNationalLevelThreeBoxes(false);
    setNationalLevelFourSecondHalfBoxes(true);
  };

  const [nationalLevelTwoFirstThreeBoxes, setNationalLevelTwoFirstThreeBoxes] =
    useState(true);
  const [
    nationalLevelTwoSecondThreeBoxes,
    setNationalLevelTwoSecondThreeBoxes,
  ] = useState(false);

  const showNationalLevelTwoFirstThreeBoxes = () => {
    setNationalLevelTwoFirstThreeBoxes(true);
    setNationalLevelTwoSecondThreeBoxes(false);
    setNationalLevelThreeBoxes(false);
    setNationalLevelFourFirstHalfBoxes(false);
    setNationalLevelFourSecondHalfBoxes(false);

    setNationalLevelNBOBOtherBoxes(false);
    setNationalLevelNBOBBoxes(false);
    setNationalLevelOwnOtherBoxes(false);
    setNationalLevelOBNBONLYBoxes(false);
    setNationalLevelThreeBoxes(false);
  };

  const showNationalLevelTwoSecondThreeBoxes = () => {
    setNationalLevelTwoSecondThreeBoxes(true);
    setNationalLevelTwoFirstThreeBoxes(false);
    setNationalLevelThreeBoxes(false);
    setNationalLevelFourFirstHalfBoxes(false);
    setNationalLevelFourSecondHalfBoxes(false);

    setNationalLevelNBOBOtherBoxes(false);
    setNationalLevelNBOBBoxes(false);
    setNationalLevelOwnOtherBoxes(false);
    setNationalLevelOBNBONLYBoxes(false);
    setNationalLevelThreeBoxes(false);
  };

  const [welcomeLevelTwoFirstThreeBoxes, setWelcomeLevelTwoFirstThreeBoxes] =
    useState(true);
  const [welcomeLevelTwoSecondThreeBoxes, setWelcomeLevelTwoSecondThreeBoxes] =
    useState(false);

  const showWelcomeLevelTwoFirstThreeBoxes = () => {
    setWelcomeLevelTwoFirstThreeBoxes(true);
    setWelcomeLevelTwoSecondThreeBoxes(false);
    setWelcomeLevelFourFirstHalfBoxes(false);
    setWelcomeLevelTLLastBoxes(false);
  };

  const showWelcomeLevelTwoSecondThreeBoxes = () => {
    setWelcomeLevelTwoSecondThreeBoxes(true);
    setWelcomeLevelTwoFirstThreeBoxes(false);
    setWelcomeLevelFourFirstHalfBoxes(false);
  };

  const [welcomeLevelTLLastBoxes, setWelcomeLevelTLLastBoxes] = useState(false);

  const showWelcomeLevelTLLastBoxes = () => {
    setWelcomeLevelTLLastBoxes(true);
    setWelcomeLevelFourFirstHalfBoxes(false);
  };

  const hideWelcomeLevelTLLastBoxes = () => {
    setWelcomeLevelFourFirstHalfBoxes(false);
    setWelcomeLevelTLLastBoxes(false);
  };

  const [nationalLevelOBNBONLYBoxes, setNationalLevelOBNBONLYBoxes] =
    useState(false);

  const showNationalLevelOBNBONLYBoxes = () => {
    setNationalLevelOBNBONLYBoxes(true);
    setNationalLevelThreeBoxes(false);
    setNationalLevelFourFirstHalfBoxes(false);
    setNationalLevelFourSecondHalfBoxes(false);
    setNationalLevelOwnOtherBoxes(false);
    setNationalLevelNBOBOtherBoxes(false);
  };

  const hideNationalLevelOBNBONLYBoxes = () => {
    setNationalLevelOwnOtherBoxes(false);
    setNationalLevelOBNBONLYBoxes(false);
    setNationalLevelThreeBoxes(false);
    setNationalLevelFourFirstHalfBoxes(false);
    setNationalLevelFourSecondHalfBoxes(false);
    setNationalLevelNBOBBoxes(false);
    setNationalLevelNBOBOtherBoxes(false);
  };

  const [nationalLevelOwnOtherBoxes, setNationalLevelOwnOtherBoxes] =
    useState(false);

  const showNationalLevelOwnOtherBoxes = () => {
    setNationalLevelOwnOtherBoxes(true);
    setNationalLevelOBNBONLYBoxes(false);
    setNationalLevelThreeBoxes(false);
    setNationalLevelFourFirstHalfBoxes(false);
    setNationalLevelFourSecondHalfBoxes(false);
    setNationalLevelNBOBBoxes(false);
    setNationalLevelNBOBOtherBoxes(false);
  };

  const hideNationalLevelOwnOtherBoxes = () => {
    setNationalLevelOwnOtherBoxes(false);
    setNationalLevelOBNBONLYBoxes(false);
    setNationalLevelThreeBoxes(false);
    setNationalLevelFourFirstHalfBoxes(false);
    setNationalLevelFourSecondHalfBoxes(false);
    setNationalLevelNBOBBoxes(false);
    setNationalLevelNBOBOtherBoxes(false);
  };

  const [nationalLevelNBOBBoxes, setNationalLevelNBOBBoxes] = useState(false);

  const showNationalLevelNBOBBoxes = () => {
    setNationalLevelNBOBBoxes(true);
    setNationalLevelOwnOtherBoxes(false);
    setNationalLevelOBNBONLYBoxes(false);
    setNationalLevelThreeBoxes(false);
    setNationalLevelFourFirstHalfBoxes(false);
    setNationalLevelFourSecondHalfBoxes(false);
    setNationalLevelNBOBOtherBoxes(false);
  };

  const hideNationalLevelNBOBBoxes = () => {
    setNationalLevelNBOBBoxes(false);
    setNationalLevelOwnOtherBoxes(false);
    setNationalLevelOBNBONLYBoxes(false);
    setNationalLevelThreeBoxes(false);
    setNationalLevelFourFirstHalfBoxes(false);
    setNationalLevelFourSecondHalfBoxes(false);
    setNationalLevelNBOBOtherBoxes(false);
  };

  const [nationalLevelNBOBOtherBoxes, setNationalLevelNBOBOtherBoxes] =
    useState(false);

  const showNationalLevelNBOBOtherBoxes = () => {
    setNationalLevelNBOBOtherBoxes(true);
    setNationalLevelNBOBBoxes(false);
    setNationalLevelOwnOtherBoxes(false);
    setNationalLevelOBNBONLYBoxes(false);
    setNationalLevelThreeBoxes(false);
    setNationalLevelFourFirstHalfBoxes(false);
    setNationalLevelFourSecondHalfBoxes(false);
  };

  const hideNationalLevelNBOBOtherBoxes = () => {
    setNationalLevelNBOBOtherBoxes(false);
    setNationalLevelNBOBBoxes(false);
    setNationalLevelOwnOtherBoxes(false);
    setNationalLevelOBNBONLYBoxes(false);
    setNationalLevelThreeBoxes(false);
    setNationalLevelFourFirstHalfBoxes(false);
    setNationalLevelFourSecondHalfBoxes(false);
  };

  const showVennDiagram = () => {
    setVennDiagramDisplayed(true);
  };

  const hideVennDiagram = () => {
    setVennDiagramDisplayed(false);
    setNationalLevelTwoBoxes(false);
    setNationalLevelThreeBoxes(false);
    setNationalLevelFourFirstHalfBoxes(false);
    setNationalLevelFourSecondHalfBoxes(false);
  };

  const handleFunnelBanner = useCallback(
    (event) => {
      setSelectedFunnelBanner((prevsValue) => ({
        ...prevsValue,
        value: event.target.innerText,
        id: event.target.id,
      }));
      dispatch(
        handleFunnelBannerChange({
          value: event.target.innerText,
          id: event.target.id,
        })
      );
      setLevelTwoBoxes(false);
      setLevelThreeBoxes(false);
      setChannelLevelTwoBoxes(false);
      setChannelLevelThreeBoxes(false);
      setChannelLevelFourFirstHalfBoxes(false);
      setChannelLevelFourSecondHalfBoxes(false);
      setNearLevelTwoBoxes(false);
      setNearLevelThreeBoxes(false);
      setNearLevelFourFirstHalfBoxes(false);
      setNearLevelFourSecondHalfBoxes(false);
      setNationalLevelTwoBoxes(false);
      setNationalLevelThreeBoxes(false);
      setNationalLevelFourFirstHalfBoxes(false);
      setNationalLevelFourSecondHalfBoxes(false);
      setVennDiagramDisplayed(false);
    },
    [selectedFunnelBannerId]
  );

  const handleFunnelDate = (dateSelected) => {
    if (moment(dateSelected, "MM/DD/YYYY", true).isValid()) {
      setDefaultDate();
      dispatch(handleFunnelDateChange(dateSelected.format("YYYY-MM-DD")));
    } else {
      setDefaultDate(moment().subtract(2, "days"));
    }
    setLevelTwoBoxes(false);
    setLevelThreeBoxes(false);
    setChannelLevelTwoBoxes(false);
    setChannelLevelThreeBoxes(false);
    setChannelLevelFourFirstHalfBoxes(false);
    setChannelLevelFourSecondHalfBoxes(false);
    setNearLevelTwoBoxes(false);
    setNearLevelThreeBoxes(false);
    setNearLevelFourFirstHalfBoxes(false);
    setNearLevelFourSecondHalfBoxes(false);
    setNationalLevelTwoBoxes(false);
    setNationalLevelThreeBoxes(false);
    setNationalLevelFourFirstHalfBoxes(false);
    setNationalLevelFourSecondHalfBoxes(false);
    setVennDiagramDisplayed(false);
  };

  const handleFunnelType = useCallback(
    (event) => {
      setSelectedFunnelType((prevsValue) => ({
        ...prevsValue,
        value: event.target.innerText,
        id: event.target.id,
      }));
      dispatch(
        handleFunnelTypeChange({
          value: event.target.innerText,
          id: event.target.id,
        })
      );
      setLevelTwoBoxes(false);
      setLevelThreeBoxes(false);
      setChannelLevelTwoBoxes(false);
      setChannelLevelThreeBoxes(false);
      setChannelLevelFourFirstHalfBoxes(false);
      setChannelLevelFourSecondHalfBoxes(false);
      setNearLevelTwoBoxes(false);
      setNearLevelThreeBoxes(false);
      setNearLevelFourFirstHalfBoxes(false);
      setNearLevelFourSecondHalfBoxes(false);
      setNationalLevelTwoBoxes(false);
      setNationalLevelThreeBoxes(false);
      setNationalLevelFourFirstHalfBoxes(false);
      setNationalLevelFourSecondHalfBoxes(false);
      setVennDiagramDisplayed(false);
    },
    [selectedFunnelTypeId]
  );

  const disableCustomDt = (current) => {
    return current.isBefore(moment().subtract(2, "days"));
  };

  const [loading, setloader] = useState({
    refreshTime: false,
  });

  useEffect(() => {
    const getLastRefreshTime = async () => {
      try {
        setloader((currValue) => ({
          ...currValue,
          refreshTime: true,
        }));
        let url =
          process.env.REACT_APP_API_ENDPOINT +
          process.env.REACT_APP_REFRESH_TIME +
          "dagId=FUNNEL";
        await axios({ url }).then((res) => {
          setloader((currValue) => ({
            ...currValue,
            refreshTime: false,
          }));
          setRefreshTime(res.data);
        });
      } catch (err) {
        setloader((currValue) => ({
          ...currValue,
          refreshTime: true,
        }));
        console.log("err-getLastRefreshTime", err);
      }
    };
    getLastRefreshTime();
  }, []);

  useEffect(() => {
    const url1 =
      process.env.REACT_APP_API_ENDPOINT +
      process.env.REACT_APP_FUNNEL_FIRST_REPORT +
      "concept=" +
      selectedFunnelBannerId +
      "&date=" +
      selectedDate;
    const url2 =
      process.env.REACT_APP_API_ENDPOINT +
      process.env.REACT_APP_FUNNEL_SECOND_REPORT +
      "concept=" +
      selectedFunnelBannerId +
      "&date=" +
      selectedDate;
    const url3 =
      process.env.REACT_APP_API_ENDPOINT +
      process.env.REACT_APP_FUNNEL_THIRD_REPORT +
      "concept=" +
      selectedFunnelBannerId +
      "&date=" +
      selectedDate;
    const url4 =
      process.env.REACT_APP_API_ENDPOINT +
      process.env.REACT_APP_FUNNEL_FORTH_REPORT +
      "concept=" +
      selectedFunnelBannerId +
      "&date=" +
      selectedDate;
    const url5 =
      process.env.REACT_APP_API_ENDPOINT +
      process.env.REACT_APP_FUNNEL_FIFTH_REPORT +
      "concept=" +
      selectedFunnelBannerId +
      "&date=" +
      selectedDate;
    const channelurl1 =
      process.env.REACT_APP_API_ENDPOINT +
      process.env.REACT_APP_FUNNEL_FIRST_REPORT +
      "concept=" +
      selectedFunnelBannerId +
      "&date=" +
      selectedDate;
    const channelUrl2 =
      process.env.REACT_APP_API_ENDPOINT +
      process.env.REACT_APP_FUNNEL_CHANNEL_SECOND_REPORT +
      "concept=" +
      selectedFunnelBannerId +
      "&date=" +
      selectedDate;
    const channelUrl3 =
      process.env.REACT_APP_API_ENDPOINT +
      process.env.REACT_APP_FUNNEL_CHANNEL_THIRD_REPORT +
      "concept=" +
      selectedFunnelBannerId +
      "&date=" +
      selectedDate;
    const channelUrl4 =
      process.env.REACT_APP_API_ENDPOINT +
      process.env.REACT_APP_FUNNEL_CHANNEL_FORTH_REPORT +
      "concept=" +
      selectedFunnelBannerId +
      "&date=" +
      selectedDate;
    const channelUrl5 =
      process.env.REACT_APP_API_ENDPOINT +
      process.env.REACT_APP_FUNNEL_CHANNEL_FIFTH_REPORT +
      "concept=" +
      selectedFunnelBannerId +
      "&date=" +
      selectedDate;
    const channelUrl6 =
      process.env.REACT_APP_API_ENDPOINT +
      process.env.REACT_APP_FUNNEL_CHANNEL_SIXTH_REPORT +
      "concept=" +
      selectedFunnelBannerId +
      "&date=" +
      selectedDate;
    const channelUrl7 =
      process.env.REACT_APP_API_ENDPOINT +
      process.env.REACT_APP_FUNNEL_CHANNEL_SEVENTH_REPORT +
      "concept=" +
      selectedFunnelBannerId +
      "&date=" +
      selectedDate;
    const channelUrl8 =
      process.env.REACT_APP_API_ENDPOINT +
      process.env.REACT_APP_FUNNEL_CHANNEL_EIGHT_REPORT +
      "concept=" +
      selectedFunnelBannerId +
      "&date=" +
      selectedDate;
    const channelUrl9 =
      process.env.REACT_APP_API_ENDPOINT +
      process.env.REACT_APP_FUNNEL_CHANNEL_NINTH_REPORT +
      "concept=" +
      selectedFunnelBannerId +
      "&date=" +
      selectedDate;
    const channelUrl10 =
      process.env.REACT_APP_API_ENDPOINT +
      process.env.REACT_APP_FUNNEL_CHANNEL_TENTH_REPORT +
      "concept=" +
      selectedFunnelBannerId +
      "&date=" +
      selectedDate;
    const nearUrl1 =
      process.env.REACT_APP_API_ENDPOINT +
      process.env.REACT_APP_FUNNEL_NEAR_FIRST_REPORT +
      "concept=" +
      selectedFunnelBannerId +
      "&date=" +
      selectedDate;
    const nearUrl2 =
      process.env.REACT_APP_API_ENDPOINT +
      process.env.REACT_APP_FUNNEL_NEAR_SECOND_REPORT +
      "concept=" +
      selectedFunnelBannerId +
      "&date=" +
      selectedDate;
    const nearUrl3 =
      process.env.REACT_APP_API_ENDPOINT +
      process.env.REACT_APP_FUNNEL_NEAR_THIRD_REPORT +
      "concept=" +
      selectedFunnelBannerId +
      "&date=" +
      selectedDate;
    const nearUrl4 =
      process.env.REACT_APP_API_ENDPOINT +
      process.env.REACT_APP_FUNNEL_NEAR_FORTH_REPORT +
      "concept=" +
      selectedFunnelBannerId +
      "&date=" +
      selectedDate;
    const nearUrl5 =
      process.env.REACT_APP_API_ENDPOINT +
      process.env.REACT_APP_FUNNEL_NEAR_FIFTH_REPORT +
      "concept=" +
      selectedFunnelBannerId +
      "&date=" +
      selectedDate;
    const nearUrl6 =
      process.env.REACT_APP_API_ENDPOINT +
      process.env.REACT_APP_FUNNEL_NEAR_SIXTH_REPORT +
      "concept=" +
      selectedFunnelBannerId +
      "&date=" +
      selectedDate;
    const nearUrl7 =
      process.env.REACT_APP_API_ENDPOINT +
      process.env.REACT_APP_FUNNEL_NEAR_SEVENTH_REPORT +
      "concept=" +
      selectedFunnelBannerId +
      "&date=" +
      selectedDate;
    const nearUrl8 =
      process.env.REACT_APP_API_ENDPOINT +
      process.env.REACT_APP_FUNNEL_NEAR_EIGHT_REPORT +
      "concept=" +
      selectedFunnelBannerId +
      "&date=" +
      selectedDate;
    const nearUrl9 =
      process.env.REACT_APP_API_ENDPOINT +
      process.env.REACT_APP_FUNNEL_NEAR_NINTH_REPORT +
      "concept=" +
      selectedFunnelBannerId +
      "&date=" +
      selectedDate;
    const nearUrl10 =
      process.env.REACT_APP_API_ENDPOINT +
      process.env.REACT_APP_FUNNEL_NEAR_TENTH_REPORT +
      "concept=" +
      selectedFunnelBannerId +
      "&date=" +
      selectedDate;
    const nationalUrl1 =
      process.env.REACT_APP_API_ENDPOINT +
      process.env.REACT_APP_FUNNEL_NATIONAL_FIRST_REPORT +
      "concept=" +
      selectedFunnelBannerId +
      "&date=" +
      selectedDate;
    const nationalUrlSecondLayer1 =
      process.env.REACT_APP_API_ENDPOINT +
      process.env.REACT_APP_FUNNEL_NATIONAL_SECOND_LAYER_REPORT +
      "concept=" +
      selectedFunnelBannerId +
      "&date=" +
      selectedDate +
      "&metrics=OB_ONLY&channelType=OB_ONLY";
    const nationalUrlSecondLayer2 =
      process.env.REACT_APP_API_ENDPOINT +
      process.env.REACT_APP_FUNNEL_NATIONAL_SECOND_LAYER_REPORT +
      "concept=" +
      selectedFunnelBannerId +
      "&date=" +
      selectedDate +
      "&metrics=NB_ONLY&channelType=NB_ONLY";
    const nationalUrlSecondLayer3 =
      process.env.REACT_APP_API_ENDPOINT +
      process.env.REACT_APP_FUNNEL_NATIONAL_SECOND_LAYER_REPORT +
      "concept=" +
      selectedFunnelBannerId +
      "&date=" +
      selectedDate +
      "&metrics=OTH_ONLY&channelType=OTH_ONLY";
    const nationalUrlSecondLayer4 =
      process.env.REACT_APP_API_ENDPOINT +
      process.env.REACT_APP_FUNNEL_NATIONAL_SECOND_LAYER_REPORT +
      "concept=" +
      selectedFunnelBannerId +
      "&date=" +
      selectedDate +
      "&metrics=OB_NB_ONLY&channelType=OB_NB_ONLY";
    const nationalUrlSecondLayer5 =
      process.env.REACT_APP_API_ENDPOINT +
      process.env.REACT_APP_FUNNEL_NATIONAL_SECOND_LAYER_REPORT +
      "concept=" +
      selectedFunnelBannerId +
      "&date=" +
      selectedDate +
      "&metrics=OB_OTH_ONLY&channelType=OB_OTH_ONLY";
    const nationalUrlSecondLayer6 =
      process.env.REACT_APP_API_ENDPOINT +
      process.env.REACT_APP_FUNNEL_NATIONAL_SECOND_LAYER_REPORT +
      "concept=" +
      selectedFunnelBannerId +
      "&date=" +
      selectedDate +
      "&metrics=NB_OTH_ONLY&channelType=NB_OTH_ONLY";
    const nationalUrlSecondLayer7 =
      process.env.REACT_APP_API_ENDPOINT +
      process.env.REACT_APP_FUNNEL_NATIONAL_SECOND_LAYER_REPORT +
      "concept=" +
      selectedFunnelBannerId +
      "&date=" +
      selectedDate +
      "&metrics=OB_NB_OTH_ONLY&channelType=OB_NB_OTH_ONLY";
    //start : Second layer first box click - api for third layer first two boxes
    const nationalUrl5 =
      process.env.REACT_APP_API_ENDPOINT +
      process.env.REACT_APP_FUNNEL_NATIONAL_THIRD_LAYER_FIRST_SVC_REPORT +
      "concept=" +
      selectedFunnelBannerId +
      "&date=" +
      selectedDate +
      "&channelType1=TOP2_OB_ONLY&channelType2=OB_ONLY";
    const nationalUrl6 =
      process.env.REACT_APP_API_ENDPOINT +
      process.env.REACT_APP_FUNNEL_NATIONAL_THIRD_LAYER_SECOND_SVC_REPORT +
      "concept=" +
      selectedFunnelBannerId +
      "&date=" +
      selectedDate +
      "&channelType1=REST_OB_ONLY&channelType2=OB_ONLY&metrics=OB_ONLY";
    //start : Second layer second box click - api for third layer 3rd & 4th boxes
    const nationalUrl7 =
      process.env.REACT_APP_API_ENDPOINT +
      process.env.REACT_APP_FUNNEL_NATIONAL_THIRD_LAYER_FIRST_SVC_REPORT +
      "concept=" +
      selectedFunnelBannerId +
      "&date=" +
      selectedDate +
      "&channelType1=TOP2_NB_ONLY&channelType2=NB_ONLY";
    const nationalUrl8 =
      process.env.REACT_APP_API_ENDPOINT +
      process.env.REACT_APP_FUNNEL_NATIONAL_THIRD_LAYER_SECOND_SVC_REPORT +
      "concept=" +
      selectedFunnelBannerId +
      "&date=" +
      selectedDate +
      "&channelType1=REST_NB_ONLY&channelType2=NB_ONLY&metrics=NB_ONLY";
    //start : Second layer third box click - api for third layer 5th & 6th boxes
    const nationalUrl9 =
      process.env.REACT_APP_API_ENDPOINT +
      process.env.REACT_APP_FUNNEL_NATIONAL_THIRD_LAYER_FIRST_SVC_REPORT +
      "concept=" +
      selectedFunnelBannerId +
      "&date=" +
      selectedDate +
      "&channelType1=TOP2_OTH_ONLY&channelType2=OTH_ONLY";
    const nationalUrl10 =
      process.env.REACT_APP_API_ENDPOINT +
      process.env.REACT_APP_FUNNEL_NATIONAL_THIRD_LAYER_SECOND_SVC_REPORT +
      "concept=" +
      selectedFunnelBannerId +
      "&date=" +
      selectedDate +
      "&channelType1=REST_OTH_ONLY&channelType2=OTH_ONLY&metrics=OTH_ONLY";
    //start : Second layer forth box click - api for third layer 7th & 8th boxes
    const nationalUrl11 =
      process.env.REACT_APP_API_ENDPOINT +
      process.env.REACT_APP_FUNNEL_NATIONAL_THIRD_LAYER_FIRST_SVC_REPORT +
      "concept=" +
      selectedFunnelBannerId +
      "&date=" +
      selectedDate +
      "&channelType1=TOP2_OB_NB_ONLY&channelType2=OB_NB_ONLY";
    const nationalUrl12 =
      process.env.REACT_APP_API_ENDPOINT +
      process.env.REACT_APP_FUNNEL_NATIONAL_THIRD_LAYER_SECOND_SVC_REPORT +
      "concept=" +
      selectedFunnelBannerId +
      "&date=" +
      selectedDate +
      "&channelType1=REST_OB_NB_ONLY&channelType2=OB_NB_ONLY&metrics=OB_NB_ONLY";
    //start : Second layer fifth box click - api for third layer 9th & 10th boxes
    const nationalUrl13 =
      process.env.REACT_APP_API_ENDPOINT +
      process.env.REACT_APP_FUNNEL_NATIONAL_THIRD_LAYER_FIRST_SVC_REPORT +
      "concept=" +
      selectedFunnelBannerId +
      "&date=" +
      selectedDate +
      "&channelType1=TOP2_OB_OTH_ONLY&channelType2=OB_OTH_ONLY";
    const nationalUrl14 =
      process.env.REACT_APP_API_ENDPOINT +
      process.env.REACT_APP_FUNNEL_NATIONAL_THIRD_LAYER_SECOND_SVC_REPORT +
      "concept=" +
      selectedFunnelBannerId +
      "&date=" +
      selectedDate +
      "&channelType1=REST_OB_OTH_ONLY&channelType2=OB_OTH_ONLY&metrics=OB_OTH_ONLY";
    //start : Second layer sixth box click - api for third layer 11th & 12th boxes
    const nationalUrl15 =
      process.env.REACT_APP_API_ENDPOINT +
      process.env.REACT_APP_FUNNEL_NATIONAL_THIRD_LAYER_FIRST_SVC_REPORT +
      "concept=" +
      selectedFunnelBannerId +
      "&date=" +
      selectedDate +
      "&channelType1=TOP2_NB_OTH_ONLY&channelType2=NB_OTH_ONLY";
    const nationalUrl16 =
      process.env.REACT_APP_API_ENDPOINT +
      process.env.REACT_APP_FUNNEL_NATIONAL_THIRD_LAYER_SECOND_SVC_REPORT +
      "concept=" +
      selectedFunnelBannerId +
      "&date=" +
      selectedDate +
      "&channelType1=REST_NB_OTH_ONLY&channelType2=NB_OTH_ONLY&metrics=NB_OTH_ONLY";
    //start : Second layer seventh box click - api for third layer 13th & 14th boxes
    const nationalUrl17 =
      process.env.REACT_APP_API_ENDPOINT +
      process.env.REACT_APP_FUNNEL_NATIONAL_THIRD_LAYER_FIRST_SVC_REPORT +
      "concept=" +
      selectedFunnelBannerId +
      "&date=" +
      selectedDate +
      "&channelType1=TOP2_OB_NB_OTH_ONLY&channelType2=OB_NB_OTH_ONLY";
    const nationalUrl18 =
      process.env.REACT_APP_API_ENDPOINT +
      process.env.REACT_APP_FUNNEL_NATIONAL_THIRD_LAYER_SECOND_SVC_REPORT +
      "concept=" +
      selectedFunnelBannerId +
      "&date=" +
      selectedDate +
      "&channelType1=REST_OB_NB_OTH_ONLY&channelType2=OB_NB_OTH_ONLY&metrics=OB_NB_OTH_ONLY";
    const welcomeUrlFirstLayer1 =
      process.env.REACT_APP_API_ENDPOINT +
      process.env.REACT_APP_FUNNEL_LOYALTY_FIRST_REPORT +
      "concept=" +
      selectedFunnelBannerId +
      "&date=" +
      selectedDate;
    const welcomeUrlSecondLayer1 =
      process.env.REACT_APP_API_ENDPOINT +
      process.env.REACT_APP_FUNNEL_LOYALTY_SECOND_REPORT +
      "concept=" +
      selectedFunnelBannerId +
      "&date=" +
      selectedDate;
    const welcomeUrlSecondLayer2 =
      process.env.REACT_APP_API_ENDPOINT +
      process.env.REACT_APP_FUNNEL_LOYALTY_THIRD_REPORT +
      "concept=" +
      selectedFunnelBannerId +
      "&date=" +
      selectedDate +
      "&customerType=ALL";
    const welcomeUrlSecondLayer3 =
      process.env.REACT_APP_API_ENDPOINT +
      process.env.REACT_APP_FUNNEL_LOYALTY_FORTH_REPORT +
      "concept=" +
      selectedFunnelBannerId +
      "&date=" +
      selectedDate;
    const welcomeUrlSecondLayer4 =
      process.env.REACT_APP_API_ENDPOINT +
      process.env.REACT_APP_FUNNEL_LOYALTY_FIFTH_REPORT +
      "concept=" +
      selectedFunnelBannerId +
      "&date=" +
      selectedDate +
      "&customerType=ALL";
    const welcomeUrlThirdLayer1 =
      process.env.REACT_APP_API_ENDPOINT +
      process.env.REACT_APP_FUNNEL_LOYALTY_SIXTH_REPORT +
      "concept=" +
      selectedFunnelBannerId +
      "&date=" +
      selectedDate;
    const welcomeUrlThirdLayer2 =
      process.env.REACT_APP_API_ENDPOINT +
      process.env.REACT_APP_FUNNEL_LOYALTY_SEVENTH_REPORT +
      "concept=" +
      selectedFunnelBannerId +
      "&date=" +
      selectedDate;
    const welcomeUrlThirdLayer3 =
      process.env.REACT_APP_API_ENDPOINT +
      process.env.REACT_APP_FUNNEL_LOYALTY_EIGHTH_REPORT +
      "concept=" +
      selectedFunnelBannerId +
      "&date=" +
      selectedDate;
    const welcomeUrlThirdLayer4 =
      process.env.REACT_APP_API_ENDPOINT +
      process.env.REACT_APP_FUNNEL_LOYALTY_NINTH_REPORT +
      "concept=" +
      selectedFunnelBannerId +
      "&date=" +
      selectedDate;
    setTableOneUrl(url1);
    setTableTwoUrl(url2);
    setTableThreeUrl(url3);
    setTableForthUrl(url4);
    setTableFifthUrl(url5);
    setChannelTableOneUrl(channelurl1);
    setChannelTableTwoUrl(channelUrl2);
    setChannelTableThreeUrl(channelUrl3);
    setChannelTableForthUrl(channelUrl4);
    setChannelTableFifthUrl(channelUrl5);
    setChannelTableSixthUrl(channelUrl6);
    setChannelTableSeventhUrl(channelUrl7);
    setChannelTableEightUrl(channelUrl8);
    setChannelTableNinthUrl(channelUrl9);
    setChannelTableTenthUrl(channelUrl10);
    setNearTableOneUrl(nearUrl1);
    setNearTableTwoUrl(nearUrl2);
    setNearTableThreeUrl(nearUrl3);
    setNearTableForthUrl(nearUrl4);
    setNearTableFifthUrl(nearUrl5);
    setNearTableSixthUrl(nearUrl6);
    setNearTableSeventhUrl(nearUrl7);
    setNearTableEightUrl(nearUrl8);
    setNearTableNinthUrl(nearUrl9);
    setNearTableTenthUrl(nearUrl10);
    setNationalTableOneUrl(nationalUrl1);
    setNationalTableSLFirstUrl(nationalUrlSecondLayer1);
    setNationalTableSLSecondUrl(nationalUrlSecondLayer2);
    setNationalTableSLThreeUrl(nationalUrlSecondLayer3);
    setNationalTableSLForthUrl(nationalUrlSecondLayer4);
    setNationalTableSLFifthUrl(nationalUrlSecondLayer5);
    setNationalTableSLSixthUrl(nationalUrlSecondLayer6);
    setNationalTableSLSeventhUrl(nationalUrlSecondLayer7);
    setNationalTableFifthUrl(nationalUrl5);
    setNationalTableSixthUrl(nationalUrl6);
    setNationalTableSeventhUrl(nationalUrl7);
    setNationalTableEightUrl(nationalUrl8);
    setNationalTableNinthUrl(nationalUrl9);
    setNationalTableTenthUrl(nationalUrl10);
    setNationalTableEleventhUrl(nationalUrl11);
    setNationalTableTwelthUrl(nationalUrl12);
    setNationalTableThirteenthUrl(nationalUrl13);
    setNationalTableForteenthUrl(nationalUrl14);
    setNationalTableFifteenthUrl(nationalUrl15);
    setNationalTableSixteenthUrl(nationalUrl16);
    setNationalTableSeventeenthUrl(nationalUrl17);
    setNationalTableEighteenthUrl(nationalUrl18);
    setWelcomeTableFirstUrl(welcomeUrlFirstLayer1);
    setWelcomeTableSLSecondUrl(welcomeUrlSecondLayer1);
    setWelcomeTableSLThirdUrl(welcomeUrlSecondLayer2);
    setWelcomeTableSLForthUrl(welcomeUrlSecondLayer3);
    setWelcomeTableSLFifthUrl(welcomeUrlSecondLayer4);
    setWelcomeTableTLSixthUrl(welcomeUrlThirdLayer1);
    setWelcomeTableTLSeventhUrl(welcomeUrlThirdLayer2);
    setWelcomeTableTLEighthUrl(welcomeUrlThirdLayer3);
    setWelcomeTableTLNinthUrl(welcomeUrlThirdLayer4);
  }, [selectedFunnelBannerId, selectedDate, selectedFunnelTypeId]);

  return localStorage.getItem("isFUNNEL") === "Y" ? (
    <>
      {refreshTime.length > 0 && <NotificationMessage message={refreshDate} />}
      <div className="p-3" style={{ marginBottom: "50px" }}>
        <div className="mt-1 d-flex align-items-center headings">
          <div className="d-flex justify-content-start p-3">
            <span className="progselectupText">Concept</span>
          </div>
          <div className="d-flex justify-content-start p-3">
            <span className="progselectupText">Type</span>
          </div>
        </div>
        <div className="mt-3 d-flex align-items-center">
          <div className="d-flex justify-content-start p-3">
            <Dropdown className="d-inline">
              <Dropdown.Toggle>{selectedFunnelBanner.value}</Dropdown.Toggle>
              <Dropdown.Menu
                className="dropdown-menu-ext"
                onClick={(e) => handleFunnelBanner(e)}
              >
                {FunnelBanners.map((data) => {
                  return (
                    <Dropdown.Item
                      key={data.id}
                      className="dropdown-item-ext"
                      id={data.id}
                    >
                      {data.value}
                    </Dropdown.Item>
                  );
                })}
              </Dropdown.Menu>
            </Dropdown>
          </div>
          <div className="d-flex justify-content-start p-3">
            <Dropdown className="d-inline">
              <Dropdown.Toggle>{selectedFunnelType.value}</Dropdown.Toggle>
              <Dropdown.Menu
                className="dropdown-menu-ext"
                onClick={(e) => handleFunnelType(e)}
              >
                {FunnelType.map((data) => {
                  return (
                    <Dropdown.Item
                      key={data.id}
                      className="dropdown-item-ext"
                      id={data.id}
                    >
                      {data.value}
                    </Dropdown.Item>
                  );
                })}
              </Dropdown.Menu>
            </Dropdown>
          </div>
          <div className="d-flex justify-content-start p-3">
            <label
              className="d-flex datepicker"
              onClick={(e) => e.preventDefault()}
            >
              <DatePicker
                timeFormat={false}
                value={
                  defaultDate
                    ? defaultDate
                    : moment(selectedDate).format("MM/DD/YYYY")
                }
                isValidDate={disableCustomDt}
                onChange={(date) => handleFunnelDate(date)}
                closeOnSelect
                inputProps={{ readOnly: true }}
              />
              <img src={calender} className="date-picker-icon" />
            </label>
          </div>
        </div>
        {selectedFunnelTypeId === "0" ? (
          <LoyalityTopCustNew
            // change the name here just a replica from national
            welcomeTableOneUrl={welcomeTableOneUrl}
            welcomeTableTwoUrl={welcomeTableTwoUrl}
            welcomeTableThreeUrl={welcomeTableThreeUrl}
            welcomeTableForthUrl={welcomeTableForthUrl}
            welcomeTableFifthUrl={welcomeTableFifthUrl}
            showWelcomeLevelTwoBoxes={showWelcomeLevelTwoBoxes}
            hideWelcomeLevelTwoBoxes={hideWelcomeLevelTwoBoxes}
            welcomeLevelTwoBoxes={welcomeLevelTwoBoxes}
            welcomeTableSixthUrl={welcomeTableTLSixthUrl}
            welcomeTableSeventhUrl={welcomeTableTLSeventhUrl}
            showWelcomeLevelFourFirstHalfBoxes={
              showWelcomeLevelFourFirstHalfBoxes
            }
            welcomeLevelFourFirstHalfBoxes={welcomeLevelFourFirstHalfBoxes}
            hideWelcomeLevelThreeBoxes={hideWelcomeLevelThreeBoxes}
            showWelcomeLevelTwoFirstThreeBoxes={
              showWelcomeLevelTwoFirstThreeBoxes
            }
            welcomeLevelTwoFirstThreeBoxes={welcomeLevelTwoFirstThreeBoxes}
            showWelcomeLevelTwoSecondThreeBoxes={
              showWelcomeLevelTwoSecondThreeBoxes
            }
            welcomeLevelTwoSecondThreeBoxes={welcomeLevelTwoSecondThreeBoxes}
            welcomeTableEighthUrl={welcomeTableTLEighthUrl}
            welcomeTableNinthUrl={welcomeTableTLNinthUrl}
            welcomeLevelTLLastBoxes={welcomeLevelTLLastBoxes}
            showWelcomeLevelTLLastBoxes={showWelcomeLevelTLLastBoxes}
            hideWelcomeLevelTLLastBoxes={hideWelcomeLevelTLLastBoxes}
          />
        ) : selectedFunnelTypeId === "1" ? (
          <LoyalityTopCust
            tableOneUrl={tableOneUrl}
            tableTwoUrl={tableTwoUrl}
            tableThreeUrl={tableThreeUrl}
            tableForthUrl={tableForthUrl}
            tableFifthUrl={tableFifthUrl}
            showLevelTwoBoxes={showLevelTwoBoxes}
            showLevelThreeBoxes={showLevelThreeBoxes}
            hideLevelTwoBoxes={hideLevelTwoBoxes}
            hideLevelThreeBoxes={hideLevelThreeBoxes}
            levelTwoBoxes={levelTwoBoxes}
            levelThreeBoxes={levelThreeBoxes}
          />
        ) : selectedFunnelTypeId === "2" ? (
          <Channel
            channelTableOneUrl={channelTableOneUrl}
            channelTableTwoUrl={channelTableTwoUrl}
            channelTableThreeUrl={channelTableThreeUrl}
            channelTableForthUrl={channelTableForthUrl}
            showChannelLevelTwoBoxes={showChannelLevelTwoBoxes}
            showChannelLevelThreeBoxes={showChannelLevelThreeBoxes}
            hideChannelLevelTwoBoxes={hideChannelLevelTwoBoxes}
            hideChannelLevelThreeBoxes={hideChannelLevelThreeBoxes}
            channelLevelTwoBoxes={channelLevelTwoBoxes}
            channelLevelThreeBoxes={channelLevelThreeBoxes}
            channelTableFifthUrl={channelTableFifthUrl}
            channelTableSixthUrl={channelTableSixthUrl}
            showChannelLevelFourFirstHalfBoxes={
              showChannelLevelFourFirstHalfBoxes
            }
            channelLevelFourFirstHalfBoxes={channelLevelFourFirstHalfBoxes}
            channelTableSeventhUrl={channelTableSeventhUrl}
            channelTableEighthUrl={channelTableEighthUrl}
            channelTableNinthUrl={channelTableNinthUrl}
            channelTableTenthUrl={channelTableTenthUrl}
            channelLevelFourSecondHalfBoxes={channelLevelFourSecondHalfBoxes}
            showChannelLevelFourSecondHalfBoxes={
              showChannelLevelFourSecondHalfBoxes
            }
          />
        ) : selectedFunnelTypeId === "3" ? (
          <Near
            nearTableOneUrl={nearTableOneUrl}
            nearTableTwoUrl={nearTableTwoUrl}
            nearTableThreeUrl={nearTableThreeUrl}
            nearTableForthUrl={nearTableForthUrl}
            showNearLevelTwoBoxes={showNearLevelTwoBoxes}
            hideNearLevelTwoBoxes={hideNearLevelTwoBoxes}
            nearLevelTwoBoxes={nearLevelTwoBoxes}
            showNearLevelThreeBoxes={showNearLevelThreeBoxes}
            nearLevelThreeBoxes={nearLevelThreeBoxes}
            nearTableFifthUrl={nearTableFifthUrl}
            nearTableSixthUrl={nearTableSixthUrl}
            showNearLevelFourFirstHalfBoxes={showNearLevelFourFirstHalfBoxes}
            nearLevelFourFirstHalfBoxes={nearLevelFourFirstHalfBoxes}
            nearTableSeventhUrl={nearTableSeventhUrl}
            nearTableEighthUrl={nearTableEighthUrl}
            nearTableNinthUrl={nearTableNinthUrl}
            nearTableTenthUrl={nearTableTenthUrl}
            nearLevelFourSecondHalfBoxes={nearLevelFourSecondHalfBoxes}
            showNearLevelFourSecondHalfBoxes={showNearLevelFourSecondHalfBoxes}
            hideNearLevelThreeBoxes={hideNearLevelThreeBoxes}
          />
        ) : selectedFunnelTypeId === "4" ? (
          <NationalOwn
            nationalTableOneUrl={nationalTableOneUrl}
            nationalTableSLFirstUrl={nationalTableSLFirstUrl}
            nationalTableSLSecondUrl={nationalTableSLSecondUrl}
            nationalTableSLThreeUrl={nationalTableSLThreeUrl}
            nationalTableSLForthUrl={nationalTableSLForthUrl}
            nationalTableSLFifthUrl={nationalTableSLFifthUrl}
            nationalTableSLSixthUrl={nationalTableSLSixthUrl}
            nationalTableSLSeventhUrl={nationalTableSLSeventhUrl}
            showNationalLevelTwoBoxes={showNationalLevelTwoBoxes}
            hideNationalLevelTwoBoxes={hideNationalLevelTwoBoxes}
            nationalLevelTwoBoxes={nationalLevelTwoBoxes}
            showNationalLevelThreeBoxes={showNationalLevelThreeBoxes}
            nationalLevelThreeBoxes={nationalLevelThreeBoxes}
            nationalTableFifthUrl={nationalTableFifthUrl}
            nationalTableSixthUrl={nationalTableSixthUrl}
            showNationalLevelFourFirstHalfBoxes={
              showNationalLevelFourFirstHalfBoxes
            }
            nationalLevelFourFirstHalfBoxes={nationalLevelFourFirstHalfBoxes}
            nationalTableSeventhUrl={nationalTableSeventhUrl}
            nationalTableEighthUrl={nationalTableEighthUrl}
            nationalTableNinthUrl={nationalTableNinthUrl}
            nationalTableTenthUrl={nationalTableTenthUrl}
            hideNationalLevelThreeBoxes={hideNationalLevelThreeBoxes}
            nationalLevelFourSecondHalfBoxes={nationalLevelFourSecondHalfBoxes}
            showNationalLevelFourSecondHalfBoxes={
              showNationalLevelFourSecondHalfBoxes
            }
            selectedFunnelBannerId={selectedFunnelBannerId}
            selectedDate={selectedDate}
            vennDiagramDisplayed={vennDiagramDisplayed}
            showVennDiagram={showVennDiagram}
            hideVennDiagram={hideVennDiagram}
            showNationalLevelTwoFirstThreeBoxes={
              showNationalLevelTwoFirstThreeBoxes
            }
            nationalLevelTwoFirstThreeBoxes={nationalLevelTwoFirstThreeBoxes}
            showNationalLevelTwoSecondThreeBoxes={
              showNationalLevelTwoSecondThreeBoxes
            }
            nationalLevelTwoSecondThreeBoxes={nationalLevelTwoSecondThreeBoxes}
            nationalTableEleventhUrl={nationalTableEleventhUrl}
            nationalTableTwelthUrl={nationalTableTwelthUrl}
            nationalLevelOBNBONLYBoxes={nationalLevelOBNBONLYBoxes}
            showNationalLevelOBNBONLYBoxes={showNationalLevelOBNBONLYBoxes}
            hideNationalLevelOBNBONLYBoxes={hideNationalLevelOBNBONLYBoxes}
            nationalTableThirteenthUrl={nationalTableThirteenthUrl}
            nationalTableForteenthUrl={nationalTableForteenthUrl}
            nationalLevelOwnOtherBoxes={nationalLevelOwnOtherBoxes}
            showNationalLevelOwnOtherBoxes={showNationalLevelOwnOtherBoxes}
            hideNationalLevelOwnOtherBoxes={hideNationalLevelOwnOtherBoxes}
            nationalLevelNBOBBoxes={nationalLevelNBOBBoxes}
            showNationalLevelNBOBBoxes={showNationalLevelNBOBBoxes}
            hideNationalLevelNBOBBoxes={hideNationalLevelNBOBBoxes}
            nationalLevelNBOBOtherBoxes={nationalLevelNBOBOtherBoxes}
            showNationalLevelNBOBOtherBoxes={showNationalLevelNBOBOtherBoxes}
            hideNationalLevelNBOBOtherBoxes={hideNationalLevelNBOBOtherBoxes}
            nationalTableFifteenthUrl={nationalTableFifteenthUrl}
            nationalTableSixteenthUrl={nationalTableSixteenthUrl}
            nationalTableSeventeenthUrl={nationalTableSeventeenthUrl}
            nationalTableEighteethUrl={nationalTableEighteethUrl}
          />
        ) : (
          ""
        )}
      </div>
    </>
  ) : (
    <NoAccess tabName="Funnel" />
  );
}

export default FunnelContainer;
