import React, { useState, useEffect } from "react";
import { Row, Col } from "react-bootstrap";
import { ImArrowDown } from "react-icons/im";
import FunnelTable from "./FunnelTable";
import FunnelWrapper from "./FunnelWrapper";
import { FcCollapse } from "react-icons/fc";
import {
  BsFillArrowLeftCircleFill,
  BsFillArrowRightCircleFill,
} from "react-icons/bs";

import ReactTooltip from "react-tooltip";
import axios from "axios";
import "./FunnelContainer.css";
import {
  ACTIVE_CUSTOMERS,
  OWN_BRAND,
  NATIONAL_BRAND,
  OTHER,
  NB_ONLY,
  NB_REST,
  OB,
  OB_REST,
  OTHER_ONLY,
  OTHER_REST,
  NATIONAL_OWN,
  OWN_OTHER,
  NATIONAL_OTHER,
  NATIONAL_OWN_OTHER,
  NATIONAL_OWN_DECILE,
  NATIONAL_OWN_REST,
  OWN_OTHER_DECILE,
  OWN_OTHER_REST,
  NATIONAL_OTHER_DECILE,
  NATIONAL_OTHER_REST,
  NATIONAL_OWN_OTHER_DECILE,
  NATIONAL_OWN_OTHER_REST,
} from "./constants";
import "../Funnel/FunnelContainer.css";
import {
  VennDiagram,
  VennSeries,
  VennLabel,
  VennOuterLabel,
  VennArc,
  Gradient,
} from "reaviz";
import LoaderForRow from "../LoaderForTable/LoaderForRow";

const NationalTableOne = FunnelWrapper(FunnelTable);
const NationalTableSLFirst = FunnelWrapper(FunnelTable);
const NationalTableSLSecond = FunnelWrapper(FunnelTable);
const NationalTableSLThird = FunnelWrapper(FunnelTable);
const NationalTableSLForth = FunnelWrapper(FunnelTable);
const NationalTableSLFifth = FunnelWrapper(FunnelTable);
const NationalTableSLSixth = FunnelWrapper(FunnelTable);
const NationalTableSLSeventh = FunnelWrapper(FunnelTable);
const NationalTableFifth = FunnelWrapper(FunnelTable);
const NationalTableSixth = FunnelWrapper(FunnelTable);
const NationalTableSeventh = FunnelWrapper(FunnelTable);
const NationalTableEight = FunnelWrapper(FunnelTable);
const NationalTableNinth = FunnelWrapper(FunnelTable);
const NationalTableTenth = FunnelWrapper(FunnelTable);
const NationalTableEleventh = FunnelWrapper(FunnelTable);
const NationalTableTwelth = FunnelWrapper(FunnelTable);
const NationalTableThirteenth = FunnelWrapper(FunnelTable);
const NationalTableForteenth = FunnelWrapper(FunnelTable);
const NationalTableFifteenth = FunnelWrapper(FunnelTable);
const NationalTableSixteenth = FunnelWrapper(FunnelTable);
const NationalTableSeventeenth = FunnelWrapper(FunnelTable);
const NationalTableEighteenth = FunnelWrapper(FunnelTable);

function National({
  nationalTableOneUrl,
  nationalTableSLFirstUrl,
  nationalTableSLSecondUrl,
  nationalTableSLThreeUrl,
  nationalTableSLForthUrl,
  nationalTableSLFifthUrl,
  nationalTableSLSixthUrl,
  nationalTableSLSeventhUrl,
  showNationalLevelTwoBoxes,
  hideNationalLevelTwoBoxes,
  showNationalLevelThreeBoxes,
  nationalLevelTwoBoxes,
  nationalLevelThreeBoxes,
  nationalTableFifthUrl,
  nationalTableSixthUrl,
  showNationalLevelFourFirstHalfBoxes,
  nationalLevelFourFirstHalfBoxes,
  nationalTableSeventhUrl,
  nationalTableEighthUrl,
  hideNationalLevelThreeBoxes,
  nationalTableNinthUrl,
  nationalTableTenthUrl,
  nationalLevelFourSecondHalfBoxes,
  showNationalLevelFourSecondHalfBoxes,
  selectedDate,
  selectedFunnelBannerId,
  vennDiagramDisplayed,
  showVennDiagram,
  hideVennDiagram,
  showNationalLevelTwoFirstThreeBoxes,
  nationalLevelTwoFirstThreeBoxes,
  showNationalLevelTwoSecondThreeBoxes,
  nationalLevelTwoSecondThreeBoxes,
  nationalTableEleventhUrl,
  nationalTableTwelthUrl,
  nationalLevelOBNBONLYBoxes,
  showNationalLevelOBNBONLYBoxes,
  hideNationalLevelOBNBONLYBoxes,
  nationalTableThirteenthUrl,
  nationalTableForteenthUrl,
  nationalLevelOwnOtherBoxes,
  showNationalLevelOwnOtherBoxes,
  hideNationalLevelOwnOtherBoxes,
  nationalLevelNBOBBoxes,
  showNationalLevelNBOBBoxes,
  hideNationalLevelNBOBBoxes,
  nationalLevelNBOBOtherBoxes,
  showNationalLevelNBOBOtherBoxes,
  hideNationalLevelNBOBOtherBoxes,
  nationalTableFifteenthUrl,
  nationalTableSixteenthUrl,
  nationalTableSeventeenthUrl,
  nationalTableEighteethUrl,
}) {
  const [vennData, setVennData] = useState([]);
  const [venn_loader, setloader] = useState(false);

  useEffect(() => {
    const getFunnelNationalOwnVennData = async () => {
      try {
        setloader(true);
        let url =
          process.env.REACT_APP_API_ENDPOINT +
          process.env.REACT_APP_FUNNEL_NATIONAL_OWN_VENN +
          "concept=" +
          selectedFunnelBannerId +
          "&date=" +
          selectedDate;

        await axios({ url }).then((res) => {
          setloader(false);
          setVennData(res.data);
        });
      } catch (err) {
        console.log("err-getFunnelNationalOwnVennData", err);
        setloader(false);
      }
    };

    getFunnelNationalOwnVennData();
  }, [selectedFunnelBannerId, selectedDate]);

  return (
    <>
      <Row>
        <NationalTableOne
          data={{
            url: nationalTableOneUrl,
            header: ACTIVE_CUSTOMERS,
          }}
        />
        {vennDiagramDisplayed ? (
          <>
            <div className="collapseArrowContainer">
              <span className="collapseArrow">
                <FcCollapse
                  className="CollapseIconInfo"
                  data-tip
                  data-for="CollapseIcon"
                  style={{ cursor: "pointer" }}
                  onClick={hideVennDiagram}
                />
                <ReactTooltip
                  className="tooltip_css "
                  id="CollapseIcon"
                  place="top"
                  effect="float"
                  backgroundColor="#595959"
                >
                  Collapse All
                </ReactTooltip>
              </span>
            </div>
            <div className="venn-row-Container">
              {venn_loader ? (
                <>
                  <LoaderForRow tdCount={1} height={"170px"} />
                </>
              ) : vennData[0] !== null &&
                vennData[0] !== undefined &&
                vennData[0].length !== 0 ? (
                <>
                  <VennDiagram
                    type="starEuler"
                    height={450}
                    width={650}
                    data={[
                      {
                        key: ["National Brands"],
                        data: Number(vennData[0].CUST_COUNT_NB_TY),
                      },
                      {
                        key: ["Own Brands"],
                        data: Number(vennData[0].CUST_COUNT_OB_TY),
                      },
                      {
                        key: ["Other Brands"],
                        data: Number(vennData[0].CUST_COUNT_OTH_TY),
                      },
                      {
                        key: ["National Brands", "Own Brands"],
                        data: Number(vennData[0].CUST_COUNT_OB_NB_TY),
                      },
                      {
                        key: ["Own Brands", "Other Brands"],
                        data: Number(vennData[0].CUST_COUNT_OB_OTH_TY),
                      },
                      {
                        key: ["National Brands", "Other Brands"],
                        data: Number(vennData[0].CUST_COUNT_NB_OTH_TY),
                      },
                      {
                        key: ["National Brands", "Own Brands", "Other Brands"],
                        data: Number(vennData[0].CUST_COUNT_OB_NB_OTH_TY),
                      },
                    ]}
                    series={
                      <VennSeries
                        colorScheme={["#0b5ed7"]}
                        arc={
                          <VennArc
                            stroke={(data, index, active, hovered) => {
                              if (hovered) {
                                return "#0a58ca";
                              } else if (active) {
                                return "grey";
                              }
                              return "white";
                            }}
                            gradient={<Gradient />}
                          />
                        }
                        label={
                          <VennLabel
                            labelType="value"
                            showAll={true}
                            fill={"#fff"}
                          />
                        }
                        outerLabel={<VennOuterLabel fill={"black"} />}
                      />
                    }
                  />
                </>
              ) : (
                <Col>
                  <b>Data not available for Venn Diagram</b>
                </Col>
              )}
            </div>
            {nationalLevelTwoBoxes ? (
              ""
            ) : (
              <div className="funnel-arrow">
                <ImArrowDown
                  onClick={showNationalLevelTwoBoxes}
                  className="arrowDown"
                />
              </div>
            )}
          </>
        ) : (
          <div className="funnel-arrow">
            <ImArrowDown onClick={showVennDiagram} className="arrowDown" />
          </div>
        )}
        <div>
          {nationalLevelTwoBoxes ? (
            <>
              <div className="collapseArrowContainer">
                <span className="collapseArrow">
                  <FcCollapse
                    className="CollapseIconInfo"
                    data-tip
                    data-for="CollapseIcon"
                    style={{ cursor: "pointer" }}
                    onClick={hideNationalLevelTwoBoxes}
                  />
                  <ReactTooltip
                    className="tooltip_css "
                    id="CollapseIcon"
                    place="top"
                    effect="float"
                    backgroundColor="#595959"
                  >
                    Collapse All
                  </ReactTooltip>
                </span>
              </div>
              <div className="funnel-arrow">
                <ImArrowDown />
                <ImArrowDown />
                <ImArrowDown />
              </div>
            </>
          ) : (
            ""
          )}
        </div>
      </Row>
      {nationalLevelTwoBoxes && (
        <>
          {nationalLevelTwoSecondThreeBoxes && (
            <div className="funnel-arrow-left">
              <BsFillArrowLeftCircleFill
                fill="grey"
                onClick={showNationalLevelTwoFirstThreeBoxes}
              />
            </div>
          )}
          <Row>
            {nationalLevelTwoFirstThreeBoxes && (
              <>
                <Col>
                  <NationalTableSLFirst
                    data={{
                      url: nationalTableSLFirstUrl,
                      header: OWN_BRAND,
                    }}
                  />
                  <div className="funnel-arrow">
                    {nationalLevelFourFirstHalfBoxes ? (
                      <>
                        <div className="collapseArrowContainer">
                          <span className="collapseArrow">
                            <FcCollapse
                              className="CollapseIconInfo"
                              data-tip
                              data-for="CollapseIcon"
                              style={{ cursor: "pointer" }}
                              onClick={hideNationalLevelThreeBoxes}
                            />
                            <ReactTooltip
                              className="tooltip_css "
                              id="CollapseIcon"
                              place="top"
                              effect="float"
                              backgroundColor="#595959"
                            >
                              Collapse All
                            </ReactTooltip>
                          </span>

                          <ImArrowDown style={{ fontSize: "3rem" }} />
                        </div>
                      </>
                    ) : (
                      <ImArrowDown
                        onClick={showNationalLevelFourFirstHalfBoxes}
                        className="arrowDown"
                      />
                    )}
                  </div>
                </Col>
                <Col>
                  <NationalTableSLSecond
                    data={{
                      url: nationalTableSLSecondUrl,
                      header: NATIONAL_BRAND,
                    }}
                  />
                  <div className="funnel-arrow">
                    {nationalLevelThreeBoxes ? (
                      <>
                        <div className="collapseArrowContainer">
                          <span className="collapseArrow">
                            <FcCollapse
                              className="CollapseIconInfo"
                              data-tip
                              data-for="CollapseIcon"
                              style={{ cursor: "pointer" }}
                              onClick={hideNationalLevelThreeBoxes}
                            />
                            <ReactTooltip
                              className="tooltip_css "
                              id="CollapseIcon"
                              place="top"
                              effect="float"
                              backgroundColor="#595959"
                            >
                              Collapse All
                            </ReactTooltip>
                          </span>
                          <ImArrowDown style={{ fontSize: "3rem" }} />
                        </div>
                      </>
                    ) : (
                      <ImArrowDown
                        onClick={showNationalLevelThreeBoxes}
                        className="arrowDown"
                      />
                    )}
                  </div>
                </Col>
                <Col>
                  <NationalTableSLThird
                    data={{
                      url: nationalTableSLThreeUrl,
                      header: OTHER,
                    }}
                  />
                  <div className="funnel-arrow">
                    {nationalLevelFourSecondHalfBoxes ? (
                      <>
                        <div className="collapseArrowContainer">
                          <span className="collapseArrow">
                            <FcCollapse
                              className="CollapseIconInfo"
                              data-tip
                              data-for="CollapseIcon"
                              style={{ cursor: "pointer" }}
                              onClick={hideNationalLevelThreeBoxes}
                            />
                            <ReactTooltip
                              className="tooltip_css "
                              id="CollapseIcon"
                              place="top"
                              effect="float"
                              backgroundColor="#595959"
                            >
                              Collapse All
                            </ReactTooltip>
                          </span>
                          <ImArrowDown style={{ fontSize: "3rem" }} />
                        </div>
                      </>
                    ) : (
                      <ImArrowDown
                        onClick={showNationalLevelFourSecondHalfBoxes}
                        className="arrowDown"
                      />
                    )}
                  </div>
                </Col>
              </>
            )}
            {nationalLevelTwoSecondThreeBoxes && (
              <>
                <Col>
                  <NationalTableSLForth
                    data={{
                      url: nationalTableSLForthUrl,
                      header: NATIONAL_OWN,
                    }}
                  />
                  <div className="funnel-arrow">
                    {nationalLevelOBNBONLYBoxes ? (
                      <>
                        <div className="collapseArrowContainer">
                          <span className="collapseArrow">
                            <FcCollapse
                              className="CollapseIconInfo"
                              data-tip
                              data-for="CollapseIcon"
                              style={{ cursor: "pointer" }}
                              onClick={hideNationalLevelOBNBONLYBoxes}
                            />
                            <ReactTooltip
                              className="tooltip_css "
                              id="CollapseIcon"
                              place="top"
                              effect="float"
                              backgroundColor="#595959"
                            >
                              Collapse All
                            </ReactTooltip>
                          </span>

                          <ImArrowDown style={{ fontSize: "3rem" }} />
                        </div>
                      </>
                    ) : (
                      <ImArrowDown
                        onClick={showNationalLevelOBNBONLYBoxes}
                        className="arrowDown"
                      />
                    )}
                  </div>
                </Col>
                <Col>
                  <NationalTableSLFifth
                    data={{
                      url: nationalTableSLFifthUrl,
                      header: OWN_OTHER,
                    }}
                  />
                  <div className="funnel-arrow">
                    {nationalLevelOwnOtherBoxes ? (
                      <>
                        <div className="collapseArrowContainer">
                          <span className="collapseArrow">
                            <FcCollapse
                              className="CollapseIconInfo"
                              data-tip
                              data-for="CollapseIcon"
                              style={{ cursor: "pointer" }}
                              onClick={hideNationalLevelOwnOtherBoxes}
                            />
                            <ReactTooltip
                              className="tooltip_css "
                              id="CollapseIcon"
                              place="top"
                              effect="float"
                              backgroundColor="#595959"
                            >
                              Collapse All
                            </ReactTooltip>
                          </span>
                          <ImArrowDown style={{ fontSize: "3rem" }} />
                        </div>
                      </>
                    ) : (
                      <ImArrowDown
                        onClick={showNationalLevelOwnOtherBoxes}
                        className="arrowDown"
                      />
                    )}
                  </div>
                </Col>
                <Col>
                  <NationalTableSLSixth
                    data={{
                      url: nationalTableSLSixthUrl,
                      header: NATIONAL_OTHER,
                    }}
                  />
                  <div className="funnel-arrow">
                    {nationalLevelNBOBBoxes ? (
                      <>
                        <div className="collapseArrowContainer">
                          <span className="collapseArrow">
                            <FcCollapse
                              className="CollapseIconInfo"
                              data-tip
                              data-for="CollapseIcon"
                              style={{ cursor: "pointer" }}
                              onClick={hideNationalLevelNBOBBoxes}
                            />
                            <ReactTooltip
                              className="tooltip_css "
                              id="CollapseIcon"
                              place="top"
                              effect="float"
                              backgroundColor="#595959"
                            >
                              Collapse All
                            </ReactTooltip>
                          </span>
                          <ImArrowDown style={{ fontSize: "3rem" }} />
                        </div>
                      </>
                    ) : (
                      <ImArrowDown
                        onClick={showNationalLevelNBOBBoxes}
                        className="arrowDown"
                      />
                    )}
                  </div>
                </Col>
                <Col>
                  <NationalTableSLSeventh
                    data={{
                      url: nationalTableSLSeventhUrl,
                      header: NATIONAL_OWN_OTHER,
                    }}
                  />
                  <div className="funnel-arrow">
                    {nationalLevelNBOBOtherBoxes ? (
                      <>
                        <div className="collapseArrowContainer">
                          <span className="collapseArrow">
                            <FcCollapse
                              className="CollapseIconInfo"
                              data-tip
                              data-for="CollapseIcon"
                              style={{ cursor: "pointer" }}
                              onClick={hideNationalLevelNBOBOtherBoxes}
                            />
                            <ReactTooltip
                              className="tooltip_css "
                              id="CollapseIcon"
                              place="top"
                              effect="float"
                              backgroundColor="#595959"
                            >
                              Collapse All
                            </ReactTooltip>
                          </span>
                          <ImArrowDown style={{ fontSize: "3rem" }} />
                        </div>
                      </>
                    ) : (
                      <ImArrowDown
                        onClick={showNationalLevelNBOBOtherBoxes}
                        className="arrowDown"
                      />
                    )}
                  </div>
                </Col>
              </>
            )}
            <>
              {nationalLevelTwoFirstThreeBoxes && (
                <div className="funnel-arrow-right">
                  <BsFillArrowRightCircleFill
                    fill="grey"
                    onClick={showNationalLevelTwoSecondThreeBoxes}
                  />
                </div>
              )}
            </>
          </Row>
        </>
      )}
      {nationalLevelFourFirstHalfBoxes && (
        <Row style={{ margin: "1rem", boxShadow: "0 0 10px" }}>
          <Col>
            <NationalTableFifth
              data={{
                url: nationalTableFifthUrl,
                header: OB,
              }}
            />
          </Col>
          <Col>
            <NationalTableSixth
              data={{
                url: nationalTableSixthUrl,
                header: OB_REST,
              }}
            />
          </Col>
        </Row>
      )}
      {nationalLevelThreeBoxes && (
        <Row style={{ margin: "1rem", boxShadow: "0 0 10px" }}>
          <Col>
            <NationalTableSeventh
              data={{
                url: nationalTableSeventhUrl,
                header: NB_ONLY,
              }}
            />
          </Col>
          <Col>
            <NationalTableEight
              data={{
                url: nationalTableEighthUrl,
                header: NB_REST,
              }}
            />
          </Col>
        </Row>
      )}
      {nationalLevelFourSecondHalfBoxes && (
        <Row style={{ margin: "1rem", boxShadow: "0 0 10px" }}>
          <Col>
            <NationalTableNinth
              data={{
                url: nationalTableNinthUrl,
                header: OTHER_ONLY,
              }}
            />
          </Col>
          <Col>
            <NationalTableTenth
              data={{
                url: nationalTableTenthUrl,
                header: OTHER_REST,
              }}
            />
          </Col>
        </Row>
      )}
      {nationalLevelOBNBONLYBoxes && (
        <Row style={{ margin: "1rem", boxShadow: "0 0 10px" }}>
          <Col>
            <NationalTableEleventh
              data={{
                url: nationalTableEleventhUrl,
                header: NATIONAL_OWN_DECILE,
              }}
            />
          </Col>
          <Col>
            <NationalTableTwelth
              data={{
                url: nationalTableTwelthUrl,
                header: NATIONAL_OWN_REST,
              }}
            />
          </Col>
        </Row>
      )}
      {nationalLevelOwnOtherBoxes && (
        <Row style={{ margin: "1rem", boxShadow: "0 0 10px" }}>
          <Col>
            <NationalTableThirteenth
              data={{
                url: nationalTableThirteenthUrl,
                header: OWN_OTHER_DECILE,
              }}
            />
          </Col>
          <Col>
            <NationalTableForteenth
              data={{
                url: nationalTableForteenthUrl,
                header: OWN_OTHER_REST,
              }}
            />
          </Col>
        </Row>
      )}
      {nationalLevelNBOBBoxes && (
        <Row style={{ margin: "1rem", boxShadow: "0 0 10px" }}>
          <Col>
            <NationalTableFifteenth
              data={{
                url: nationalTableFifteenthUrl,
                header: NATIONAL_OTHER_DECILE,
              }}
            />
          </Col>
          <Col>
            <NationalTableSixteenth
              data={{
                url: nationalTableSixteenthUrl,
                header: NATIONAL_OTHER_REST,
              }}
            />
          </Col>
        </Row>
      )}
      {nationalLevelNBOBOtherBoxes && (
        <Row style={{ margin: "1rem", boxShadow: "0 0 10px" }}>
          <Col>
            <NationalTableSeventeenth
              data={{
                url: nationalTableSeventeenthUrl,
                header: NATIONAL_OWN_OTHER_DECILE,
              }}
            />
          </Col>
          <Col>
            <NationalTableEighteenth
              data={{
                url: nationalTableEighteethUrl,
                header: NATIONAL_OWN_OTHER_REST,
              }}
            />
          </Col>
        </Row>
      )}
    </>
  );
}

export default National;
