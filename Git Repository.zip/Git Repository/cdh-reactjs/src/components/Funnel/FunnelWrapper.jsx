import React from "react";
import axios from "axios";
function FunnelWrapper(WrapperComponent) {
  return class extends React.Component {
    constructor(props) {
      super(props);
      this.state = {
        FunnelDataError: "error",
        FunnelDataLoaded: false,
        FunnelData: [],
      };
      this.GetFunnelData = this.GetFunnelData.bind(this);
    }
    componentDidMount() {
      this.GetFunnelData();
    }
    componentDidUpdate(prevProps, prevState) {
      if (prevProps.data.url !== this.props.data.url) {
        this.GetFunnelData();
      }
    }
    GetFunnelData() {
      const FunnelUrl = this.props.data.url;
      try {
        this.setState({
          FunnelDataLoaded: true,
          FunnelDataError: "",
          FunnelData: [],
        });
        if (FunnelUrl !== "") {
          axios.get(FunnelUrl).then((res) => {
            this.setState({
              FunnelData: res.data,
              FunnelDataLoaded: false,
            });
          });
        }
      } catch (err) {
        this.setState({
          FunnelDataError: "",
          FunnelDataLoaded: false,
          FunnelData: [],
        });
      }
    }

    render() {
      return (
        <WrapperComponent {...this.state} header={this.props.data.header} />
      );
    }
  };
}

export default FunnelWrapper;
