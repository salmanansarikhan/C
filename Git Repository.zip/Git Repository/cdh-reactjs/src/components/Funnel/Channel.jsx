import React, { useState } from "react";
import { Row, Col } from "react-bootstrap";
import { ImArrowDown } from "react-icons/im";
import FunnelTable from "./FunnelTable";
import FunnelWrapper from "./FunnelWrapper";
import { FcCollapse } from "react-icons/fc";
import ReactTooltip from "react-tooltip";
import {
  ACTIVE_CUSTOMERS,
  STORE,
  STORE_DECILE,
  STORE_REST,
  OMNI,
  ONLINE_ONLY,
  OMNI_DECILE,
  OMNI_REST,
  ONLINE_DECILE,
  ONLINE_REST,
} from "./constants";
import "../Funnel/FunnelContainer.css";

const ChannelTableOne = FunnelWrapper(FunnelTable);
const ChannelTableTwo = FunnelWrapper(FunnelTable);
const ChannelTableThird = FunnelWrapper(FunnelTable);
const ChannelTableForth = FunnelWrapper(FunnelTable);
const ChannelTableFifth = FunnelWrapper(FunnelTable);
const ChannelTableSixth = FunnelWrapper(FunnelTable);
const ChannelTableSeventh = FunnelWrapper(FunnelTable);
const ChannelTableEight = FunnelWrapper(FunnelTable);
const ChannelTableNinth = FunnelWrapper(FunnelTable);
const ChannelTableTenth = FunnelWrapper(FunnelTable);

function Channel({
  channelTableOneUrl,
  channelTableTwoUrl,
  channelTableThreeUrl,
  channelTableForthUrl,
  showChannelLevelTwoBoxes,
  showChannelLevelThreeBoxes,
  hideChannelLevelTwoBoxes,
  hideChannelLevelThreeBoxes,
  channelLevelTwoBoxes,
  channelLevelThreeBoxes,
  channelTableFifthUrl,
  channelTableSixthUrl,
  showChannelLevelFourFirstHalfBoxes,
  channelLevelFourFirstHalfBoxes,
  channelTableSeventhUrl,
  channelTableEighthUrl,
  channelTableNinthUrl,
  channelTableTenthUrl,
  channelLevelFourSecondHalfBoxes,
  showChannelLevelFourSecondHalfBoxes,
}) {
  return (
    <>
      <Row>
        <ChannelTableOne
          data={{
            url: channelTableOneUrl,
            header: ACTIVE_CUSTOMERS,
          }}
        />
        <div>
          {channelLevelTwoBoxes ? (
            <>
              <div className="collapseArrowContainer">
                <span className="collapseArrow">
                  <FcCollapse
                    className="CollapseIconInfo"
                    data-tip
                    data-for="CollapseIcon"
                    style={{ cursor: "pointer" }}
                    onClick={hideChannelLevelTwoBoxes}
                  />
                  <ReactTooltip
                    className="tooltip_css "
                    id="CollapseIcon"
                    place="top"
                    effect="float"
                    backgroundColor="#595959"
                  >
                    Collapse All
                  </ReactTooltip>
                </span>
              </div>
              <div className="funnel-arrow">
                <ImArrowDown />
                <ImArrowDown />
                <ImArrowDown />
              </div>
            </>
          ) : (
            <div className="funnel-arrow">
              <ImArrowDown
                onClick={showChannelLevelTwoBoxes}
                className="arrowDown"
              />
            </div>
          )}
        </div>
      </Row>
      {channelLevelTwoBoxes && (
        <Row>
          <Col>
            <ChannelTableTwo
              data={{
                url: channelTableTwoUrl,
                header: STORE,
              }}
            />
            <div>
              {channelLevelFourFirstHalfBoxes ? (
                <>
                  <div className="collapseArrowContainer">
                    <span className="collapseArrow">
                      <FcCollapse
                        className="CollapseIconInfo"
                        data-tip
                        data-for="CollapseIcon"
                        style={{ cursor: "pointer" }}
                        onClick={hideChannelLevelThreeBoxes}
                      />
                      <ReactTooltip
                        className="tooltip_css "
                        id="CollapseIcon"
                        place="top"
                        effect="float"
                        backgroundColor="#595959"
                      >
                        Collapse All
                      </ReactTooltip>
                    </span>
                    <ImArrowDown style={{ fontSize: "3rem" }} />
                  </div>
                </>
              ) : (
                <div className="funnel-arrow">
                  <ImArrowDown
                    onClick={showChannelLevelFourFirstHalfBoxes}
                    className="arrowDown"
                  />
                </div>
              )}
            </div>
          </Col>
          <Col>
            <ChannelTableThird
              data={{
                url: channelTableThreeUrl,
                header: OMNI,
              }}
            />
            <div>
              {channelLevelThreeBoxes ? (
                <>
                  <div className="collapseArrowContainer">
                    <span className="collapseArrow">
                      <FcCollapse
                        className="CollapseIconInfo"
                        data-tip
                        data-for="CollapseIcon"
                        style={{ cursor: "pointer" }}
                        onClick={hideChannelLevelThreeBoxes}
                      />
                      <ReactTooltip
                        className="tooltip_css "
                        id="CollapseIcon"
                        place="top"
                        effect="float"
                        backgroundColor="#595959"
                      >
                        Collapse All
                      </ReactTooltip>
                    </span>
                  </div>
                  <ImArrowDown style={{ fontSize: "3rem" }} />
                </>
              ) : (
                <div className="funnel-arrow">
                  <ImArrowDown
                    onClick={showChannelLevelThreeBoxes}
                    className="arrowDown"
                  />
                </div>
              )}
            </div>
          </Col>
          <Col>
            <ChannelTableForth
              data={{
                url: channelTableForthUrl,
                header: ONLINE_ONLY,
              }}
            />
            <div>
              {channelLevelFourSecondHalfBoxes ? (
                <>
                  <div className="collapseArrowContainer">
                    <span className="collapseArrow">
                      <FcCollapse
                        className="CollapseIconInfo"
                        data-tip
                        data-for="CollapseIcon"
                        style={{ cursor: "pointer", color: "red" }}
                        onClick={hideChannelLevelThreeBoxes}
                      />
                      <ReactTooltip
                        className="tooltip_css "
                        id="CollapseIcon"
                        place="top"
                        effect="float"
                        backgroundColor="#595959"
                      >
                        Collapse All
                      </ReactTooltip>
                    </span>
                    <ImArrowDown style={{ fontSize: "3rem" }} />
                  </div>
                </>
              ) : (
                <div className="funnel-arrow">
                  <ImArrowDown
                    onClick={showChannelLevelFourSecondHalfBoxes}
                    className="arrowDown"
                  />
                </div>
              )}
            </div>
          </Col>
        </Row>
      )}
      {channelLevelFourFirstHalfBoxes && (
        <Row style={{ margin: "1rem", boxShadow: "0 0 10px" }}>
          <Col>
            <ChannelTableFifth
              data={{
                url: channelTableFifthUrl,
                header: STORE_DECILE,
              }}
            />
          </Col>
          <Col>
            <ChannelTableSixth
              data={{
                url: channelTableSixthUrl,
                header: STORE_REST,
              }}
            />
          </Col>
        </Row>
      )}
      {channelLevelThreeBoxes && (
        <Row style={{ margin: "1rem", boxShadow: "0 0 10px" }}>
          <Col>
            <ChannelTableSeventh
              data={{
                url: channelTableSeventhUrl,
                header: OMNI_DECILE,
              }}
            />
          </Col>
          <Col>
            <ChannelTableEight
              data={{
                url: channelTableEighthUrl,
                header: OMNI_REST,
              }}
            />
          </Col>
        </Row>
      )}
      {channelLevelFourSecondHalfBoxes && (
        <Row style={{ margin: "1rem", boxShadow: "0 0 10px" }}>
          <Col>
            <ChannelTableNinth
              data={{
                url: channelTableNinthUrl,
                header: ONLINE_DECILE,
              }}
            />
          </Col>
          <Col>
            <ChannelTableTenth
              data={{
                url: channelTableTenthUrl,
                header: ONLINE_REST,
              }}
            />
          </Col>
        </Row>
      )}
    </>
  );
}

export default Channel;
