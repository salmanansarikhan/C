import React, { useState } from "react";
import { Row, Col } from "react-bootstrap";
import { ImArrowDown } from "react-icons/im";
import FunnelTable from "./FunnelTable";
import FunnelWrapper from "./FunnelWrapper";
import { FcCollapse } from "react-icons/fc";
import ReactTooltip from "react-tooltip";
import {
  ACTIVE_CUSTOMERS,
  NEW,
  ACTIVE_ENGAGED,
  REACTIVATED,
  ACTIVE_ENGAGED_DECILE,
  RETAIL_REST,
  NEW_CUSTOMER_DECILE,
  NEW_ONLY_REST,
  REACT_ONLY_DECILE,
  REACT_ONLY_REST,
} from "./constants";
import "../Funnel/FunnelContainer.css";

const NearTableOne = FunnelWrapper(FunnelTable);
const NearTableTwo = FunnelWrapper(FunnelTable);
const NearTableThird = FunnelWrapper(FunnelTable);
const NearTableForth = FunnelWrapper(FunnelTable);
const NearTableFifth = FunnelWrapper(FunnelTable);
const NearTableSixth = FunnelWrapper(FunnelTable);
const NearTableSeventh = FunnelWrapper(FunnelTable);
const NearTableEight = FunnelWrapper(FunnelTable);
const NearTableNinth = FunnelWrapper(FunnelTable);
const NearTableTenth = FunnelWrapper(FunnelTable);

function Near({
  nearTableOneUrl,
  nearTableTwoUrl,
  nearTableThreeUrl,
  nearTableForthUrl,
  showNearLevelTwoBoxes,
  hideNearLevelTwoBoxes,
  showNearLevelThreeBoxes,
  nearLevelTwoBoxes,
  nearLevelThreeBoxes,
  nearTableFifthUrl,
  nearTableSixthUrl,
  showNearLevelFourFirstHalfBoxes,
  nearLevelFourFirstHalfBoxes,
  nearTableSeventhUrl,
  nearTableEighthUrl,
  nearTableNinthUrl,
  nearTableTenthUrl,
  nearLevelFourSecondHalfBoxes,
  showNearLevelFourSecondHalfBoxes,
  hideNearLevelThreeBoxes,
}) {
  return (
    <>
      <Row>
        <NearTableOne
          data={{
            url: nearTableOneUrl,
            header: ACTIVE_CUSTOMERS,
          }}
        />
        <div>
          {nearLevelTwoBoxes ? (
            <>
              <div className="collapseArrowContainer">
                <span className="collapseArrow">
                  <FcCollapse
                    className="CollapseIconInfo"
                    data-tip
                    data-for="CollapseIcon"
                    style={{ cursor: "pointer" }}
                    onClick={hideNearLevelTwoBoxes}
                  />
                  <ReactTooltip
                    className="tooltip_css "
                    id="CollapseIcon"
                    place="top"
                    effect="float"
                    backgroundColor="#595959"
                  >
                    Collapse All
                  </ReactTooltip>
                </span>
              </div>
              <div className="funnel-arrow">
                <ImArrowDown />
                <ImArrowDown />
                <ImArrowDown />
              </div>
            </>
          ) : (
            <div className="funnel-arrow">
              <ImArrowDown
                onClick={showNearLevelTwoBoxes}
                className="arrowDown"
              />
            </div>
          )}
        </div>
      </Row>
      {nearLevelTwoBoxes && (
        <Row>
          <Col>
            <NearTableTwo
              data={{
                url: nearTableTwoUrl,
                header: NEW,
              }}
            />
            <div className="funnel-arrow">
              {nearLevelFourFirstHalfBoxes ? (
                <>
                  <div className="collapseArrowContainer">
                    <span className="collapseArrow">
                      <FcCollapse
                        className="CollapseIconInfo"
                        data-tip
                        data-for="CollapseIcon"
                        style={{ cursor: "pointer" }}
                        onClick={hideNearLevelThreeBoxes}
                      />
                      <ReactTooltip
                        className="tooltip_css "
                        id="CollapseIcon"
                        place="top"
                        effect="float"
                        backgroundColor="#595959"
                      >
                        Collapse All
                      </ReactTooltip>
                    </span>

                    <ImArrowDown style={{ fontSize: "3rem" }} />
                  </div>
                </>
              ) : (
                <ImArrowDown
                  onClick={showNearLevelFourFirstHalfBoxes}
                  className="arrowDown"
                />
              )}
            </div>
          </Col>
          <Col>
            <NearTableThird
              data={{
                url: nearTableThreeUrl,
                header: ACTIVE_ENGAGED,
              }}
            />
            <div className="funnel-arrow">
              {nearLevelThreeBoxes ? (
                <>
                  <div className="collapseArrowContainer">
                    <span className="collapseArrow">
                      <FcCollapse
                        className="CollapseIconInfo"
                        data-tip
                        data-for="CollapseIcon"
                        style={{ cursor: "pointer" }}
                        onClick={hideNearLevelThreeBoxes}
                      />
                      <ReactTooltip
                        className="tooltip_css "
                        id="CollapseIcon"
                        place="top"
                        effect="float"
                        backgroundColor="#595959"
                      >
                        Collapse All
                      </ReactTooltip>
                    </span>
                    <ImArrowDown style={{ fontSize: "3rem" }} />
                  </div>
                </>
              ) : (
                <ImArrowDown
                  onClick={showNearLevelThreeBoxes}
                  className="arrowDown"
                />
              )}
            </div>
          </Col>
          <Col>
            <NearTableForth
              data={{
                url: nearTableForthUrl,
                header: REACTIVATED,
              }}
            />
            <div className="funnel-arrow">
              {nearLevelFourSecondHalfBoxes ? (
                <>
                  <div className="collapseArrowContainer">
                    <span className="collapseArrow">
                      <FcCollapse
                        className="CollapseIconInfo"
                        data-tip
                        data-for="CollapseIcon"
                        style={{ cursor: "pointer", color: "red" }}
                        onClick={hideNearLevelThreeBoxes}
                      />
                      <ReactTooltip
                        className="tooltip_css "
                        id="CollapseIcon"
                        place="top"
                        effect="float"
                        backgroundColor="#595959"
                      >
                        Collapse All
                      </ReactTooltip>
                    </span>
                    <ImArrowDown style={{ fontSize: "3rem" }} />
                  </div>
                </>
              ) : (
                <ImArrowDown
                  onClick={showNearLevelFourSecondHalfBoxes}
                  className="arrowDown"
                />
              )}
            </div>
          </Col>
        </Row>
      )}
      {nearLevelFourFirstHalfBoxes && (
        <Row style={{ margin: "1rem", boxShadow: "0 0 10px" }}>
          <Col>
            <NearTableFifth
              data={{
                url: nearTableFifthUrl,
                header: NEW_CUSTOMER_DECILE,
              }}
            />
          </Col>
          <Col>
            <NearTableSixth
              data={{
                url: nearTableSixthUrl,
                header: NEW_ONLY_REST,
              }}
            />
          </Col>
        </Row>
      )}
      {nearLevelThreeBoxes && (
        <Row style={{ margin: "1rem", boxShadow: "0 0 10px" }}>
          <Col>
            <NearTableSeventh
              data={{
                url: nearTableSeventhUrl,
                header: ACTIVE_ENGAGED_DECILE,
              }}
            />
          </Col>
          <Col>
            <NearTableEight
              data={{
                url: nearTableEighthUrl,
                header: RETAIL_REST,
              }}
            />
          </Col>
        </Row>
      )}
      {nearLevelFourSecondHalfBoxes && (
        <Row style={{ margin: "1rem", boxShadow: "0 0 10px" }}>
          <Col>
            <NearTableNinth
              data={{
                url: nearTableNinthUrl,
                header: REACT_ONLY_DECILE,
              }}
            />
          </Col>
          <Col>
            <NearTableTenth
              data={{
                url: nearTableTenthUrl,
                header: REACT_ONLY_REST,
              }}
            />
          </Col>
        </Row>
      )}
    </>
  );
}

export default Near;
