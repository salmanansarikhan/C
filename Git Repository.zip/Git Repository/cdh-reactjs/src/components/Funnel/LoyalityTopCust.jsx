import React, { useState } from "react";
import { Row, Col } from "react-bootstrap";
import { ImArrowDown } from "react-icons/im";
import { FcCollapse } from "react-icons/fc";
import FunnelTable from "./FunnelTable";
import FunnelWrapper from "./FunnelWrapper";
import {
  ACTIVE_CUSTOMERS,
  BPLUS_OR_DECILE,
  BPLUS_AND_DECILE,
  REST,
  NON_BPLUS_OR_DECILE,
} from "./constants";
import "../Funnel/FunnelContainer.css";
import ReactTooltip from "react-tooltip";

const TableOne = FunnelWrapper(FunnelTable);
const TableTwo = FunnelWrapper(FunnelTable);
const TableThird = FunnelWrapper(FunnelTable);
const TableForth = FunnelWrapper(FunnelTable);
const TableFifth = FunnelWrapper(FunnelTable);

function LoyalityTopCust({
  tableOneUrl,
  tableTwoUrl,
  tableThreeUrl,
  tableForthUrl,
  tableFifthUrl,
  showLevelTwoBoxes,
  showLevelThreeBoxes,
  hideLevelTwoBoxes,
  hideLevelThreeBoxes,
  levelTwoBoxes,
  levelThreeBoxes,
}) {
  return (
    <>
      <Row>
        <TableOne
          data={{
            url: tableOneUrl,
            header: ACTIVE_CUSTOMERS,
          }}
        />
        <div>
          {levelTwoBoxes ? (
            <>
              <div className="collapseArrowContainer">
                <span className="collapseArrow">
                  <FcCollapse
                    className="CollapseIconInfo"
                    data-tip
                    data-for="CollapseIcon"
                    style={{ cursor: "pointer" }}
                    onClick={hideLevelTwoBoxes}
                  />
                  <ReactTooltip
                    className="tooltip_css "
                    id="CollapseIcon"
                    place="top"
                    effect="float"
                    backgroundColor="#595959"
                  >
                    Collapse All
                  </ReactTooltip>
                </span>
              </div>
              <div className="funnel-arrow">
                <ImArrowDown />
                <ImArrowDown />
              </div>
            </>
          ) : (
            <div className="funnel-arrow">
              <ImArrowDown onClick={showLevelTwoBoxes} className="arrowDown" />
            </div>
          )}
        </div>
      </Row>
      {levelTwoBoxes && (
        <Row>
          <Col>
            <TableTwo
              data={{
                url: tableTwoUrl,
                header: BPLUS_OR_DECILE,
              }}
            />
            <div>
              {levelThreeBoxes ? (
                <>
                  <div className="collapseArrowContainer">
                    <span className="collapseArrow">
                      <FcCollapse
                        className="CollapseIconInfo"
                        data-tip
                        data-for="CollapseIcon"
                        style={{ cursor: "pointer" }}
                        onClick={hideLevelThreeBoxes}
                      />
                      <ReactTooltip
                        className="tooltip_css "
                        id="CollapseIcon"
                        place="top"
                        effect="float"
                        backgroundColor="#595959"
                      >
                        Collapse All
                      </ReactTooltip>
                    </span>
                  </div>
                  <ImArrowDown style={{ fontSize: "3rem" }} />
                </>
              ) : (
                <div className="funnel-arrow">
                  <ImArrowDown
                    onClick={showLevelThreeBoxes}
                    className="arrowDown"
                  />
                </div>
              )}
            </div>
          </Col>
          <Col>
            <TableThird
              data={{
                url: tableThreeUrl,
                header: NON_BPLUS_OR_DECILE,
              }}
            />
          </Col>
        </Row>
      )}
      {levelThreeBoxes && (
        <Row style={{ margin: "1rem", boxShadow: "0 0 10px" }}>
          <Col>
            <TableForth
              data={{
                url: tableForthUrl,
                header: BPLUS_AND_DECILE,
              }}
            />
          </Col>
          <Col>
            <TableFifth
              data={{
                url: tableFifthUrl,
                header: REST,
              }}
            />
          </Col>
        </Row>
      )}
    </>
  );
}

export default LoyalityTopCust;
