import React from "react";
import { Table } from "react-bootstrap";
import "../Funnel/FunnelContainer.css";
import LoaderForRow from "../LoaderForTable/LoaderForRow";
import { currencyFormat } from "../CdhHome/CdhHome";
import { decimalCurrencyFormat } from "../ScoreCard/Marketing";
import { ImArrowDown, ImArrowUp } from "react-icons/im";
import { gettooltip } from "../Utils";
import {
  STORE_DECILE,
  STORE_REST,
  OMNI_DECILE,
  OMNI_REST,
  ONLINE_DECILE,
  ONLINE_REST,
} from "./constants";

export default function FunnelTable({ ...props }) {
  const upArrow = <ImArrowUp style={{ color: "green" }} />;
  const downArrow = <ImArrowDown style={{ color: "red" }} />;
  return (
    <>
      <div className={"funnel-table"}>
        <Table
          style={{ width: "80%" }}
          funnel-table
          striped
          bordered
          hover
          size="sm"
        >
          <thead style={{ fontSize: "13px" }}>
            <th colSpan={4}>{props.header}</th>
          </thead>
          <tbody
            style={{
              fontSize: "12px",
              fontWeight: "bold",
            }}
          >
            {props.FunnelDataLoaded ? (
              <>
                <LoaderForRow tdCount={4} height={"170px"} />
              </>
            ) : props.FunnelData !== null &&
              props.FunnelData !== undefined &&
              props.FunnelData.length !== 0 ? (
              <>
                <tr>
                  <th className="textHeader">Customers</th>
                  <td>
                    {props.FunnelData[0].CUST_COUNT_TY === "-999999"
                      ? "-"
                      : currencyFormat(
                          Number(props.FunnelData[0].CUST_COUNT_TY)
                        )}
                  </td>
                  <td>
                    {props.FunnelData[0].CUST_COUNT_TY_VS_LY === "-999999"
                      ? ""
                      : props.FunnelData[0].CUST_COUNT_TY_VS_LY.includes("-")
                      ? downArrow
                      : upArrow}
                  </td>
                  <td>
                    {" "}
                    {props.FunnelData[0].CUST_COUNT_TY_VS_LY === "-999999"
                      ? "-"
                      : `${decimalCurrencyFormat(
                          props.FunnelData[0].CUST_COUNT_TY_VS_LY
                        )}%`}
                  </td>
                </tr>
                <tr>
                  <th className="textHeader">Transactions</th>
                  <td>
                    {props.FunnelData[0].TRANS_COUNT_TY === "-999999"
                      ? "-"
                      : currencyFormat(
                          Number(props.FunnelData[0].TRANS_COUNT_TY)
                        )}
                  </td>
                  <td>
                    {props.FunnelData[0].TRANS_COUNT_TY_VS_LY === "-999999"
                      ? ""
                      : props.FunnelData[0].TRANS_COUNT_TY_VS_LY.includes("-")
                      ? downArrow
                      : upArrow}
                  </td>
                  <td>
                    {props.FunnelData[0].TRANS_COUNT_TY_VS_LY === "-999999"
                      ? "-"
                      : `${decimalCurrencyFormat(
                          props.FunnelData[0].TRANS_COUNT_TY_VS_LY
                        )}%`}
                  </td>
                </tr>
                <tr>
                  <th className="textHeader">Net Sales per Customer</th>
                  <td>
                    {props.FunnelData[0].NET_SALES_PER_CUST_TY === "-999999"
                      ? "-"
                      : "$" +
                        currencyFormat(
                          Number(props.FunnelData[0].NET_SALES_PER_CUST_TY)
                        )}
                  </td>
                  <td>
                    {props.FunnelData[0].NET_SALES_PER_CUST_TY_VS_LY ===
                    "-999999"
                      ? ""
                      : props.FunnelData[0].NET_SALES_PER_CUST_TY_VS_LY.includes(
                          "-"
                        )
                      ? downArrow
                      : upArrow}
                  </td>
                  <td>
                    {props.FunnelData[0].NET_SALES_PER_CUST_TY_VS_LY ===
                    "-999999"
                      ? "-"
                      : `${decimalCurrencyFormat(
                          props.FunnelData[0].NET_SALES_PER_CUST_TY_VS_LY
                        )}%`}
                  </td>
                </tr>
                <tr>
                  <th className="textHeader">Margin per Customer</th>
                  <td>
                    {props.FunnelData[0].PM_PER_CUST_TY === "-999999"
                      ? "-"
                      : "$" +
                        currencyFormat(
                          Number(props.FunnelData[0].PM_PER_CUST_TY)
                        )}
                  </td>
                  <td>
                    {" "}
                    {props.FunnelData[0].PM_PER_CUST_TY_VS_LY === "-999999"
                      ? ""
                      : props.FunnelData[0].PM_PER_CUST_TY_VS_LY.includes("-")
                      ? downArrow
                      : upArrow}
                  </td>
                  <td>
                    {" "}
                    {props.FunnelData[0].PM_PER_CUST_TY_VS_LY === "-999999"
                      ? "-"
                      : `${decimalCurrencyFormat(
                          props.FunnelData[0].PM_PER_CUST_TY_VS_LY
                        )}%`}
                  </td>
                </tr>
                <tr>
                  <th className="textHeader">
                    Margin Rate %{" "}
                    {gettooltip(
                      "MarginRateInfoIcon",
                      "MarginRate",
                      "MarginRate",
                      "(Net Sales- Sales Cost)/Net Sales"
                    )}
                  </th>
                  <td>
                    {props.FunnelData[0].MARGIN_RATE_PER_TY === "-999999"
                      ? "-"
                      : Number(props.FunnelData[0].MARGIN_RATE_PER_TY).toFixed(
                          1
                        ) + "%"}
                  </td>
                  <td>
                    {" "}
                    {props.FunnelData[0].MARGIN_RATE_PER_TY_VS_LY === "-999999"
                      ? ""
                      : props.FunnelData[0].MARGIN_RATE_PER_TY_VS_LY.includes(
                          "-"
                        )
                      ? downArrow
                      : upArrow}
                  </td>
                  <td>
                    {" "}
                    {props.FunnelData[0].MARGIN_RATE_PER_TY_VS_LY === "-999999"
                      ? "-"
                      : `${decimalCurrencyFormat(
                          props.FunnelData[0].MARGIN_RATE_PER_TY_VS_LY
                        )}%`}
                  </td>
                </tr>
                {props.FunnelData[0].CRR_TY && (
                  <tr>
                    <th className="textHeader">
                      Customer Retention Rate{" "}
                      {gettooltip(
                        "CustomerRetentionRateInfoIcon",
                        "CustomerRetentionRate",
                        "CustomerRetentionRate",
                        "Number of customer active in L12M who were active in L15M to L12M /",
                        "Number of customer active in L15M to L12M"
                      )}
                    </th>
                    <td>
                      {props.FunnelData[0].CRR_TY === "-999999"
                        ? "-"
                        : Number(props.FunnelData[0].CRR_TY).toFixed(1) + "%"}
                    </td>
                    <td>
                      {" "}
                      {props.FunnelData[0].CRR_TY_VS_LY === "-999999"
                        ? ""
                        : props.FunnelData[0].CRR_TY_VS_LY.includes("-")
                        ? downArrow
                        : upArrow}
                    </td>
                    <td>
                      {props.FunnelData[0].CRR_TY_VS_LY === "-999999"
                        ? "-"
                        : `${decimalCurrencyFormat(
                            props.FunnelData[0].CRR_TY_VS_LY
                          )}%`}
                    </td>
                  </tr>
                )}
              </>
            ) : (
              <tr>
                <td align="center" colSpan="4">
                  DATA NOT AVAILABLE
                </td>
              </tr>
            )}
          </tbody>
        </Table>
      </div>
    </>
  );
}
