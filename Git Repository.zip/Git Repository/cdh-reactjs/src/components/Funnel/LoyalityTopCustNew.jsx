import React, { useState, useEffect } from "react";
import { Row, Col } from "react-bootstrap";
import { ImArrowDown } from "react-icons/im";
import FunnelTable from "./FunnelTable";
import FunnelWrapper from "./FunnelWrapper";
import { FcCollapse } from "react-icons/fc";
import {
  BsFillArrowLeftCircleFill,
  BsFillArrowRightCircleFill,
} from "react-icons/bs";

import ReactTooltip from "react-tooltip";
import "./FunnelContainer.css";
import {
  ACTIVE_CUSTOMERS,
  WELCOME_OR_DECILE,
  NON_WELCOME_OR_DECILE,
  WELCOMEPLUS_OR_DECILE,
  NON_WELCOMEPLUS_OR_DECILE,
  WELCOME_AND_DECILE,
  WELCOMEPLUS_AND_DECILE,
  REST,
} from "./constants";
import "../Funnel/FunnelContainer.css";

const WelcomeTableOne = FunnelWrapper(FunnelTable);
const WelcomeTableSLFirst = FunnelWrapper(FunnelTable);
const WelcomeTableSLSecond = FunnelWrapper(FunnelTable);
const WelcomeTableSLThird = FunnelWrapper(FunnelTable);
const WelcomeTableSLForth = FunnelWrapper(FunnelTable);
const WelcomeTableFifth = FunnelWrapper(FunnelTable);
const WelcomeTableSixth = FunnelWrapper(FunnelTable);
const WelcomeTableSeventh = FunnelWrapper(FunnelTable);
const WelcomeTableEight = FunnelWrapper(FunnelTable);

function LoyalityTopCustNew({
  welcomeTableOneUrl,
  welcomeTableTwoUrl,
  welcomeTableThreeUrl,
  welcomeTableForthUrl,
  welcomeTableFifthUrl,
  showWelcomeLevelTwoBoxes,
  hideWelcomeLevelTwoBoxes,
  welcomeLevelTwoBoxes,
  welcomeTableSixthUrl,
  welcomeTableSeventhUrl,
  showWelcomeLevelFourFirstHalfBoxes,
  welcomeLevelFourFirstHalfBoxes,
  hideWelcomeLevelThreeBoxes,
  showWelcomeLevelTwoFirstThreeBoxes,
  welcomeLevelTwoFirstThreeBoxes,
  showWelcomeLevelTwoSecondThreeBoxes,
  welcomeLevelTwoSecondThreeBoxes,
  welcomeTableEighthUrl,
  welcomeTableNinthUrl,
  welcomeLevelTLLastBoxes,
  showWelcomeLevelTLLastBoxes,
  hideWelcomeLevelTLLastBoxes,
}) {
  return (
    <>
      <Row>
        <WelcomeTableOne
          data={{
            url: welcomeTableOneUrl,
            header: ACTIVE_CUSTOMERS,
          }}
        />
        <div>
          {welcomeLevelTwoBoxes ? (
            <>
              <div className="collapseArrowContainer">
                <span className="collapseArrow">
                  <FcCollapse
                    className="CollapseIconInfo"
                    data-tip
                    data-for="CollapseIcon"
                    style={{ cursor: "pointer" }}
                    onClick={hideWelcomeLevelTwoBoxes}
                  />
                  <ReactTooltip
                    className="tooltip_css "
                    id="CollapseIcon"
                    place="top"
                    effect="float"
                    backgroundColor="#595959"
                  >
                    Collapse All
                  </ReactTooltip>
                </span>
              </div>
              <div className="funnel-arrow">
                <ImArrowDown />
                <ImArrowDown />
              </div>
            </>
          ) : (
            <div className="funnel-arrow">
              <ImArrowDown
                onClick={showWelcomeLevelTwoBoxes}
                className="arrowDown"
              />
            </div>
          )}
        </div>
      </Row>
      {welcomeLevelTwoBoxes && (
        <>
          {welcomeLevelTwoSecondThreeBoxes && (
            <div className="funnel-arrow-left">
              <BsFillArrowLeftCircleFill
                fill="grey"
                onClick={showWelcomeLevelTwoFirstThreeBoxes}
              />
            </div>
          )}
          <Row>
            {welcomeLevelTwoFirstThreeBoxes && (
              <>
                <Col>
                  <WelcomeTableSLFirst
                    data={{
                      url: welcomeTableTwoUrl,
                      header: WELCOME_OR_DECILE,
                    }}
                  />
                  <div className="funnel-arrow">
                    {welcomeLevelFourFirstHalfBoxes ? (
                      <>
                        <div className="collapseArrowContainer">
                          <span className="collapseArrow">
                            <FcCollapse
                              className="CollapseIconInfo"
                              data-tip
                              data-for="CollapseIcon"
                              style={{ cursor: "pointer" }}
                              onClick={hideWelcomeLevelThreeBoxes}
                            />
                            <ReactTooltip
                              className="tooltip_css "
                              id="CollapseIcon"
                              place="top"
                              effect="float"
                              backgroundColor="#595959"
                            >
                              Collapse All
                            </ReactTooltip>
                          </span>

                          <ImArrowDown style={{ fontSize: "3rem" }} />
                        </div>
                      </>
                    ) : (
                      <ImArrowDown
                        onClick={showWelcomeLevelFourFirstHalfBoxes}
                        className="arrowDown"
                      />
                    )}
                  </div>
                </Col>
                <Col>
                  <WelcomeTableSLSecond
                    data={{
                      url: welcomeTableThreeUrl,
                      header: NON_WELCOME_OR_DECILE,
                    }}
                  />
                </Col>
              </>
            )}
            {welcomeLevelTwoSecondThreeBoxes && (
              <>
                <Col>
                  <WelcomeTableSLThird
                    data={{
                      url: welcomeTableForthUrl,
                      header: WELCOMEPLUS_OR_DECILE,
                    }}
                  />
                  <div className="funnel-arrow">
                    {welcomeLevelTLLastBoxes ? (
                      <>
                        <div className="collapseArrowContainer">
                          <span className="collapseArrow">
                            <FcCollapse
                              className="CollapseIconInfo"
                              data-tip
                              data-for="CollapseIcon"
                              style={{ cursor: "pointer" }}
                              onClick={hideWelcomeLevelTLLastBoxes}
                            />
                            <ReactTooltip
                              className="tooltip_css "
                              id="CollapseIcon"
                              place="top"
                              effect="float"
                              backgroundColor="#595959"
                            >
                              Collapse All
                            </ReactTooltip>
                          </span>

                          <ImArrowDown style={{ fontSize: "3rem" }} />
                        </div>
                      </>
                    ) : (
                      <ImArrowDown
                        onClick={showWelcomeLevelTLLastBoxes}
                        className="arrowDown"
                      />
                    )}
                  </div>
                </Col>
                <Col>
                  <WelcomeTableSLForth
                    data={{
                      url: welcomeTableFifthUrl,
                      header: NON_WELCOMEPLUS_OR_DECILE,
                    }}
                  />
                </Col>
              </>
            )}
            <>
              {welcomeLevelTwoFirstThreeBoxes && (
                <div className="funnel-arrow-right">
                  <BsFillArrowRightCircleFill
                    fill="grey"
                    onClick={showWelcomeLevelTwoSecondThreeBoxes}
                  />
                </div>
              )}
            </>
          </Row>
        </>
      )}
      {welcomeLevelFourFirstHalfBoxes && (
        <Row style={{ margin: "1rem", boxShadow: "0 0 10px" }}>
          <Col>
            <WelcomeTableFifth
              data={{
                url: welcomeTableSixthUrl,
                header: WELCOME_AND_DECILE,
              }}
            />
          </Col>
          <Col>
            <WelcomeTableSixth
              data={{
                url: welcomeTableSeventhUrl,
                header: REST,
              }}
            />
          </Col>
        </Row>
      )}
      {welcomeLevelTLLastBoxes && (
        <Row style={{ margin: "1rem", boxShadow: "0 0 10px" }}>
          <Col>
            <WelcomeTableSeventh
              data={{
                url: welcomeTableEighthUrl,
                header: WELCOMEPLUS_AND_DECILE,
              }}
            />
          </Col>
          <Col>
            <WelcomeTableEight
              data={{
                url: welcomeTableNinthUrl,
                header: REST,
              }}
            />
          </Col>
        </Row>
      )}
    </>
  );
}

export default LoyalityTopCustNew;
