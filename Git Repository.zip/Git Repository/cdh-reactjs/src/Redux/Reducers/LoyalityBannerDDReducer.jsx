import { CHANGE_LOYALITY_BANNER_VALUE } from "../Constants/FilterConstants";
const initalState = {
  value: "BBBY US",
  id: "1",
};
const LoyalityBannerDDReducer = (state = initalState, action) => {
  switch (action.type) {
    case CHANGE_LOYALITY_BANNER_VALUE:
      return {
        ...state,
        value: action.payload.value,
        id: action.payload.id,
      };
    default:
      return { ...state };
  }
};
export default LoyalityBannerDDReducer;
