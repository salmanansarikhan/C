import { CHANGE_SCORECARD_YEAR_VALUE } from "../Constants/FilterConstants";
const initalState = {
  value: "",
  id: "",
};
const ScoreCardYearDDReducer = (state = initalState, action) => {
  switch (action.type) {
    case CHANGE_SCORECARD_YEAR_VALUE:
      return {
        ...state,
        value: action.payload.value,
        id: action.payload.id,
      };
    default:
      return { ...state };
  }
};
export default ScoreCardYearDDReducer;