import { CHANGE_DECILE_CATEGORY_VALUE } from "../Constants/FilterConstants";
const initalState = {
  value: "Net Sales",
  id: "NET",
};
const DecileCategoryDDReducer = (state = initalState, action) => {
  switch (action.type) {
    case CHANGE_DECILE_CATEGORY_VALUE:
      return {
        ...state,
        value: action.payload.value,
        id: action.payload.id,
      };
    default:
      return { ...state };
  }
};
export default DecileCategoryDDReducer;
