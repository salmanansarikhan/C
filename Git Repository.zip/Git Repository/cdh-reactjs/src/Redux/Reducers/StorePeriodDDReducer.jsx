import { CHANGE_STORE_PERIOD_VALUE } from "../Constants/FilterConstants";
const initalState = {
  value: "Yesterday",
  id: "0",
};
const StorePeriodDDReducer = (state = initalState, action) => {
  switch (action.type) {
    case CHANGE_STORE_PERIOD_VALUE:
      return {
        ...state,
        value: action.payload.value,
        id: action.payload.id,
      };
    default:
      return { ...state };
  }
};
export default StorePeriodDDReducer;
