import { CHANGE_FEEDBACK_CHANNEL_VALUE } from "../Constants/FilterConstants";
const initalState = {
  value: "All",
  id: "Online','Store','Call Center",
};
const FeedbackChannelDDReducer = (state = initalState, action) => {
  switch (action.type) {
    case CHANGE_FEEDBACK_CHANNEL_VALUE:
      return {
        ...state,
        value: action.payload.value,
        id: action.payload.id,
      };
    default:
      return { ...state };
  }
};
export default FeedbackChannelDDReducer;
