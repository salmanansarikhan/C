import { CHANGE_BANNER_VALUE } from "../Constants/FilterConstants";
const initalState = {
  value: "All Banner",
  id: "0",
};
const BannerDDReducer = (state = initalState, action) => {
  switch (action.type) {
    case CHANGE_BANNER_VALUE:
      return {
        ...state,
        value: action.payload.value,
        id: action.payload.id,
      };
    default:
      return { ...state };
  }
};
export default BannerDDReducer;
