import { CHANGE_CHANNEL_DATE_VALUE } from "../Constants/FilterConstants";
let dateObj = new Date();
dateObj.setUTCDate(dateObj.getUTCDate() - 2);
let day = dateObj.getUTCDate();
let year = dateObj.getUTCFullYear();
let month = dateObj.getUTCMonth() + 1; //months from 1-12
let YesterDay =
  year +
  "-" +
  (month < 10 ? `0${month}` : month) +
  "-" +
  (day < 10 ? `0${day}` : day);

const initalState = {
  value: YesterDay,
};
const ChannelDatePickerReducer = (state = initalState, action) => {
  switch (action.type) {
    case CHANGE_CHANNEL_DATE_VALUE:
      return {
        ...state,
        value: action.payload,
      };
    default:
      return { ...state };
  }
};
export default ChannelDatePickerReducer;
