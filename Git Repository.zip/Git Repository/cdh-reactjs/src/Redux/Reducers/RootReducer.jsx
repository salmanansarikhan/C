import BannerDDReducer from "./BannerDDReducer";
import CategoryCBReducer from "./CategoryCBReducer";
import DatePickerReducer from "./DatePickerReducer";
import DecileBannerDDReducer from "./DecileBannerDDReducer";
import DecileCategoryDDReducer from "./DecileCategoryDDReducer";
import DecileDatePickerReducer from "./DecileDatePickerReducer";
import ChannelBannerDDReducer from "./ChannelBannerDDReducer";
import ChannelCategoryCBReducer from "./ChannelCategoryCBReducer";
import ChannelDatePickerReducer from "./ChannelDatePickerReducer";
import ProgramBannerDDReducer from "./ProgramBannerDDReducer";
import ProgramCategoryCBReducer from "./ProgramCategoryCBReducer";
import ProgramDatePickerReducer from "./ProgramDatePickerReducer";
import ChannelCustCBReducer from "./ChannelCustCBReducer";
import ScoreCardBannerDDReducer from "./ScoreCardBannerDDReducer";
import ScoreCardPeriodDDReducer from "./ScoreCardPeriodDDReducer";
import ScoreCardYearDDReducer from "./ScoreCardYearDDReducer";
import LoyalityPeriodDDReducer from "./LoyalityPeriodDDReducer";
import LoyalityBannerDDReducer from "./LoyalityBannerDDReducer";
import LoyalityCustCBReducer from "./LoyalityCustCBReducer";
import LoyalityChannelDDReducer from "./LoyalityChannelDDReducer";
import FunnelBannerDDReducer from "./FunnelBannerDDReducer";
import FunnelDatePickerReducer from "./FunnelDatePickerReducer";
import FunnelTypeDDReducer from "./FunnelTypeDDReducer";
import MarketingBannerDDReducer from "./MarketingBannerDDReducer";
import MarketingCategoryCBReducer from "./MarketingCategoryCBReducer";
import MarketingDatePickerReducer from "./MarketingDatePickerReducer";
import StoreBannerDDReducer from "./StoreBannerDDReducer";
import StoreCategoryDDReducer from "./StoreCategoryDDReducer";
import StorePeriodDDReducer from "./StorePeriodDDReducer";
import FeedbackPeriodDDReducer from "./FeedbackPeriodDDReducer";
import FeedbackBannerDDReducer from "./FeedbackBannerDDReducer";
import FeedbackJourneyDDReducer from "./FeedbackJourneyDDReducer";
import FeedbackRegionDDReducer from "./FeedbackRegionDDReducer";
import FeedbackStoreDDReducer from "./FeedbackStoreDDReducer";
import FeedbackDistrictDDReducer from "./FeedbackDistrictDDReducer";
import FeedbackSelectedStoreReducer from "./FeedbackSelectedStoreReducer";
import FeedbackChannelDDReducer from "./FeedbackChannelDDReducer";
import FeedbackSelectedChannelReducer from "./FeedbackSelectedChannelReducer";
import CustomerFileBannerDDReducer from "./CustomerFileBannerDDReducer";
import CustomerFilePeriodDDReducer from "./CustomerFilePeriodDDReducer";

import { combineReducers } from "redux";

const RootReducer = combineReducers({
  Banner: BannerDDReducer,
  Category: CategoryCBReducer,
  Date: DatePickerReducer,
  DecileBanner: DecileBannerDDReducer,
  DecileCategory: DecileCategoryDDReducer,
  DecileDate: DecileDatePickerReducer,
  ChannelBanner: ChannelBannerDDReducer,
  ChannelCategory: ChannelCategoryCBReducer,
  ChannelDate: ChannelDatePickerReducer,
  ChannelCust: ChannelCustCBReducer,
  ProgramBanner: ProgramBannerDDReducer,
  ProgramCategory: ProgramCategoryCBReducer,
  ProgramDate: ProgramDatePickerReducer,
  ScoreCardBanner: ScoreCardBannerDDReducer,
  ScoreCardPeriod: ScoreCardPeriodDDReducer,
  ScoreCardYear: ScoreCardYearDDReducer,
  LoyalityPeriod: LoyalityPeriodDDReducer,
  LoyalityBanner: LoyalityBannerDDReducer,
  LoyalityCust: LoyalityCustCBReducer,
  LoyalityChannel: LoyalityChannelDDReducer,
  FunnelBanner: FunnelBannerDDReducer,
  FunnelDate: FunnelDatePickerReducer,
  FunnelType: FunnelTypeDDReducer,
  MarketingBanner: MarketingBannerDDReducer,
  MarketingCategory: MarketingCategoryCBReducer,
  MarketingDate: MarketingDatePickerReducer,
  StoreBanner: StoreBannerDDReducer,
  StoreCategory: StoreCategoryDDReducer,
  StorePeriod: StorePeriodDDReducer,
  FeedbackPeriod: FeedbackPeriodDDReducer,
  FeedbackBanner: FeedbackBannerDDReducer,
  FeedbackJourney: FeedbackJourneyDDReducer,
  FeedbackRegion: FeedbackRegionDDReducer,
  FeedbackStore: FeedbackStoreDDReducer,
  FeedbackDistrict: FeedbackDistrictDDReducer,
  FeedbackSelectedStoreId: FeedbackSelectedStoreReducer,
  FeedbackChannelTypeId: FeedbackChannelDDReducer,
  FeedbackSelectedChannel: FeedbackSelectedChannelReducer,
  CustomerFileBanner: CustomerFileBannerDDReducer,
  CustomerFilePeriod: CustomerFilePeriodDDReducer,
});

export default RootReducer;
