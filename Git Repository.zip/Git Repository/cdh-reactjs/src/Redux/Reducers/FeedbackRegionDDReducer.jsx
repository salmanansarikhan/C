import { CHANGE_FEEDBACK_REGION_VALUE } from "../Constants/FilterConstants";
const initalState = {
  value: "(Select)",
  id: "(Select)",
};
const FeedbackRegionDDReducer = (state = initalState, action) => {
  switch (action.type) {
    case CHANGE_FEEDBACK_REGION_VALUE:
      return {
        ...state,
        value: action.payload.value,
        id: action.payload.id,
      };
    default:
      return { ...state };
  }
};
export default FeedbackRegionDDReducer;
