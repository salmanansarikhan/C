import { CHANGE_LOYALITY_CUST_VALUE } from "../Constants/FilterConstants";
const initalState = {
  value: "Beyond+",
  id: "BPLUS",
};
const LoyalityCustCBReducer = (state = initalState, action) => {
  switch (action.type) {
    case CHANGE_LOYALITY_CUST_VALUE:
      return {
        ...state,
        value: action.payload.value,
        id: action.payload.id,
      };
    default:
      return { ...state };
  }
};
export default LoyalityCustCBReducer;
