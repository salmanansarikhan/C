import { CHANGE_FEEDBACK_BANNER_VALUE } from "../Constants/FilterConstants";
const initalState = {
  value: "All Banner",
  id: "0,1,2,3,5",
};
const FeedbackBannerDDReducer = (state = initalState, action) => {
  switch (action.type) {
    case CHANGE_FEEDBACK_BANNER_VALUE:
      return {
        ...state,
        value: action.payload.value,
        id: action.payload.id,
      };
    default:
      return { ...state };
  }
};
export default FeedbackBannerDDReducer;
