import { CHANGE_FEEDBACK_DISTRICT_VALUE } from "../Constants/FilterConstants";
const initalState = {
  value: "(Select)",
  id: "(Select)",
};
const FeedbackDistrictDDReducer = (state = initalState, action) => {
  switch (action.type) {
    case CHANGE_FEEDBACK_DISTRICT_VALUE:
      return {
        ...state,
        value: action.payload.value,
        id: action.payload.id,
      };
    default:
      return { ...state };
  }
};
export default FeedbackDistrictDDReducer;
