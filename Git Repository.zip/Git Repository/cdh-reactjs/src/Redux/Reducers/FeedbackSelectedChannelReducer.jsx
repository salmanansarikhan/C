import { CHANGE_FEEDBACK_CHANNEL_ID } from "../Constants/FilterConstants";
const initalState = {
  value: "",
  id: "",
};
const FeedbackSelectedChannelReducer = (state = initalState, action) => {
  switch (action.type) {
    case CHANGE_FEEDBACK_CHANNEL_ID:
      return {
        ...state,
        value: action.payload.value,
        id: action.payload.id,
      };
    default:
      return { ...state };
  }
};
export default FeedbackSelectedChannelReducer;
