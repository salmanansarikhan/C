import { CHANGE_FEEDBACK_JOURNEY_VALUE } from "../Constants/FilterConstants";
const initalState = {
  value: "",
  id: "",
};
const FeedbackJourneyDDReducer = (state = initalState, action) => {
  switch (action.type) {
    case CHANGE_FEEDBACK_JOURNEY_VALUE:
      return {
        ...state,
        value: action.payload.value,
        id: action.payload.id,
      };
    default:
      return { ...state };
  }
};
export default FeedbackJourneyDDReducer;
