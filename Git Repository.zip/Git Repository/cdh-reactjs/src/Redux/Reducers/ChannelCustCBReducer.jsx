import { CHANGE_CHANNEL_CUST_VALUE } from "../Constants/FilterConstants";
const initalState = {
  value: "ALL",
  id: "ALL",
};
const ChannelCustCBReducer = (state = initalState, action) => {
  switch (action.type) {
    case CHANGE_CHANNEL_CUST_VALUE:
      return {
        ...state,
        value: action.payload.value,
        id: action.payload.id,
      };
    default:
      return { ...state };
  }
};
export default ChannelCustCBReducer;
