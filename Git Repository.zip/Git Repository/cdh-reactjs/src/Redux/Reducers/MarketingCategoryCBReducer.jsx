import { CHANGE_MARKETING_CATEGORY_VALUE } from "../Constants/FilterConstants";
const initalState = {
  value: "DM",
  id: "DM",
};
const MarketingCategoryCBReducer = (state = initalState, action) => {
  switch (action.type) {
    case CHANGE_MARKETING_CATEGORY_VALUE:
      return {
        ...state,
        value: action.payload.value,
        id: action.payload.id,
      };
    default:
      return { ...state };
  }
};
export default MarketingCategoryCBReducer;
