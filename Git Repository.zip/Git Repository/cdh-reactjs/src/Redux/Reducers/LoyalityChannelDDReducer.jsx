import { CHANGE_LOYALITY_CHANNEL_VALUE } from "../Constants/FilterConstants";
const initalState = {
  value: "Store",
  id: "1",
};
const LoyalityChannelDDReducer = (state = initalState, action) => {
  switch (action.type) {
    case CHANGE_LOYALITY_CHANNEL_VALUE:
      return {
        ...state,
        value: action.payload.value,
        id: action.payload.id,
      };
    default:
      return { ...state };
  }
};
export default LoyalityChannelDDReducer;
