import { CHANGE_FEEDBACK_STORE_ID } from "../Constants/FilterConstants";
const initalState = {
  value: "",
  id: "",
};
const FeedbackSelectedStoreReducer = (state = initalState, action) => {
  switch (action.type) {
    case CHANGE_FEEDBACK_STORE_ID:
      return {
        ...state,
        value: action.payload.value,
        id: action.payload.id,
      };
    default:
      return { ...state };
  }
};
export default FeedbackSelectedStoreReducer;
