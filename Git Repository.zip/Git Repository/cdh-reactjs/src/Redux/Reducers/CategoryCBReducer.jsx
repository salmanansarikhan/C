import { CHANGE_CATEGORY_VALUE } from "../Constants/FilterConstants";
const initalState = {
  value: "All Customers",
  id: "ALL",
};
const CategoryCBReducer = (state = initalState, action) => {
  switch (action.type) {
    case CHANGE_CATEGORY_VALUE:
      return {
        ...state,
        value: action.payload.value,
        id: action.payload.id,
      };
    default:
      return { ...state };
  }
};
export default CategoryCBReducer;
