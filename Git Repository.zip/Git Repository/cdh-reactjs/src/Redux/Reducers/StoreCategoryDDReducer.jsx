import { CHANGE_STORE_CATEGORY_VALUE } from "../Constants/FilterConstants";
const initalState = {
  value: "Stores with more than (custom) sign ups",
  id: "1",
};
const StoreCategoryDDReducer = (state = initalState, action) => {
  switch (action.type) {
    case CHANGE_STORE_CATEGORY_VALUE:
      return {
        ...state,
        value: action.payload.value,
        id: action.payload.id,
      };
    default:
      return { ...state };
  }
};
export default StoreCategoryDDReducer;
