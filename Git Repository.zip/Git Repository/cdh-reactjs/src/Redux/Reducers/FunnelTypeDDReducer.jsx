import { CHANGE_FUNNEL_TYPE_VALUE } from "../Constants/FilterConstants";
const initalState = {
  value: "Loyalty and Top Cust New",
  id: "0",
};
const FunnelTypeDDReducer = (state = initalState, action) => {
  switch (action.type) {
    case CHANGE_FUNNEL_TYPE_VALUE:
      return {
        ...state,
        value: action.payload.value,
        id: action.payload.id,
      };
    default:
      return { ...state };
  }
};
export default FunnelTypeDDReducer;
