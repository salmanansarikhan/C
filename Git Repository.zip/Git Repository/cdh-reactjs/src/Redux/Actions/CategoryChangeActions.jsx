import {
  CHANGE_CATEGORY_VALUE,
  CHANGE_DECILE_CATEGORY_VALUE,
  CHANGE_CHANNEL_CATEGORY_VALUE,
  CHANGE_PROGRAM_CATEGORY_VALUE,
  CHANGE_CHANNEL_CUST_VALUE,
  CHANGE_LOYALITY_CUST_VALUE,
  CHANGE_LOYALITY_CHANNEL_VALUE,
  CHANGE_FUNNEL_TYPE_VALUE,
  CHANGE_MARKETING_CATEGORY_VALUE,
  CHANGE_STORE_CATEGORY_VALUE,
  CHANGE_FEEDBACK_CHANNEL_VALUE,
} from "../Constants/FilterConstants";
export const handleCategoryChange = (value) => {
  return {
    type: CHANGE_CATEGORY_VALUE,
    payload: value,
  };
};
export const handleDecilesCategoryChange = (value) => {
  return {
    type: CHANGE_DECILE_CATEGORY_VALUE,
    payload: value,
  };
};
export const handleChannelCategoryChange = (value) => {
  return {
    type: CHANGE_CHANNEL_CATEGORY_VALUE,
    payload: value,
  };
};
export const handleProgramCategoryChange = (value) => {
  return {
    type: CHANGE_PROGRAM_CATEGORY_VALUE,
    payload: value,
  };
};
export const handleChannelCustChange = (value) => {
  return {
    type: CHANGE_CHANNEL_CUST_VALUE,
    payload: value,
  };
};
export const handleLoyalityCustChange = (value) => {
  return {
    type: CHANGE_LOYALITY_CUST_VALUE,
    payload: value,
  };
};
export const handleLoyalityChannelChange = (value) => {
  return {
    type: CHANGE_LOYALITY_CHANNEL_VALUE,
    payload: value,
  };
};
export const handleFunnelTypeChange = (value) => {
  return {
    type: CHANGE_FUNNEL_TYPE_VALUE,
    payload: value,
  };
};
export const handleMarketingCategoryChange = (value) => {
  return {
    type: CHANGE_MARKETING_CATEGORY_VALUE,
    payload: value,
  };
};
export const handleStoreCategoryChange = (value) => {
  return {
    type: CHANGE_STORE_CATEGORY_VALUE,
    payload: value,
  };
};

export const handleFeedbackChannelTypeChange = (value) => {
  return {
    type: CHANGE_FEEDBACK_CHANNEL_VALUE,
    payload: value,
  };
};
