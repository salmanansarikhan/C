import { CHANGE_STORE_PERIOD_VALUE } from "../Constants/FilterConstants";
export const handleStorePeriodChange = (value) => {
  return {
    type: CHANGE_STORE_PERIOD_VALUE,
    payload: value,
  };
};
