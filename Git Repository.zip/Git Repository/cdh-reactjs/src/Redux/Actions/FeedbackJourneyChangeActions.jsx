import { CHANGE_FEEDBACK_JOURNEY_VALUE, CHANGE_FEEDBACK_STORE_ID, CHANGE_FEEDBACK_CHANNEL_ID } from "../Constants/FilterConstants";
export const handleFeedbackJourneyChange = (value) => {
  return {
    type: CHANGE_FEEDBACK_JOURNEY_VALUE,
    payload: value,
  };
};

//selected store id - onclick of Journey
export const handleFeedbackSelectedStoreId = (value) => {
  return {
    type: CHANGE_FEEDBACK_STORE_ID,
    payload: value,
  };
};
export const handleFeedbackSelectedChannelId = (value) => {
  return {
    type: CHANGE_FEEDBACK_CHANNEL_ID,
    payload: value,
  };
};



