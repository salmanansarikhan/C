import { CHANGE_FEEDBACK_PERIOD_VALUE } from "../Constants/FilterConstants";
export const handleFeedbackPeriodChange = (value) => {
  return {
    type: CHANGE_FEEDBACK_PERIOD_VALUE,
    payload: value,
  };
};
