import { CHANGE_CUSTOMER_FILE_PERIOD_VALUE } from "../Constants/FilterConstants";

export const handleCustomerFilePeriodChange = (value) => {
  return {
    type: CHANGE_CUSTOMER_FILE_PERIOD_VALUE,
    payload: value,
  };
};
