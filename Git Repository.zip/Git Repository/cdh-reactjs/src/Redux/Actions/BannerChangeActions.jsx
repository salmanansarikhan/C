import {
  CHANGE_BANNER_VALUE,
  CHANGE_DECILE_BANNER_VALUE,
  CHANGE_CHANNEL_BANNER_VALUE,
  CHANGE_PROGRAM_BANNER_VALUE,
  CHANGE_SCORECARD_BANNER_VALUE,
  CHANGE_LOYALITY_BANNER_VALUE,
  CHANGE_FUNNEL_BANNER_VALUE,
  CHANGE_MARKETING_BANNER_VALUE,
  CHANGE_STORE_BANNER_VALUE,
  CHANGE_FEEDBACK_BANNER_VALUE,
  CHANGE_CUSTOMER_FILE_BANNER_VALUE,
} from "../Constants/FilterConstants";
export const handleBannerChange = (value) => {
  return {
    type: CHANGE_BANNER_VALUE,
    payload: value,
  };
};
export const handleDecilesBannerChange = (value) => {
  return {
    type: CHANGE_DECILE_BANNER_VALUE,
    payload: value,
  };
};
export const handleChannelBannerChange = (value) => {
  return {
    type: CHANGE_CHANNEL_BANNER_VALUE,
    payload: value,
  };
};

export const handleProgramBannerChange = (value) => {
  return {
    type: CHANGE_PROGRAM_BANNER_VALUE,
    payload: value,
  };
};

export const handleScoreCardBannerChange = (value) => {
  return {
    type: CHANGE_SCORECARD_BANNER_VALUE,
    payload: value,
  };
};

export const handleLoyalityBannerChange = (value) => {
  return {
    type: CHANGE_LOYALITY_BANNER_VALUE,
    payload: value,
  };
};

export const handleFunnelBannerChange = (value) => {
  return {
    type: CHANGE_FUNNEL_BANNER_VALUE,
    payload: value,
  };
};

export const handleMarketingBannerChange = (value) => {
  return {
    type: CHANGE_MARKETING_BANNER_VALUE,
    payload: value,
  };
};

export const handleStoreBannerChange = (value) => {
  return {
    type: CHANGE_STORE_BANNER_VALUE,
    payload: value,
  };
};

export const handleFeedbackBannerChange = (value) => {
  return {
    type: CHANGE_FEEDBACK_BANNER_VALUE,
    payload: value,
  };
};

export const handleCustomerFileBannerChange = (value) => {
  return {
    type: CHANGE_CUSTOMER_FILE_BANNER_VALUE,
    payload: value,
  };
};
