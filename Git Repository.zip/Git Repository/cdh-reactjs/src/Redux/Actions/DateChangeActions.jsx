import {
  CHANGE_DATE_VALUE,
  CHANGE_DECILE_DATE_VALUE,
  CHANGE_CHANNEL_DATE_VALUE,
  CHANGE_PROGRAM_DATE_VALUE,
  CHANGE_FUNNEL_DATE_VALUE,
  CHANGE_MARKETING_DATE_VALUE,
} from "../Constants/FilterConstants";
export const handleDateChange = (value) => {
  return {
    type: CHANGE_DATE_VALUE,
    payload: value,
  };
};
export const handleDecilesDateChange = (value) => {
  return {
    type: CHANGE_DECILE_DATE_VALUE,
    payload: value,
  };
};
export const handleChannelDateChange = (value) => {
  return {
    type: CHANGE_CHANNEL_DATE_VALUE,
    payload: value,
  };
};
export const handleProgramDateChange = (value) => {
  return {
    type: CHANGE_PROGRAM_DATE_VALUE,
    payload: value,
  };
};
export const handleFunnelDateChange = (value) => {
  return {
    type: CHANGE_FUNNEL_DATE_VALUE,
    payload: value,
  };
};
export const handleMarketingDateChange = (value) => {
  return {
    type: CHANGE_MARKETING_DATE_VALUE,
    payload: value,
  };
};
