import { CHANGE_SCORECARD_PERIOD_VALUE, CHANGE_SCORECARD_YEAR_VALUE } from "../Constants/FilterConstants";
export const handleScoreCardPeriodChange = (value) => {
  return {
    type: CHANGE_SCORECARD_PERIOD_VALUE,
    payload: value,
  };
};

export const handleScoreCardYearChange = (value) => {
    return {
      type: CHANGE_SCORECARD_YEAR_VALUE,
      payload: value,
    };
  };


