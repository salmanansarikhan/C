import {
  CHANGE_FEEDBACK_REGION_VALUE,
  CHANGE_FEEDBACK_STORE_VALUE,
  CHANGE_FEEDBACK_DISTRICT_VALUE,
} from "../Constants/FilterConstants";

export const handleFeedbackRegionChange = (value) => {
  return {
    type: CHANGE_FEEDBACK_REGION_VALUE,
    payload: value,
  };
};

export const handleFeedbackStoreChange = (value) => {
  return {
    type: CHANGE_FEEDBACK_STORE_VALUE,
    payload: value,
  };
};
export const handleFeedbackDistrictChange = (value) => {
  return {
    type: CHANGE_FEEDBACK_DISTRICT_VALUE,
    payload: value,
  };
};
