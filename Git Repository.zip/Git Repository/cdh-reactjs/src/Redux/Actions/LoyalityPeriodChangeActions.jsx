import { CHANGE_LOYALITY_PERIOD_VALUE } from "../Constants/FilterConstants";
export const handleLoyalityPeriodChange = (value) => {
  return {
    type: CHANGE_LOYALITY_PERIOD_VALUE,
    payload: value,
  };
};
