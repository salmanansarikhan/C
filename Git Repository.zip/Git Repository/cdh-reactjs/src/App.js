import "./App.css";
import HomePage from "./components/HomePage/HomePage";
import Login from "./components/Login/Login";
import { Route, Switch, Redirect } from "react-router-dom";
import NewCustomers from "./components/NewCustomers/NewCustomers";
import Header from "./components/Header/Header";
import Footer from "./components/Footer/Footer";
import DecilesContainer from "./components/Deciles/DecilesContainer";
import ChannelContainer from "./components/Channel/ChannelContainer";
import ProgramContainer from "./components/Program/ProgramContainer";
import ScoreCardContainer from "./components/ScoreCard/ScoreCardContainer";
import LoyalityContainer from "./components/Loyality/LoyalityContainer";
import FunnelContainer from "./components/Funnel/FunnelContainer";
import MarketingContainer from "./components/Marketing/MarketingContainer";
import StoresContainer from "./components/Store/StoreContainer";
import FeedbackContainer from "./components/Feedback/FeedbackContainer";
import CustomerFileContainer from "./components/CustomerFileHealth/CustomerFileContaner";
// import AtRiskTable from "./components/AtRiskTable/AtRiskTable";
// import AtRiskTable_9_12 from "./components/AtRiskTable_9_12/AtRiskTable_9_12";
function App() {
  const isLoggedIn = localStorage.getItem("isLoggedIn");
  return (
    <div className="App">
      <Switch>
        {/* <Route exact path="/cdh" component={Login} /> */}
        <Route exact path="/cdh/">
          {isLoggedIn === "" ||
          isLoggedIn === undefined ||
          isLoggedIn === null ||
          isLoggedIn !== "true" ? (
            <Login />
          ) : (
            <Redirect to="/cdh/home" />
          )}
        </Route>

        <Route exact path="/cdh/home">
          {isLoggedIn === "" ||
          isLoggedIn === undefined ||
          isLoggedIn === null ||
          isLoggedIn !== "true" ? (
            <Redirect to="/cdh/" />
          ) : (<><Header />
            <HomePage />
            <Footer /></>
          )}
        </Route>

        <Route path="/cdh/Marketing/Returning_Customers">
          <NewCustomers />
        </Route>
        <Route exact path="/cdh/deciles">
          <Header />
          <DecilesContainer />
          <Footer />
        </Route>
        <Route exact path="/cdh/channel">
          <Header />
          <ChannelContainer />
          <Footer />
        </Route>
        <Route exact path="/cdh/program">
          <Header />
          <ProgramContainer />
          <Footer />
        </Route>
        <Route exact path="/cdh/marketing">
          <Header />
          <MarketingContainer />
          <Footer />
        </Route>
        <Route exact path="/cdh/scorecard">
          <Header />
          <ScoreCardContainer />
          <Footer />
        </Route>
        <Route exact path="/cdh/loyalty">
          <Header />
          <LoyalityContainer />
          <Footer />
        </Route>
        <Route exact path="/cdh/funnel">
          <Header />
          <FunnelContainer/>
          <Footer />
        </Route>
        <Route exact path="/cdh/stores">
          <Header />
          <StoresContainer/>
          <Footer />
        </Route>
        <Route exact path="/cdh/feedback">
          <Header />
          <FeedbackContainer/>
          <Footer />
        </Route>
        <Route exact path="/cdh/customerfilehealth">
          <Header />
          <CustomerFileContainer />
          <Footer />
        </Route>
        <Route
          path="/cdh*"
          render={() => <Redirect to={{ pathname: "/cdh/" }} />}
        />
      </Switch>
    </div>
  );
}

export default App;
